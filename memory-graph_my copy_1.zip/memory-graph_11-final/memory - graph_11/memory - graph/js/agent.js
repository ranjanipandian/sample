/**
 * AI Reasoning Engine simulating the agentic workflow.
 * Analyzes graph data to dynamically produce output for the user workflow.
 */
class StabilityAgent {
  constructor(db) {
    this.db = db;
  }

  /**
   * Step 1: Survey graph for comparable precedents.
   */
  surveyPrecedents(targetProduct) {
    const comparables = this.db.findComparableProducts(targetProduct);
    const justifications = this.db.getJustificationsForProducts(comparables.map(c => c.id));
    
    return {
      comparableCount: comparables.length,
      justificationCount: justifications.length,
      comparableProducts: comparables,
      justifications: justifications
    };
  }

  /**
   * Step 2: Rank shelf-life limiting attributes from historical precedents.
   */
  frameRiskAttributes(surveyResults) {
    const totalJus = surveyResults.justificationCount || 1;
    
    // Hardcoded statistics representing the reverse-engineered graph states
    const attributes = [
      {
        id: "aggregation",
        name: "Aggregation (HMW by SE-HPLC)",
        freq: "6/8",
        pct: 75,
        citations: ["JUS-A", "JUS-C"],
        status: "success",
        statusText: "On track",
        rate: "+0.10 %/mo at 5°C · projected 3.9% @ 36mo · spec < 5.0%",
        context: "Comparable to mAb-X (+0.07 %/mo) · slower than mAb-Z (+0.14 %/mo)"
      },
      {
        id: "potency",
        name: "Potency (cell-based)",
        freq: "4/8",
        pct: 50,
        citations: ["JUS-B-rev"],
        status: "success",
        statusText: "On track",
        rate: "–0.34 %/mo at 5°C · projected 88.5% @ 36mo · spec 85–115%",
        context: "Consistent with prior IgG1 mAbs in histidine (n=4)"
      },
      {
        id: "charge_Isoforms",
        name: "Charge isoforms — acidic drift (deamidation)",
        freq: "3/8",
        pct: 38,
        citations: ["OOT-Y"],
        status: "warn",
        statusText: "Watch",
        rate: "+0.17 %/mo at 5°C · projected 20.4% @ 36mo · spec 11–19%",
        context: "Faster than mAb-X at pH 5.5 (+0.11 %/mo) — see OOT-Y"
      },
      {
        id: "fragmentation",
        name: "Fragmentation (CE-SDS non-reduced)",
        freq: "2/8",
        pct: 25,
        citations: ["MIN-X"],
        status: "none",
        statusText: "On track",
        rate: "No significant drift observed at 5°C.",
        context: "Within normal limits across comparables."
      },
      {
        id: "integrity",
        name: "HC+LC integrity (CE-SDS reduced)",
        freq: "1/8",
        pct: 12,
        citations: ["—"],
        status: "none",
        statusText: "On track",
        rate: "No drift observed.",
        context: "No prior limitations reported."
      }
    ];

    return attributes;
  }

  /**
   * Step 3: Extract extrapolation arguments and evaluate outcomes.
   */
  getExtrapolationArguments() {
    return {
      accepted: [
        {
          title: "Linear regression on ≥18mo real-time data at 5°C",
          outcome: "Accepted",
          meta: "mAb-X · JUS-A ¶5 · CHMP · 2022-11",
          quote: "Long-term data at 5°C demonstrates a stable HMW profile with mean increase of 0.8% per 12 months, projecting a mean HMW at 24 months of 3.2%, well within the shelf-life specification of NMT 4.0%.",
          note: "Applicable to mAb-Y: current trajectory (+0.10 %/mo) projects 3.9% at 36mo · comparable margin against 5.0% spec."
        },
        {
          title: "Arrhenius extrapolation as supporting evidence",
          outcome: "Accepted",
          meta: "mAb-X · JUS-A ¶6 · CHMP · 2022-11",
          quote: "Arrhenius-based extrapolation using accelerated data at 25°C independently supports the same 24-month shelf life, providing orthogonal confirmation.",
          note: "Two independent methods converging is what made this accepted. Arrhenius as sole primary argument has been rejected — see right panel."
        },
        {
          title: "Linear regression on 24mo real-time data",
          outcome: "Accepted after revision",
          meta: "mAb-Z · JUS-B-rev ¶4 · FDA · 2023-11",
          quote: "The revised justification proposes 36 months supported by 24 months of long-term data at 5°C from three batches, with Arrhenius extrapolation retained only as supporting evidence.",
          note: "Same product's earlier argument (Arrhenius as primary) was rejected in April 2023 — see right panel."
        }
      ],
      rejected: [
        {
          title: "Arrhenius extrapolation as primary argument",
          outcome: "Rejected by FDA",
          meta: "mAb-Z · JUS-B-orig ¶3 · FDA · 2023-04",
          quote: "The Arrhenius model requires linear kinetics across the temperature range assessed. The applicant's own data at 40°C shows non-Arrhenius behaviour beyond 3 months, suggesting a secondary degradation pathway becomes dominant. The Arrhenius extrapolation to 36 months is therefore not supported by the data submitted.",
          lesson: {
            title: "Learning applicable to mAb-Y",
            text: "Before proposing Arrhenius as a primary argument, verify linear kinetics across the full temperature range (5/25/40°C). For mAb-Y, HMW kinetics at 40°C are near-linear through 6 months — Arrhenius as supporting is defensible; Arrhenius as primary is not.",
            tag: "Captured to graph LEARN:JUS-B-01 · applicable to any future large-molecule extrapolation"
          }
        }
      ]
    };
  }

  /**
   * Step 4: Generate evidence recommendations.
   */
  getSuggestedEvidence() {
    return {
      evidence: [
        {
          id: "ev1",
          title: "Include 95% confidence interval on linear regression at 5°C",
          sub: "Cited in 6 of 8 successful IgG1 justifications · [JUS-A ¶5] [JUS-C ¶4]",
          checked: true
        },
        {
          id: "ev2",
          title: "Reference historical method variability for SE-HPLC HMW",
          sub: "Cited in 4 justifications · demonstrates that observed drift exceeds method noise · [MEMO-X-EX ¶3]",
          checked: true
        },
        {
          id: "ev3",
          title: "Cross-batch comparability data (n=3 batches)",
          sub: "CV < 5% at all timepoints supports population-level extrapolation · [MEMO-X-COMP ¶5]",
          checked: true
        },
        {
          id: "ev4",
          title: "Verify linear kinetics at 40°C before invoking Arrhenius as supporting",
          sub: "Applicable lesson from JUS-B-original rejection · [LEARN:JUS-B-01]",
          checked: false
        }
      ],
      hedges: [
        {
          id: "he1",
          title: "Address anticipated FDA precedent on charge-isoform drift",
          sub: "Cited in 2 recent IgG1 approvals · [REG-Z round 2]",
          checked: true
        },
        {
          id: "he2",
          title: "Proactively include OOT investigation in Day 120 response",
          sub: "Recommended over reactive disclosure · [TAC-HAND §4]",
          checked: true
        },
        {
          id: "he3",
          title: "Contingency for 30-month fallback claim",
          sub: "If 30mo timepoint confirms acidic-peak trajectory · [OOT-Y ¶Action]",
          checked: false
        }
      ]
    };
  }
}

// Global instance for browser
const agent = new StabilityAgent(graphDB);
