/**
 * Simple in-memory Graph Database simulating property graph behaviors.
 * Persists changes in localStorage for live interactive updates.
 */
class MemoryGraphDB {
  constructor() {
    this.storageKey = 'stability_reasoning_memory_graph';
    this.loadGraph();
  }

  loadGraph() {
    const saved = localStorage.getItem(this.storageKey);
    if (saved) {
      this.data = JSON.parse(saved);
    } else {
      this.data = JSON.parse(JSON.stringify(seedData)); // Deep clone from seedData
      this.saveGraph();
    }
  }

  saveGraph() {
    localStorage.setItem(this.storageKey, JSON.stringify(this.data));
  }

  resetGraph() {
    this.data = JSON.parse(JSON.stringify(seedData));
    this.saveGraph();
  }

  // --- Graph Queries (Cypher-like JavaScript Traversal) ---

  /**
   * Find comparable products based on IgG subclass, buffer family, pH proximity, and container.
   */
  findComparableProducts(targetProduct) {
    return this.data.products.filter(p => {
      // Don't compare with self
      if (p.id === targetProduct.id) return false;

      const sameSubclass = p.subclass === targetProduct.subclass;
      const sameBuffer = p.buffer_family === targetProduct.buffer_family;
      const similarPH = Math.abs(p.pH - targetProduct.pH) <= 0.4;
      const sameContainer = p.container === targetProduct.container;

      return sameSubclass && sameBuffer && similarPH && sameContainer;
    });
  }

  /**
   * Get all justifications related to a set of products.
   */
  getJustificationsForProducts(productIds) {
    return this.data.justifications.filter(j => productIds.includes(j.productId));
  }

  /**
   * Get paragraph citation text from a justification or memo.
   */
  getCitation(key) {
    // Expected formats: "JUS-A ¶5", "OOT-Y ¶H3", "MEMO-X-COMP ¶5", "REG-Z round 2"
    const cleaned = key.replace(/\[|\]/g, '').trim();
    
    // Check if it's a paragraph reference (contains ¶)
    if (cleaned.includes('¶')) {
      const parts = cleaned.split('¶');
      const docId = parts[0].trim();
      const paraId = parts[1].trim();

      // Look in justifications
      const just = this.data.justifications.find(j => j.id === docId);
      if (just && just.paragraphs[paraId]) {
        return {
          title: `${just.id} (Proposed Claim: ${just.proposed_shelf_life || 'N/A'})`,
          source: `${just.regulator} Decision · Product ${just.productId} · ${just.date}`,
          text: just.paragraphs[paraId],
          status: just.outcome
        };
      }

      // Look in memos/logs
      const memo = this.data.memos_and_logs[docId];
      if (memo && memo.paragraphs[paraId]) {
        return {
          title: memo.title,
          source: `Internal Documentation Archive (${memo.id})`,
          text: memo.paragraphs[paraId],
          status: 'Informational'
        };
      }
    }

    // Check directly in memos for non-para keys (e.g. "REG-Z round 2")
    if (cleaned.includes(' ')) {
      const parts = cleaned.split(' ');
      const docId = parts[0].trim();
      const paraId = parts.slice(1).join(' ').trim();

      const memo = this.data.memos_and_logs[docId];
      if (memo && memo.paragraphs[paraId]) {
        return {
          title: memo.title,
          source: `Internal Regulatory Archive (${memo.id})`,
          text: memo.paragraphs[paraId],
          status: 'Precedent'
        };
      }
    }

    // Try finding whole memos
    const memo = this.data.memos_and_logs[cleaned];
    if (memo) {
      const firstKey = Object.keys(memo.paragraphs)[0];
      return {
        title: memo.title,
        source: `Internal Memo Archive (${memo.id})`,
        text: memo.paragraphs[firstKey],
        status: 'Informational'
      };
    }

    // Try finding learnings
    const learn = this.data.learnings.find(l => l.id === cleaned);
    if (learn) {
      return {
        title: `CROSS-GRAPH LESSON: ${learn.title}`,
        source: `Applicable to ${learn.applicableTo} · Source: ${learn.source}`,
        text: learn.text,
        status: 'Recommendation'
      };
    }

    return {
      title: cleaned,
      source: 'External reference',
      text: 'No document snippet matched the specified citation key in the current Memory Graph context.',
      status: 'Unknown'
    };
  }

  /**
   * Write reasoning back into the graph.
   */
  writeBackReasoning(justification) {
    // 1. Add justification to database
    this.data.justifications.push({
      id: justification.id,
      productId: justification.productId,
      regulator: justification.regulator,
      date: new Date().toISOString().substring(0, 7), // YYYY-MM
      outcome: "Draft",
      proposed_shelf_life: justification.proposed_shelf_life,
      paragraphs: justification.paragraphs
    });

    // 2. Add any newly asserted learnings
    if (justification.new_learnings) {
      justification.new_learnings.forEach(l => {
        this.data.learnings.push(l);
      });
    }

    this.saveGraph();
  }
}

// Global instance for browser
const graphDB = new MemoryGraphDB();
