/**
 * app.js — Router, sidebar builder, state manager for Memory Graph Virtual Lab
 * Uses original seedData from memory-graph_11
 */
class MemoryGraphApp {
  constructor() {
    this.state = {
      currentScreen: 0,
      product: graphDB.data.products.find(p => p.id === 'mAb-Y'),
      evidence: null,
      hedges: null,
      theme: localStorage.getItem('mg_theme') || 'light',
      sidebarOpen: true
    };

    window.addEventListener('popstate', (e) => {
      if (e.state && typeof e.state.screen !== 'undefined') {
        this.navigate(e.state.screen, false);
      }
    });
  }

  init() {
    document.documentElement.setAttribute('data-theme', this.state.theme);
    this._buildSidebar();
    this.navigate(0, false);
  }

  // ── Navigation ──
  navigate(screenNumber, pushHistory = true) {
    this.state.currentScreen = screenNumber;

    if (pushHistory) {
      history.pushState({ screen: screenNumber }, `Screen ${screenNumber}`, `?screen=${screenNumber}`);
    }

    this.render();
    this._updateSidebarActive();
  }

  render() {
    const container = document.getElementById('screen-container');
    if (!container) return;

    container.style.animation = 'none';
    container.offsetHeight;
    container.style.animation = 'fadeIn 0.18s ease';

    switch (this.state.currentScreen) {
      case 0: container.innerHTML = screens.renderHome(this.state); break;
      case 'cmc':
      case 'cmc-dp': container.innerHTML = screens.renderCmc(this.state); break;
      case 1: container.innerHTML = screens.renderScreen1(this.state); break;
      case 2: container.innerHTML = screens.renderScreen2(this.state); break;
      case 3: container.innerHTML = screens.renderScreen3(this.state); break;
      case 4: container.innerHTML = screens.renderScreen4(this.state); break;
      case 5: container.innerHTML = screens.renderScreen5(this.state); break;
      case 6: container.innerHTML = screens.renderScreen6(this.state); break;
      default: container.innerHTML = `<div class="page-shell"><p>Screen not found.</p></div>`;
    }

    // Animate attribute bars after render
    setTimeout(() => {
      document.querySelectorAll('.attr-bar-fill').forEach(bar => {
        const pct = bar.getAttribute('data-pct');
        if (pct) bar.style.width = pct + '%';
      });
    }, 60);
  }

  // ── Sidebar Builder ──
  _buildSidebar() {
    const projectsEl = document.getElementById('sidebar-projects');
    if (!projectsEl) return;

    // Projects list in sidebar
    projectsEl.innerHTML = `
      <div class="sidebar-project-group">
        <div class="sidebar-project-header" id="sb-maby-header" onclick="app._toggleProject('maby')">
          <svg class="sidebar-project-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
          <span class="sidebar-project-name">mAb-Y (anti-HER2)</span>
          <svg class="sidebar-project-arrow open" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
        <div id="sb-maby-steps">
          <div class="sidebar-section-label" style="padding-left:30px;">WORKFLOW (6)</div>
          <div class="sidebar-step-item" id="ss-1" onclick="app.navigate(1)"><span class="step-dot"></span>Entry</div>
          <div class="sidebar-step-item" id="ss-2" onclick="app.navigate(2)"><span class="step-dot"></span>Risk Framing</div>
          <div class="sidebar-step-item" id="ss-3" onclick="app.navigate(3)"><span class="step-dot"></span>Extrapolation</div>
          <div class="sidebar-step-item" id="ss-4" onclick="app.navigate(4)"><span class="step-dot"></span>Evidence</div>
          <div class="sidebar-step-item" id="ss-5" onclick="app.navigate(5)"><span class="step-dot"></span>Writeback</div>
          <div class="sidebar-step-item" id="ss-6" onclick="app.navigate(6)"><span class="step-dot"></span>Value Impact</div>
        </div>
      </div>

      <div class="sidebar-project-group">
        <div class="sidebar-project-header" style="opacity:0.6;cursor:default;">
          <svg class="sidebar-project-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
          <span class="sidebar-project-name">mAb-X (anti-CD20)</span>
        </div>
      </div>

      <div class="sidebar-project-group">
        <div class="sidebar-project-header" style="opacity:0.6;cursor:default;">
          <svg class="sidebar-project-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          <span class="sidebar-project-name">mAb-Z</span>
        </div>
      </div>
    `;
  }

  _toggleProject(key) {
    const steps = document.getElementById(`sb-${key}-steps`);
    const header = document.getElementById(`sb-${key}-header`);
    const arrow = header ? header.querySelector('.sidebar-project-arrow') : null;
    if (steps) steps.style.display = steps.style.display === 'none' ? '' : 'none';
    if (arrow) arrow.classList.toggle('open');
  }

  _updateSidebarActive() {
    // Clear active states
    document.querySelectorAll('.sidebar-item, .sidebar-step-item, .sidebar-project-header, .pipeline-item').forEach(el => {
      el.classList.remove('active', 'active-pipe', 'active-project');
    });

    const s = this.state.currentScreen;

    if (s === 0) {
      const el = document.getElementById('sb-home');
      if (el) el.classList.add('active');
    } else if (s === 'cmc' || s === 'cmc-dp') {
      const el = document.getElementById('sb-cmc');
      if (el) el.classList.add('active');
      const pipeline = document.getElementById('cmc-pipeline');
      if (pipeline) pipeline.style.display = 'flex';

      if (s === 'cmc-dp') {
        const dpItem = document.getElementById('sb-drug-product');
        if (dpItem) dpItem.classList.add('active-pipe');
        const projs = document.getElementById('sidebar-projects');
        if (projs) projs.style.display = 'block';
      }
    } else if (s >= 1 && s <= 6) {
      const el = document.getElementById(`ss-${s}`);
      if (el) el.classList.add('active');
      const hdr = document.getElementById('sb-maby-header');
      if (hdr) hdr.classList.add('active-project');
      const pipeline = document.getElementById('cmc-pipeline');
      if (pipeline) pipeline.style.display = 'flex';
      const dpItem = document.getElementById('sb-drug-product');
      if (dpItem) dpItem.classList.add('active-pipe');
      const projs = document.getElementById('sidebar-projects');
      if (projs) projs.style.display = 'block';
      const steps = document.getElementById('sb-maby-steps');
      if (steps) steps.style.display = 'block';
    }
  }

  // ── UI Actions ──
  openCmc() {
    const pipeline = document.getElementById('cmc-pipeline');
    if (pipeline) pipeline.style.display = 'flex';
    this.navigate('cmc');
  }

  openDrugProduct() {
    const pipeline = document.getElementById('cmc-pipeline');
    if (pipeline) pipeline.style.display = 'flex';
    const projs = document.getElementById('sidebar-projects');
    if (projs) projs.style.display = 'block';
    this.navigate('cmc-dp');
  }

  toggleCmc() {
    this.openCmc();
  }

  showDrugProduct() {
    this.openDrugProduct();
  }

  toggleSidebar() {
    this.state.sidebarOpen = !this.state.sidebarOpen;
    const sidebar = document.getElementById('sidebar');
    const main = document.getElementById('main-content');
    if (sidebar) sidebar.classList.toggle('collapsed', !this.state.sidebarOpen);
    if (main) main.style.marginLeft = this.state.sidebarOpen ? 'var(--sidebar-width)' : '0';
  }

  toggleTheme() {
    this.state.theme = this.state.theme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', this.state.theme);
    localStorage.setItem('mg_theme', this.state.theme);
  }

  toggleCheck(id) {
    const allItems = [...(this.state.evidence || []), ...(this.state.hedges || [])];
    const item = allItems.find(i => i.id === id);
    if (item) { item.checked = !item.checked; this.render(); }
  }

  renderCitations(text) {
    return (text || '').replace(/\[([^\]]+)\]/g, (match, key) => {
      return `<span class="prov" onclick="app.showCitation('${key}')">${key}</span>`;
    });
  }

  showCitation(key) {
    const citation = graphDB.getCitation(key);
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.onclick = () => overlay.remove();
    overlay.innerHTML = `
      <div class="modal" onclick="event.stopPropagation()">
        <div class="modal-head">
          <h4>Memory Graph Precedent — ${key}</h4>
          <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div class="field-label">Document Key</div>
          <div class="field-value mono"><strong>${key}</strong></div>
          <div class="field-label">Registry Source</div>
          <div class="field-value">${citation.source}</div>
          <div class="field-label">Document Title</div>
          <div class="field-value">${citation.title}</div>
          <div class="field-label">Precedent Logic</div>
          <div class="field-quote">${citation.text}</div>
          <div style="margin-top:16px;display:flex;justify-content:space-between;align-items:center;">
            <span class="badge-status ${citation.status === 'Accepted' ? 'approved' : 'rejected'}">${citation.status}</span>
            <button class="btn-outline" onclick="this.closest('.modal-overlay').remove()">Dismiss</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
  }

  triggerWriteback() {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';

    graphDB.writeBackReasoning({
      id: "JUS-mAb-Y-001",
      productId: "mAb-Y",
      regulator: "EMA",
      proposed_shelf_life: "36 months",
      paragraphs: {
        5: "Linear regression on 18 months of long-term stability data at 5°C projects HMW aggregation to 3.9% at 36 months.",
        6: "Arrhenius extrapolation from accelerated data provides orthogonal confirmation of the 36-month shelf-life claim."
      },
      new_learnings: [{
        id: "LEARN:mAb-Y-01",
        title: "Proactive OOT deamidation disclosures reduce assessor follow-ups.",
        source: "JUS-mAb-Y-001",
        applicableTo: "IgG1 deamidation justifications"
      }]
    });

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.onclick = () => overlay.remove();
    overlay.innerHTML = `
      <div class="modal" onclick="event.stopPropagation()" style="max-width:420px;">
        <div class="modal-head">
          <h4 style="color:var(--green);">✓ Reasoning Captured to Memory Graph</h4>
          <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div style="text-align:center;padding:20px 0;">
            <div style="font-size:48px;margin-bottom:12px;">🧬</div>
            <div style="font-size:15px;font-weight:600;color:var(--ink);margin-bottom:8px;">17 reasoning triples written back</div>
            <div style="font-size:13px;color:var(--ink-3);">JUS-mAb-Y-001 · mAb-Y · 36 months at 2–8°C</div>
            <div style="font-size:12px;color:var(--ink-4);margin-top:6px;font-family:var(--font-mono);">Asserted by Scientist · ${timestamp}</div>
          </div>
          <button class="btn-primary" style="width:100%;margin-top:8px;" onclick="this.closest('.modal-overlay').remove();app.navigate(6)">
            View Value Impact →
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
  }

  resetDB() {
    if (confirm("Reset the Memory Graph database back to original seed precedents?")) {
      graphDB.resetGraph();
      this.state.evidence = null;
      this.state.hedges = null;
      this.navigate(0);
    }
  }
}

const app = new MemoryGraphApp();
window.addEventListener('DOMContentLoaded', () => app.init());
