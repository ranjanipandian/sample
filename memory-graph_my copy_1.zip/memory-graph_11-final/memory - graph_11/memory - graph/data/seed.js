/**
 * Seed data representing the initial Memory Graph state.
 * Contains 8 products, justifications, arguments, and cross-linked learnings.
 */
const seedData = {
  products: [
    {
      id: "mAb-Y",
      name: "mAb-Y (anti-HER2)",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.2,
      concentration: "50 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BY-2024-001", "BY-2024-002", "BY-2023-005"]
    },
    {
      id: "mAb-X",
      name: "mAb-X (anti-CD20)",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.5,
      concentration: "100 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BX-2021-001", "BX-2021-002", "BX-2022-003"]
    },
    {
      id: "mAb-Z",
      name: "mAb-Z",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.0,
      concentration: "20 mg/mL",
      surfactant: "PS80 · 0.01%",
      container: "Type-I glass vial",
      registered_batches: ["BZ-2022-001", "BZ-2022-002"]
    },
    {
      id: "mAb-A",
      name: "mAb-A",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.6,
      concentration: "50 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BA-2023-001"]
    },
    {
      id: "mAb-B",
      name: "mAb-B",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.2,
      concentration: "75 mg/mL",
      surfactant: "PS20 · 0.04%",
      container: "Type-I glass vial",
      registered_batches: ["BB-2023-001", "BB-2023-002"]
    },
    {
      id: "mAb-C",
      name: "mAb-C",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.4,
      concentration: "50 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BC-2022-001"]
    },
    {
      id: "mAb-D",
      name: "mAb-D",
      subclass: "IgG2",
      buffer_family: "phosphate",
      pH: 6.2,
      concentration: "10 mg/mL",
      surfactant: "PS80 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BD-2021-001"]
    },
    {
      id: "mAb-E",
      name: "mAb-E",
      subclass: "IgG4",
      buffer_family: "citrate",
      pH: 6.0,
      concentration: "150 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BE-2020-001"]
    }
  ],
  justifications: [
    {
      id: "JUS-A",
      productId: "mAb-X",
      regulator: "CHMP",
      date: "2022-11",
      outcome: "Accepted",
      proposed_shelf_life: "24 months",
      paragraphs: {
        5: "Long-term data at 5°C demonstrates a stable HMW profile with mean increase of 0.8% per 12 months, projecting a mean HMW at 24 months of 3.2%, well within the shelf-life specification of NMT 4.0%.",
        6: "Arrhenius-based extrapolation using accelerated data at 25°C independently supports the same 24-month shelf life, providing orthogonal confirmation."
      }
    },
    {
      id: "JUS-B-orig",
      productId: "mAb-Z",
      regulator: "FDA",
      date: "2023-04",
      outcome: "Rejected",
      proposed_shelf_life: "36 months",
      paragraphs: {
        3: "The Arrhenius model requires linear kinetics across the temperature range assessed. The applicant's own data at 40°C shows non-Arrhenius behaviour beyond 3 months, suggesting a secondary degradation pathway becomes dominant. The Arrhenius extrapolation to 36 months is therefore not supported by the data submitted."
      }
    },
    {
      id: "JUS-B-rev",
      productId: "mAb-Z",
      regulator: "FDA",
      date: "2023-11",
      outcome: "Accepted",
      proposed_shelf_life: "36 months",
      paragraphs: {
        4: "The revised justification proposes 36 months supported by 24 months of long-term data at 5°C from three batches, with Arrhenius extrapolation retained only as supporting evidence."
      }
    },
    {
      id: "JUS-C",
      productId: "mAb-X",
      regulator: "CHMP",
      date: "2022-11",
      outcome: "Accepted",
      proposed_shelf_life: "24 months",
      paragraphs: {
        3: "Aggregation is the dominant historical driver of shelf-life determination for IgG1 mAbs in histidine formulations.",
        4: "Including the 95% confidence interval on linear regressions at 5°C provides robust validation of the regression model's reliability for projecting shelf-life limits."
      }
    },
    {
      id: "JUS-A-potency",
      productId: "mAb-X",
      regulator: "CHMP",
      date: "2022-11",
      outcome: "Accepted",
      paragraphs: {
        6: "Loss of cell-based potency follows standard first-order kinetics at accelerated temperatures and does not limit shelf-life at 2-8°C up to 36 months."
      }
    }
  ],
  memos_and_logs: {
    "OOT-Y": {
      id: "OOT-Y",
      title: "Charge Isoform Drift Analysis",
      paragraphs: {
        "H3": "The differential is consistent with pH-dependent deamidation kinetics — mAb-Y is at pH 5.2, mAb-X at pH 5.5 — a known effect for IgG1 CDR asparagine residues.",
        "Action": "Contingency: 30-month claim reserved if the 30-month timepoint confirms the projection."
      }
    },
    "MEMO-X-EX": {
      id: "MEMO-X-EX",
      title: "Method Variability in SE-HPLC HMW Determination",
      paragraphs: {
        3: "Observed analytical method variability (SD = 0.15%) indicates that observed aggregation drift exceeds baseline assay noise and represents true chemical degradation."
      }
    },
    "MEMO-X-COMP": {
      id: "MEMO-X-COMP",
      title: "Cross-Batch Comparability Study for IgG1 Monoclonals",
      paragraphs: {
        5: "Batch-to-batch comparability across three GMP validation batches (CV < 5% for slope and intercept at 5°C) justifies using combined regression data for shelf-life extrapolation."
      }
    },
    "TAC-INT": {
      id: "TAC-INT",
      title: "Internal Technical Advisory on Deamidation Kinetics",
      paragraphs: {
        "Q6": "Deamidation rates of IgG1 CDR regions display acute sensitivity to formulation pH between 5.0 and 6.0, doubling for every 0.4 pH unit drop."
      }
    },
    "TAC-HAND": {
      id: "TAC-HAND",
      title: "Regulatory Negotiation Handbook",
      paragraphs: {
        4: "Proactive disclosure of open OOT investigations with a robust root-cause analysis is strongly favored by EMA/FDA assessors over reactive disclosure during Day 120/180 question rounds."
      }
    },
    "REG-Z": {
      id: "REG-Z",
      title: "Precedents on Charge-Isoform Drift Hedges",
      paragraphs: {
        "round 2": "Including clinical batch comparability and showing that high acidic variant content remains biologically active (potency unchanged) mitigates regulatory queries regarding charge isoform drift."
      }
    }
  },
  learnings: [
    {
      id: "LEARN:JUS-B-01",
      title: "Arrhenius Extrapolation Limits",
      text: "Before proposing Arrhenius as a primary argument, verify linear kinetics across the full temperature range (5/25/40°C). For mAb-Y, HMW kinetics at 40°C are near-linear through 6 months — Arrhenius as supporting is defensible; Arrhenius as primary is not.",
      source: "JUS-B-orig ¶3",
      applicableTo: "IgG1 Extrapolation"
    }
  ]
};

if (typeof module !== 'undefined') {
  module.exports = seedData;
}
