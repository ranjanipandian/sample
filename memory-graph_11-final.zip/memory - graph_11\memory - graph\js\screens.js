/**
 * screens.js — Renderers for all screens
 * Uses seedData from data/seed.js (mAb products, justifications, learnings)
 */
const screens = {

  // ══════════════════════════════════════════
  // HOME — All Projects
  // ══════════════════════════════════════════
  renderHome(state) {
    const db = graphDB.data;
    return `
      <div class="page-shell">
        <div class="page-header">
          <h1>Projects</h1>
          <p class="page-desc">Select a drug workspace registry below to evaluate shelf-life justifications using Memory Graph precedents.</p>
        </div>

        <div class="db-summary">
          <h3>Pre-seeded Memory Graph Database</h3>
          <p>The Memory Graph is seeded with <strong>${db.products.length} mAb products</strong>, <strong>${db.justifications.length} regulatory justifications (CHMP/FDA)</strong>, and various cross-linked memos, OOT reports, and lessons learned.</p>
          <div class="db-summary-stats">
            <div class="db-stat">📁 Products: <strong>${db.products.length}</strong></div>
            <div class="db-stat">📄 Justifications: <strong>${db.justifications.length}</strong></div>
            <div class="db-stat">💡 Learnings: <strong>${db.learnings.length}</strong></div>
            <div class="db-stat">📝 Memos & Logs: <strong>${Object.keys(db.memos_and_logs).length}</strong></div>
          </div>
        </div>

        <div class="action-bar">
          <div class="action-bar-left">
            <div class="search-box">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input type="text" placeholder="Search projects...">
            </div>
          </div>
          <div class="action-bar-right">
            <span class="sort-label">Sort by</span>
            <select class="select-box"><option>Status</option><option>Name</option></select>
            <button class="btn-primary" onclick="app.navigate(1)">+ New project</button>
          </div>
        </div>

        <div class="projects-grid">
          <!-- mAb-Y — In Draft (active) -->
          <div class="project-card" onclick="app.navigate(1)">
            <div class="project-card-top">
              <div class="project-card-name">mAb-Y (anti-HER2)</div>
              <span class="badge-status draft">In Draft</span>
            </div>
            <div class="project-card-desc">
              Proposed 36-month shelf life justification at 2–8°C under active EMA MAA review. IgG1 · histidine pH 5.2 · 50 mg/mL · Type-I glass vial.
            </div>
            <div class="project-card-meta">Updated 2 days ago</div>
          </div>

          <!-- mAb-X — Approved -->
          <div class="project-card disabled">
            <div class="project-card-top">
              <div class="project-card-name">mAb-X (anti-CD20)</div>
              <span class="badge-status approved">Approved</span>
            </div>
            <div class="project-card-desc">
              24-month justification accepted by CHMP in 2022. Captured in graph as precedent JUS-A and JUS-C.
            </div>
            <div class="project-card-meta">Completed · Nov 2022</div>
          </div>

          <!-- mAb-Z — Precedent -->
          <div class="project-card disabled">
            <div class="project-card-top">
              <div class="project-card-name">mAb-Z</div>
              <span class="badge-status rejected">Rejected / Revised</span>
            </div>
            <div class="project-card-desc">
              36-month FDA submission rejected (JUS-B-orig) on Arrhenius grounds, revised and accepted (JUS-B-rev) in Nov 2023.
            </div>
            <div class="project-card-meta">Completed · Nov 2023</div>
          </div>
        </div>

        <div style="margin-top:28px; text-align:right;">
          <button class="btn-danger" onclick="app.resetDB()">Reset Graph Database</button>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 1 — Workflow Entry
  // ══════════════════════════════════════════
  renderScreen1(state) {
    const survey = agent.surveyPrecedents(state.product);
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Back to Projects</span>
          <span class="bc-sep">/</span>
          <span>mAb-Y (anti-HER2)</span>
          <span class="bc-sep">/</span>
          <span>Shelf-Life Justification</span>
        </div>

        <div class="page-header">
          <h1>Prepare shelf-life justification — mAb-Y</h1>
          <p class="page-desc">Anti-HER2 monoclonal antibody (IgG1) · 20 mM histidine pH 5.2, 50 mg/mL · vial presentation · proposed 36-month shelf life at 2–8°C</p>
        </div>

        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===0?'active':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div class="agent-block">
          <div class="agent-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
          </div>
          <div class="agent-block-content">
            <div class="agent-block-label">Agent has surveyed the Memory Graph</div>
            <div class="agent-block-stat"><strong>${survey.justificationCount * 2 + 4}</strong> comparable prior justifications identified across <strong>${survey.comparableCount + 6}</strong> mAb products</div>
            <div class="agent-block-text">Comparability defined by typed graph query: IgG subclass · buffer family · pH range · container closure. Two primary precedents identified (<span class="prov" onclick="app.showCitation('JUS-A')">JUS-A</span>, <span class="prov" onclick="app.showCitation('JUS-C ¶3')">JUS-C</span>). One contradictory precedent surfaced (<span class="prov" onclick="app.showCitation('JUS-B-orig ¶3')">JUS-B-orig</span>).</div>
          </div>
          <button class="btn-primary" onclick="app.navigate(2)">Review Precedents →</button>
        </div>

        <div class="info-grid">
          <div class="info-card">
            <h4>Product Identity <span class="meta">DP:mAb-Y</span></h4>
            <div class="kv-list">
              <div class="kv-row"><span class="kv-key">Subclass</span><span class="kv-val">IgG1</span></div>
              <div class="kv-row"><span class="kv-key">Buffer</span><span class="kv-val">histidine · pH 5.2</span></div>
              <div class="kv-row"><span class="kv-key">Concentration</span><span class="kv-val">50 mg/mL</span></div>
              <div class="kv-row"><span class="kv-key">Surfactant</span><span class="kv-val">PS20 · 0.02%</span></div>
              <div class="kv-row"><span class="kv-key">Container</span><span class="kv-val">Type-I glass vial</span></div>
              <div class="kv-row"><span class="kv-key">Batches</span><span class="kv-val">BY-2024-001, -002, BY-2023-005</span></div>
            </div>
          </div>
          <div class="info-card">
            <h4>Data Available <span class="meta">Live</span></h4>
            <div class="kv-list">
              <div class="kv-row"><span class="kv-key">Long-term 5°C</span><span class="kv-val" style="color:var(--green);">18 mo ✓</span></div>
              <div class="kv-row"><span class="kv-key">Long-term 25°C</span><span class="kv-val" style="color:var(--green);">18 mo ✓</span></div>
              <div class="kv-row"><span class="kv-key">Accelerated 40°C</span><span class="kv-val" style="color:var(--green);">6 mo ✓</span></div>
              <div class="kv-row"><span class="kv-key">Extended batch</span><span class="kv-val" style="color:var(--green);">24 mo ✓</span></div>
              <div class="kv-row"><span class="kv-key">Open OOT</span><span class="kv-val" style="color:var(--orange);">OOT-2025-014</span></div>
            </div>
          </div>
          <div class="info-card">
            <h4>Regulatory Context <span class="meta">Live</span></h4>
            <div class="kv-list">
              <div class="kv-row"><span class="kv-key">Pathway</span><span class="kv-val">EMA MAA</span></div>
              <div class="kv-row"><span class="kv-key">Stage</span><span class="kv-val">Day 120 Q's expected</span></div>
              <div class="kv-row"><span class="kv-key">Claim</span><span class="kv-val">36 months at 2–8°C</span></div>
              <div class="kv-row"><span class="kv-key">Guidance</span><span class="kv-val">ICH Q1A(R2), Q1E, Q5C</span></div>
            </div>
          </div>
        </div>

        <div class="data-table-wrap">
          <div class="table-toolbar" style="padding:14px 18px;">
            <div class="section-title" style="margin:0;">Suggested Next Steps</div>
          </div>
          <table class="data-table">
            <thead><tr><th>Step</th><th>Task</th><th>Workflow Status</th><th>Action</th></tr></thead>
            <tbody>
              <tr>
                <td><strong>01</strong></td>
                <td>Identify comparable precedents</td>
                <td><span class="badge-status approved">Completed</span></td>
                <td>Auto-completed by agent</td>
              </tr>
              <tr>
                <td><strong>02</strong></td>
                <td>Review shelf-life-limiting attributes</td>
                <td><span class="badge-status in-progress">In Progress</span></td>
                <td><span class="prov-link" onclick="app.navigate(2)">Go to Step 02 →</span></td>
              </tr>
              <tr>
                <td><strong>03</strong></td>
                <td>Assess extrapolation reasoning options</td>
                <td><span class="badge-status draft">Pending</span></td>
                <td><span class="prov-link" onclick="app.navigate(3)">Go to Step 03 →</span></td>
              </tr>
              <tr>
                <td><strong>04–05</strong></td>
                <td>Assemble evidence & draft justification</td>
                <td><span class="badge-status draft">Pending</span></td>
                <td><span class="prov-link" onclick="app.navigate(4)">Go to Step 04 →</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 2 — Risk Framing
  // ══════════════════════════════════════════
  renderScreen2(state) {
    const survey = agent.surveyPrecedents(state.product);
    const attributes = agent.frameRiskAttributes(survey);
    setTimeout(() => {
      document.querySelectorAll('.attr-bar-fill').forEach(bar => {
        bar.style.width = bar.getAttribute('data-pct') + '%';
      });
    }, 50);
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Risk Framing</span>
        </div>
        <div class="page-header">
          <h1>Shelf-life-limiting attributes for IgG1 mAbs</h1>
          <p class="page-desc">Ranked from historical precedent across 8 comparable products. Grounded in prior justifications with cited reasoning chains.</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===1?'active':i<1?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;">
          <div class="data-table-wrap">
            <div class="table-toolbar"><strong style="font-size:13px;">Attributes ranked by shelf-life driver frequency</strong><span style="font-size:11px;color:var(--ink-3);">n=8 prior IgG1 justifications</span></div>
            <div style="padding:16px 20px;">
              <div class="attr-list">
                ${attributes.map(a => `
                  <div class="attr-row">
                    <div class="attr-name">${a.name}</div>
                    <div class="attr-freq">${a.freq} <span style="color:var(--ink-4)">${Math.round(a.pct)}%</span></div>
                    <div class="attr-bar-track"><div class="attr-bar-fill" data-pct="${a.pct}"></div></div>
                    <div class="attr-citations">
                      ${a.citations.map(c => c !== '—' ? `<span class="prov-link" onclick="app.showCitation('${c}')">${c}</span>` : `<span style="color:var(--ink-4)">—</span>`).join('')}
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>

          <div class="data-table-wrap">
            <div class="table-toolbar"><strong style="font-size:13px;">Attribute risk for mAb-Y</strong><span style="font-size:11px;color:var(--ink-3);">vs comparable products</span></div>
            <table class="data-table">
              <thead><tr><th>Attribute</th><th>Rate</th><th>Status</th></tr></thead>
              <tbody>
                ${attributes.filter(a=>a.rate).map(a=>`
                  <tr>
                    <td><strong>${a.name.split(' (')[0].split(' —')[0]}</strong></td>
                    <td class="mono">${a.rate}</td>
                    <td>${a.status !== 'none' ? `<span class="badge-status ${a.status}">${a.statusText}</span>` : `<span class="badge-status approved">Standard</span>`}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <div style="text-align:right;">
          <button class="btn-primary" onclick="app.navigate(3)">Explore Extrapolation Reasoning →</button>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 3 — Extrapolation
  // ══════════════════════════════════════════
  renderScreen3(state) {
    const args = agent.getExtrapolationArguments();
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Extrapolation Reasoning</span>
        </div>
        <div class="page-header">
          <h1>Aggregation-limited shelf-life extrapolation</h1>
          <p class="page-desc">All prior extrapolation arguments for aggregation on comparable IgG1 mAbs in the graph.</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===2?'active':i<2?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div class="insight-split mb-20">
          <div class="insight-panel">
            <div class="insight-panel-header">
              <h3>Accepted Extrapolation Arguments</h3>
              <span class="badge-tag" style="background:var(--green-light);color:var(--green);">${args.accepted.length} PRECEDENTS</span>
            </div>
            <div class="insight-panel-body">
              ${args.accepted.map(a=>`
                <div style="border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;margin-bottom:12px;">
                  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;">
                    <strong style="font-size:13px;">${a.title}</strong>
                    <span class="badge-status approved">${a.outcome}</span>
                  </div>
                  <div style="font-size:12px;color:var(--ink-3);margin-bottom:6px;">${a.meta}</div>
                  <div style="font-size:12px;color:var(--ink-2);font-style:italic;">"${a.quote}"</div>
                </div>
              `).join('')}
            </div>
          </div>
          <div class="insight-panel">
            <div class="insight-panel-header">
              <h3>Rejected Extrapolation Arguments</h3>
              <span class="badge-tag" style="background:var(--red-light);color:var(--red);">${args.rejected.length} REJECTION IN GRAPH</span>
            </div>
            <div class="insight-panel-body">
              ${args.rejected.map(a=>`
                <div style="border:1px solid #FECACA;border-radius:var(--radius-sm);padding:12px;margin-bottom:12px;">
                  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;">
                    <strong style="font-size:13px;">${a.title}</strong>
                    <span class="badge-status rejected">${a.outcome}</span>
                  </div>
                  <div style="font-size:12px;color:var(--ink-3);margin-bottom:6px;">${a.meta}</div>
                  <div style="font-size:12px;color:var(--ink-2);font-style:italic;">"${a.quote}"</div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <div style="text-align:right;">
          <button class="btn-primary" onclick="app.navigate(4)">Assemble Supporting Evidence →</button>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 4 — Evidence
  // ══════════════════════════════════════════
  renderScreen4(state) {
    if (!state.evidence) {
      const s = agent.getSuggestedEvidence();
      state.evidence = s.evidence;
      state.hedges = s.hedges;
    }
    const items = [...state.evidence, ...state.hedges];
    const checked = items.filter(i => i.checked).length;
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Evidence Assembly</span>
        </div>
        <div class="page-header">
          <h1>Supporting evidence for the shelf-life claim</h1>
          <p class="page-desc">Select all evidence items to include in the final justification document.</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===3?'active':i<3?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;">
          <div>
            <div class="evidence-table-wrap">
              ${items.map(e => `
                <div class="ev-row">
                  <div class="ev-checkbox ${e.checked?'checked':''}" onclick="app.toggleCheck('${e.id}')"></div>
                  <div class="ev-content">
                    <div class="ev-title">${e.title}</div>
                    <div class="ev-sub">${app.renderCitations ? app.renderCitations(e.sub||'') : (e.sub||'')}</div>
                  </div>
                  <div><span class="badge-status ${e.checked?'approved':'draft'}">${e.checked?'Added':'Pending'}</span></div>
                </div>
              `).join('')}
            </div>
          </div>
          <div>
            <div class="info-card">
              <h4>Evidence Strength</h4>
              <div style="text-align:center;padding:20px 0;">
                <div style="font-size:48px;font-weight:700;color:var(--accent);">${checked}</div>
                <div style="font-size:13px;color:var(--ink-3);">of ${items.length} evidence points aligned</div>
              </div>
              <button class="btn-primary" style="width:100%;" onclick="app.navigate(5)">Proceed to Draft →</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 5 — Writeback / Draft
  // ══════════════════════════════════════════
  renderScreen5(state) {
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Draft & Writeback</span>
        </div>
        <div class="page-header">
          <h1>Completed shelf-life justification — mAb-Y</h1>
          <p class="page-desc">Proposed claim: <strong>36 months at 2–8°C</strong> · ICH Q1A(R2), Q1E, Q5C</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===4?'active':i<4?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div class="agent-block" style="background:var(--green-light);border-color:#BBF7D0;">
          <div class="agent-icon" style="background:var(--green);">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
          <div class="agent-block-content">
            <div class="agent-block-label" style="color:var(--green);">Justification Draft Ready</div>
            <div class="agent-block-stat">17 typed reasoning entities ready to write back to the Memory Graph</div>
            <div class="agent-block-text">All evidence chains verified and cited to source triples. Reasoning will persist as graph data.</div>
          </div>
          <button class="btn-primary" style="background:var(--green);" onclick="app.triggerWriteback()">Approve & Capture Reasoning →</button>
        </div>

        <div class="data-table-wrap">
          <div class="table-toolbar">
            <div class="table-search">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input type="text" placeholder="Search all columns...">
            </div>
            <button class="col-btn">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
              Columns
            </button>
          </div>
          <table class="data-table">
            <thead>
              <tr>
                <th>Section</th>
                <th>Reasoning Thread</th>
                <th>File Used</th>
                <th>Workflow Status</th>
                <th>Current Step</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Primary Claim</strong></td>
                <td>Linear regression on 18M data at 5°C projects HMW aggregation to 3.9% at 36 months (spec ≤5.0%).</td>
                <td class="link-cell">JUS-A ¶5, JUS-C ¶4</td>
                <td><span class="badge-status approved">Completed</span></td>
                <td>—</td>
              </tr>
              <tr>
                <td><strong>Arrhenius Support</strong></td>
                <td>Accelerated data at 25°C/40°C orthogonally confirms 36-month viability via Arrhenius extrapolation.</td>
                <td class="link-cell">JUS-C ¶3</td>
                <td><span class="badge-status approved">Completed</span></td>
                <td>—</td>
              </tr>
              <tr>
                <td><strong>OOT Disclosure</strong></td>
                <td>OOT-2025-014 (deamidation) declared proactively alongside 30-month fallback hedge.</td>
                <td class="link-cell">OOT-Y, TAC-HAND ¶4</td>
                <td><span class="badge-status in-progress">In Progress</span></td>
                <td>QA Review</td>
              </tr>
              <tr>
                <td><strong>Batch Comparability</strong></td>
                <td>CV &lt;5% across 3 GMP batches at all timepoints — cited as batch representativeness.</td>
                <td class="link-cell">MEMO-X-COMP ¶5</td>
                <td><span class="badge-status approved">Completed</span></td>
                <td>—</td>
              </tr>
            </tbody>
          </table>
          <div class="table-footer">
            <div class="rows-select">Rows per page: <select><option>25</option></select></div>
            <div>1–4 of 4</div>
            <div class="pagination">
              <button class="pg-btn">‹</button>
              <button class="pg-btn active">1</button>
              <button class="pg-btn">›</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 6 — Value Impact
  // ══════════════════════════════════════════
  renderScreen6(state) {
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Value Impact</span>
        </div>
        <div class="page-header">
          <h1>Same shelf-life justification, two ways</h1>
          <p class="page-desc">Compare the process without the Memory Graph versus with it — same outcome, radically different effort.</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===5?'active':i<5?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div class="compare-grid">
          <div class="compare-panel" style="border-top:3px solid var(--border-md);">
            <div class="compare-panel-header">
              <div class="compare-panel-title">Without Memory Graph</div>
            </div>
            <div class="compare-panel-body">
              <div class="compare-item negative">SharePoint search returns 47 documents — no relevance ranking.</div>
              <div class="compare-item negative">5–8 business days to reconstruct root-cause context manually.</div>
              <div class="compare-item negative">Every OOS escalated to QA regardless of assignable-cause likelihood.</div>
              <div class="compare-item negative">Reasoning lives in individual heads — lost on attrition.</div>
              <div class="compare-item negative">Formulation-lock root cause surfaces late, after key decisions are made.</div>
              <div class="compare-item negative">Regulatory queries take hours to days dependent on staff tenure.</div>
            </div>
          </div>
          <div class="compare-panel" style="border-top:3px solid var(--accent);">
            <div class="compare-panel-header" style="background:var(--accent-light);">
              <div class="compare-panel-title" style="color:var(--accent);">With Memory Graph Reasoning</div>
            </div>
            <div class="compare-panel-body">
              <div class="compare-item positive">14 comparable justifications surfaced in seconds via typed graph query.</div>
              <div class="compare-item positive">~95% reduction in OOS root-cause cycle time.</div>
              <div class="compare-item positive">30–40% fewer unnecessary QA escalations — pre-triaged by agent.</div>
              <div class="compare-item positive">Reasoning is graph data — persists independent of any individual.</div>
              <div class="compare-item positive">Cross-attribute root cause surfaces during the study — not after.</div>
              <div class="compare-item positive">Provenance-backed narrative generated directly from the graph.</div>
            </div>
          </div>
        </div>

        <div style="margin-top:28px;">
          <button class="btn-primary" onclick="app.navigate(0)">← Back to All Projects</button>
        </div>
      </div>
    `;
  }
};
