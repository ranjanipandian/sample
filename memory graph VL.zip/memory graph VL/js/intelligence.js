/**
 * intelligence.js
 * "Intelligence Companion" — a grounded Q&A engine over the real stability dataset
 * (stabilityData.js) plus the Memory Graph precedents (seed.js). Answers are computed
 * from actual data via StabilityEngine, not canned text. Also drives the slide-out chat panel UI.
 */
const Intelligence = {

  panelOpen: false,
  history: [], // { role: 'user'|'agent', html }

  SUGGESTED_QUESTIONS: [
    "What's the HMW trend for mAb-Y at 5°C?",
    "Which batch shows the fastest potency decline?",
    "Is charge isoform drift within spec at 36 months?",
    "Compare all batches for protein concentration.",
    "What does the data say about the 40°C Arrhenius linearity?",
    "Summarize data coverage for mAb-Y."
  ],

  // ── Panel control ──
  togglePanel() {
    this.panelOpen = !this.panelOpen;
    this.render();
  },

  openPanel() {
    this.panelOpen = true;
    this.render();
  },

  closePanel() {
    this.panelOpen = false;
    this.render();
  },

  render() {
    let el = document.getElementById('intel-panel-root');
    if (!el) {
      el = document.createElement('div');
      el.id = 'intel-panel-root';
      document.body.appendChild(el);
    }
    if (!this.panelOpen) {
      el.innerHTML = '';
      return;
    }

    el.innerHTML = `
      <div class="intel-panel">
        <div class="intel-panel-head">
          <div style="display:flex;align-items:center;gap:8px;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6L12 3zM19 14l.9 2.4L22 17l-2.1.6L19 20l-.9-2.4L16 17l2.1-.6L19 14zM5 14l.7 1.9L8 17l-2.3.7L5 20l-.7-2.3L2 17l2.3-.7L5 14z"></path></svg>
            <strong style="font-size:14px;">Intelligence Companion</strong>
          </div>
          <button class="modal-close" onclick="Intelligence.closePanel()">×</button>
        </div>
        <div class="intel-panel-body" id="intel-chat-body">
          ${this.history.length === 0 ? `
            <div class="intel-welcome">
              I'm grounded in the mAb-Y stability dataset (5 batches × 3 conditions × 13 CQAs) and the Memory Graph precedents.
              Ask about trends, spec margins, batch comparisons, or regulatory precedents — or try a suggestion below.
            </div>
          ` : this.history.map(h => this._renderMsg(h)).join('')}
        </div>
        <div class="intel-suggestions" id="intel-suggestions">
          ${this.SUGGESTED_QUESTIONS.map(q => `<span class="intel-chip" onclick="Intelligence.ask(${JSON.stringify(q)})">${q}</span>`).join('')}
        </div>
        <div class="intel-input-row">
          <input type="text" id="intel-input" placeholder="Ask about mAb-Y stability data..." onkeydown="if(event.key==='Enter'){Intelligence.submitInput();}">
          <button class="btn-primary" onclick="Intelligence.submitInput()" style="padding:9px 14px;">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </div>
    `;

    const body = document.getElementById('intel-chat-body');
    if (body) body.scrollTop = body.scrollHeight;
  },

  _renderMsg(h) {
    if (h.role === 'user') {
      return `<div class="intel-msg intel-msg-user">${h.html}</div>`;
    }
    return `<div class="intel-msg intel-msg-agent">${h.html}</div>`;
  },

  submitInput() {
    const input = document.getElementById('intel-input');
    if (!input || !input.value.trim()) return;
    const q = input.value.trim();
    input.value = '';
    this.ask(q);
  },

  ask(question) {
    this.history.push({ role: 'user', html: this._escape(question) });
    const answerHtml = this._answer(question);
    this.history.push({ role: 'agent', html: answerHtml });
    this.render();
  },

  _escape(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  },

  // ── Query engine: pattern-match question → compute from real data ──
  _answer(qRaw) {
    const q = qRaw.toLowerCase();

    // Attribute keyword map
    const attrMatchers = [
      { keys: ['hmw', 'aggregat'], attr: 'purityHMW' },
      { keys: ['potency'], attr: 'potency' },
      { keys: ['protein concentration', 'concentration'], attr: 'proteinConc' },
      { keys: ['main peak (se', 'se-hplc', 'sehplc', 'main peak se'], attr: 'purityMainSEHPLC' },
      { keys: ['hc+lc', 'heavy chain', 'reduced'], attr: 'purityHCLC' },
      { keys: ['non-reduced main', 'ce-sds non'], attr: 'purityMainNonReduced' },
      { keys: ['charge isoform', 'acidic', 'deamidation'], attr: 'chargeAcidic' },
      { keys: ['basic peak', 'basic isoform'], attr: 'chargeBasic' },
      { keys: ['main peak', 'charge main'], attr: 'chargeMain' },
      { keys: ['ph value', ' ph ', 'ph trend'], attr: 'pH' },
      { keys: ['osmolality'], attr: 'osmolality' }
    ];

    let condition = '5C';
    if (q.includes('25')) condition = '25C';
    else if (q.includes('40')) condition = '40C';

    let batch = null;
    const batchMatch = q.match(/batch\s*([1-5])/);
    if (batchMatch) batch = 'B' + batchMatch[1];

    let targetMonth = 36;
    const monthMatch = q.match(/(\d+)\s*(month|mo)/);
    if (monthMatch) targetMonth = parseInt(monthMatch[1], 10);

    // Coverage / summary questions
    if (q.includes('coverage') || q.includes('summarize') || (q.includes('data') && q.includes('available'))) {
      return this._answerCoverage();
    }

    // Arrhenius / linearity
    if (q.includes('arrhenius') || q.includes('linear')) {
      return this._answerArrhenius();
    }

    // Fastest / comparison across batches
    if (q.includes('fastest') || q.includes('compare all batches') || (q.includes('compare') && q.includes('batch'))) {
      const matched = attrMatchers.find(m => m.keys.some(k => q.includes(k)));
      const attr = matched ? matched.attr : 'potency';
      if (q.includes('compare all batches')) {
        return this._answerBatchComparisonChart(attr, condition);
      }
      return this._answerFastestBatch(attr, condition);
    }

    // Spec / within-spec questions
    if (q.includes('spec') || q.includes('within') || q.includes('drift')) {
      const matched = attrMatchers.find(m => m.keys.some(k => q.includes(k)));
      const attr = matched ? matched.attr : 'chargeAcidic';
      return this._answerSpecMargin(attr, condition, targetMonth);
    }

    // Batch-specific trend
    if (batch) {
      const matched = attrMatchers.find(m => m.keys.some(k => q.includes(k)));
      const attr = matched ? matched.attr : 'purityHMW';
      return this._answerBatchTrend(attr, condition, batch);
    }

    // General trend question
    const matched = attrMatchers.find(m => m.keys.some(k => q.includes(k)));
    if (matched) {
      return this._answerTrend(matched.attr, condition, targetMonth);
    }

    // Fallback
    return `
      <div>I can answer questions grounded in the mAb-Y stability dataset — trends, spec margins, batch comparisons, and Arrhenius linearity checks.
      Try: <em>"What's the HMW trend at 5°C?"</em> or <em>"Which batch shows the fastest potency decline?"</em></div>
    `;
  },

  _answerTrend(attrKey, condition, targetMonth) {
    const a = StabilityEngine.analyzeAttribute(attrKey, condition, targetMonth);
    if (!a) return `<div>No sufficient data found for that attribute at ${StabilityEngine.conditionLabel(condition)}.</div>`;
    const statusColor = { ok: 'var(--green)', warn: 'var(--orange)', fail: 'var(--red)', none: 'var(--ink-3)' }[a.status];
    const statusLabel = { ok: 'On track', warn: 'Watch', fail: 'Out of spec', none: 'N/A' }[a.status];
    const chart = Charts.lineChart({
      series: [{ name: `Avg (n=5 batches)`, color: 'var(--accent)', points: a.series }],
      specLow: a.specLow, specHigh: a.specHigh, unit: a.unit, height: 180
    });
    return `
      <div class="intel-answer">
        <div class="intel-answer-title">${a.label} — averaged across 5 batches at ${StabilityEngine.conditionLabel(condition)}</div>
        <div class="intel-answer-stat">Rate: <strong>${StabilityEngine.formatRate(a.slope, a.unit)}</strong> · Projected at ${a.projectedMonth}mo: <strong>${a.projectedValue}${a.unit}</strong> · Spec: ${a.spec}</div>
        <div style="margin:8px 0;"><span class="badge-status" style="background:${statusColor}22;color:${statusColor};">${statusLabel}</span></div>
        ${chart}
        <div class="intel-answer-note">Fit R² = ${a.r2.toFixed(3)} · last observed value ${a.lastValue}${a.unit} @ ${a.lastMonth}mo</div>
      </div>
    `;
  },

  _answerBatchTrend(attrKey, condition, batch) {
    const meta = stabilityMeta[attrKey];
    const series = StabilityEngine.getSeries(condition, batch, attrKey);
    if (series.length === 0) return `<div>No data for ${batch} on that attribute at ${StabilityEngine.conditionLabel(condition)}.</div>`;
    const reg = StabilityEngine.linearRegression(series);
    const chart = Charts.lineChart({
      series: [{ name: batch, color: Charts.batchColors[batch], points: series }],
      specLow: meta.low, specHigh: meta.high, unit: meta.unit, height: 180
    });
    return `
      <div class="intel-answer">
        <div class="intel-answer-title">${meta.label} — ${batch} at ${StabilityEngine.conditionLabel(condition)}</div>
        <div class="intel-answer-stat">Rate: <strong>${StabilityEngine.formatRate(reg.slope, meta.unit)}</strong> · Spec: ${meta.range}</div>
        ${chart}
      </div>
    `;
  },

  _answerFastestBatch(attrKey, condition) {
    const meta = stabilityMeta[attrKey];
    const worseIsHigh = !(meta.high === null || meta.high === undefined) || attrKey === 'purityHMW' || attrKey === 'chargeAcidic';
    const fastest = StabilityEngine.fastestBatch(attrKey, condition, worseIsHigh !== false);
    if (!fastest) return `<div>Not enough data to compare batches for that attribute.</div>`;
    const chart = Charts.lineChart({
      series: Charts.buildBatchSeries(attrKey, condition),
      specLow: meta.low, specHigh: meta.high, unit: meta.unit, height: 200
    });
    return `
      <div class="intel-answer">
        <div class="intel-answer-title">${meta.label} — rate comparison across all batches at ${StabilityEngine.conditionLabel(condition)}</div>
        <div class="intel-answer-stat"><strong>${fastest.batch}</strong> shows the steepest trend: ${StabilityEngine.formatRate(fastest.slope, meta.unit)}</div>
        ${chart}
      </div>
    `;
  },

  _answerBatchComparisonChart(attrKey, condition) {
    const meta = stabilityMeta[attrKey];
    const chart = Charts.lineChart({
      series: Charts.buildBatchSeries(attrKey, condition),
      specLow: meta.low, specHigh: meta.high, unit: meta.unit, height: 210
    });
    return `
      <div class="intel-answer">
        <div class="intel-answer-title">${meta.label} — all 5 batches at ${StabilityEngine.conditionLabel(condition)}</div>
        <div class="intel-answer-stat">Spec: ${meta.range} · Method: ${meta.method}</div>
        ${chart}
      </div>
    `;
  },

  _answerSpecMargin(attrKey, condition, targetMonth) {
    const a = StabilityEngine.analyzeAttribute(attrKey, condition, targetMonth);
    if (!a) return `<div>Insufficient data for spec-margin projection on that attribute.</div>`;
    const statusColor = { ok: 'var(--green)', warn: 'var(--orange)', fail: 'var(--red)' }[a.status] || 'var(--ink-3)';
    const statusLabel = { ok: 'Within spec', warn: 'Approaching limit', fail: 'Out of spec' }[a.status] || 'N/A';
    const chart = Charts.lineChart({
      series: [{ name: 'Avg (n=5 batches)', color: 'var(--accent)', points: a.series }],
      specLow: a.specLow, specHigh: a.specHigh, unit: a.unit, height: 190
    });
    return `
      <div class="intel-answer">
        <div class="intel-answer-title">${a.label} — spec margin at ${targetMonth} months (${StabilityEngine.conditionLabel(condition)})</div>
        <div class="intel-answer-stat">Projected: <strong>${a.projectedValue}${a.unit}</strong> vs spec ${a.spec} → <span style="color:${statusColor};font-weight:600;">${statusLabel}</span></div>
        ${chart}
      </div>
    `;
  },

  _answerArrhenius() {
    const check = StabilityEngine.checkArrheniusLinearity('purityHMW');
    const chart = Charts.lineChart({
      series: [{ name: 'HMW @ 40°C (avg)', color: 'var(--orange)', points: check.series }],
      unit: '%', height: 180
    });
    return `
      <div class="intel-answer">
        <div class="intel-answer-title">Arrhenius validity check — HMW kinetics at 40°C</div>
        <div class="intel-answer-stat">Linear fit R² = <strong>${check.r2.toFixed(3)}</strong> → ${check.linear ? '<span style="color:var(--green);font-weight:600;">Near-linear</span> — Arrhenius may be used as supporting evidence' : '<span style="color:var(--red);font-weight:600;">Non-linear</span> — do not rely on Arrhenius as a primary argument (see JUS-B-orig precedent)'}</div>
        ${chart}
        <div class="intel-answer-note">Cross-referenced against Memory Graph learning LEARN:JUS-B-01 — Arrhenius Extrapolation Limits.</div>
      </div>
    `;
  },

  _answerCoverage() {
    const c = StabilityEngine.coverageSummary();
    return `
      <div class="intel-answer">
        <div class="intel-answer-title">mAb-Y stability data coverage</div>
        <div class="intel-answer-stat">
          Long-term 5°C: <strong>${c.longTerm5C} months</strong> · Long-term 25°C: <strong>${c.longTerm25C} months</strong> · Accelerated 40°C: <strong>${c.accelerated40C} months</strong><br>
          Batches: <strong>${c.batchCount}</strong> (B1–B5) · CQAs tracked: <strong>${c.cqaCount}</strong>
        </div>
        <div class="intel-answer-note">Source: Monoclonal Antibody Stability Data (5 Batches), integrated into the Memory Graph as mAb-Y's registered batch data.</div>
      </div>
    `;
  }
};

if (typeof module !== 'undefined') {
  module.exports = Intelligence;
}
