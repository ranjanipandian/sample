/**
 * app.js — Router, sidebar builder, state manager for Memory Graph Virtual Lab
 * Uses original seedData from memory-graph_11
 */
class MemoryGraphApp {
  constructor() {
    this.state = {
      currentScreen: 0,
      product: graphDB.data.products.find(p => p.id === 'mAb-Y'),
      evidence: null,
      hedges: null,
      theme: localStorage.getItem('mg_theme') || 'light',
      sidebarOpen: true,
      users: [
        { name: 'Admin User', email: 'admin@memorygraph.dev', role: 'Administrator' },
        { name: 'Sarah Chen', email: 'sarah.chen@memorygraph.dev', role: 'Principal Investigator' }
      ],
      currentUserIndex: 1
    };


    window.addEventListener('popstate', (e) => {
      if (e.state && typeof e.state.screen !== 'undefined') {
        this.navigate(e.state.screen, false);
      }
    });

    document.addEventListener('click', (e) => {
      const wrap = document.getElementById('user-menu-wrap');
      const dropdown = document.getElementById('user-menu-dropdown');
      if (!wrap || !dropdown) return;
      if (dropdown.style.display === 'block' && !wrap.contains(e.target)) {
        dropdown.style.display = 'none';
      }
    });
  }

  init() {
    document.documentElement.setAttribute('data-theme', this.state.theme);
    this._buildSidebar();
    this._updateUserBar();
    this.navigate(0, false);
  }


  // ── Navigation ──
  navigate(screenNumber, pushHistory = true) {
    this.state.currentScreen = screenNumber;

    if (pushHistory) {
      history.pushState({ screen: screenNumber }, `Screen ${screenNumber}`, `?screen=${screenNumber}`);
    }

    this.render();
    this._updateSidebarActive();
  }

  render() {
    const container = document.getElementById('screen-container');
    if (!container) return;

    container.style.animation = 'none';
    container.offsetHeight;
    container.style.animation = 'fadeIn 0.18s ease';

    switch (this.state.currentScreen) {
      case 0: container.innerHTML = screens.renderHome(this.state); break;
      case 'users': container.innerHTML = screens.renderUsers(this.state); break;
      case 'drug-substance': container.innerHTML = screens.renderDrugSubstance(this.state); break;
      case 'cmc':
      case 'cmc-ds': container.innerHTML = screens.renderCmc(this.state); break;


      case 1: container.innerHTML = screens.renderScreen1(this.state); break;
      case 2: container.innerHTML = screens.renderScreen2(this.state); break;
      case 3: container.innerHTML = screens.renderScreen3(this.state); break;
      case 4: container.innerHTML = screens.renderScreen4(this.state); break;
      case 5: container.innerHTML = screens.renderScreen5(this.state); break;
      case 6: container.innerHTML = screens.renderScreen6(this.state); break;
      default: container.innerHTML = `<div class="page-shell"><p>Screen not found.</p></div>`;
    }

    // Animate attribute bars after render
    setTimeout(() => {
      document.querySelectorAll('.attr-bar-fill').forEach(bar => {
        const pct = bar.getAttribute('data-pct');
        if (pct) bar.style.width = pct + '%';
      });
    }, 60);
  }

  // ── Sidebar Builder ──
  _buildSidebar() {
    const projectsEl = document.getElementById('sidebar-projects');
    if (!projectsEl) return;

    // Projects list in sidebar
    projectsEl.innerHTML = `
      <div class="sidebar-project-group">
        <div class="sidebar-project-header" id="sb-maby-header" onclick="app._toggleProject('maby')">
          <svg class="sidebar-project-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
          <span class="sidebar-project-name">mAb-Y (anti-HER2)</span>
          <svg class="sidebar-project-arrow open" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
        <div id="sb-maby-steps">
          <div class="sidebar-section-label" style="padding-left:30px;">WORKFLOW (6)</div>
          <div class="sidebar-step-item" id="ss-1" onclick="app.navigate(1)"><span class="step-dot"></span>01 Entry</div>
          <div class="sidebar-step-item" id="ss-2" onclick="app.navigate(2)"><span class="step-dot"></span>02 Risk Framing</div>
          <div class="sidebar-step-item" id="ss-3" onclick="app.navigate(3)"><span class="step-dot"></span>03 Extrapolation</div>
          <div class="sidebar-step-item" id="ss-4" onclick="app.navigate(4)"><span class="step-dot"></span>04 Evidence</div>
          <div class="sidebar-step-item" id="ss-5" onclick="app.navigate(5)"><span class="step-dot"></span>05 Writeback</div>
          <div class="sidebar-step-item" id="ss-6" onclick="app.navigate(6)"><span class="step-dot"></span>06 Value Impact</div>
        </div>
      </div>

      <div class="sidebar-project-group">
        <div class="sidebar-project-header" style="opacity:0.6;cursor:default;">
          <svg class="sidebar-project-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
          <span class="sidebar-project-name">mAb-X (anti-CD20)</span>
        </div>
      </div>

      <div class="sidebar-project-group">
        <div class="sidebar-project-header" style="opacity:0.6;cursor:default;">
          <svg class="sidebar-project-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          <span class="sidebar-project-name">mAb-Z</span>
        </div>
      </div>
    `;
  }

  _toggleProject(key) {
    const steps = document.getElementById(`sb-${key}-steps`);
    const header = document.getElementById(`sb-${key}-header`);
    const arrow = header ? header.querySelector('.sidebar-project-arrow') : null;
    if (steps) steps.style.display = steps.style.display === 'none' ? '' : 'none';
    if (arrow) arrow.classList.toggle('open');
  }

  _updateSidebarActive() {
    // Clear active states
    document.querySelectorAll('.sidebar-item, .sidebar-step-item, .sidebar-project-header, .pipeline-item').forEach(el => {
      el.classList.remove('active', 'active-pipe', 'active-project');
    });

    const s = this.state.currentScreen;

    if (s === 0) {
      const el = document.getElementById('sb-home');
      if (el) el.classList.add('active');
    } else if (s === 'users') {
      const el = document.getElementById('sb-users');
      if (el) el.classList.add('active');
    } else if (s === 'cmc' || s === 'cmc-ds') {

      const el = document.getElementById('sb-cmc');
      if (el) el.classList.add('active');
      const pipeline = document.getElementById('cmc-pipeline');
      if (pipeline) pipeline.style.display = 'flex';

      if (s === 'cmc-ds') {
        const dsItem = document.getElementById('sb-drug-substance');
        if (dsItem) dsItem.classList.add('active-pipe');
        const projs = document.getElementById('sidebar-projects');
        if (projs) projs.style.display = 'block';
      }
    } else if (s === 'drug-substance') {
      const pipeline = document.getElementById('cmc-pipeline');
      if (pipeline) pipeline.style.display = 'flex';
      const dsItem = document.getElementById('sb-drug-substance');
      if (dsItem) dsItem.classList.add('active-pipe');
      const projs = document.getElementById('sidebar-projects');
      if (projs) projs.style.display = 'block';
    } else if (s >= 1 && s <= 6) {

      const el = document.getElementById(`ss-${s}`);
      if (el) el.classList.add('active');
      const hdr = document.getElementById('sb-maby-header');
      if (hdr) hdr.classList.add('active-project');
      const pipeline = document.getElementById('cmc-pipeline');
      if (pipeline) pipeline.style.display = 'flex';
      const dsItem = document.getElementById('sb-drug-substance');
      if (dsItem) dsItem.classList.add('active-pipe');
      const projs = document.getElementById('sidebar-projects');
      if (projs) projs.style.display = 'block';
      const steps = document.getElementById('sb-maby-steps');
      if (steps) steps.style.display = 'block';
    }
  }

  // ── UI Actions ──
  openCmc() {
    const pipeline = document.getElementById('cmc-pipeline');
    if (pipeline) pipeline.style.display = 'flex';
    this.navigate('cmc');
  }

  openDrugSubstance() {
    const pipeline = document.getElementById('cmc-pipeline');
    if (pipeline) pipeline.style.display = 'flex';
    const projs = document.getElementById('sidebar-projects');
    if (projs) projs.style.display = 'block';
    this.navigate('drug-substance');
  }


  openDrugProduct() {
    const pipeline = document.getElementById('cmc-pipeline');
    if (pipeline) pipeline.style.display = 'flex';
    this.navigate('cmc');
  }

  toggleCmc() {
    this.openCmc();
  }

  showDrugSubstance() {
    this.openDrugSubstance();
  }

  // ── User Management ──
  openUserManagement() {
    this.navigate('users');
  }

  openAddUserModal() {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.onclick = () => overlay.remove();
    overlay.innerHTML = `
      <div class="modal" onclick="event.stopPropagation()" style="max-width:420px;">
        <div class="modal-head">
          <h4>Add User</h4>
          <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div class="field-label">Name</div>
          <input type="text" id="new-user-name" placeholder="e.g. Jane Smith" style="width:100%;border:1px solid var(--border);border-radius:6px;padding:8px 10px;font-size:13px;margin-top:4px;">

          <div class="field-label">Email</div>
          <input type="email" id="new-user-email" placeholder="e.g. jane.smith@memorygraph.dev" style="width:100%;border:1px solid var(--border);border-radius:6px;padding:8px 10px;font-size:13px;margin-top:4px;">

          <div class="field-label">Business Role</div>
          <select id="new-user-role" style="width:100%;border:1px solid var(--border);border-radius:6px;padding:8px 10px;font-size:13px;margin-top:4px;background:var(--surface);color:var(--ink);">
            <option value="Administrator">Administrator</option>
            <option value="Principal Investigator">Principal Investigator</option>
          </select>

          <button class="btn-primary" style="width:100%;margin-top:20px;" onclick="app.addUser()">Add User</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
  }

  addUser() {
    const nameEl = document.getElementById('new-user-name');
    const emailEl = document.getElementById('new-user-email');
    const roleEl = document.getElementById('new-user-role');
    const name = (nameEl?.value || '').trim();
    const email = (emailEl?.value || '').trim();
    const role = roleEl?.value || 'Administrator';

    if (!name || !email) {
      alert('Please enter both name and email.');
      return;
    }

    this.state.users.push({ name, email, role });
    document.querySelector('.modal-overlay')?.remove();
    this.render();
  }

  deleteUser(index) {
    if (confirm('Remove this user?')) {
      this.state.users.splice(index, 1);
      this.render();
    }
  }


  toggleSidebar() {
    this.state.sidebarOpen = !this.state.sidebarOpen;
    const sidebar = document.getElementById('sidebar');
    const main = document.getElementById('main-content');
    if (sidebar) sidebar.classList.toggle('collapsed', !this.state.sidebarOpen);
    if (main) main.style.marginLeft = this.state.sidebarOpen ? 'var(--sidebar-width)' : '0';
  }

  toggleTheme() {
    this.state.theme = this.state.theme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', this.state.theme);
    localStorage.setItem('mg_theme', this.state.theme);
  }

  // ── User Switcher Dropdown ──
  _updateUserBar() {
    const user = this.state.users[this.state.currentUserIndex] || this.state.users[0];
    if (!user) return;
    const nameEl = document.getElementById('user-name-label');
    const roleEl = document.getElementById('user-role-label');
    const letterEl = document.getElementById('user-avatar-letter');
    if (nameEl) nameEl.textContent = user.name;
    if (roleEl) roleEl.textContent = user.role;
    if (letterEl) letterEl.textContent = user.name.charAt(0).toUpperCase();
  }

  toggleUserMenu(e) {
    if (e) e.stopPropagation();
    const dropdown = document.getElementById('user-menu-dropdown');
    if (!dropdown) return;
    const isOpen = dropdown.style.display === 'block';
    if (isOpen) {
      dropdown.style.display = 'none';
      return;
    }
    const current = this.state.users[this.state.currentUserIndex] || this.state.users[0];
    dropdown.innerHTML = `
      <div class="user-menu-current">
        <div class="user-menu-current-name">${current.name}</div>
        <div class="user-menu-current-email">${current.email}</div>
        <span class="user-menu-current-role">${current.role}</span>
      </div>
      <div class="user-menu-list">
        ${this.state.users.map((u, i) => `
          <div class="user-menu-item ${i === this.state.currentUserIndex ? 'active-user' : ''}" onclick="app.switchUser(${i})">
            <div class="user-menu-item-av">${u.name.charAt(0).toUpperCase()}</div>
            <div>
              <div class="user-menu-item-name">${u.name}</div>
              <div class="user-menu-item-role">${u.role}</div>
            </div>
          </div>
        `).join('')}
      </div>
      <div class="user-menu-divider"></div>
      <div class="user-menu-footer">
        <div class="user-menu-manage-btn" onclick="app.openUserManagement();document.getElementById('user-menu-dropdown').style.display='none';">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M20 8v6"/><path d="M23 11h-6"/></svg>
          Manage Users
        </div>
      </div>
    `;
    dropdown.style.display = 'block';
  }

  switchUser(index) {
    this.state.currentUserIndex = index;
    this._updateUserBar();
    const dropdown = document.getElementById('user-menu-dropdown');
    if (dropdown) dropdown.style.display = 'none';
  }


  toggleCheck(id) {
    const allItems = [...(this.state.evidence || []), ...(this.state.hedges || [])];
    const item = allItems.find(i => i.id === id);
    if (item) { item.checked = !item.checked; this.render(); }
  }

  renderCitations(text) {
    return (text || '').replace(/\[([^\]]+)\]/g, (match, key) => {
      return `<span class="prov" onclick="app.showCitation('${key}')">${key}</span>`;
    });
  }

  showCitation(key) {
    const citation = graphDB.getCitation(key);
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.onclick = () => overlay.remove();
    overlay.innerHTML = `
      <div class="modal" onclick="event.stopPropagation()">
        <div class="modal-head">
          <h4>Memory Graph Precedent — ${key}</h4>
          <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div class="field-label">Document Key</div>
          <div class="field-value mono"><strong>${key}</strong></div>
          <div class="field-label">Registry Source</div>
          <div class="field-value">${citation.source}</div>
          <div class="field-label">Document Title</div>
          <div class="field-value">${citation.title}</div>
          <div class="field-label">Precedent Logic</div>
          <div class="field-quote">${citation.text}</div>
          <div style="margin-top:16px;display:flex;justify-content:space-between;align-items:center;">
            <span class="badge-status ${citation.status === 'Accepted' ? 'approved' : 'rejected'}">${citation.status}</span>
            <button class="btn-outline" onclick="this.closest('.modal-overlay').remove()">Dismiss</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
  }

  triggerWriteback() {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';

    graphDB.writeBackReasoning({
      id: "JUS-mAb-Y-001",
      productId: "mAb-Y",
      regulator: "EMA",
      proposed_shelf_life: "36 months",
      paragraphs: {
        5: "Linear regression on 18 months of long-term stability data at 5°C projects HMW aggregation to 3.9% at 36 months.",
        6: "Arrhenius extrapolation from accelerated data provides orthogonal confirmation of the 36-month shelf-life claim."
      },
      new_learnings: [{
        id: "LEARN:mAb-Y-01",
        title: "Proactive OOT deamidation disclosures reduce assessor follow-ups.",
        source: "JUS-mAb-Y-001",
        applicableTo: "IgG1 deamidation justifications"
      }]
    });

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.onclick = () => overlay.remove();
    overlay.innerHTML = `
      <div class="modal" onclick="event.stopPropagation()" style="max-width:420px;">
        <div class="modal-head">
          <h4 style="color:var(--green);">✓ Reasoning Captured to Memory Graph</h4>
          <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div style="text-align:center;padding:20px 0;">
            <div style="font-size:48px;margin-bottom:12px;">🧬</div>
            <div style="font-size:15px;font-weight:600;color:var(--ink);margin-bottom:8px;">17 reasoning triples written back</div>
            <div style="font-size:13px;color:var(--ink-3);">JUS-mAb-Y-001 · mAb-Y · 36 months at 2–8°C</div>
            <div style="font-size:12px;color:var(--ink-4);margin-top:6px;font-family:var(--font-mono);">Asserted by Scientist · ${timestamp}</div>
          </div>
          <button class="btn-primary" style="width:100%;margin-top:8px;" onclick="this.closest('.modal-overlay').remove();app.navigate(6)">
            View Value Impact →
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
  }

  resetDB() {
    if (confirm("Reset the Memory Graph database back to original seed precedents?")) {
      graphDB.resetGraph();
      this.state.evidence = null;
      this.state.hedges = null;
      this.navigate(0);
    }
  }
}

const app = new MemoryGraphApp();
window.addEventListener('DOMContentLoaded', () => app.init());
