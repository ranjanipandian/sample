/**
 * charts.js
 * Lightweight, dependency-free SVG line-chart renderer for stability trend visualization.
 */
const Charts = {

  /**
   * Render a multi-series SVG line chart.
   * @param {Object} opts
   *   series: [{ name, color, points: [{month, value}] }]
   *   width, height
   *   specLow, specHigh (optional horizontal reference lines)
   *   unit
   *   title
   */
  lineChart(opts) {
    const {
      series = [],
      width = 560,
      height = 220,
      specLow = null,
      specHigh = null,
      unit = '',
      yLabel = ''
    } = opts;

    const padL = 46, padR = 16, padT = 16, padB = 30;
    const innerW = width - padL - padR;
    const innerH = height - padT - padB;

    const allPoints = series.flatMap(s => s.points);
    if (allPoints.length === 0) {
      return `<div style="font-size:12px;color:var(--ink-4);padding:20px;text-align:center;">No data available.</div>`;
    }

    const months = allPoints.map(p => p.month);
    const values = allPoints.map(p => p.value);
    let minY = Math.min(...values);
    let maxY = Math.max(...values);
    if (specLow !== null && specLow !== undefined) minY = Math.min(minY, specLow);
    if (specHigh !== null && specHigh !== undefined) maxY = Math.max(maxY, specHigh);
    const rangeY = (maxY - minY) || 1;
    minY -= rangeY * 0.12;
    maxY += rangeY * 0.12;

    const minX = 0;
    const maxX = Math.max(...months, 1);

    const xScale = (m) => padL + (maxX === minX ? 0 : (m - minX) / (maxX - minX)) * innerW;
    const yScale = (v) => padT + innerH - ((v - minY) / (maxY - minY)) * innerH;

    let svg = `<svg viewBox="0 0 ${width} ${height}" width="100%" height="${height}" style="overflow:visible;font-family:var(--font);">`;

    // Grid lines (horizontal, 4 divisions)
    const gridCount = 4;
    for (let i = 0; i <= gridCount; i++) {
      const v = minY + (maxY - minY) * (i / gridCount);
      const y = yScale(v);
      svg += `<line x1="${padL}" y1="${y}" x2="${width - padR}" y2="${y}" stroke="var(--border)" stroke-width="1" />`;
      svg += `<text x="${padL - 8}" y="${y + 3}" font-size="10" fill="var(--ink-4)" text-anchor="end">${v.toFixed(1)}</text>`;
    }

    // Spec boundary lines
    if (specLow !== null && specLow !== undefined) {
      const y = yScale(specLow);
      svg += `<line x1="${padL}" y1="${y}" x2="${width - padR}" y2="${y}" stroke="var(--red)" stroke-width="1.4" stroke-dasharray="4,3" />`;
      svg += `<text x="${width - padR}" y="${y - 4}" font-size="9" fill="var(--red)" text-anchor="end">Spec Low ${specLow}</text>`;
    }
    if (specHigh !== null && specHigh !== undefined) {
      const y = yScale(specHigh);
      svg += `<line x1="${padL}" y1="${y}" x2="${width - padR}" y2="${y}" stroke="var(--red)" stroke-width="1.4" stroke-dasharray="4,3" />`;
      svg += `<text x="${width - padR}" y="${y - 4}" font-size="9" fill="var(--red)" text-anchor="end">Spec High ${specHigh}</text>`;
    }

    // X axis labels (months)
    const uniqueMonths = [...new Set(months)].sort((a, b) => a - b);
    uniqueMonths.forEach(m => {
      const x = xScale(m);
      svg += `<text x="${x}" y="${height - 8}" font-size="10" fill="var(--ink-4)" text-anchor="middle">${m}mo</text>`;
    });

    // Series lines + points
    series.forEach(s => {
      const pts = [...s.points].sort((a, b) => a.month - b.month);
      if (pts.length === 0) return;
      const pathD = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${xScale(p.month)} ${yScale(p.value)}`).join(' ');
      svg += `<path d="${pathD}" fill="none" stroke="${s.color}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" />`;
      pts.forEach(p => {
        svg += `<circle cx="${xScale(p.month)}" cy="${yScale(p.value)}" r="3" fill="${s.color}" stroke="var(--surface)" stroke-width="1.2">
          <title>${s.name}: ${p.value}${unit} @ ${p.month}mo</title>
        </circle>`;
      });
    });

    svg += `</svg>`;

    // Legend
    const legend = series.map(s => `
      <span style="display:inline-flex;align-items:center;gap:5px;margin-right:14px;font-size:11px;color:var(--ink-3);">
        <span style="width:9px;height:9px;border-radius:50%;background:${s.color};display:inline-block;"></span>${s.name}
      </span>
    `).join('');

    return `
      <div>
        ${svg}
        <div style="margin-top:6px;display:flex;flex-wrap:wrap;">${legend}</div>
      </div>
    `;
  },

  /** Color palette for up to 5 batches */
  batchColors: {
    B1: '#1259AE',
    B2: '#16A34A',
    B3: '#D97706',
    B4: '#7C3AED',
    B5: '#DC2626'
  },

  /** Build series array for all batches for a given attribute + condition */
  buildBatchSeries(attrKey, condition) {
    return StabilityEngine.BATCHES.map(b => ({
      name: b,
      color: this.batchColors[b],
      points: StabilityEngine.getSeries(condition, b, attrKey)
    })).filter(s => s.points.length > 0);
  }
};

if (typeof module !== 'undefined') {
  module.exports = Charts;
}
