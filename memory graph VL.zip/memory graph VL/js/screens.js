/**
 * screens.js — Renderers for all screens
 * Uses seedData from data/seed.js (mAb products, justifications, learnings)
 */
const screens = {

  // ══════════════════════════════════════════
  // USER MANAGEMENT
  // ══════════════════════════════════════════
  renderUsers(state) {
    const users = state.users || [];
    const roleColors = {
      'Administrator': { bg: '#EDE9FE', color: '#7C3AED' },
      'Principal Investigator': { bg: '#DBEAFE', color: '#1D4ED8' }
    };
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← All Projects</span>
          <span class="bc-sep">/</span>
          <span>User Management</span>
        </div>

        <div class="page-header">
          <h1>User Management</h1>
          <p class="page-desc">Manage users available for project onboarding.</p>
        </div>

        <button class="btn-primary" style="margin-bottom:20px;" onclick="app.openAddUserModal()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add User
        </button>

        <div class="data-table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Business Role</th>
                <th style="text-align:right;">Actions</th>
              </tr>
            </thead>
            <tbody>
              ${users.map((u, i) => {
                const rc = roleColors[u.role] || { bg: '#F3F4F6', color: '#374151' };
                return `
                <tr>
                  <td style="display:flex;align-items:center;gap:8px;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    <strong>${u.name}</strong>
                  </td>
                  <td>${u.email}</td>
                  <td><span class="badge-status" style="background:${rc.bg};color:${rc.color};text-transform:lowercase;">${u.role}</span></td>
                  <td style="text-align:right;">
                    <button class="icon-btn" style="width:30px;height:30px;border-radius:6px;background:#111827;color:#fff;" onclick="app.deleteUser(${i})" title="Delete user">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                  </td>
                </tr>
              `;}).join('')}
              ${users.length === 0 ? `<tr><td colspan="4" style="text-align:center;color:var(--ink-4);padding:24px;">No users yet. Click "Add User" to create one.</td></tr>` : ''}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // DRUG SUBSTANCE MANUFACTURING — Pipeline/Batch Screen
  // ══════════════════════════════════════════
  renderDrugSubstance(state) {
    const icon = (path, extra) => `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${path}</svg>`;
    const ICONS = {
      snowflake: icon(`<line x1="12" y1="2" x2="12" y2="22"/><line x1="17" y1="4.5" x2="7" y2="19.5"/><line x1="17" y1="19.5" x2="7" y2="4.5"/>`),
      flask: icon(`<path d="M9 2h6"/><path d="M10 2v6.4a2 2 0 0 1-.4 1.2L5 16a3 3 0 0 0 2.4 4.8h9.2A3 3 0 0 0 19 16l-4.6-6.4A2 2 0 0 1 14 8.4V2"/>`),
      battery: icon(`<rect x="3" y="7" width="15" height="10" rx="1"/><line x1="21" y1="10" x2="21" y2="14"/><rect x="6" y="10" width="4" height="4" fill="currentColor" stroke="none"/>`),
      bioreactor: icon(`<path d="M6 3h12"/><path d="M6 3v6l-2 9a2 2 0 0 0 2 2.5h12A2 2 0 0 0 20 18l-2-9V3"/><line x1="6" y1="12" x2="18" y2="12"/>`),
      sparkle: icon(`<path d="M12 3v4"/><path d="M12 17v4"/><path d="M3 12h4"/><path d="M17 12h4"/><path d="M5.6 5.6l2.8 2.8"/><path d="M15.6 15.6l2.8 2.8"/><path d="M5.6 18.4l2.8-2.8"/><path d="M15.6 8.4l2.8-2.8"/>`),
      funnel: icon(`<polygon points="4 4 20 4 14 12 14 19 10 21 10 12 4 4"/>`),
      dna: icon(`<path d="M8 3s0 4 4 4 4-4 4-4"/><path d="M8 21s0-4 4-4 4 4 4 4"/><path d="M8 3c0 8 8 10 8 18"/><path d="M16 3c0 8-8 10-8 18"/>`),
      gear: icon(`<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9A1.65 1.65 0 0 0 10 3.09V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>`),
      droplet: icon(`<path d="M12 2.7s5.5 6.5 5.5 10.5a5.5 5.5 0 1 1-11 0C6.5 9.2 12 2.7 12 2.7z"/>`)
    };
    const usp = [
      { icon: ICONS.snowflake, name: 'Vial Thaw', status: 'green' },
      { icon: ICONS.flask, name: 'Seed Flask (n=4)', status: 'orange' },
      { icon: ICONS.battery, name: 'Seed Bioreactor (n=3)', status: 'orange' },
      { icon: ICONS.bioreactor, name: 'Production Bioreactor', status: 'red' },
      { icon: ICONS.sparkle, name: 'New!', status: 'red' }
    ];
    const dsp = [
      { icon: ICONS.funnel, name: 'Clarification', status: 'green' },
      { icon: ICONS.dna, name: 'Protein A Capture', status: 'green', active: true },
      { icon: ICONS.gear, name: 'Virus Inactivation', status: 'orange' },
      { icon: ICONS.flask, name: 'IEX Polishing', status: 'green' },
      { icon: ICONS.bioreactor, name: 'Virus Filtration', status: 'orange' },
      { icon: ICONS.flask, name: 'UF/DF', status: 'green' },
      { icon: ICONS.droplet, name: 'Excipient Addition', status: 'orange' }
    ];
    const dotColor = { green: '#16A34A', orange: '#D97706', red: '#DC2626', blue: '#1D4ED8' };

    const batches = [
      { id: 'BY-2024-001', status: 'Completed', color: 'green' },
      { id: 'BY-2024-002', status: 'Completed', color: 'green' },
      { id: 'BY-2024-003', status: 'Completed', color: 'green' },
      { id: 'BY-2024-004', status: 'Stability Ongoing', color: 'orange' },
      { id: 'BY-2024-005', status: 'Active', color: 'blue' }
    ];

    const stepCard = (s) => `
      <div style="background:#FFF;border:1px solid ${s.active ? '#1D4ED8' : '#D1D5DB'};border-radius:6px;padding:8px 10px;min-width:104px;flex-shrink:0;${s.active ? 'background:#1D4ED8;' : ''}">
        <div style="margin-bottom:4px;${s.active ? 'filter:brightness(0) invert(1);' : 'color:#374151;'}">${s.icon}</div>
        <div style="font-size:11px;font-weight:600;color:${s.active ? '#FFF' : '#111827'};margin-bottom:4px;line-height:1.2;">${s.name}</div>
        ${s.active ? `<div style="font-size:9px;font-weight:700;color:#FFF;letter-spacing:0.05em;margin-bottom:4px;">ACTIVE</div>` : ''}
        <div style="width:7px;height:7px;border-radius:50%;background:${dotColor[s.status]};"></div>
      </div>
    `;
    const arrow = `<div style="display:flex;align-items:center;color:#9CA3AF;flex-shrink:0;padding:0 2px;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></div>`;

    return `
      <div class="page-shell" style="padding:16px 32px;max-width:1280px;height:calc(100vh - var(--topbar-h) - 32px);display:flex;flex-direction:column;overflow:hidden;">
        <div class="breadcrumb" style="margin-bottom:8px;">
          <span class="bc-link" onclick="app.navigate(0)">← All Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.openCmc()">Process Dev</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.openCmc()">CMC</span>
          <span class="bc-sep">/</span>
          <span>Drug Substance Manufacturing</span>
        </div>

        <div class="page-header" style="margin-bottom:6px;">
          <h1 style="font-size:20px;margin:0;">Drug Substance Manufacturing</h1>
        </div>

        <div style="font-size:13px;color:#4B5563;margin-bottom:10px;">
          <strong>PI:</strong> Sarah Chen &nbsp;•&nbsp; <strong>Product:</strong> mAb-Y (anti-HER2) &nbsp;•&nbsp; <strong>Objective:</strong> Prepare 36-month shelf-life justification
        </div>

        <div style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap;">
          <div style="display:flex;align-items:center;gap:6px;background:#F0FDF4;border:1px solid #BBF7D0;border-radius:16px;padding:5px 14px;font-size:12px;font-weight:500;color:#166534;">
            <span style="width:7px;height:7px;border-radius:50%;background:#16A34A;"></span>5 Batches
          </div>
          <div style="display:flex;align-items:center;gap:6px;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:16px;padding:5px 14px;font-size:12px;font-weight:500;color:#1E40AF;">
            <span style="width:7px;height:7px;border-radius:50%;background:#1D4ED8;"></span>12 CQAs
          </div>
          <div style="display:flex;align-items:center;gap:6px;background:#F9FAFB;border:1px solid #E5E7EB;border-radius:16px;padding:5px 14px;font-size:12px;font-weight:500;color:#374151;">
            <span style="width:7px;height:7px;border-radius:50%;background:#9CA3AF;"></span>Storage Conditions
          </div>
          <div style="display:flex;align-items:center;gap:6px;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:16px;padding:5px 14px;font-size:12px;font-weight:500;color:#1E40AF;">
            <span style="width:7px;height:7px;border-radius:50%;background:#1D4ED8;"></span>24 Months Data
          </div>
        </div>

        <div style="font-size:11px;font-weight:700;letter-spacing:0.05em;color:#374151;text-transform:uppercase;border-bottom:1px solid #E5E7EB;padding-bottom:5px;margin-bottom:8px;">Upstream Processing (USP)</div>
        <div style="display:flex;align-items:center;margin-bottom:14px;">
          ${usp.map((s, i) => stepCard(s) + (i < usp.length - 1 ? arrow : '')).join('')}
        </div>

        <div style="font-size:11px;font-weight:700;letter-spacing:0.05em;color:#374151;text-transform:uppercase;border-bottom:1px solid #E5E7EB;padding-bottom:5px;margin-bottom:8px;">Downstream Processing (DSP)</div>
        <div style="display:flex;align-items:center;margin-bottom:14px;">
          ${dsp.map((s, i) => stepCard(s) + (i < dsp.length - 1 ? arrow : '')).join('')}
        </div>

        <div style="font-size:13px;font-weight:600;color:#111827;border-bottom:1px solid #E5E7EB;padding-bottom:6px;margin-bottom:4px;">Batch Progress</div>
        <div style="flex:1;min-height:0;overflow:hidden;margin-bottom:10px;">
          ${batches.map(b => `
            <div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid #F3F4F6;font-size:13px;">
              <span style="width:7px;height:7px;border-radius:50%;background:${dotColor[b.color]};flex-shrink:0;"></span>
              <span style="color:#111827;font-weight:500;min-width:140px;">Batch ${b.id}</span>
              <span style="width:7px;height:7px;border-radius:50%;background:${dotColor[b.color]};flex-shrink:0;"></span>
              <span style="color:${dotColor[b.color]};font-weight:500;">${b.status}</span>
            </div>
          `).join('')}
        </div>

        <div style="text-align:right;flex-shrink:0;">
          <button class="btn-primary" style="background:#1D4ED8;border-radius:6px;padding:10px 22px;font-weight:600;font-size:13px;" onclick="app.navigate(1)">Open Batch Workspace</button>
        </div>
      </div>
    `;
  },


  // ══════════════════════════════════════════
  // PROCESS DEV / CMC — 7 Stage Pipeline Screen
  // ══════════════════════════════════════════


  renderCmc(state) {
    const showDpProjects = state.currentScreen === 'cmc-ds' || state.showCmcProjects;
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← All Projects</span>
          <span class="bc-sep">/</span>
          <span>Process Dev / CMC</span>
        </div>

        <div class="page-header">
          <h1>Process Dev / CMC Pipeline</h1>
          <p class="page-desc">7-Stage Continuous Process Development & Manufacturing Pipeline. Select a pipeline stage to access its active project workflows.</p>
        </div>

        <div class="cmc-stages-grid">
          <!-- Stage 1 -->
          <div class="cmc-stage-card" onclick="app.openCmc()">
            <div class="cmc-stage-num">Stage 01</div>
            <div class="cmc-stage-header">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2"><path d="M10 2v7.31"/><path d="M14 9.3V1.99"/><path d="M8.5 2h7"/><path d="M14 9.3a6.5 6.5 0 1 1-4 0"/></svg>
              <div class="cmc-stage-title">Product & Process Design</div>
            </div>
            <div class="cmc-stage-desc">Target product profile formulation and early process window definition.</div>
            <span class="badge-status in-progress">In Progress</span>
          </div>

          <!-- Stage 2 — Drug Substance Manufacturing (Active / Interactive) -->
          <div class="cmc-stage-card active-stage" onclick="app.openDrugSubstance()">
            <div class="cmc-stage-num">Stage 02 — Active</div>
            <div class="cmc-stage-header">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2"><path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v16z"/></svg>
              <div class="cmc-stage-title">Drug Substance Manufacturing</div>
            </div>
            <div class="cmc-stage-desc">Upstream cell culture, harvest, downstream purification and bulk API storage.</div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px;">
              <span class="badge-status approved">3 Projects Available</span>
              <span style="font-size:12px;color:var(--accent);font-weight:600;">${showDpProjects ? 'Expanded ▲' : 'Click to View Projects ▼'}</span>
            </div>
          </div>

          <!-- Stage 3 -->
          <div class="cmc-stage-card" onclick="app.openCmc()">
            <div class="cmc-stage-num">Stage 03</div>
            <div class="cmc-stage-header">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" stroke-width="2"><path d="M18 2l4 4"/><path d="M17 7l-1-1"/><path d="M19 9l-1-1"/><path d="M20 6l1-1"/><path d="M16 8l-8 8"/><path d="M11.5 9.5l3 3"/><path d="M3 21l3-3"/><path d="M3 21l-1 1"/></svg>
              <div class="cmc-stage-title">Drug Product Manufacturing</div>
            </div>
            <div class="cmc-stage-desc">Compounding, sterile filtration, vial filling, lyophilization and finished DP stability.</div>
            <span class="badge-status draft">Not Started</span>
          </div>

          <!-- Stage 4 -->
          <div class="cmc-stage-card" onclick="app.openCmc()">
            <div class="cmc-stage-num">Stage 04</div>
            <div class="cmc-stage-header">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" stroke-width="2"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
              <div class="cmc-stage-title">Packaging & Labelling</div>
            </div>
            <div class="cmc-stage-desc">Primary & secondary container labeling, serialization and cold-chain carton packing.</div>
            <span class="badge-status draft">Not Started</span>
          </div>

          <!-- Stage 5 -->
          <div class="cmc-stage-card" onclick="app.openCmc()">
            <div class="cmc-stage-num">Stage 05</div>
            <div class="cmc-stage-header">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" stroke-width="2"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
              <div class="cmc-stage-title">Logistics / Distribution</div>
            </div>
            <div class="cmc-stage-desc">Cold-chain depot distribution, temperature monitoring, and global shipment validation.</div>
            <span class="badge-status draft">Not Started</span>
          </div>

          <!-- Stage 6 -->
          <div class="cmc-stage-card" onclick="app.openCmc()">
            <div class="cmc-stage-num">Stage 06</div>
            <div class="cmc-stage-header">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
              <div class="cmc-stage-title">Dispensing & Clinical Interface</div>
            </div>
            <div class="cmc-stage-desc">Hospital pharmacy preparation, IV bag compatibility, and clinical dosing guidelines.</div>
            <span class="badge-status draft">Not Started</span>
          </div>

          <!-- Stage 7 -->
          <div class="cmc-stage-card" onclick="app.openCmc()">
            <div class="cmc-stage-num">Stage 07</div>
            <div class="cmc-stage-header">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" stroke-width="2"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>
              <div class="cmc-stage-title">Tech Transfer to Manufacturing</div>
            </div>
            <div class="cmc-stage-desc">Commercial scale-up, validation batch execution and regulatory dossier handoff.</div>
            <span class="badge-status draft">Not Started</span>
          </div>
        </div>

        ${showDpProjects ? `
          <div style="margin-top:28px;" id="cmc-projects-section">
            <div class="section-title">Projects under Stage 02 — Drug Substance Manufacturing</div>
            <div class="projects-grid">
              <!-- mAb-Y — Active Project -->
              <div class="project-card" onclick="app.navigate(1)" style="border:2px solid var(--accent);background:var(--surface);">
                <div class="project-card-top">
                  <div class="project-card-name" style="color:var(--accent);">mAb-Y (anti-HER2)</div>
                  <span class="badge-status draft">In Draft (Active)</span>
                </div>
                <div class="project-card-desc">
                  Proposed 36-month shelf life justification at 2–8°C under active EMA MAA review. IgG1 · histidine pH 5.2 · 50 mg/mL · Type-I glass vial.
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;">
                  <span class="project-card-meta">Updated 2 days ago</span>
                  <button class="btn-primary" onclick="event.stopPropagation();app.navigate(1)">Launch Workflow →</button>
                </div>
              </div>


              <!-- mAb-X — Approved -->
              <div class="project-card disabled">
                <div class="project-card-top">
                  <div class="project-card-name">mAb-X (anti-CD20)</div>
                  <span class="badge-status approved">Approved</span>
                </div>
                <div class="project-card-desc">
                  24-month justification accepted by CHMP in 2022. Captured in graph as precedent JUS-A and JUS-C.
                </div>
                <div class="project-card-meta">Completed · Nov 2022</div>
              </div>

              <!-- mAb-Z — Precedent -->
              <div class="project-card disabled">
                <div class="project-card-top">
                  <div class="project-card-name">mAb-Z</div>
                  <span class="badge-status rejected">Rejected / Revised</span>
                </div>
                <div class="project-card-desc">
                  36-month FDA submission rejected on Arrhenius grounds, revised and accepted in Nov 2023.
                </div>
                <div class="project-card-meta">Completed · Nov 2023</div>
              </div>
            </div>
          </div>
        ` : ''}
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // HOME — All Projects
  // ══════════════════════════════════════════
  renderHome(state) {
    const db = graphDB.data;
    return `
      <div class="page-shell">
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: flex-end;">
          <div>
            <h1 style="font-size: 24px; font-weight: 500; margin-bottom: 2px;">Projects</h1>
          </div>
        </div>

        <div class="db-summary" style="background: #EBF3FC; border: 1px solid #C4DDFC; border-radius: 6px; padding: 22px 24px; margin-bottom: 24px; box-shadow: none;">
          <h2 style="font-size: 18px; font-weight: 500; color: #1E3A8A; margin-bottom: 12px; font-family: var(--font);">Memory Graph — Reasoning Substrate</h2>
          <div style="font-size: 13px; color: #1E3A8A; line-height: 1.5;">
            Reasoning across <strong>8 mAb programs</strong>, <strong>5 regulatory decisions</strong>, <strong>14 justification precedents</strong>, <strong>6 review memos</strong>
          </div>
        </div>

        <div class="action-bar" style="margin-bottom: 24px; border-bottom: 1px solid var(--border); padding-bottom: 16px;">
          <div class="action-bar-left" style="flex: 1;">
            <div class="search-box" style="width: 100%; max-width: 480px; border-radius: 4px; border: 1px solid #D1D5DB; background: #FFF;">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#6B7280" stroke-width="2" style="margin-right: 4px;"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input type="text" placeholder="Search projects..." style="font-size: 14px;">
            </div>
          </div>
          <div class="action-bar-right" style="gap: 12px;">
            <div style="display: flex; align-items: center; gap: 8px; border: 1px solid #D1D5DB; border-radius: 4px; padding: 4px 10px; background: #FFF; font-size: 14px;">
              <span style="color: #4B5563;">Sort:</span>
              <span style="font-weight: 500; color: #111827;">Recent</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#4B5563" stroke-width="2" style="margin-left: 4px;"><polyline points="6 9 12 15 18 9"/></svg>
            </div>
            <button class="btn-primary" onclick="app.navigate(1)" style="background: #1D4ED8; border-radius: 4px; padding: 8px 18px; font-weight: 500; font-size: 14px;">+ New Project</button>
          </div>
        </div>

        <div class="projects-grid">
          <!-- mAb-Y — In Draft (active) -->
          <div class="project-card" onclick="app.openDrugSubstance()" style="border-radius: 4px; border: 1px solid #D1D5DB; padding: 24px; min-height: 280px; display: flex; flex-direction: column; justify-content: space-between;">

            <div>
              <div class="project-card-top" style="margin-bottom: 16px;">
                <div class="project-card-name" style="font-size: 18px; font-weight: 600; color: #111827;">mAb-Y <span style="font-weight: 400; color: #4B5563; font-size: 16px;">(anti-HER2)</span></div>
                <span class="badge-status draft" style="background: #FFF3E0; color: #E65100; font-weight: 600; padding: 4px 12px; border-radius: 4px;">In Draft</span>
              </div>
              <div style="display: flex; flex-direction: column; gap: 12px; border-top: 1px solid #F3F4F6; padding-top: 12px;">
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Objective:</span><span style="color: #111827;">36-month shelf life</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">PI:</span><span style="color: #111827;">Sarah Chen</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Batches:</span><span style="color: #111827;">5 GMP</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Experiments:</span><span style="color: #111827;">12 stability runs</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Stage:</span><span style="color: #111827; font-style: italic;">Drug Substance Mfg</span></div>
              </div>
            </div>
            <div class="project-card-meta" style="border-top: 1px solid #F3F4F6; padding-top: 12px; margin-top: 16px; font-size: 13px; color: #6B7280;">Updated: 2 days ago</div>
          </div>

          <!-- mAb-X — Approved -->
          <div class="project-card disabled" style="border-radius: 4px; border: 1px solid #D1D5DB; padding: 24px; min-height: 280px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div class="project-card-top" style="margin-bottom: 16px;">
                <div class="project-card-name" style="font-size: 18px; font-weight: 600; color: #111827;">mAb-X <span style="font-weight: 400; color: #4B5563; font-size: 16px;">(anti-CD20)</span></div>
                <span class="badge-status approved" style="background: #E8F5E9; color: #2E7D32; font-weight: 600; padding: 4px 12px; border-radius: 4px;">Approved</span>
              </div>
              <div style="display: flex; flex-direction: column; gap: 12px; border-top: 1px solid #F3F4F6; padding-top: 12px;">
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Objective:</span><span style="color: #111827;">36-month shelf life</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">PI:</span><span style="color: #111827;">Sarah Chen</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Batches:</span><span style="color: #111827;">5 GMP</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Experiments:</span><span style="color: #111827;">12 stability runs</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Stage:</span><span style="color: #111827; font-style: italic;">Drug Substance Mfg</span></div>
              </div>
            </div>
            <div class="project-card-meta" style="border-top: 1px solid #F3F4F6; padding-top: 12px; margin-top: 16px; font-size: 13px; color: #6B7280;">Updated: 1 week ago</div>
          </div>

          <!-- mAb-Z — Precedent -->
          <div class="project-card disabled" style="border-radius: 4px; border: 1px solid #D1D5DB; padding: 24px; min-height: 280px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div class="project-card-top" style="margin-bottom: 16px;">
                <div class="project-card-name" style="font-size: 18px; font-weight: 600; color: #111827;">mAb-Z</div>
                <span class="badge-status rejected" style="background: #FFEBEE; color: #C62828; font-weight: 600; padding: 4px 12px; border-radius: 4px;">Revised</span>
              </div>
              <div style="display: flex; flex-direction: column; gap: 12px; border-top: 1px solid #F3F4F6; padding-top: 12px;">
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Objective:</span><span style="color: #111827;">36-month shelf life</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">PI:</span><span style="color: #111827;">Sarah Chen</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Batches:</span><span style="color: #111827;">5 GMP</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Experiments:</span><span style="color: #111827;">12 stability runs</span></div>
                <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px; flex-shrink: 0;">Stage:</span><span style="color: #111827; font-style: italic;">Drug Substance Mfg</span></div>
              </div>
            </div>
            <div class="project-card-meta" style="border-top: 1px solid #F3F4F6; padding-top: 12px; margin-top: 16px; font-size: 13px; color: #6B7280;">Updated: 3 days ago</div>
          </div>
        </div>

      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 1 — Workflow Entry
  // ══════════════════════════════════════════
  renderScreen1(state) {
    const survey = agent.surveyPrecedents(state.product);

    return `
      <div class="page-shell" style="padding-bottom: 120px;">
        <div class="breadcrumb" style="font-size: 13px; color: #4B5563; margin-bottom: 24px;">
          <span class="bc-link" onclick="app.navigate(0)" style="color: #4B5563;">&lt; Back to Projects</span>
          <span class="bc-sep" style="margin: 0 8px; color: #9CA3AF;">/</span>
          <span style="color: #4B5563;">mAb-Y (anti-HER2)</span>
          <span class="bc-sep" style="margin: 0 8px; color: #9CA3AF;">/</span>
          <span style="color: #111827; font-weight: 500;">Shelf-Life Justification</span>
        </div>

        <div class="page-header" style="display: flex; align-items: center; gap: 16px; margin-bottom: 12px;">
          <h1 style="font-size: 24px; font-weight: 600; margin: 0; color: #111827;">mAb-Y (anti-HER2) — Shelf-Life Justification</h1>
          <span class="badge-status draft" style="background: #FFF3E0; color: #E65100; font-weight: 600; padding: 4px 14px; border-radius: 12px; font-size: 13px;">In Draft</span>
        </div>

        <div style="font-size: 14px; color: #4B5563; margin-bottom: 24px;">
          <strong>Objective:</strong> Justify 36-month shelf life at 2-8°C for EMA MAA.<br>
          <strong>PI:</strong> Sarah Chen (CMC Stability).<br>
          <strong>Batches:</strong> 5 GMP • CQAs: 12 • Conditions: 3
        </div>

        <div style="display: flex; gap: 16px; margin-bottom: 24px;">
          <div style="position: relative; display: flex; align-items: center;">
            <select class="select-box" style="border: 1px solid #D1D5DB; border-radius: 4px; padding: 8px 32px 8px 12px; font-size: 14px; color: #111827; background: #FFF; appearance: none; font-family: var(--font);">
              <option>Batch: BY-2024-001</option>
            </select>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#4B5563" stroke-width="2" style="position: absolute; right: 12px; pointer-events: none;"><polyline points="6 9 12 15 18 9"/></svg>
          </div>

          <div style="position: relative; display: flex; align-items: center;">
            <select class="select-box" style="border: 1px solid #D1D5DB; border-radius: 4px; padding: 8px 32px 8px 12px; font-size: 14px; color: #111827; background: #FFF; appearance: none; font-family: var(--font);">
              <option>Experiment Set: Long-term 5°C</option>
            </select>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#4B5563" stroke-width="2" style="position: absolute; right: 12px; pointer-events: none;"><polyline points="6 9 12 15 18 9"/></svg>
          </div>
        </div>

        <!-- Tab-style Breadcrumb steps -->
        <div class="step-breadcrumb" style="display: flex; border: none; border-bottom: 1px solid #D1D5DB; background: none; border-radius: 0; box-shadow: none; margin-bottom: 24px; padding-bottom: 0; gap: 32px;">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb-tab" style="padding: 12px 4px; font-size: 14px; font-weight: 500; cursor: pointer; color: ${i===0?'#1D4ED8':'#4B5563'}; border-bottom: 3px solid ${i===0?'#1D4ED8':'transparent'};" onclick="app.navigate(${i+1})">
              <span style="font-weight: 600; margin-right: 4px;">${n}</span> ${l}
            </div>
          `).join('')}
        </div>

        <div class="agent-block" style="background: #F0F6FF; border: 1px solid #BFDBFE; border-left: 4px solid #1D4ED8; border-radius: 4px; padding: 24px; margin-bottom: 24px; display: flex; align-items: flex-start; gap: 16px;">
          <div style="background: none; color: #1D4ED8; flex-shrink: 0; padding-top: 2px;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
          </div>
          <div class="agent-block-content" style="flex: 1;">
            <div class="agent-block-label" style="color: #1D4ED8; font-size: 12px; font-weight: 600; letter-spacing: 0.05em; margin-bottom: 8px;">AGENT HAS SURVEYED THE MEMORY GRAPH</div>
            <div class="agent-block-text" style="font-size: 14px; color: #1E3A8A; line-height: 1.6;">
              14 comparable prior justifications <i>identified</i> across 11 mAb products. Primary precedents JUS-A and JUS-C.<br>Contradictory precedent JUS-B-original.
            </div>
          </div>
          <button class="btn-primary" style="background: #1D4ED8; border-radius: 4px; padding: 8px 18px; font-weight: 500;" onclick="app.navigate(2)">Review Precedents</button>
        </div>

        <div class="info-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 32px;">
          <div class="info-card" style="border: 1px solid #D1D5DB; border-radius: 4px; padding: 20px; box-shadow: none;">
            <h4 style="font-size: 15px; font-weight: 600; color: #111827; border-bottom: 1px solid #F3F4F6; padding-bottom: 10px; margin-bottom: 14px;">Product Identity</h4>
            <div class="kv-list" style="gap: 10px;">
              <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px;">Subclass:</span><span style="color: #111827; font-family: var(--font);">IgG1</span></div>
              <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px;">Buffer:</span><span style="color: #111827; font-family: var(--font);">Histidine pH 5.2</span></div>
              <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px;">Concentration:</span><span style="color: #111827; font-family: var(--font);">50 mg/mL</span></div>
              <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px;">Container:</span><span style="color: #111827; font-family: var(--font);">Type-I glass vial</span></div>
            </div>
          </div>
          
          <div class="info-card" style="border: 1px solid #D1D5DB; border-radius: 4px; padding: 20px; box-shadow: none;">
            <h4 style="font-size: 15px; font-weight: 600; color: #111827; border-bottom: 1px solid #F3F4F6; padding-bottom: 10px; margin-bottom: 14px;">Data Available</h4>
            <div class="kv-list" style="gap: 10px;">
              <div style="display: flex; font-size: 14px; align-items: center;"><span style="color: #6B7280; width: 140px;">Long-term 5°C:</span><span style="color: #111827; font-family: var(--font); display: flex; align-items: center; gap: 6px;">18 mo <span style="color: #16A34A; font-weight: bold;">✔</span></span></div>
              <div style="display: flex; font-size: 14px; align-items: center;"><span style="color: #6B7280; width: 140px;">Long-term 25°C:</span><span style="color: #111827; font-family: var(--font); display: flex; align-items: center; gap: 6px;">18 mo <span style="color: #16A34A; font-weight: bold;">✔</span></span></div>
              <div style="display: flex; font-size: 14px; align-items: center;"><span style="color: #6B7280; width: 140px;">Accelerated 40°C:</span><span style="color: #111827; font-family: var(--font); display: flex; align-items: center; gap: 6px;">6 mo <span style="color: #16A34A; font-weight: bold;">✔</span></span></div>
              <div style="display: flex; font-size: 14px; align-items: center;"><span style="color: #6B7280; width: 140px;">Extended Batch:</span><span style="color: #111827; font-family: var(--font); display: flex; align-items: center; gap: 6px;">24 mo <span style="color: #16A34A; font-weight: bold;">✔</span></span></div>
            </div>
          </div>

          <div class="info-card" style="border: 1px solid #D1D5DB; border-radius: 4px; padding: 20px; box-shadow: none;">
            <h4 style="font-size: 15px; font-weight: 600; color: #111827; border-bottom: 1px solid #F3F4F6; padding-bottom: 10px; margin-bottom: 14px;">Regulatory Context</h4>
            <div class="kv-list" style="gap: 10px;">
              <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px;">Pathway:</span><span style="color: #111827; font-family: var(--font);">EMA MAA</span></div>
              <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px;">Stage:</span><span style="color: #111827; font-family: var(--font);">Day 120</span></div>
              <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px;">Claim:</span><span style="color: #111827; font-family: var(--font);">36 months at 2-8°C</span></div>
              <div style="display: flex; font-size: 14px;"><span style="color: #6B7280; width: 120px;">Guidance:</span><span style="color: #111827; font-family: var(--font);">ICH Q1A(R2), Q1E, QSC</span></div>
            </div>
          </div>
        </div>

        <!-- Horizontal Timeline -->
        <div style="margin-bottom: 48px; position: relative;">
          <div style="position: absolute; top: 10px; left: 24px; right: 120px; height: 4px; background: #D1D5DB; z-index: 1;"></div>
          <div style="display: flex; justify-content: space-between; position: relative; z-index: 2;">
            <div style="display: flex; flex-direction: column; align-items: center; width: 60px;">
              <div style="width: 24px; height: 24px; border-radius: 50%; background: #64748B; border: 4px solid #FFF; box-shadow: 0 0 0 1px #64748B;"></div>
              <div style="margin-top: 8px; font-size: 13px; font-weight: 500; color: #374151; white-space: nowrap;">0 mo</div>
            </div>
            <div style="display: flex; flex-direction: column; align-items: center; width: 60px;">
              <div style="width: 24px; height: 24px; border-radius: 50%; background: #16A34A; border: 4px solid #FFF; box-shadow: 0 0 0 1px #16A34A; display: flex; align-items: center; justify-content: center; color: #FFF; font-size: 10px;">✔</div>
              <div style="margin-top: 8px; font-size: 13px; font-weight: 500; color: #374151; white-space: nowrap;">3 mo</div>
            </div>
            <div style="display: flex; flex-direction: column; align-items: center; width: 60px;">
              <div style="width: 24px; height: 24px; border-radius: 50%; background: #16A34A; border: 4px solid #FFF; box-shadow: 0 0 0 1px #16A34A; display: flex; align-items: center; justify-content: center; color: #FFF; font-size: 10px;">✔</div>
              <div style="margin-top: 8px; font-size: 13px; font-weight: 500; color: #374151; white-space: nowrap;">6 mo</div>
            </div>
            <div style="display: flex; flex-direction: column; align-items: center; width: 60px;">
              <div style="width: 24px; height: 24px; border-radius: 50%; background: #16A34A; border: 4px solid #FFF; box-shadow: 0 0 0 1px #16A34A; display: flex; align-items: center; justify-content: center; color: #FFF; font-size: 10px;">✔</div>
              <div style="margin-top: 8px; font-size: 13px; font-weight: 500; color: #374151; white-space: nowrap;">9 mo</div>
            </div>
            <div style="display: flex; flex-direction: column; align-items: center; width: 60px;">
              <div style="width: 24px; height: 24px; border-radius: 50%; background: #16A34A; border: 4px solid #FFF; box-shadow: 0 0 0 1px #16A34A; display: flex; align-items: center; justify-content: center; color: #FFF; font-size: 10px;">✔</div>
              <div style="margin-top: 8px; font-size: 13px; font-weight: 500; color: #374151; white-space: nowrap;">12 mo</div>
            </div>
            <div style="display: flex; flex-direction: column; align-items: center; width: 120px;">
              <div style="width: 24px; height: 24px; border-radius: 50%; background: #16A34A; border: 4px solid #FFF; box-shadow: 0 0 0 1px #16A34A; display: flex; align-items: center; justify-content: center; color: #FFF; font-size: 10px;">✔</div>
              <div style="margin-top: 8px; font-size: 13px; font-weight: 500; color: #374151; white-space: nowrap; text-align: center;">18 mo <span style="font-weight: 400; color: #6B7280; font-size: 11px;">Scheduled</span></div>
            </div>
          </div>
        </div>

        <!-- Sticky/Fixed bottom Action Bar matching the mockup -->
        <div style="position: fixed; bottom: 0; left: var(--sidebar-width); right: 0; background: #FFF; border-top: 1px solid #D1D5DB; padding: 18px 32px; display: flex; gap: 16px; align-items: center; z-index: 100; transition: left var(--transition);">
          <div style="position: relative; flex: 1; display: flex; align-items: center;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6B7280" stroke-width="2" style="position: absolute; left: 16px; pointer-events: none;"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" placeholder="Ask about this product..." style="width: 100%; border: 1px solid #D1D5DB; border-radius: 24px; padding: 12px 16px 12px 48px; font-size: 14px; outline: none; background: #F9FAFB;">
          </div>
          <button class="btn-primary" onclick="app.navigate(2)" style="background: #1D4ED8; border-radius: 4px; padding: 12px 24px; font-weight: 600; font-size: 14px; display: flex; align-items: center; gap: 8px;">
            Continue <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </button>
        </div>
      </div>
    `;
  },
  // ══════════════════════════════════════════
  // SCREEN 2 — Risk Framing
  // ══════════════════════════════════════════
  renderScreen2(state) {
    const survey = agent.surveyPrecedents(state.product);
    const attributes = agent.frameRiskAttributes(survey);
    setTimeout(() => {
      document.querySelectorAll('.attr-bar-fill').forEach(bar => {
        bar.style.width = bar.getAttribute('data-pct') + '%';
      });
    }, 50);
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Risk Framing</span>
        </div>
        <div class="page-header">
          <h1>Shelf-life-limiting attributes for IgG1 mAbs</h1>
          <p class="page-desc">Ranked from historical precedent across 8 comparable products. Grounded in prior justifications with cited reasoning chains.</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===1?'active':i<1?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;">
          <div class="data-table-wrap">
            <div class="table-toolbar"><strong style="font-size:13px;">Attributes ranked by shelf-life driver frequency</strong><span style="font-size:11px;color:var(--ink-3);">n=8 prior IgG1 justifications</span></div>
            <div style="padding:16px 20px;">
              <div class="attr-list">
                ${attributes.map(a => `
                  <div class="attr-row">
                    <div class="attr-name">${a.name}</div>
                    <div class="attr-freq">${a.freq} <span style="color:var(--ink-4)">${Math.round(a.pct)}%</span></div>
                    <div class="attr-bar-track"><div class="attr-bar-fill" data-pct="${a.pct}"></div></div>
                    <div class="attr-citations">
                      ${a.citations.map(c => c !== '—' ? `<span class="prov-link" onclick="app.showCitation('${c}')">${c}</span>` : `<span style="color:var(--ink-4)">—</span>`).join('')}
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>

          <div class="data-table-wrap">
            <div class="table-toolbar"><strong style="font-size:13px;">Attribute risk for mAb-Y</strong><span style="font-size:11px;color:var(--ink-3);">vs comparable products</span></div>
            <table class="data-table">
              <thead><tr><th>Attribute</th><th>Rate</th><th>Status</th></tr></thead>
              <tbody>
                ${attributes.filter(a=>a.rate).map(a=>`
                  <tr>
                    <td><strong>${a.name.split(' (')[0].split(' —')[0]}</strong></td>
                    <td class="mono">${a.rate}</td>
                    <td>${a.status !== 'none' ? `<span class="badge-status ${a.status}">${a.statusText}</span>` : `<span class="badge-status approved">Standard</span>`}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <div style="text-align:right;">
          <button class="btn-primary" onclick="app.navigate(3)">Explore Extrapolation Reasoning →</button>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 3 — Extrapolation
  // ══════════════════════════════════════════
  renderScreen3(state) {
    const args = agent.getExtrapolationArguments();
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Extrapolation Reasoning</span>
        </div>
        <div class="page-header">
          <h1>Aggregation-limited shelf-life extrapolation</h1>
          <p class="page-desc">All prior extrapolation arguments for aggregation on comparable IgG1 mAbs in the graph.</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===2?'active':i<2?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div class="insight-split mb-20">
          <div class="insight-panel">
            <div class="insight-panel-header">
              <h3>Accepted Extrapolation Arguments</h3>
              <span class="badge-tag" style="background:var(--green-light);color:var(--green);">${args.accepted.length} PRECEDENTS</span>
            </div>
            <div class="insight-panel-body">
              ${args.accepted.map(a=>`
                <div style="border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;margin-bottom:12px;">
                  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;">
                    <strong style="font-size:13px;">${a.title}</strong>
                    <span class="badge-status approved">${a.outcome}</span>
                  </div>
                  <div style="font-size:12px;color:var(--ink-3);margin-bottom:6px;">${a.meta}</div>
                  <div style="font-size:12px;color:var(--ink-2);font-style:italic;">"${a.quote}"</div>
                </div>
              `).join('')}
            </div>
          </div>
          <div class="insight-panel">
            <div class="insight-panel-header">
              <h3>Rejected Extrapolation Arguments</h3>
              <span class="badge-tag" style="background:var(--red-light);color:var(--red);">${args.rejected.length} REJECTION IN GRAPH</span>
            </div>
            <div class="insight-panel-body">
              ${args.rejected.map(a=>`
                <div style="border:1px solid #FECACA;border-radius:var(--radius-sm);padding:12px;margin-bottom:12px;">
                  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;">
                    <strong style="font-size:13px;">${a.title}</strong>
                    <span class="badge-status rejected">${a.outcome}</span>
                  </div>
                  <div style="font-size:12px;color:var(--ink-3);margin-bottom:6px;">${a.meta}</div>
                  <div style="font-size:12px;color:var(--ink-2);font-style:italic;">"${a.quote}"</div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <div style="text-align:right;">
          <button class="btn-primary" onclick="app.navigate(4)">Assemble Supporting Evidence →</button>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 4 — Evidence
  // ══════════════════════════════════════════
  renderScreen4(state) {
    if (!state.evidence) {
      const s = agent.getSuggestedEvidence();
      state.evidence = s.evidence;
      state.hedges = s.hedges;
    }
    const items = [...state.evidence, ...state.hedges];
    const checked = items.filter(i => i.checked).length;
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Evidence Assembly</span>
        </div>
        <div class="page-header">
          <h1>Supporting evidence for the shelf-life claim</h1>
          <p class="page-desc">Select all evidence items to include in the final justification document.</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===3?'active':i<3?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;">
          <div>
            <div class="evidence-table-wrap">
              ${items.map(e => `
                <div class="ev-row">
                  <div class="ev-checkbox ${e.checked?'checked':''}" onclick="app.toggleCheck('${e.id}')"></div>
                  <div class="ev-content">
                    <div class="ev-title">${e.title}</div>
                    <div class="ev-sub">${app.renderCitations ? app.renderCitations(e.sub||'') : (e.sub||'')}</div>
                  </div>
                  <div><span class="badge-status ${e.checked?'approved':'draft'}">${e.checked?'Added':'Pending'}</span></div>
                </div>
              `).join('')}
            </div>
          </div>
          <div>
            <div class="info-card">
              <h4>Evidence Strength</h4>
              <div style="text-align:center;padding:20px 0;">
                <div style="font-size:48px;font-weight:700;color:var(--accent);">${checked}</div>
                <div style="font-size:13px;color:var(--ink-3);">of ${items.length} evidence points aligned</div>
              </div>
              <button class="btn-primary" style="width:100%;" onclick="app.navigate(5)">Proceed to Draft →</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 5 — Writeback / Draft
  // ══════════════════════════════════════════
  renderScreen5(state) {
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Draft & Writeback</span>
        </div>
        <div class="page-header">
          <h1>Completed shelf-life justification — mAb-Y</h1>
          <p class="page-desc">Proposed claim: <strong>36 months at 2–8°C</strong> · ICH Q1A(R2), Q1E, Q5C</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===4?'active':i<4?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div class="agent-block" style="background:var(--green-light);border-color:#BBF7D0;">
          <div class="agent-icon" style="background:var(--green);">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
          <div class="agent-block-content">
            <div class="agent-block-label" style="color:var(--green);">Justification Draft Ready</div>
            <div class="agent-block-stat">17 typed reasoning entities ready to write back to the Memory Graph</div>
            <div class="agent-block-text">All evidence chains verified and cited to source triples. Reasoning will persist as graph data.</div>
          </div>
          <button class="btn-primary" style="background:var(--green);" onclick="app.triggerWriteback()">Approve & Capture Reasoning →</button>
        </div>

        <div class="data-table-wrap">
          <div class="table-toolbar">
            <div class="table-search">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input type="text" placeholder="Search all columns...">
            </div>
            <button class="col-btn">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
              Columns
            </button>
          </div>
          <table class="data-table">
            <thead>
              <tr>
                <th>Section</th>
                <th>Reasoning Thread</th>
                <th>File Used</th>
                <th>Workflow Status</th>
                <th>Current Step</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Primary Claim</strong></td>
                <td>Linear regression on 18M data at 5°C projects HMW aggregation to 3.9% at 36 months (spec ≤5.0%).</td>
                <td class="link-cell">JUS-A ¶5, JUS-C ¶4</td>
                <td><span class="badge-status approved">Completed</span></td>
                <td>—</td>
              </tr>
              <tr>
                <td><strong>Arrhenius Support</strong></td>
                <td>Accelerated data at 25°C/40°C orthogonally confirms 36-month viability via Arrhenius extrapolation.</td>
                <td class="link-cell">JUS-C ¶3</td>
                <td><span class="badge-status approved">Completed</span></td>
                <td>—</td>
              </tr>
              <tr>
                <td><strong>OOT Disclosure</strong></td>
                <td>OOT-2025-014 (deamidation) declared proactively alongside 30-month fallback hedge.</td>
                <td class="link-cell">OOT-Y, TAC-HAND ¶4</td>
                <td><span class="badge-status in-progress">In Progress</span></td>
                <td>QA Review</td>
              </tr>
              <tr>
                <td><strong>Batch Comparability</strong></td>
                <td>CV &lt;5% across 3 GMP batches at all timepoints — cited as batch representativeness.</td>
                <td class="link-cell">MEMO-X-COMP ¶5</td>
                <td><span class="badge-status approved">Completed</span></td>
                <td>—</td>
              </tr>
            </tbody>
          </table>
          <div class="table-footer">
            <div class="rows-select">Rows per page: <select><option>25</option></select></div>
            <div>1–4 of 4</div>
            <div class="pagination">
              <button class="pg-btn">‹</button>
              <button class="pg-btn active">1</button>
              <button class="pg-btn">›</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // ══════════════════════════════════════════
  // SCREEN 6 — Value Impact
  // ══════════════════════════════════════════
  renderScreen6(state) {
    return `
      <div class="page-shell">
        <div class="breadcrumb">
          <span class="bc-link" onclick="app.navigate(0)">← Projects</span>
          <span class="bc-sep">/</span>
          <span class="bc-link" onclick="app.navigate(1)">mAb-Y</span>
          <span class="bc-sep">/</span>
          <span>Value Impact</span>
        </div>
        <div class="page-header">
          <h1>Same shelf-life justification, two ways</h1>
          <p class="page-desc">Compare the process without the Memory Graph versus with it — same outcome, radically different effort.</p>
        </div>
        <div class="step-breadcrumb">
          ${[['01','Entry'],['02','Risk Framing'],['03','Extrapolation'],['04','Evidence'],['05','Writeback'],['06','Value Impact']].map(([n,l],i)=>`
            <div class="step-crumb ${i===5?'active':i<5?'done':''}" onclick="app.navigate(${i+1})"><span class="step-num">${n}</span>${l}</div>
          `).join('')}
        </div>

        <div class="compare-grid">
          <div class="compare-panel" style="border-top:3px solid var(--border-md);">
            <div class="compare-panel-header">
              <div class="compare-panel-title">Without Memory Graph</div>
            </div>
            <div class="compare-panel-body">
              <div class="compare-item negative">SharePoint search returns 47 documents — no relevance ranking.</div>
              <div class="compare-item negative">5–8 business days to reconstruct root-cause context manually.</div>
              <div class="compare-item negative">Every OOS escalated to QA regardless of assignable-cause likelihood.</div>
              <div class="compare-item negative">Reasoning lives in individual heads — lost on attrition.</div>
              <div class="compare-item negative">Formulation-lock root cause surfaces late, after key decisions are made.</div>
              <div class="compare-item negative">Regulatory queries take hours to days dependent on staff tenure.</div>
            </div>
          </div>
          <div class="compare-panel" style="border-top:3px solid var(--accent);">
            <div class="compare-panel-header" style="background:var(--accent-light);">
              <div class="compare-panel-title" style="color:var(--accent);">With Memory Graph Reasoning</div>
            </div>
            <div class="compare-panel-body">
              <div class="compare-item positive">14 comparable justifications surfaced in seconds via typed graph query.</div>
              <div class="compare-item positive">~95% reduction in OOS root-cause cycle time.</div>
              <div class="compare-item positive">30–40% fewer unnecessary QA escalations — pre-triaged by agent.</div>
              <div class="compare-item positive">Reasoning is graph data — persists independent of any individual.</div>
              <div class="compare-item positive">Cross-attribute root cause surfaces during the study — not after.</div>
              <div class="compare-item positive">Provenance-backed narrative generated directly from the graph.</div>
            </div>
          </div>
        </div>

        <div style="margin-top:28px;">
          <button class="btn-primary" onclick="app.navigate(0)">← Back to All Projects</button>
        </div>
      </div>
    `;
  }
};
