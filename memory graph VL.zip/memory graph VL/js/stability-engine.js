/**
 * stability-engine.js
 * Computation layer over the real stabilityData dataset (5 batches × 3 conditions × 13 CQAs).
 * Provides trend regression, spec-margin projection, and cross-batch comparison utilities
 * that back both the AI agent (agent.js) and the Intelligence Companion (intelligence.js).
 */
const StabilityEngine = {

  CONDITIONS: ['5C', '25C', '40C'],
  BATCHES: ['B1', 'B2', 'B3', 'B4', 'B5'],

  /** Human label for a condition code */
  conditionLabel(cond) {
    return { '5C': '5°C', '25C': '25°C', '40C': '40°C' }[cond] || cond;
  },

  /** Get raw time series [{month, value}] for one batch + attribute + condition */
  getSeries(condition, batch, attrKey) {
    const rows = (stabilityData[condition] && stabilityData[condition][batch]) || [];
    return rows
      .filter(r => r[attrKey] !== null && r[attrKey] !== undefined)
      .map(r => ({ month: r.month, value: r[attrKey] }));
  },

  /** Get series averaged across all 5 batches for an attribute + condition */
  getAverageSeries(condition, attrKey) {
    const months = new Set();
    this.BATCHES.forEach(b => this.getSeries(condition, b, attrKey).forEach(p => months.add(p.month)));
    const sortedMonths = [...months].sort((a, b) => a - b);
    return sortedMonths.map(month => {
      const vals = this.BATCHES
        .map(b => this.getSeries(condition, b, attrKey).find(p => p.month === month))
        .filter(Boolean)
        .map(p => p.value);
      const avg = vals.reduce((s, v) => s + v, 0) / vals.length;
      return { month, value: Math.round(avg * 100) / 100, n: vals.length };
    });
  },

  /** Simple linear regression y = slope*x + intercept, plus R^2 */
  linearRegression(points) {
    const n = points.length;
    if (n < 2) return { slope: 0, intercept: points[0] ? points[0].value : 0, r2: 0 };
    const sumX = points.reduce((s, p) => s + p.month, 0);
    const sumY = points.reduce((s, p) => s + p.value, 0);
    const sumXY = points.reduce((s, p) => s + p.month * p.value, 0);
    const sumXX = points.reduce((s, p) => s + p.month * p.month, 0);
    const meanX = sumX / n, meanY = sumY / n;
    const denom = (sumXX - n * meanX * meanX);
    const slope = denom !== 0 ? (sumXY - n * meanX * meanY) / denom : 0;
    const intercept = meanY - slope * meanX;

    // R^2
    const ssTot = points.reduce((s, p) => s + Math.pow(p.value - meanY, 2), 0);
    const ssRes = points.reduce((s, p) => {
      const pred = slope * p.month + intercept;
      return s + Math.pow(p.value - pred, 2);
    }, 0);
    const r2 = ssTot !== 0 ? 1 - (ssRes / ssTot) : 1;

    return { slope, intercept, r2 };
  },

  /** Project a value at a given month using regression fit on a series */
  projectAtMonth(points, month) {
    const { slope, intercept } = this.linearRegression(points);
    return slope * month + intercept;
  },

  /** Determine spec status for a value given stabilityMeta bounds */
  specStatus(attrKey, value) {
    const meta = stabilityMeta[attrKey];
    if (!meta || value === null || value === undefined) return 'none';
    const { low, high } = meta;
    if (low !== null && low !== undefined && value < low) return 'fail';
    if (high !== null && high !== undefined && value > high) return 'fail';
    // Warn zone: within 10% of spec width from the boundary
    if (low !== null && high !== null && low !== undefined && high !== undefined) {
      const width = high - low;
      const warnBand = width * 0.15;
      if (value < low + warnBand || value > high - warnBand) return 'warn';
    } else if (high !== null && high !== undefined) {
      if (value > high * 0.85) return 'warn';
    } else if (low !== null && low !== undefined) {
      if (value < low * 1.05) return 'warn';
    }
    return 'ok';
  },

  /** Rate string per month, direction-aware */
  formatRate(slope, unit = '%') {
    const sign = slope >= 0 ? '+' : '';
    return `${sign}${slope.toFixed(3)} ${unit}/mo`;
  },

  /**
   * Full trend analysis for one attribute at 5°C, averaged across batches,
   * with projection to a target month and spec-margin evaluation.
   */
  analyzeAttribute(attrKey, condition = '5C', targetMonth = 36) {
    const series = this.getAverageSeries(condition, attrKey);
    if (series.length < 2) return null;
    const reg = this.linearRegression(series);
    const projected = this.projectAtMonth(series, targetMonth);
    const meta = stabilityMeta[attrKey];
    const status = this.specStatus(attrKey, projected);
    const lastPoint = series[series.length - 1];

    return {
      attrKey,
      label: meta ? meta.label : attrKey,
      unit: meta ? meta.unit : '',
      condition,
      series,
      slope: reg.slope,
      intercept: reg.intercept,
      r2: reg.r2,
      lastMonth: lastPoint.month,
      lastValue: lastPoint.value,
      projectedMonth: targetMonth,
      projectedValue: Math.round(projected * 100) / 100,
      spec: meta ? meta.range : '',
      specLow: meta ? meta.low : null,
      specHigh: meta ? meta.high : null,
      status
    };
  },

  /** Check linearity of kinetics at 40°C (used for Arrhenius validity check) */
  checkArrheniusLinearity(attrKey) {
    const series = this.getAverageSeries('40C', attrKey);
    if (series.length < 3) return { linear: true, r2: 1, series };
    const reg = this.linearRegression(series);
    return { linear: reg.r2 >= 0.9, r2: reg.r2, series };
  },

  /** Find which batch has the fastest (steepest) rate of change for an attribute at a condition */
  fastestBatch(attrKey, condition = '5C', directionWorstIsHigh = true) {
    let best = null;
    this.BATCHES.forEach(b => {
      const series = this.getSeries(condition, b, attrKey);
      if (series.length < 2) return;
      const { slope } = this.linearRegression(series);
      const magnitude = directionWorstIsHigh ? slope : -slope;
      if (!best || magnitude > best.magnitude) {
        best = { batch: b, slope, magnitude };
      }
    });
    return best;
  },

  /** Get the list of available months across a condition (from Batch 1 as reference) */
  availableMonths(condition) {
    return this.getSeries(condition, 'B1', 'month').length
      ? (stabilityData[condition]['B1'] || []).map(r => r.month)
      : [];
  },

  /** Data coverage summary for display */
  coverageSummary() {
    const months5 = this.availableMonths('5C');
    const months25 = this.availableMonths('25C');
    const months40 = this.availableMonths('40C');
    return {
      longTerm5C: months5.length ? Math.max(...months5) : 0,
      longTerm25C: months25.length ? Math.max(...months25) : 0,
      accelerated40C: months40.length ? Math.max(...months40) : 0,
      batchCount: this.BATCHES.length,
      cqaCount: stabilityAttrOrder.length - 1 // exclude "month"
    };
  }
};

if (typeof module !== 'undefined') {
  module.exports = StabilityEngine;
}
