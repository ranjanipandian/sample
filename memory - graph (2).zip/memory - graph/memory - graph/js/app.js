/**
 * Router, state manager, theme controller, and event handlers for Memory Graph Virtual Lab Work application.
 */
class MemoryGraphApp {
  constructor() {
    this.state = {
      activeTab: 'studies', // 'studies', 'study-detail', 'justification', 'roi', 'provenance'
      justificationStep: 1, // 1 to 6
      activeStudyId: 'study-mab114-lt',
      studyDetailTab: 'experiments', // 'experiments', 'insights', 'failures'
      product: graphDB.data.products.find(p => p.id === 'mAb-Y'),
      evidence: null,
      hedges: null,
      toastVisible: false,
      theme: localStorage.getItem('memory_graph_theme') || 'light',
      graphDrawerOpen: false,
      nodes: [],
      links: []
    };

    window.addEventListener('popstate', (e) => {
      if (e.state) {
        if (e.state.tab) this.state.activeTab = e.state.tab;
        if (e.state.step) this.state.justificationStep = e.state.step;
        if (e.state.studyId) this.state.activeStudyId = e.state.studyId;
        this.render();
      }
    });
  }

  init() {
    document.documentElement.setAttribute('data-theme', this.state.theme);
    
    const urlParams = new URLSearchParams(window.location.search);
    const tab = urlParams.get('tab') || 'studies';
    const step = parseInt(urlParams.get('step')) || 1;
    const studyId = urlParams.get('study') || 'study-mab114-lt';

    this.navigateTab(tab, step, studyId, false);
    this.initGraphInspector();
  }

  toggleTheme() {
    this.state.theme = this.state.theme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', this.state.theme);
    localStorage.setItem('memory_graph_theme', this.state.theme);
    if (this.state.graphDrawerOpen) {
      this.drawGraphCanvas();
    }
  }

  toggleGraphDrawer() {
    const drawer = document.getElementById('graph-drawer');
    if (!drawer) return;
    this.state.graphDrawerOpen = !this.state.graphDrawerOpen;
    drawer.classList.toggle('open', this.state.graphDrawerOpen);

    if (this.state.graphDrawerOpen) {
      this.drawGraphCanvas();
    }
  }

  navigateTab(tabName, stepNum = 1, studyId = null, pushHistory = true) {
    this.state.activeTab = tabName;
    if (stepNum) this.state.justificationStep = stepNum;
    if (studyId) this.state.activeStudyId = studyId;

    if (pushHistory) {
      let url = `?tab=${tabName}`;
      if (tabName === 'justification') url += `&step=${stepNum}`;
      if (tabName === 'study-detail') url += `&study=${this.state.activeStudyId}`;
      history.pushState({ tab: tabName, step: stepNum, studyId: this.state.activeStudyId }, '', url);
    }

    this.render();
  }

  openStudy(studyId) {
    this.navigateTab('study-detail', 1, studyId);
  }

  setStudyTab(tab) {
    this.state.studyDetailTab = tab;
    this.render();
  }

  toggleFailureCard(id) {
    const body = document.getElementById(`fbody-${id}`);
    if (body) {
      body.style.display = (body.style.display === 'none' || !body.style.display) ? 'flex' : 'none';
    }
  }

  render() {
    const container = document.getElementById('screen-container');
    if (!container) return;

    container.style.animation = 'none';
    container.offsetHeight; // trigger reflow
    container.style.animation = 'fadeIn 0.22s ease';

    switch (this.state.activeTab) {
      case 'studies':
        container.innerHTML = screens.renderVirtualLabHome(this.state);
        break;
      case 'study-detail':
        container.innerHTML = screens.renderStudyDetail(this.state);
        break;
      case 'roi':
        container.innerHTML = screens.renderRoiImpact(this.state);
        break;
      case 'provenance':
        container.innerHTML = screens.renderProvenanceTrail(this.state);
        break;
      case 'justification':
        switch (this.state.justificationStep) {
          case 1: container.innerHTML = screens.renderScreen1(this.state); break;
          case 2: container.innerHTML = screens.renderScreen2(this.state); break;
          case 3: container.innerHTML = screens.renderScreen3(this.state); break;
          case 4: container.innerHTML = screens.renderScreen4(this.state); break;
          case 5: container.innerHTML = screens.renderScreen5(this.state); break;
          case 6: container.innerHTML = screens.renderScreen6(this.state); break;
          default: container.innerHTML = screens.renderScreen1(this.state);
        }
        break;
      default:
        container.innerHTML = screens.renderVirtualLabHome(this.state);
    }

    this.updateChrome();
  }

  updateChrome() {
    // Update main nav tab active state
    ['studies', 'justification', 'roi', 'provenance'].forEach(t => {
      const el = document.getElementById(`nav-tab-${t}`);
      if (el) el.classList.toggle('active', this.state.activeTab === t || (t === 'studies' && this.state.activeTab === 'study-detail'));
    });

    const stepRail = document.getElementById('step-rail-container');
    if (stepRail) {
      stepRail.style.display = (this.state.activeTab === 'justification') ? 'block' : 'none';
      if (this.state.activeTab === 'justification') {
        for (let i = 1; i <= 6; i++) {
          const stepEl = document.getElementById(`step-nav-${i}`);
          if (stepEl) {
            stepEl.classList.toggle('active', this.state.justificationStep === i);
            stepEl.classList.toggle('completed', this.state.justificationStep > i);
          }
        }
      }
    }
  }

  toggleCheck(listType, id) {
    if (!this.state[listType]) return;
    const item = this.state[listType].find(i => i.id === id);
    if (item) {
      item.checked = !item.checked;
      this.render();
    }
  }

  showCitation(key) {
    const citation = graphDB.getCitation(key);

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.onclick = () => overlay.remove();

    overlay.innerHTML = `
      <div class="modal" onclick="event.stopPropagation()">
        <div class="modal-head">
          <h4><i class="ti ti-database"></i> MEMORY GRAPH PRECEDENT</h4>
          <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div class="field-label">Document Key</div>
          <div class="field-value mono"><strong>${key}</strong></div>
          
          <div class="field-label">Registry Source</div>
          <div class="field-value">${citation.source}</div>
          
          <div class="field-label">Document Title</div>
          <div class="field-value">${citation.title}</div>
          
          <div class="field-label">Precedent Logic / Verbatim Snippet</div>
          <div class="field-quote">${citation.text}</div>
          
          <div style="margin-top: 20px; display: flex; justify-content: space-between; align-items: center;">
            <div class="tag success">${citation.status}</div>
            <button class="btn btn-sm outline" style="padding: 6px 14px; font-size:12px;" onclick="this.closest('.modal-overlay').remove()">Dismiss</button>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);
  }

  renderCitations(text) {
    return text.replace(/\[([^\]]+)\]/g, (match, key) => {
      return `<span class="prov" onclick="app.showCitation('${key}')">${key}</span>`;
    });
  }

  triggerWriteback() {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';

    graphDB.writeBackReasoning({
      id: "JUS-mAb-Y-001",
      productId: "mAb-Y",
      regulator: "EMA",
      proposed_shelf_life: "36 months",
      paragraphs: {
        5: "Linear regression on 18 months of long-term stability data at 5°C across three GMP batches projects HMW aggregation to 3.9% at 36 months.",
        6: "Arrhenius extrapolation from accelerated data at 25°C and 40°C provides orthogonal confirmation of the 36-month shelf-life claim."
      },
      new_learnings: [
        {
          id: "LEARN:mAb-Y-01",
          title: "Proactive OOT deamidation disclosures",
          text: "Proactively declaring open OOT reports on deamidation (such as OOT-2025-014) alongside a 30-month fallback hedge decreases subsequent assessor follow-ups.",
          source: "JUS-mAb-Y-001",
          applicableTo: "IgG1 deamidation justifications"
        }
      ]
    });

    const toast = document.getElementById('toast');
    if (toast) {
      const tsVal = document.getElementById('toast-ts-val');
      if (tsVal) tsVal.innerText = `ASSERTED BY SCIENTIST · ${timestamp}`;
      toast.classList.add('visible');
      
      if (this.state.graphDrawerOpen) {
        this.drawGraphCanvas();
      }

      setTimeout(() => {
        toast.classList.remove('visible');
      }, 8000);
    }
  }

  resetDB() {
    if (confirm("Reset the Memory Graph database back to original seed precedents?")) {
      graphDB.resetGraph();
      this.state.evidence = null;
      this.state.hedges = null;
      this.navigateTab('studies');
      if (this.state.graphDrawerOpen) {
        this.drawGraphCanvas();
      }
    }
  }

  initGraphInspector() {
    const canvas = document.getElementById('graph-canvas');
    if (!canvas) return;

    canvas.addEventListener('click', (e) => {
      const rect = canvas.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;

      const clicked = this.state.nodes.find(n => {
        const dx = n.x - clickX;
        const dy = n.y - clickY;
        return Math.sqrt(dx * dx + dy * dy) <= n.radius + 6;
      });

      const detailsEl = document.getElementById('graph-node-details');
      if (clicked && detailsEl) {
        detailsEl.innerHTML = `
          <div style="font-weight: 700; color: var(--accent); margin-bottom: 4px;">Node: ${clicked.label}</div>
          <div class="mono" style="font-size: 11px; color: var(--ink-3); margin-bottom: 8px;">Type: ${clicked.type} | ID: ${clicked.id}</div>
          <div>${clicked.desc || 'Connected entity in stability precedent graph.'}</div>
        `;
      }
    });
  }

  drawGraphCanvas() {
    const canvas = document.getElementById('graph-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const isDark = this.state.theme === 'dark';

    const w = canvas.width = 400;
    const h = canvas.height = 260;

    const nodes = [
      { id: 'mAb-114', label: 'mAb-114', type: 'Product', color: '#3B82F6', x: 120, y: 70, radius: 12, desc: 'mAb-114 Long-Term & Accelerated Stability product.' },
      { id: 'FP-207', label: 'FP-207', type: 'Product', color: '#3B82F6', x: 280, y: 70, radius: 12, desc: 'Fusion Protein-207 Thermal Stress product.' },
      { id: 'study-lt', label: 'mAb-114 LT', type: 'Study', color: '#10B981', x: 90, y: 140, radius: 9, desc: 'Long-term 5°C stability study.' },
      { id: 'study-acc', label: 'mAb-114 ACC', type: 'Study', color: '#10B981', x: 180, y: 140, radius: 9, desc: 'Accelerated 25°C stability study.' },
      { id: 'DEV-2291', label: 'DEV-2291', type: 'Deviation', color: '#EF4444', x: 70, y: 210, radius: 8, desc: 'Open column-performance deviation on OpenLab-HPLC-04.' },
      { id: 'DEV-2114', label: 'DEV-2114', type: 'Deviation', color: '#EF4444', x: 190, y: 210, radius: 8, desc: 'Bioassay reference-standard aging deviation.' },
      { id: 'mAb-Y', label: 'mAb-Y', type: 'Product', color: '#3B82F6', x: 330, y: 140, radius: 10, desc: 'Anti-HER2 MAA shelf-life justification product.' },
      { id: 'LEARN-B', label: 'LEARN:JUS-B-01', type: 'Learning', color: '#8B5CF6', x: 280, y: 210, radius: 8, desc: 'Extrapolation rule: verify linear kinetics before Arrhenius.' }
    ];

    const links = [
      { from: 'mAb-114', to: 'study-lt' },
      { from: 'mAb-114', to: 'study-acc' },
      { from: 'study-lt', to: 'DEV-2291' },
      { from: 'study-acc', to: 'DEV-2114' },
      { from: 'mAb-Y', to: 'LEARN-B' },
      { from: 'FP-207', to: 'LEARN-B' }
    ];

    this.state.nodes = nodes;
    this.state.links = links;

    ctx.clearRect(0, 0, w, h);

    ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)';
    ctx.lineWidth = 1.5;
    links.forEach(l => {
      const n1 = nodes.find(n => n.id === l.from);
      const n2 = nodes.find(n => n.id === l.to);
      if (n1 && n2) {
        ctx.beginPath();
        ctx.moveTo(n1.x, n1.y);
        ctx.lineTo(n2.x, n2.y);
        ctx.stroke();
      }
    });

    nodes.forEach(n => {
      ctx.fillStyle = n.color;
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = isDark ? '#111827' : '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = isDark ? '#F8FAFC' : '#0F172A';
      ctx.font = '10px JetBrains Mono, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(n.label, n.x, n.y + n.radius + 12);
    });

    document.getElementById('g-stat-products').innerText = graphDB.data.products.length;
    document.getElementById('g-stat-justifications').innerText = graphDB.data.justifications.length;
    document.getElementById('g-stat-learnings').innerText = graphDB.data.learnings.length;
    document.getElementById('g-stat-memos').innerText = Object.keys(graphDB.data.memos_and_logs).length;
  }
}

const app = new MemoryGraphApp();
window.onload = () => app.init();
