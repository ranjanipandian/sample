/**
 * Enhanced Renderers for the Memory Graph Virtual Lab Work & Shelf-Life Justification application.
 */
const screens = {
  // --- VIRTUAL LAB HOME ---
  renderVirtualLabHome: (state) => {
    const content = seedData.virtualLabContent;
    return `
      <div class="sh-wrap">
        <div class="pg-title">Stability Studies — Large Molecules</div>
        <div class="pg-sub">
          GSK pilot program area. Below are the labs and studies as they exist in the ELN (IDBS) today —
          click any study to compare ELN-only insights against insights derived once reasoning and
          failure intelligence are captured in the Memory Graph.
        </div>

        <div class="roi-cta" onclick="app.navigateTab('roi')">
          <i class="ti ti-chart-bar"></i>
          <span>See ROI, Productivity & Persona Impact across all studies</span>
          <i class="ti ti-chevron-right" style="margin-left: auto;"></i>
        </div>

        ${content.labs.map(lab => {
          const labStudies = content.studies.filter(s => s.labId === lab.id);
          return `
            <div class="lab-block">
              <div class="lab-block__head">
                <div class="lab-block__icon"><i class="ti ti-building-warehouse"></i></div>
                <div>
                  <div class="lab-block__name">${lab.name}</div>
                  <div class="lab-block__loc">${lab.location}</div>
                  <div class="lab-block__focus">${lab.focus}</div>
                </div>
              </div>

              <div class="study-grid">
                ${labStudies.map(study => `
                  <div class="study-card" onclick="app.openStudy('${study.id}')">
                    <div class="study-card__top">
                      <div class="study-card__name">${study.name}</div>
                      <span class="pill-${study.status}">${study.status}</span>
                    </div>
                    <div class="study-card__meta">
                      <span><i class="ti ti-molecule"></i> ${study.molecule} — ${study.modality}</span>
                      <span><i class="ti ti-thermometer"></i> ${study.condition}</span>
                      <span><i class="ti ti-calendar"></i> ${study.durationMonths} months, started ${study.startDate}</span>
                    </div>
                    <div class="study-card__summary">${study.summary}</div>
                  </div>
                `).join('')}
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  },

  // --- STUDY DETAIL & FAILURE INTELLIGENCE ---
  renderStudyDetail: (state) => {
    const content = seedData.virtualLabContent;
    const studyId = state.activeStudyId || 'study-mab114-lt';
    const study = content.studies.find(s => s.id === studyId);
    if (!study) return `<div>Study not found</div>`;

    const lab = content.labs.find(l => l.id === study.labId);
    const experiments = content.experiments.filter(e => e.studyId === studyId);
    const failures = content.failureEvents.filter(f => f.studyId === studyId);
    const comparison = content.insightComparisons.find(i => i.studyId === studyId);
    const activeTab = state.studyDetailTab || 'experiments';

    return `
      <div class="std-wrap">
        <button class="btn btn-sm outline" style="margin-bottom: 16px;" onclick="app.navigateTab('studies')">
          <i class="ti ti-arrow-left"></i> Back to Studies
        </button>

        <div class="pg-title-row">
          <div>
            <div class="pg-title">${study.name}</div>
            <div class="pg-sub">
              ${study.molecule} — ${study.modality} · ${study.condition} · ${lab ? lab.name : ''}
            </div>
          </div>
          <button class="prov-btn" onclick="app.navigateTab('provenance')">
            <i class="ti ti-git-branch"></i> View Provenance Trail
          </button>
        </div>

        <p class="study-summary" style="margin-bottom: 24px; color: var(--ink-2); line-height: 1.6;">${study.summary}</p>

        <div class="tab-row">
          <button class="tab-btn ${activeTab === 'experiments' ? 'active' : ''}" onclick="app.setStudyTab('experiments')">
            <i class="ti ti-flask"></i> Experiments (ELN Record)
          </button>
          <button class="tab-btn ${activeTab === 'insights' ? 'active' : ''}" onclick="app.setStudyTab('insights')">
            <i class="ti ti-bulb"></i> Insight Comparison
          </button>
          <button class="tab-btn ${activeTab === 'failures' ? 'active' : ''}" onclick="app.setStudyTab('failures')">
            <i class="ti ti-alert-triangle"></i> Failure Intelligence (${failures.length})
          </button>
        </div>

        <!-- Experiments tab -->
        ${activeTab === 'experiments' ? `
          <div class="tab-panel">
            <table class="exp-table">
              <thead>
                <tr>
                  <th>Parameter</th>
                  <th>Timepoint</th>
                  <th>Result</th>
                  <th>Status</th>
                  <th>ELN Record (IDBS)</th>
                </tr>
              </thead>
              <tbody>
                ${experiments.map(e => `
                  <tr>
                    <td><strong>${e.parameter}</strong></td>
                    <td>${e.timepoint}</td>
                    <td>${e.result}</td>
                    <td><span class="pill-${e.status}">${e.status.toUpperCase()}</span></td>
                    <td class="eln-cell">${e.elnRecordedFact}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        ` : ''}

        <!-- Insight comparison tab -->
        ${activeTab === 'insights' ? `
          <div class="tab-panel">
            ${comparison ? `
              <div class="split-panel">
                <div class="panel" style="border-top: 3px solid var(--ink-3);">
                  <div class="panel-head">
                    <h3 style="display:flex; align-items:center; gap:8px;"><i class="ti ti-notebook"></i> ELN-Only Insights</h3>
                    <span class="n">Raw ELN Data</span>
                  </div>
                  <ul style="padding-left: 20px; line-height: 1.8; color: var(--ink-2);">
                    ${comparison.elnOnlyInsights.map(i => `<li>${i}</li>`).join('')}
                  </ul>
                </div>

                <div class="panel" style="border-top: 3px solid var(--purple); background: var(--purple-tint);">
                  <div class="panel-head">
                    <h3 style="display:flex; align-items:center; gap:8px; color: var(--purple);"><i class="ti ti-brain"></i> With Memory Graph Reasoning</h3>
                    <span class="n" style="color: var(--purple);">Failure Intelligence</span>
                  </div>
                  <ul style="padding-left: 20px; line-height: 1.8; color: var(--ink);">
                    ${comparison.withReasoningInsights.map(i => `<li><strong>${i}</strong></li>`).join('')}
                  </ul>
                </div>
              </div>
            ` : `<div class="empty-note">No insight comparison available for this study.</div>`}
          </div>
        ` : ''}

        <!-- Failure intelligence tab -->
        ${activeTab === 'failures' ? `
          <div class="tab-panel">
            ${failures.map(f => `
              <div class="failure-card">
                <div class="failure-card__head" onclick="app.toggleFailureCard('${f.id}')">
                  <i class="ti ti-alert-triangle failure-icon"></i>
                  <div class="failure-card__title">
                    <div class="failure-card__param">${f.parameter} — ${f.timepoint}</div>
                    <div class="failure-card__result">${f.observedResult}</div>
                  </div>
                  <i class="ti ti-chevron-down chev"></i>
                </div>

                <div class="failure-card__body" id="fbody-${f.id}">
                  <div class="fb-block fb-block--eln">
                    <div class="fb-block__label"><i class="ti ti-notebook"></i> What IDBS Records Today</div>
                    <p>${f.elnRecordedFact}</p>
                  </div>
                  <div class="fb-block fb-block--missing">
                    <div class="fb-block__label"><i class="ti ti-help-circle"></i> Missing Reasoning</div>
                    <p>${f.missingReasoning}</p>
                  </div>
                  <div class="fb-block fb-block--recovered">
                    <div class="fb-block__label"><i class="ti ti-sparkles"></i> Recovered by Agentic AI on the Memory Graph</div>
                    <p>${f.recoveredHypothesis}</p>
                  </div>

                  <div class="fb-meta">
                    <div class="fb-meta__row">
                      <span class="fb-chip fb-chip--category"><i class="ti ti-tag"></i> ${f.reasonCategory}</span>
                      <span class="fb-chip fb-chip--confidence"><i class="ti ti-gauge"></i> Confidence: ${Math.round(f.confidenceScore * 100)}%</span>
                    </div>
                    <div class="fb-meta__line"><span class="fb-meta__label">Evidence Basis (mg:evidenceBasis):</span> ${f.evidenceBasis}</div>
                    <div class="fb-meta__line"><span class="fb-meta__label">Derived From (prov:wasDerivedFrom):</span> ${f.wasDerivedFrom}</div>
                    <div class="fb-meta__line"><span class="fb-meta__label">Attributed To (prov:wasAttributedTo):</span> ${f.wasAttributedTo}</div>
                  </div>

                  <div class="fb-block fb-block--decision">
                    <div class="fb-block__label"><i class="ti ti-checkbox"></i> Recommended Decision</div>
                    <p>${f.recommendedDecision}</p>
                  </div>
                  <div class="fb-persona" style="font-size: 12px; color: var(--ink-2); margin-top: 6px;"><i class="ti ti-user"></i> Persona involved: <strong>${f.personaInvolved}</strong></div>
                </div>
              </div>
            `).join('')}
          </div>
        ` : ''}
      </div>
    `;
  },

  // --- ROI & PERSONA IMPACT ---
  renderRoiImpact: (state) => {
    const content = seedData.virtualLabContent;
    return `
      <div class="sh-wrap">
        <div class="pg-title">ROI, Productivity & Persona Impact</div>
        <div class="pg-sub">Quantifiable value metrics and role-based operational impact enabled by capturing stability reasoning as graph triples.</div>

        <div class="section-title">Quantifiable ROI & Cycle-Time Metrics</div>
        <div class="card" style="margin-bottom: 32px;">
          <div class="card-body" style="padding: 0;">
            <table class="exp-table">
              <thead>
                <tr>
                  <th>Metric / Capability</th>
                  <th>Without Memory Graph (ELN Only)</th>
                  <th>With Memory Graph Reasoning</th>
                  <th>Productivity Impact</th>
                </tr>
              </thead>
              <tbody>
                ${content.roiMetrics.map(m => `
                  <tr>
                    <td><strong>${m.metric}</strong></td>
                    <td style="color: var(--ink-2);">${m.elnOnly}</td>
                    <td style="color: var(--accent); font-weight: 600;">${m.withReasoning}</td>
                    <td><span class="tag success" style="font-size:11px;">${m.improvement}</span></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <div class="section-title">Persona Operational Impact</div>
        <div class="grid-2" style="gap: 20px;">
          ${content.personaImpacts.map(p => `
            <div class="card">
              <div class="card-head">
                <h3 style="display:flex; align-items:center; gap:8px;"><i class="ti ti-user-check"></i> ${p.persona}</h3>
                <span class="meta">Persona</span>
              </div>
              <div class="card-body">
                <div style="font-size: 13px; color: var(--ink-2); margin-bottom: 12px;"><strong>Role:</strong> ${p.role}</div>
                <div class="callout warn" style="margin-bottom: 12px;">
                  <div class="label">Pain Point Today</div>
                  <div style="font-size: 13px; color: var(--ink);">${p.painPointToday}</div>
                </div>
                <div class="callout success">
                  <div class="label">Benefit With Memory Graph</div>
                  <div style="font-size: 13px; color: var(--ink);">${p.benefitWithReasoning}</div>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  // --- PROVENANCE AUDIT TRAIL ---
  renderProvenanceTrail: (state) => {
    const content = seedData.virtualLabContent;
    return `
      <div class="sh-wrap">
        <div class="pg-title">Provenance & Decision Audit Trail</div>
        <div class="pg-sub">Complete chronological audit ledger tracing human decisions and agent reasoning walks across stability studies.</div>

        <div class="provenance-timeline">
          ${content.provenanceTrail.map(p => `
            <div class="prov-item ${p.actorType === 'agent' ? 'agent' : ''}">
              <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4px;">
                <div class="prov-actor">${p.actor} <span class="tag ${p.actorType === 'agent' ? 'purple' : 'success'}">${p.actorType.toUpperCase()}</span></div>
                <div class="prov-ts">${p.timestamp}</div>
              </div>
              <div class="prov-action">${p.action}</div>
              <div style="margin-top: 6px; font-family: var(--font-mono); font-size: 11px; color: var(--ink-3);">Entity: ${p.entity} | Study: ${p.studyId}</div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  // --- SHELF-LIFE JUSTIFICATION SCREENS 1-6 ---
  renderScreen1: (state) => screens.renderScreen1Orig(state),
  renderScreen2: (state) => screens.renderScreen2Orig(state),
  renderScreen3: (state) => screens.renderScreen3Orig(state),
  renderScreen4: (state) => screens.renderScreen4Orig(state),
  renderScreen5: (state) => screens.renderScreen5Orig(state),
  renderScreen6: (state) => screens.renderScreen6Orig(state),

  // Original screen renderers preserved for justification workflow
  renderScreen1Orig: (state) => {
    const survey = agent.surveyPrecedents(state.product);
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Screen 1 · Workflow Entry</div>
          <h1 class="page-title">Prepare shelf-life justification — mAb-Y</h1>
          <p class="page-sub">Anti-HER2 monoclonal antibody (IgG1) · 20 mM histidine pH 5.2, 50 mg/mL · vial presentation · proposed 36-month shelf life at 2–8°C</p>
        </div>
        <button class="btn primary" onclick="app.navigateTab('justification', 2)">Review comparable precedents →</button>
      </div>

      <div class="grid-3" style="margin-bottom: 24px;">
        <div class="card">
          <div class="card-head"><h3>Product identity</h3><span class="meta">DP:mAb-Y</span></div>
          <div class="card-body">
            <div style="display: grid; grid-template-columns: auto 1fr; row-gap: 10px; column-gap: 16px; font-size: 13px;">
              <span style="color: var(--ink-3);">Subclass</span><span class="mono">IgG1</span>
              <span style="color: var(--ink-3);">Buffer</span><span class="mono">histidine · pH 5.2</span>
              <span style="color: var(--ink-3);">Concentration</span><span class="mono">50 mg/mL</span>
              <span style="color: var(--ink-3);">Surfactant</span><span class="mono">PS20 · 0.02%</span>
              <span style="color: var(--ink-3);">Container</span><span class="mono">Type-I glass vial</span>
              <span style="color: var(--ink-3);">Registered batches</span><span class="mono">3 (BY-2024-001, -002, BY-2023-005)</span>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-head"><h3>Data available</h3><span class="meta">Live</span></div>
          <div class="card-body">
            <div style="display: grid; grid-template-columns: 1fr auto; row-gap: 12px; column-gap: 16px; font-size: 13px;">
              <span>Long-term at 5°C</span><span class="mono" style="color: var(--success);">18 mo ✓</span>
              <span>Long-term at 25°C</span><span class="mono" style="color: var(--success);">18 mo ✓</span>
              <span>Accelerated at 40°C</span><span class="mono" style="color: var(--success);">6 mo ✓</span>
              <span>Extended (BY-2023-005)</span><span class="mono" style="color: var(--success);">24 mo ✓</span>
              <span style="color: var(--warning);">OOT investigation open</span><span class="mono" style="color: var(--warning); cursor:pointer;" onclick="app.showCitation('OOT-Y')">OOT-2025-014 ↗</span>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-head"><h3>Regulatory context</h3><span class="meta">Live</span></div>
          <div class="card-body">
            <div style="display: grid; grid-template-columns: auto 1fr; row-gap: 10px; column-gap: 16px; font-size: 13px;">
              <span style="color: var(--ink-3);">Pathway</span><span>EMA MAA</span>
              <span style="color: var(--ink-3);">Stage</span><span>Day 120 questions expected</span>
              <span style="color: var(--ink-3);">Proposed claim</span><span class="mono">36 months at 2–8°C</span>
              <span style="color: var(--ink-3);">Applicable guidance</span><span class="mono">ICH Q1A(R2), Q1E, Q5C</span>
            </div>
          </div>
        </div>
      </div>

      <div class="agent-callout">
        <div>
          <div class="agent-callout-label">Agent has surveyed the graph</div>
          <div class="agent-stat">
            <span class="num">${survey.justificationCount * 2 + 4}</span> comparable prior justifications identified across
            <span class="num">${survey.comparableCount + 6}</span> mAb products
          </div>
          <div class="prose" style="color: var(--ink-2); font-size: 13px; margin-top: 8px;">
            Comparability defined by typed graph query: IgG subclass · buffer family · pH range · container closure. Two primary precedents identified (<span class="prov" onclick="app.showCitation('JUS-A')">JUS-A</span>, <span class="prov" onclick="app.showCitation('JUS-C ¶3')">JUS-C</span>). One contradictory precedent surfaced from prior FDA correspondence (<span class="prov" onclick="app.showCitation('JUS-B-orig ¶3')">JUS-B-orig</span>).
          </div>
        </div>
        <div style="text-align: right;">
          <button class="btn accent" onclick="app.navigateTab('justification', 2)">Review comparable precedents</button>
        </div>
      </div>

      <div class="grid-2">
        <div class="card">
          <div class="card-head"><h3>Suggested next steps</h3><span class="meta">Ordered by dependency</span></div>
          <div class="card-body" style="padding: 10px 20px;">
            <div class="evidence-row done">
              <span class="check"></span>
              <div><div class="title">Identify comparable precedents</div><div class="sub">Automatic · agent-completed</div></div>
              <span class="mono" style="font-size: 11px; color: var(--ink-3);">DONE</span>
            </div>
            <div class="evidence-row">
              <span class="check" onclick="app.navigateTab('justification', 2)"></span>
              <div><div class="title" style="cursor:pointer;" onclick="app.navigateTab('justification', 2)">Review shelf-life-limiting attributes</div><div class="sub">Determines which reasoning threads to prioritise</div></div>
              <span class="mono" style="font-size: 11px; color: var(--accent);">NEXT</span>
            </div>
            <div class="evidence-row">
              <span class="check" onclick="app.navigateTab('justification', 3)"></span>
              <div><div class="title" style="cursor:pointer;" onclick="app.navigateTab('justification', 3)">Assess extrapolation reasoning options</div><div class="sub">Includes contradictory precedent from mAb-Z</div></div>
              <span class="mono" style="font-size: 11px; color: var(--ink-3);">STEP 3</span>
            </div>
            <div class="evidence-row">
              <span class="check" onclick="app.navigateTab('justification', 5)"></span>
              <div><div class="title" style="cursor:pointer;" onclick="app.navigateTab('justification', 5)">Draft justification and capture reasoning</div><div class="sub">Reasoning is written back to the graph on approval</div></div>
              <span class="mono" style="font-size: 11px; color: var(--ink-3);">STEP 5</span>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-head"><h3>Related activity</h3><span class="meta">Last 30 days</span></div>
          <div class="card-body prose" style="font-size: 13px;">
            <div style="padding: 10px 0; border-bottom: 1px solid var(--border);">
              <div style="font-weight: 500;">OOT investigation opened — acidic peak trending</div>
              <div style="color: var(--ink-3); font-size: 12px; margin-top: 2px;">Batch BY-2023-005 · 24-month timepoint · <span class="prov" onclick="app.showCitation('OOT-Y')">OOT-2025-014</span></div>
            </div>
            <div style="padding: 10px 0; border-bottom: 1px solid var(--border);">
              <div style="font-weight: 500;">CHMP Day 80 assessment received</div>
              <div style="color: var(--ink-3); font-size: 12px; margin-top: 2px;">Aggregation-related follow-up questions anticipated</div>
            </div>
            <div style="padding: 10px 0;">
              <div style="font-weight: 500;">Comparability confirmed across 3 batches</div>
              <div style="color: var(--ink-3); font-size: 12px; margin-top: 2px;">CV &lt; 5% at all timepoints · citable in justification</div>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  renderScreen2Orig: (state) => {
    const survey = agent.surveyPrecedents(state.product);
    const attributes = agent.frameRiskAttributes(survey);
    
    setTimeout(() => {
      document.querySelectorAll('.bar-fill').forEach(bar => {
        bar.style.width = bar.getAttribute('data-pct') + '%';
      });
    }, 50);

    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Screen 2 · Attribute-driven risk framing</div>
          <h1 class="page-title">Shelf-life-limiting attributes for IgG1 mAbs</h1>
          <p class="page-sub">Ranked from historical precedent across 8 comparable products. Grounded in prior justifications with cited reasoning chains.</p>
        </div>
        <button class="btn primary" onclick="app.navigateTab('justification', 3)">Explore extrapolation reasoning →</button>
      </div>

      <div class="grid-2-uneven" style="margin-bottom: 24px;">
        <div class="card">
          <div class="card-head"><h3>Attributes ranked by shelf-life driver frequency</h3><span class="meta">n = 8 prior justifications · IgG1</span></div>
          <div class="card-body">
            ${attributes.map(a => `
              <div class="attribute-row">
                <div class="label">${a.name}</div>
                <div class="freq">${a.freq} <span style="color: var(--ink-3);">${Math.round(a.pct)}%</span></div>
                <div class="bar-track"><div class="bar-fill" data-pct="${a.pct}"></div></div>
                <div class="count">
                  ${a.citations.map(c => c !== "—" ? `<span class="prov" onclick="app.showCitation('${c}')">${c}</span>` : `<span class="mono" style="color: var(--ink-3);">—</span>`).join('')}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
        <div class="card">
          <div class="card-head"><h3>Attribute risk for mAb-Y</h3><span class="meta">vs. comparable products</span></div>
          <div class="card-body">
            ${attributes.filter(a => a.rate).map(a => `
              <div style="padding-bottom: 14px; border-bottom: 1px solid var(--border); margin-bottom: 14px; &:last-child { border-bottom: none; margin-bottom: 0; }">
                <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 4px;">
                  <span style="font-weight: 500;">${a.name.split(' (')[0].split(' — ')[0]}</span>
                  ${a.status !== "none" ? `<span class="tag ${a.status}">${a.statusText}</span>` : `<span class="tag">Standard</span>`}
                </div>
                <div class="mono" style="font-size: 12px; color: var(--ink-2);">${a.rate}</div>
                <div style="font-size: 12px; color: var(--ink-3); margin-top: 4px;">${a.context}</div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  },

  renderScreen3Orig: (state) => {
    const args = agent.getExtrapolationArguments();
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Screen 3 · Extrapolation reasoning</div>
          <h1 class="page-title">Aggregation-limited shelf-life extrapolation — approaches used</h1>
          <p class="page-sub">All prior extrapolation arguments for aggregation on comparable IgG1 mAbs.</p>
        </div>
        <button class="btn primary" onclick="app.navigateTab('justification', 4)">Assemble supporting evidence →</button>
      </div>

      <div class="split-panel">
        <div class="panel panel-accepted">
          <div class="panel-head">
            <h3>Extrapolation arguments — accepted</h3>
            <span class="n">${args.accepted.length} PRECEDENTS</span>
          </div>
          ${args.accepted.map(a => `
            <div class="arg-card">
              <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6px;">
                <div class="arg-title">${a.title}</div>
                <span class="tag success">${a.outcome}</span>
              </div>
              <div class="arg-meta">${a.meta}</div>
              <div class="arg-quote">"${a.quote}"</div>
              <div style="font-size: 13px; color: var(--ink-2);">${a.note}</div>
            </div>
          `).join('')}
        </div>
        
        <div class="panel panel-rejected">
          <div class="panel-head">
            <h3>Extrapolation arguments — rejected</h3>
            <span class="n">${args.rejected.length} REJECTION IN GRAPH</span>
          </div>
          ${args.rejected.map(a => `
            <div class="arg-card" style="border-color: rgba(239,68,68,0.25);">
              <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6px;">
                <div class="arg-title">${a.title}</div>
                <span class="tag rejected">${a.outcome}</span>
              </div>
              <div class="arg-meta">${a.meta}</div>
              <div class="arg-quote">"${a.quote}"</div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  renderScreen4Orig: (state) => {
    if (!state.evidence) {
      const suggestions = agent.getSuggestedEvidence();
      state.evidence = suggestions.evidence;
      state.hedges = suggestions.hedges;
    }
    const items = [...state.evidence, ...state.hedges];
    const checkedCount = items.filter(i => i.checked).length;
    const totalCount = items.length;

    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Screen 4 · Evidence assembly</div>
          <h1 class="page-title">Supporting evidence for the shelf-life claim</h1>
        </div>
        <button class="btn primary" onclick="app.navigateTab('justification', 5)">Proceed to draft →</button>
      </div>

      <div class="grid-2-uneven">
        <div>
          <div class="card">
            <div class="card-body" style="padding: 8px 20px;">
              ${state.evidence.map(e => `
                <div class="evidence-row ${e.checked ? 'done' : ''}">
                  <span class="check" onclick="app.toggleCheck('evidence', '${e.id}')"></span>
                  <div>
                    <div class="title" style="cursor:pointer;" onclick="app.toggleCheck('evidence', '${e.id}')">${e.title}</div>
                    <div class="sub">${app.renderCitations(e.sub)}</div>
                  </div>
                  <span class="tag ${e.checked ? 'success' : 'warn'}">${e.checked ? 'Added' : 'Pending'}</span>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
        <div>
          <div class="strength-meter">
            <div class="strength-label">Primary argument support</div>
            <div class="strength-note"><strong>${checkedCount} of ${totalCount}</strong> evidence points aligned.</div>
          </div>
          <button class="btn accent" style="margin-top: 20px;" onclick="app.navigateTab('justification', 5)">Proceed to draft →</button>
        </div>
      </div>
    `;
  },

  renderScreen5Orig: (state) => `
    <div class="page-head">
      <div>
        <div class="eyebrow">Screen 5 · Draft, review, and capture</div>
        <h1 class="page-title">Completed shelf-life justification — mAb-Y</h1>
      </div>
      <button class="btn accent" onclick="app.triggerWriteback()">Approve and capture reasoning →</button>
    </div>

    <div class="claim-block">
      <div class="claim-label">Proposed shelf-life claim</div>
      <div class="claim-value">36 months at 2–8°C</div>
    </div>

    <div class="action-bar">
      <div>17 typed reasoning entities ready to write back.</div>
      <button class="btn accent" onclick="app.triggerWriteback()">Approve and capture reasoning →</button>
    </div>
  `,

  renderScreen6Orig: (state) => `
    <div class="compare-page">
      <div class="compare-head">
        <h1 class="compare-title">Same shelf-life justification, two ways</h1>
      </div>
      <div class="compare-grid">
        <div class="compare-side without">
          <div class="compare-header"><div class="compare-side-title">Without Memory Graph</div></div>
          <div class="compare-body"><div class="compare-item">SharePoint search returns 47 documents...</div></div>
        </div>
        <div class="compare-side with">
          <div class="compare-header"><div class="compare-side-title">With Memory Graph</div></div>
          <div class="compare-body"><div class="compare-item strong">14 comparable justifications surfaced instantly...</div></div>
        </div>
      </div>
    </div>
  `
};
