// Curated Memory Graph Virtual Lab Content (from stability-content.json)
const virtualLabContent = {
  labs: [
    {
      id: "lab-analytical-stability",
      name: "Analytical Stability Lab (Site A)",
      location: "Upper Providence, PA",
      focus: "Long-term & accelerated stability testing for monoclonal antibodies and fusion proteins",
      studyIds: ["study-mab114-lt", "study-mab114-acc"]
    },
    {
      id: "lab-formulation-stability",
      name: "Formulation Stability Lab (Site B)",
      location: "Stevenage, UK",
      focus: "Forced-degradation and thermal-stress studies to inform formulation robustness",
      studyIds: ["study-fp207-stress"]
    }
  ],
  studies: [
    {
      id: "study-mab114-lt",
      name: "mAb-114 Long-Term Stability",
      molecule: "mAb-114",
      modality: "Monoclonal Antibody (IgG1)",
      labId: "lab-analytical-stability",
      condition: "Long-Term 5°C ± 3°C",
      status: "ongoing",
      startDate: "2024-02-01",
      durationMonths: 36,
      summary: "Real-time stability study supporting shelf-life claim for mAb-114 drug product, pulled at 0/3/6/9/12/18/24/36 months."
    },
    {
      id: "study-mab114-acc",
      name: "mAb-114 Accelerated Stability",
      molecule: "mAb-114",
      modality: "Monoclonal Antibody (IgG1)",
      labId: "lab-analytical-stability",
      condition: "Accelerated 25°C/60%RH",
      status: "completed",
      startDate: "2023-08-01",
      durationMonths: 6,
      summary: "Accelerated-condition study used to predict degradation trends ahead of the long-term readout and support the initial filing timeline."
    },
    {
      id: "study-fp207-stress",
      name: "Fusion Protein-207 Thermal Stress",
      molecule: "FP-207",
      modality: "Fc-Fusion Protein",
      labId: "lab-formulation-stability",
      condition: "Stressed 40°C/75%RH",
      status: "completed",
      startDate: "2024-01-15",
      durationMonths: 3,
      summary: "Forced-degradation study used to identify the most sensitive quality attributes ahead of formulation lock for FP-207."
    }
  ],
  experiments: [
    {
      id: "exp-114lt-t12-scf",
      studyId: "study-mab114-lt",
      parameter: "SEC — % Main Peak Purity",
      timepoint: "12 months",
      result: "99.9% main peak purity (spec 95–105%) — Batch 2",
      status: "pass",
      elnRecordedFact: "SEC run 12M-R2 logged: 99.9% main peak purity (Batch 2, Long-Term 5°C), within specification. Analyst: R. Fischer. Instrument: OpenLab-HPLC-04."
    },
    {
      id: "exp-114lt-t18-scf",
      studyId: "study-mab114-lt",
      parameter: "SEC — % Main Peak Purity",
      timepoint: "18 months",
      result: "94.1% main peak purity (spec 95–105%) — Batch 2",
      status: "oos",
      elnRecordedFact: "SEC run 18M-R1 logged: 94.1% main peak purity (Batch 2, Long-Term 5°C), OOS against 95% lower spec limit. Analyst: R. Fischer. Instrument: OpenLab-HPLC-04. Retest triggered per SOP-QC-014."
    },
    {
      id: "exp-114lt-t18-cex",
      studyId: "study-mab114-lt",
      parameter: "CEX — % Acidic Variants",
      timepoint: "18 months",
      result: "15.4% acidic (spec 10–20%) — Batch 2",
      status: "pass",
      elnRecordedFact: "CEX run 18M-CEX-01 logged: 15.4% acidic variants (Batch 2, Long-Term 5°C), within specification."
    },
    {
      id: "exp-114acc-t3-potency",
      studyId: "study-mab114-acc",
      parameter: "Relative Potency (Cell-Based Bioassay)",
      timepoint: "3 months",
      result: "87.7% relative potency (spec 80–120%) — Batch 1, 40°C/75%RH stress arm",
      status: "pass",
      elnRecordedFact: "Bioassay run ACC-3M-BA02 logged: 87.7% relative potency (Batch 1, 40°C/75%RH stress arm), within specification."
    },
    {
      id: "exp-114acc-t6-potency",
      studyId: "study-mab114-acc",
      parameter: "Relative Potency (Cell-Based Bioassay)",
      timepoint: "6 months",
      result: "76.7% relative potency (spec 80–120%) — Batch 1, 40°C/75%RH stress arm",
      status: "oos",
      elnRecordedFact: "Bioassay run ACC-6M-BA05 logged: 76.7% relative potency (Batch 1, 40°C/75%RH stress arm), OOS against 80% lower spec limit. Flagged for QA review."
    },
    {
      id: "exp-fp207-t1-oxidation",
      studyId: "study-fp207-stress",
      parameter: "Met-Oxidation (%, Peptide Map/MS)",
      timepoint: "1 month",
      result: "4.1% oxidation (alert ≥ 3.5%)",
      status: "oot",
      elnRecordedFact: "Peptide map run STR-1M-PM03 logged: 4.1% Met-oxidation, exceeds internal alert limit of 3.5%. No spec breach — informational OOT."
    },
    {
      id: "exp-fp207-t3-aggregation",
      studyId: "study-fp207-stress",
      parameter: "SEC — % Aggregates",
      timepoint: "3 months",
      result: "5.6% aggregates (spec ≤ 5.0%)",
      status: "oos",
      elnRecordedFact: "SEC run STR-3M-SEC01 logged: 5.6% aggregates, OOS against 5.0% spec."
    }
  ],
  failureEvents: [
    {
      id: "fail-114lt-18m-hmw",
      studyId: "study-mab114-lt",
      parameter: "SEC — % Main Peak Purity",
      timepoint: "18 months",
      observedResult: "94.1% main peak purity vs 95% lower spec limit (Batch 2, Long-Term 5°C)",
      elnRecordedFact: "IDBS record: \"18M-R1: 94.1% main peak purity, OOS. Retest 18M-R2 initiated per SOP-QC-014.\" No further narrative attached.",
      missingReasoning: "IDBS does not record that the same batch showed a comparable main-peak dip at 9 months (94.9%, itself borderline), that a column-performance deviation was open on OpenLab-HPLC-04 the week of the 18-month run, or that the analyst's working hypothesis was instrument-related, not product-related.",
      recoveredHypothesis: "Cross-study graph walk shows: (1) OpenLab-HPLC-04 had an open column-performance deviation (DEV-2291) overlapping the run date; (2) Batch 2's own 12-month pull (99.9%) and 24-month pull (95.5%) bracket the 18-month dip, making a monotonic degradation trend inconsistent with the data; (3) the retest on a qualified column (18M-R2) returned a result back within specification. Combined evidence points to an instrument/column artifact, not real product degradation.",
      recommendedDecision: "Disposition the 18M-R1 result as invalid due to assignable instrument cause (DEV-2291), accept 18M-R2 as the reportable result, and flag OpenLab-HPLC-04 for preventive-maintenance review before the next stability pull.",
      personaInvolved: "QC Analyst / Stability Scientist",
      reasonCategory: "Instrument/Column Artifact",
      confidenceScore: 0.87,
      evidenceBasis: "DEV-2291 (open column-performance deviation, OpenLab-HPLC-04) + Batch 2's own 12M/24M main-peak-purity results bracketing the 18M dip + qualified-column retest 18M-R2",
      wasDerivedFrom: "DEV-2291; exp-114lt-t12-scf; exp-114lt-t18-scf",
      wasAttributedTo: "Memory Graph Reasoning Agent (agent-asserted); approved by Dr. A. Kessler, QA Reviewer"
    },
    {
      id: "fail-114acc-6m-potency",
      studyId: "study-mab114-acc",
      parameter: "Relative Potency (Cell-Based Bioassay)",
      timepoint: "6 months",
      observedResult: "76.7% relative potency vs 80% lower spec limit (Batch 1, 40°C/75%RH stress arm)",
      elnRecordedFact: "IDBS record: \"ACC-6M-BA05: 76.7% relative potency, OOS. Escalated to QA.\" No linkage to assay history or prior decisions.",
      missingReasoning: "The ELN does not capture that this cell-based bioassay had failed system-suitability twice in the preceding month for unrelated products, that the reference standard lot used was within 2 weeks of its requalification date, or that a prior deviation (DEV-2114) had already linked assay drift to reference-standard age.",
      recoveredHypothesis: "Graph walk across the bioassay platform surfaces DEV-2114's prior conclusion: aging reference standard correlates with a downward potency bias of 4–8%. The current reference-standard lot is 2 weeks from requalification, consistent with the observed 76.7% result being a reference-standard artifact rather than true product loss of potency.",
      recommendedDecision: "Repeat the assay against a freshly qualified reference-standard lot before accepting the 6-month potency trend as a genuine stability signal.",
      personaInvolved: "Bioassay Scientist / QA Reviewer",
      reasonCategory: "Reference-Standard Aging Artifact",
      confidenceScore: 0.74,
      evidenceBasis: "DEV-2114 (prior deviation linking reference-standard age to 4–8% potency bias) + reference-standard lot 2 weeks from requalification",
      wasDerivedFrom: "DEV-2114; exp-114acc-t6-potency",
      wasAttributedTo: "Memory Graph Reasoning Agent (agent-asserted); pending SME review"
    },
    {
      id: "fail-fp207-3m-aggregates",
      studyId: "study-fp207-stress",
      parameter: "SEC — % Aggregates",
      timepoint: "3 months",
      observedResult: "5.6% aggregates vs 5.0% specification",
      elnRecordedFact: "IDBS record: \"STR-3M-SEC01: 5.6% aggregates, OOS under stress condition (40°C).\" Logged as an expected stress-study finding.",
      missingReasoning: "The ELN does not capture the formulation team's working hypothesis that the aggregation onset correlates with the polysorbate-80 lot change introduced at month 1, and that this same PS-80 lot had already been flagged informally in a different program's forced-degradation study.",
      recoveredHypothesis: "Linking the 1-month oxidation OOT (exp-fp207-t1-oxidation) and the 3-month aggregation OOS through shared lot metadata reveals both quality attributes shifted after the same PS-80 lot change — consistent with a formulation-related root cause (surfactant oxidative degradation products promoting aggregation).",
      recommendedDecision: "Flag the PS-80 lot for investigation before formulation lock; consider re-running the thermal-stress arm with the prior qualified PS-80 lot to isolate lot-effect from thermal-stress effect.",
      personaInvolved: "Formulation Scientist / CMC Program Lead",
      reasonCategory: "Excipient Lot-Linked Degradation",
      confidenceScore: 0.69,
      evidenceBasis: "Shared PS-80 lot change at month 1 correlated across two independent quality attributes (Met-oxidation OOT + SEC aggregation OOS)",
      wasDerivedFrom: "exp-fp207-t1-oxidation; exp-fp207-t3-aggregation",
      wasAttributedTo: "Memory Graph Reasoning Agent (agent-asserted); pending SME review"
    }
  ],
  insightComparisons: [
    {
      studyId: "study-mab114-lt",
      elnOnlyInsights: [
        "SEC main peak purity dropped from 99.9% (12M) to 94.1% (18M), breaching the 95% lower spec limit — Batch 2.",
        "A retest was performed per SOP-QC-014.",
        "CEX acidic variants remain within specification through 18 months (15.4%, spec 10–20%)."
      ],
      withReasoningInsights: [
        "The 18M main-peak-purity excursion correlates with an open column-performance deviation (DEV-2291) on the exact instrument used — an assignable, non-product cause.",
        "Batch 2's own 12-month (99.9%) and 24-month (95.5%) results bracket the 18-month dip, so a monotonic degradation trend doesn't fit the data.",
        "Confidence in the shelf-life claim increases once the reasoning chain is walked — the opposite conclusion an ELN-only read would suggest."
      ]
    },
    {
      studyId: "study-mab114-acc",
      elnOnlyInsights: [
        "Relative potency dropped from 87.7% (3M) to 76.7% (6M) on Batch 1 (40°C/75%RH stress arm), breaching the 80% lower limit.",
        "The result was escalated to QA as an OOS."
      ],
      withReasoningInsights: [
        "The reference-standard lot used for the 6-month assay was 2 weeks from requalification — a known bias pattern documented in a prior deviation (DEV-2114).",
        "A retest against a freshly qualified reference standard is the recommended next step before treating the 6-month result as a true stability signal.",
        "Without this reasoning, the accelerated-stability trend risks over-stating degradation risk to the filing timeline."
      ]
    },
    {
      studyId: "study-fp207-stress",
      elnOnlyInsights: [
        "Met-oxidation exceeded the internal alert limit at 1 month (4.1% vs 3.5%).",
        "SEC aggregates breached specification at 3 months (5.6% vs 5.0%).",
        "Both findings were logged as separate, expected stress-study observations."
      ],
      withReasoningInsights: [
        "Both quality-attribute shifts trace back to the same polysorbate-80 lot change at month 1 — a shared root cause, not two independent stress artifacts.",
        "This reframes the finding from \"thermal stress degrades FP-207 as expected\" to \"a specific excipient lot may be driving degradation.\"",
        "The recommended next study design (re-run with prior PS-80 lot) only emerges once the two findings are linked through reasoning."
      ]
    }
  ],
  roiMetrics: [
    {
      metric: "Time to root-cause an OOS/OOT event",
      elnOnly: "5–8 business days (manual cross-referencing of decks, threads, and prior deviations)",
      withReasoning: "Minutes (single graph walk across linked provenance)",
      improvement: "~95% cycle-time reduction",
      narrative: "Investigators currently reconstruct context manually from OneNote, Teams and slide decks. A Memory Graph query replaces that reconstruction with a typed subgraph walk."
    },
    {
      metric: "False-positive stability excursions escalated to QA",
      elnOnly: "Every OOS/OOT is escalated regardless of assignable-cause likelihood",
      withReasoning: "Pre-triaged by likely assignable cause before human escalation",
      improvement: "Est. 30–40% reduction in unnecessary escalations",
      narrative: "Cross-study and cross-instrument correlation (as in DEV-2291 and DEV-2114) lets the agent flag likely-artifact events before they consume QA review cycles."
    },
    {
      metric: "Analyst / scientist time spent reconstructing \"why\" for regulatory queries",
      elnOnly: "Hours to days per query, dependent on tenure of staff involved",
      withReasoning: "Provenance trail answered directly from the graph, cited to source triples",
      improvement: "~70–80% time saved per regulatory information request",
      narrative: "The graph answers \"how do we know\" by walking the provenance chain to the originating run, analyst, method and approval — no dependency on institutional memory of specific people."
    },
    {
      metric: "Formulation-lock decision cycle (e.g., FP-207 PS-80 lot issue)",
      elnOnly: "Root cause surfaces late, often after formulation lock, risking rework",
      withReasoning: "Root cause (lot-linked, cross-attribute) surfaces during the stress study itself",
      improvement: "Avoids downstream formulation rework — high-value avoidance",
      narrative: "Linking oxidation and aggregation findings through shared lot metadata during the study — not after — changes the decision window entirely."
    },
    {
      metric: "Institutional knowledge retention when staff turn over",
      elnOnly: "Reasoning lives in individual heads/threads; lost on attrition",
      withReasoning: "Reasoning is graph data — persists independent of any individual",
      improvement: "Durable, compounding institutional memory",
      narrative: "The white paper's core thesis: reasoning as first-class data survives the attrition that erodes everything built only on top of the ELN."
    }
  ],
  personaImpacts: [
    {
      persona: "QC / Stability Analyst",
      role: "Runs the assay, logs the result, initiates retests on OOS/OOT.",
      painPointToday: "Spends hours manually checking whether a similar excursion happened before, on which instrument, and whether a deviation is already open.",
      benefitWithReasoning: "Gets a pre-assembled reasoning chain (prior deviations, related studies, instrument history) the moment an OOS is logged — investigation starts from a hypothesis, not a blank page."
    },
    {
      persona: "Stability / Formulation Scientist",
      role: "Owns the scientific interpretation of stability trends and formulation decisions.",
      painPointToday: "Reconstructs cross-study correlations (e.g., a shared excipient lot across two quality attributes) manually and often only discovers them late in governance review.",
      benefitWithReasoning: "Agent surfaces cross-attribute, cross-study correlations automatically as they emerge, shifting root-cause discovery earlier in the decision window."
    },
    {
      persona: "QA Reviewer",
      role: "Reviews and dispositions OOS/OOT investigations before batch release or regulatory submission.",
      painPointToday: "Every OOS/OOT arrives undifferentiated; QA must independently judge assignable-cause likelihood with limited context.",
      benefitWithReasoning: "Receives a pre-triaged view — likely-artifact events (with cited evidence) versus events with no corroborating pattern — improving review throughput."
    },
    {
      persona: "CMC Program Lead",
      role: "Owns the overall program timeline, filing readiness and risk register.",
      painPointToday: "Learns about root-cause findings that affect timeline only when they surface in a review meeting, sometimes after key decisions are already made.",
      benefitWithReasoning: "Sees a live, queryable risk/reasoning trail across labs and studies, enabling earlier intervention and more defensible timeline decisions."
    },
    {
      persona: "Regulatory Affairs / Submissions",
      role: "Assembles the scientific narrative and justification for stability claims in regulatory filings.",
      painPointToday: "Reconstructs \"why we believe this shelf-life claim is sound\" from scattered reports, decks and personal knowledge — a slow, audit-risky process.",
      benefitWithReasoning: "Can generate a provenance-backed narrative directly from the graph — every claim traceable to its originating run, analyst, deviation and decision."
    }
  ],
  provenanceTrail: [
    {
      id: "prov-01",
      timestamp: "2025-08-04 09:12",
      actor: "R. Fischer (Analyst)",
      actorType: "human",
      action: "Logged SEC run 18M-R1 result (94.1% main peak purity, Batch 2) into IDBS",
      entity: "exp-114lt-t18-scf",
      studyId: "study-mab114-lt"
    },
    {
      id: "prov-02",
      timestamp: "2025-08-04 09:15",
      actor: "IDBS (system)",
      actorType: "agent",
      action: "Flagged result as OOS against 95% lower spec limit; auto-triggered SOP-QC-014 retest workflow",
      entity: "exp-114lt-t18-scf",
      studyId: "study-mab114-lt"
    },
    {
      id: "prov-03",
      timestamp: "2025-08-04 11:40",
      actor: "Memory Graph Reasoning Agent",
      actorType: "agent",
      action: "Executed cross-study graph walk: joined instrument maintenance record, open deviation DEV-2291, and Batch 2's own 12M/24M main-peak-purity results bracketing the 18M dip",
      entity: "reasoning-chain-114lt-18m",
      studyId: "study-mab114-lt"
    },
    {
      id: "prov-04",
      timestamp: "2025-08-04 11:41",
      actor: "Memory Graph Reasoning Agent",
      actorType: "agent",
      action: "Wrote back hypothesis triple: \"OOS 18M-R1 likely attributable to DEV-2291 (column-performance deviation), not product degradation\" — marked as agent-asserted, pending SME review",
      entity: "hypothesis-114lt-18m-01",
      studyId: "study-mab114-lt"
    },
    {
      id: "prov-05",
      timestamp: "2025-08-05 14:02",
      actor: "R. Fischer (Analyst)",
      actorType: "human",
      action: "Performed retest 18M-R2 on a qualified column; result back within the 95–105% main-peak-purity specification",
      entity: "exp-114lt-t18-scf",
      studyId: "study-mab114-lt"
    },
    {
      id: "prov-06",
      timestamp: "2025-08-06 10:20",
      actor: "Dr. A. Kessler (QA Reviewer)",
      actorType: "human",
      action: "Reviewed agent-asserted hypothesis and retest evidence; approved disposition of 18M-R1 as invalid (assignable instrument cause)",
      entity: "hypothesis-114lt-18m-01",
      studyId: "study-mab114-lt"
    },
    {
      id: "prov-07",
      timestamp: "2025-08-06 10:22",
      actor: "Dr. A. Kessler (QA Reviewer)",
      actorType: "human",
      action: "Human-approved hypothesis promoted from \"pending SME review\" to accepted institutional knowledge in the graph",
      entity: "hypothesis-114lt-18m-01",
      studyId: "study-mab114-lt"
    },
    {
      id: "prov-08",
      timestamp: "2025-08-06 10:25",
      actor: "Memory Graph (system)",
      actorType: "agent",
      action: "Flagged OpenLab-HPLC-04 for preventive-maintenance review ahead of next scheduled stability pull, citing DEV-2291 and the accepted hypothesis as provenance",
      entity: "pm-flag-hplc04",
      studyId: "study-mab114-lt"
    }
  ]
};

// Seed Data
const seedData = {
  virtualLabContent: virtualLabContent,
  products: [
    {
      id: "mAb-Y",
      name: "mAb-Y (anti-HER2)",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.2,
      concentration: "50 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BY-2024-001", "BY-2024-002", "BY-2023-005"]
    },
    {
      id: "mAb-X",
      name: "mAb-X (anti-CD20)",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.5,
      concentration: "100 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BX-2021-001", "BX-2021-002", "BX-2022-003"]
    },
    {
      id: "mAb-Z",
      name: "mAb-Z",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.0,
      concentration: "20 mg/mL",
      surfactant: "PS80 · 0.01%",
      container: "Type-I glass vial",
      registered_batches: ["BZ-2022-001", "BZ-2022-002"]
    },
    {
      id: "mAb-A",
      name: "mAb-A",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.6,
      concentration: "50 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BA-2023-001"]
    },
    {
      id: "mAb-B",
      name: "mAb-B",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.2,
      concentration: "75 mg/mL",
      surfactant: "PS20 · 0.04%",
      container: "Type-I glass vial",
      registered_batches: ["BB-2023-001", "BB-2023-002"]
    },
    {
      id: "mAb-C",
      name: "mAb-C",
      subclass: "IgG1",
      buffer_family: "histidine",
      pH: 5.4,
      concentration: "50 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BC-2022-001"]
    },
    {
      id: "mAb-D",
      name: "mAb-D",
      subclass: "IgG2",
      buffer_family: "phosphate",
      pH: 6.2,
      concentration: "10 mg/mL",
      surfactant: "PS80 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BD-2021-001"]
    },
    {
      id: "mAb-E",
      name: "mAb-E",
      subclass: "IgG4",
      buffer_family: "citrate",
      pH: 6.0,
      concentration: "150 mg/mL",
      surfactant: "PS20 · 0.02%",
      container: "Type-I glass vial",
      registered_batches: ["BE-2020-001"]
    }
  ],
  justifications: [
    {
      id: "JUS-A",
      productId: "mAb-X",
      regulator: "CHMP",
      date: "2022-11",
      outcome: "Accepted",
      proposed_shelf_life: "24 months",
      paragraphs: {
        5: "Long-term data at 5°C demonstrates a stable HMW profile with mean increase of 0.8% per 12 months, projecting a mean HMW at 24 months of 3.2%, well within the shelf-life specification of NMT 4.0%.",
        6: "Arrhenius-based extrapolation using accelerated data at 25°C independently supports the same 24-month shelf life, providing orthogonal confirmation."
      }
    },
    {
      id: "JUS-B-orig",
      productId: "mAb-Z",
      regulator: "FDA",
      date: "2023-04",
      outcome: "Rejected",
      proposed_shelf_life: "36 months",
      paragraphs: {
        3: "The Arrhenius model requires linear kinetics across the temperature range assessed. The applicant's own data at 40°C shows non-Arrhenius behaviour beyond 3 months, suggesting a secondary degradation pathway becomes dominant. The Arrhenius extrapolation to 36 months is therefore not supported by the data submitted."
      }
    },
    {
      id: "JUS-B-rev",
      productId: "mAb-Z",
      regulator: "FDA",
      date: "2023-11",
      outcome: "Accepted",
      proposed_shelf_life: "36 months",
      paragraphs: {
        4: "The revised justification proposes 36 months supported by 24 months of long-term data at 5°C from three batches, with Arrhenius extrapolation retained only as supporting evidence."
      }
    },
    {
      id: "JUS-C",
      productId: "mAb-X",
      regulator: "CHMP",
      date: "2022-11",
      outcome: "Accepted",
      proposed_shelf_life: "24 months",
      paragraphs: {
        3: "Aggregation is the dominant historical driver of shelf-life determination for IgG1 mAbs in histidine formulations.",
        4: "Including the 95% confidence interval on linear regressions at 5°C provides robust validation of the regression model's reliability for projecting shelf-life limits."
      }
    },
    {
      id: "JUS-A-potency",
      productId: "mAb-X",
      regulator: "CHMP",
      date: "2022-11",
      outcome: "Accepted",
      paragraphs: {
        6: "Loss of cell-based potency follows standard first-order kinetics at accelerated temperatures and does not limit shelf-life at 2-8°C up to 36 months."
      }
    }
  ],
  memos_and_logs: {
    "OOT-Y": {
      id: "OOT-Y",
      title: "Charge Isoform Drift Analysis",
      paragraphs: {
        "H3": "The differential is consistent with pH-dependent deamidation kinetics — mAb-Y is at pH 5.2, mAb-X at pH 5.5 — a known effect for IgG1 CDR asparagine residues.",
        "Action": "Contingency: 30-month claim reserved if the 30-month timepoint confirms the projection."
      }
    },
    "MEMO-X-EX": {
      id: "MEMO-X-EX",
      title: "Method Variability in SE-HPLC HMW Determination",
      paragraphs: {
        3: "Observed analytical method variability (SD = 0.15%) indicates that observed aggregation drift exceeds baseline assay noise and represents true chemical degradation."
      }
    },
    "MEMO-X-COMP": {
      id: "MEMO-X-COMP",
      title: "Cross-Batch Comparability Study for IgG1 Monoclonals",
      paragraphs: {
        5: "Batch-to-batch comparability across three GMP validation batches (CV < 5% for slope and intercept at 5°C) justifies using combined regression data for shelf-life extrapolation."
      }
    },
    "TAC-INT": {
      id: "TAC-INT",
      title: "Internal Technical Advisory on Deamidation Kinetics",
      paragraphs: {
        "Q6": "Deamidation rates of IgG1 CDR regions display acute sensitivity to formulation pH between 5.0 and 6.0, doubling for every 0.4 pH unit drop."
      }
    },
    "TAC-HAND": {
      id: "TAC-HAND",
      title: "Regulatory Negotiation Handbook",
      paragraphs: {
        4: "Proactive disclosure of open OOT investigations with a robust root-cause analysis is strongly favored by EMA/FDA assessors over reactive disclosure during Day 120/180 question rounds."
      }
    },
    "REG-Z": {
      id: "REG-Z",
      title: "Precedents on Charge-Isoform Drift Hedges",
      paragraphs: {
        "round 2": "Including clinical batch comparability and showing that high acidic variant content remains biologically active (potency unchanged) mitigates regulatory queries regarding charge isoform drift."
      }
    }
  },
  learnings: [
    {
      id: "LEARN:JUS-B-01",
      title: "Arrhenius Extrapolation Limits",
      text: "Before proposing Arrhenius as a primary argument, verify linear kinetics across the full temperature range (5/25/40°C). For mAb-Y, HMW kinetics at 40°C are near-linear through 6 months — Arrhenius as supporting is defensible; Arrhenius as primary is not.",
      source: "JUS-B-orig ¶3",
      applicableTo: "IgG1 Extrapolation"
    }
  ]
};

if (typeof module !== 'undefined') {
  module.exports = seedData;
}

