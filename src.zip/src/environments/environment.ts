/**
 * Development environment.
 * The Cognizant backend runs on http://localhost:8001 by default.
 */
export const environment = {
  production: false,
  apiBaseUrl: '/api/servicenow',
  fetchTicketPath: '/tools/fetch_ticket',
  ticketQuery: {
    created_by: '',
    page: 1,
    page_size: 10,
  },
  /** Ticket-query body fields that SentinelApiService overwrites with the
   *  authenticated user's email at request time. Keeps dev parity with prod
   *  (which uses 'assigned_to'); dev still defaults to created_by so the
   *  hardcoded Suganya email above kicks in when ALB OIDC isn't wired. */
  userIdentityFields: ['created_by'],

  /* ── Jobs orchestration APIs ─────────────────────────────────────────
   * Two services back the Resolve flow on the Incidents page:
   *   - jobsResolveUrl: POST returns { job_id, status: 'accepted' }
   *   - jobsOrchStepsBase: GET {base}/{job_id}/orch-steps returns the
   *     orchestration step list once the agents have run.
   * jobsPollDelayMs is how long the UI waits after the resolve call
   * before requesting orch-steps (the agents need ~10s to produce output).
   */
  // Relative paths — routed by proxy.conf.json:
  //   /api/jobs/resolve        -> http://localhost:8080/v1/jobs/resolve  (resolve service)
  //   /api/jobs/{id}/resume    -> http://localhost:8003/v1/jobs/{id}/resume  (resume / orchestrator)
  jobsResolveUrl: '/api/jobs/resolve',
  jobsOrchStepsBase: '/api/jobs',
  /** Plan-approval endpoint — POST /api/jobs/{id}/approve (the renamed
   *  /resume; orchestrator. nginx routes the regex to the orchestrator, the
   *  bare /api/jobs/{id} status GET goes to the wss-service). */
  jobsApproveBase: '/api/jobs',
  /** View Ticket APIs (run on a separate service from resolve/resume).
   *   /api/view-jobs/{jobId}?include_steps=true  -> http://localhost:8003/v1/jobs/{jobId}?include_steps=true
   *   /api/view-jobs?ticket_id=INC...            -> http://localhost:8003/v1/jobs?ticket_id=INC...   (lookup)
   * Adjust jobsLookupUrl to match the actual backend lookup endpoint when known. */
  jobsViewUrlBase: '/api/view-jobs',
  jobsLookupUrl: '/api/view-jobs',

  /* ── Identity service (sentinel_identity_service) ─────────────────────
   * Same-origin path proxied by nginx (docker/default.conf) /
   * proxy.conf.json in dev, so browser XHR stays CORS-free. The session JWT
   * obtained from OIDC login is forwarded to the orchestrator by
   * authInterceptor. Override at runtime via window.__env.identityBaseUrl. */
  identityBaseUrl: '/api/identity',

  /* ── Orchestrator agent (cognizant_ams_orchestrator_agent) ────────────
   * Same-origin path proxied to the orchestrator by proxy.conf.json (dev) /
   * docker/default.conf (prod). Backs the MCP Tools settings page:
   * GET /v1/mcp/catalog returns the live server+tool catalog. The session
   * JWT is attached by authInterceptor. Override at runtime via
   * window.__env.orchestratorBaseUrl. */
  orchestratorBaseUrl: '/api/orchestrator',

  /* ── Cognizant Audit Server (cognizant-audit-server) ──────────────────
   * Same-origin path proxied to the audit server's query API by
   * proxy.conf.json (dev) / docker/default.conf (prod). Backs the Audit
   * section: /summary, /events, /incidents. The session JWT is attached by
   * authInterceptor; the audit server maps the identity role to its RBAC. */
  auditBaseUrl: '/api/audit',

  /* ── Scheduler service (cognizant_scheduler_service) ──────────────────
   * Same-origin path proxied to the scheduler's /v1/scheduler API root by
   * proxy.conf.json (dev) / docker/default.conf (prod). Backs the schedule
   * management feature: engineers submit weekly availability and supervisors
   * approve it. Override at runtime via window.__env.schedulerBaseUrl. */
  schedulerBaseUrl: '/api/scheduler',
  oidcRedirectUri: window.location.origin + '/auth/callback',
  jobsUserContext: {
    engineer_id: 'suganya.muruganandham@cognizant.com',
    engineer_name: 'Suganya Muruganandham',
    engineer_mail: 'suganya.muruganandham@cognizant.com',
    role: 'L2',
    lead_id: 'lead_001',
    session_id: 'test_session_20260513',
    ticket_categories: ['incident'],
    priority_rules: {} as Record<string, unknown>,
  },
};
