/**
 * Production environment.
 *
 * All backend URLs are same-origin (`/api/...`). In a cluster deploy the
 * nginx sidecar (docker/default.conf) proxies them to the in-cluster
 * Services in the target namespace:
 *
 *   /api/servicenow/*           -> sentinel-servicenow-mcp-server:8080/*
 *   /api/jobs/resolve           -> cognizant-orchestrator-agent:8080/v1/jobs/resolve
 *   /api/jobs/{id}/resume       -> cognizant-orchestrator-agent:8080/v1/jobs/{id}/resume
 *   /api/view-jobs/{id}         -> cognizant-wss-service:8080/v1/jobs/{id}        (view history)
 *   /api/view-jobs?ticket_id=…  -> cognizant-wss-service:8080/v1/jobs?ticket_id=…  (lookup)
 *   /api/jobs/{id}/* (anything  -> cognizant-wss-service:8080/v1/jobs/{id}/*
 *     else, e.g. orch-steps)
 */
export const environment = {
  production: true,
  apiBaseUrl: '/api/servicenow',
  fetchTicketPath: '/tools/fetch_ticket',
  ticketQuery: {
    // `assigned_to` is intentionally empty; SentinelApiService fills it in
    // with the authenticated user's email at request time. The backend
    // returns no tickets if this is empty — which is the correct signal
    // when running without ALB OIDC auth.
    assigned_to: '',
    page: 1,
    page_size: 10,
  },
  /** Ticket-query body fields to substitute with the logged-in user's email. */
  userIdentityFields: ['assigned_to'],

  jobsResolveUrl: '/api/jobs/resolve',
  jobsOrchStepsBase: '/api/jobs',
  /** Plan-approval endpoint — POST /api/jobs/{id}/approve (the renamed
   *  /resume). nginx routes the .../approve regex → orchestrator-agent:8080;
   *  the bare /api/jobs/{id} status GET → wss-service. */
  jobsApproveBase: '/api/jobs',
  /** View Ticket APIs — proxied to cognizant-wss-service by nginx. */
  jobsViewUrlBase: '/api/view-jobs',
  jobsLookupUrl: '/api/view-jobs',

  /* Identity service — same-origin path proxied by nginx to
   * sentinel-identity-service:8080. Override at runtime via
   * window.__env.identityBaseUrl (Helm values-*.yaml config.envJs). */
  identityBaseUrl: '/api/identity',

  /* Orchestrator agent — same-origin path proxied by nginx to
   * cognizant-orchestrator-agent:8080. Backs the MCP Tools settings page
   * (GET /v1/mcp/catalog). Override at runtime via
   * window.__env.orchestratorBaseUrl (Helm values-*.yaml config.envJs). */
  orchestratorBaseUrl: '/api/orchestrator',

  /* Cognizant Audit Server — same-origin path proxied by nginx to
   * cognizant-audit-server:8000. Backs the Audit section (summary/events/
   * incidents). Session JWT attached by authInterceptor. */
  auditBaseUrl: '/api/audit',

  /* Scheduler service — same-origin path proxied by nginx to
   * cognizant-scheduler-service:8000/v1/scheduler. Override at runtime via
   * window.__env.schedulerBaseUrl (Helm values-*.yaml config.envJs). */
  schedulerBaseUrl: '/api/scheduler',
  oidcRedirectUri: window.location.origin + '/auth/callback',
  jobsUserContext: {
    // Filled in by JobsService.buildUserContext() from the authenticated user.
    engineer_id: '',
    engineer_name: '',
    engineer_mail: '',
    role: 'L2',
    lead_id: 'lead_001',
    session_id: 'test_session_20260513',
    ticket_categories: ['incident'],
    priority_rules: {} as Record<string, unknown>,
  },
};
