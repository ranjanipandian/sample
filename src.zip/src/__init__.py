"""
Stage-1 Classical Image QC Engine
A deterministic, modality-agnostic quality control system for microscopy images.
"""

__version__ = "1.0.0"
__author__ = "Image QC Team"
