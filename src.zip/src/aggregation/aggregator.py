"""
Metric Aggregation - Combine slice-level metrics to volume/temporal levels
"""

import numpy as np
from typing import Dict, List


def aggregate_slice_metrics(slice_metrics_list: List[Dict]) -> Dict[str, float]:
    """
    Aggregate slice-level metrics to volume level.
    
    Args:
        slice_metrics_list: List of metric dictionaries from individual slices
        
    Returns:
        Aggregated metrics dictionary
    """
    if not slice_metrics_list:
        return {}
    
    aggregated = {}
    
    # Get all metric keys from first slice
    metric_keys = slice_metrics_list[0].keys()
    
    for key in metric_keys:
        # Skip non-numeric metrics
        try:
            values = [metrics[key] for metrics in slice_metrics_list 
                     if key in metrics and isinstance(metrics[key], (int, float, np.number))]
            
            if values:
                # Compute statistics
                aggregated[f'{key}_mean'] = float(np.mean(values))
                aggregated[f'{key}_std'] = float(np.std(values))
                aggregated[f'{key}_min'] = float(np.min(values))
                aggregated[f'{key}_max'] = float(np.max(values))
                aggregated[f'{key}_median'] = float(np.median(values))
        except:
            pass
    
    return aggregated


def aggregate_z_profile(z_metrics_list: List[Dict], metric_name: str) -> Dict[str, float]:
    """
    Create Z-profile for a specific metric.
    
    Args:
        z_metrics_list: List of metrics for each Z-slice
        metric_name: Name of metric to profile
        
    Returns:
        Z-profile statistics
    """
    values = []
    for metrics in z_metrics_list:
        if metric_name in metrics:
            values.append(metrics[metric_name])
    
    if not values:
        return {}
    
    values = np.array(values)
    
    # Find best/worst slices
    best_idx = int(np.argmax(values))
    worst_idx = int(np.argmin(values))
    
    # Compute stability
    cv = np.std(values) / (np.mean(values) + 1e-10)
    
    return {
        f'{metric_name}_z_mean': float(np.mean(values)),
        f'{metric_name}_z_std': float(np.std(values)),
        f'{metric_name}_z_range': float(np.max(values) - np.min(values)),
        f'{metric_name}_z_cv': float(cv),
        f'{metric_name}_best_z': best_idx,
        f'{metric_name}_worst_z': worst_idx
    }


def aggregate_temporal_metrics(timepoint_metrics_list: List[Dict]) -> Dict[str, float]:
    """
    Aggregate metrics across time.
    
    Args:
        timepoint_metrics_list: List of metrics for each timepoint
        
    Returns:
        Temporal aggregation
    """
    if not timepoint_metrics_list:
        return {}
    
    aggregated = {}
    
    # Get all metric keys
    metric_keys = timepoint_metrics_list[0].keys()
    
    for key in metric_keys:
        try:
            values = [metrics[key] for metrics in timepoint_metrics_list 
                     if key in metrics and isinstance(metrics[key], (int, float, np.number))]
            
            if values:
                values = np.array(values)
                
                # Temporal statistics
                aggregated[f'{key}_temporal_mean'] = float(np.mean(values))
                aggregated[f'{key}_temporal_std'] = float(np.std(values))
                aggregated[f'{key}_temporal_trend'] = compute_trend(values)
                
                # Stability
                cv = np.std(values) / (np.mean(values) + 1e-10)
                aggregated[f'{key}_temporal_stability'] = float(1.0 / (1.0 + cv))
        except:
            pass
    
    return aggregated


def compute_trend(values: np.ndarray) -> float:
    """
    Compute linear trend in values.
    
    Args:
        values: Array of values
        
    Returns:
        Normalized slope
    """
    if len(values) < 2:
        return 0.0
    
    t = np.arange(len(values))
    try:
        slope, _ = np.polyfit(t, values, 1)
        mean_val = np.mean(values)
        normalized_slope = slope / (abs(mean_val) + 1e-10)
        return float(normalized_slope)
    except:
        return 0.0


def compute_global_summary(all_metrics: Dict) -> Dict[str, float]:
    """
    Compute global summary statistics from all metrics.
    
    Args:
        all_metrics: Complete metrics dictionary
        
    Returns:
        Global summary
    """
    summary = {}
    
    # Extract key quality indicators
    if 'per_slice_metrics' in all_metrics and all_metrics['per_slice_metrics']:
        first_slice = all_metrics['per_slice_metrics'][0]
        
        # SNR summary
        if 'snr' in first_slice:
            snr_values = [m['snr'] for m in all_metrics['per_slice_metrics'] if 'snr' in m]
            summary['mean_snr'] = float(np.mean(snr_values))
            summary['min_snr'] = float(np.min(snr_values))
        
        # Focus summary
        if 'laplacian_variance' in first_slice:
            focus_values = [m['laplacian_variance'] for m in all_metrics['per_slice_metrics'] 
                          if 'laplacian_variance' in m]
            summary['mean_focus_quality'] = float(np.mean(focus_values))
        
        # Noise summary
        if 'gaussian_noise_sigma' in first_slice:
            noise_values = [m['gaussian_noise_sigma'] for m in all_metrics['per_slice_metrics'] 
                          if 'gaussian_noise_sigma' in m]
            summary['mean_noise_level'] = float(np.mean(noise_values))
    
    return summary
