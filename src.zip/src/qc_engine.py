"""
Main QC Engine - Orchestrates the entire QC pipeline
"""

import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import multiprocessing as mp
from multiprocessing import shared_memory
import os

from .core.image_loader import ImageLoader
from .core.dimension_handler import DimensionHandler
from .core.sampling import generate_structured_sampling_indices, get_sampling_info, should_enable_sampling
from .metrics import (signal_quality, blur_focus, noise, thresholding, 
                     intensity, contrast, illumination, structural, 
                     artifacts, dimensional, segmentability, integrity)
from .metrics.validation import is_valid_image_slice
from .aggregation.aggregator import (aggregate_slice_metrics, aggregate_z_profile,
                                     aggregate_temporal_metrics, compute_global_summary)
from .core.config import get_config

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False
    def tqdm(iterable, **kwargs):
        return iterable


# Top-level worker function for multiprocessing (Windows-compatible)
def _compute_slice_metrics_worker(args: Tuple) -> Dict:
    """
    Worker function for parallel slice processing with shared memory.
    Must be at module level for Windows multiprocessing compatibility.
    
    Args:
        args: Tuple of (t, z, c, shm_name, shape, dtype, fast_mode)
        
    Returns:
        Dictionary of metrics with indices
    """
    t, z, c, shm_name, shape, dtype, fast_mode = args
    
    # Attach to shared memory and extract the slice
    try:
        shm = shared_memory.SharedMemory(name=shm_name)
        shared_array = np.ndarray(shape, dtype=dtype, buffer=shm.buf)
        # Copy only the specific slice we need
        slice_2d = shared_array[t, z, c, :, :].copy()
        shm.close()  # Close connection (don't unlink - main process owns it)
    except Exception:
        # If shared memory fails, return invalid result
        return {
            'slice_valid': False,
            'skip_reason': 'shared_memory_error',
            't': int(t),
            'z': int(z),
            'c': int(c)
        }
    
    metrics = {}
    
    # Quick validity check
    if not is_valid_image_slice(slice_2d, min_pixels=10):
        metrics['slice_valid'] = False
        metrics['skip_reason'] = 'uniform_or_empty'
        metrics['t'] = int(t)
        metrics['z'] = int(z)
        metrics['c'] = int(c)
        return metrics
    
    metrics['slice_valid'] = True
    
    # 1. Signal Quality
    try:
        metrics.update(signal_quality.compute_signal_quality_metrics(slice_2d))
    except Exception:
        pass  # Silent failure in worker
    
    # 2. Blur/Focus
    metrics.update(blur_focus.compute_blur_focus_metrics(slice_2d))
    
    # 3. Noise
    metrics.update(noise.compute_noise_metrics(slice_2d))
    
    # 4. Thresholding
    metrics.update(thresholding.compute_thresholding_metrics(slice_2d))
    
    # 5. Intensity
    metrics.update(intensity.compute_intensity_metrics(slice_2d))
    
    # 6. Contrast
    metrics.update(contrast.compute_contrast_metrics(slice_2d))
    
    # 7. Illumination
    metrics.update(illumination.compute_illumination_metrics(slice_2d))
    
    # 8. Structural (with config flags for heavy metrics)
    enable_glcm = get_config('enable_glcm_texture') or False
    enable_structure = get_config('enable_structure_estimation') or False
    metrics.update(structural.compute_structural_metrics(slice_2d, enable_glcm, enable_structure))
    
    # 9. Artifacts
    metrics.update(artifacts.compute_artifact_metrics(slice_2d))
    
    # 10. Segmentability
    metrics.update(segmentability.compute_segmentability_metrics(slice_2d))
    
    # Add indices
    metrics['t'] = int(t)
    metrics['z'] = int(z)
    metrics['c'] = int(c)
    
    return metrics


class QCEngine:
    """
    Main QC Engine for computing comprehensive image quality metrics.
    """
    
    def __init__(self, verbose: bool = False, fast_mode: bool = False, 
                 sample_rate: int = 10, full_analysis: bool = False,
                 num_workers: int = -1, enable_parallel: bool = True):
        """
        Initialize QC Engine.
        
        Args:
            verbose: Enable verbose output
            fast_mode: Enable fast mode (sampling + skip heavy metrics)
            sample_rate: Sampling rate for large datasets
            full_analysis: Force full analysis (no sampling)
            num_workers: Number of parallel workers (-1 = auto, 0 = disable)
            enable_parallel: Enable parallel processing
        """
        self.verbose = verbose
        self.fast_mode = fast_mode
        self.sample_rate = sample_rate
        self.full_analysis = full_analysis
        self.enable_parallel = enable_parallel and num_workers != 0
        
        # Determine number of workers
        if num_workers == -1:
            # Auto: use all cores, minimum 2 for meaningful parallelism
            self.num_workers = max(2, mp.cpu_count())
        elif num_workers == 0:
            self.num_workers = 0
            self.enable_parallel = False
        else:
            self.num_workers = max(1, num_workers)
        
        self.image_loader = None
        self.image_data = None
        self.metadata = None
        self.dimensions = None
        self.results = {}
    
    def load_image(self, image_path: str):
        """
        Load image for QC analysis.
        
        Args:
            image_path: Path to TIFF image
        """
        if self.verbose:
            print(f"Loading image: {image_path}")
        
        self.image_loader = ImageLoader(image_path)
        self.image_data = self.image_loader.load()
        self.metadata = self.image_loader.get_metadata()
        self.dimensions = self.image_loader.get_dimensions()
        
        if self.verbose:
            print(f"Image dimensions: {self.dimensions}")
            print(f"Data type: {self.metadata.get('dtype')}")
    
    def compute_slice_metrics(self, slice_2d: np.ndarray) -> Dict:
        """
        Compute all metrics for a single 2D slice.
        
        Args:
            slice_2d: 2D image array
            
        Returns:
            Dictionary of metrics (may contain NaN for invalid slices)
        """
        metrics = {}
        
        # Quick validity check
        if not is_valid_image_slice(slice_2d, min_pixels=10):
            # Return NaN metrics for invalid slice
            metrics['slice_valid'] = False
            metrics['skip_reason'] = 'uniform_or_empty'
            return metrics
        
        metrics['slice_valid'] = True
        
        # 1. Signal Quality
        try:
            metrics.update(signal_quality.compute_signal_quality_metrics(slice_2d))
        except Exception as e:
            if self.verbose:
                print(f"  Warning: Signal quality metrics failed: {e}")
        
        # 2. Blur/Focus
        metrics.update(blur_focus.compute_blur_focus_metrics(slice_2d))
        
        # 3. Noise
        metrics.update(noise.compute_noise_metrics(slice_2d))
        
        # 4. Thresholding
        metrics.update(thresholding.compute_thresholding_metrics(slice_2d))
        
        # 5. Intensity
        metrics.update(intensity.compute_intensity_metrics(slice_2d))
        
        # 6. Contrast
        metrics.update(contrast.compute_contrast_metrics(slice_2d))
        
        # 7. Illumination
        metrics.update(illumination.compute_illumination_metrics(slice_2d))
        
        # 8. Structural (with config flags for heavy metrics)
        from .core.config import get_config
        enable_glcm = get_config('enable_glcm_texture') or False
        enable_structure = get_config('enable_structure_estimation') or False
        metrics.update(structural.compute_structural_metrics(slice_2d, enable_glcm, enable_structure))
        
        # 9. Artifacts
        metrics.update(artifacts.compute_artifact_metrics(slice_2d))
        
        # 10. Segmentability
        metrics.update(segmentability.compute_segmentability_metrics(slice_2d))
        
        return metrics
    
    def compute_volume_metrics(self, volume_3d: np.ndarray, t: int, c: int) -> Dict:
        """
        Compute 3D-specific metrics for a volume.
        
        Args:
            volume_3d: 3D array (Z, Y, X)
            t: Time index
            c: Channel index
            
        Returns:
            Dictionary of volume metrics
        """
        metrics = {}
        
        # Dimensional metrics (3D specific)
        Z = volume_3d.shape[0]
        
        if Z > 1:
            # Defocused slices
            defocus_metrics = dimensional.compute_defocused_slices_percentage(volume_3d)
            metrics.update(defocus_metrics)
            
            # Z-consistency
            metrics['z_consistency_score'] = dimensional.compute_z_consistency_score(volume_3d)
            
            # Z-illumination stability
            z_illum_metrics = illumination.compute_z_illumination_stability(volume_3d)
            metrics.update(z_illum_metrics)
            
            # Best focus slice
            best_focus_z = blur_focus.find_best_focus_slice(volume_3d)
            metrics['best_focus_z_index'] = best_focus_z
        
        return metrics
    
    def compute_temporal_metrics(self, timeseries: np.ndarray, c: int) -> Dict:
        """
        Compute 4D-specific temporal metrics.
        
        Args:
            timeseries: 4D array (T, Z, Y, X) or 3D (T, Y, X)
            c: Channel index
            
        Returns:
            Dictionary of temporal metrics
        """
        metrics = {}
        
        T = timeseries.shape[0]
        
        if T > 1:
            # Temporal illumination drift
            drift_metrics = illumination.compute_temporal_illumination_drift(timeseries)
            metrics.update(drift_metrics)
            
            # Frame-to-frame SNR stability
            snr_stability = dimensional.compute_frame_to_frame_snr_stability(timeseries)
            metrics.update(snr_stability)
            
            # Temporal blur drift
            blur_drift = dimensional.compute_temporal_blur_drift(timeseries)
            metrics.update(blur_drift)
            
            # Photobleaching
            photobleach_metrics = dimensional.estimate_photobleaching_rate(timeseries)
            metrics.update(photobleach_metrics)
            
            # Z-drift (if 4D)
            if timeseries.ndim == 4 and timeseries.shape[1] > 1:
                z_drift = dimensional.detect_z_drift(timeseries)
                metrics.update(z_drift)
        
        return metrics
    
    def run_qc(self) -> Dict:
        """
        Run complete QC analysis.
        
        Returns:
            Complete QC results dictionary
        """
        if self.image_data is None:
            raise ValueError("No image loaded. Call load_image() first.")
        
        T, Z, C, Y, X = self.image_data.shape
        
        if self.verbose:
            print(f"\nRunning QC analysis...")
            print(f"Processing {T} timepoints, {Z} z-slices, {C} channels")
        
        # Initialize results structure
        self.results = {
            'metadata': {
                'image_path': str(self.image_loader.image_path),
                'analysis_timestamp': datetime.now().isoformat(),
                'dimensions': self.dimensions,
                'dtype': self.metadata.get('dtype'),
                'bit_depth': self.metadata.get('bit_depth'),
                'original_shape': str(self.metadata.get('original_shape')),
                'dimension_order': self.metadata.get('dimension_order')
            },
            'per_slice_metrics': [],
            'per_volume_metrics': [],
            'per_timepoint_metrics': [],
            'global_summary': {}
        }
        
        # Determine sampling strategy
        use_sampling = should_enable_sampling(T, Z, C) and not self.full_analysis
        
        if use_sampling:
            sampling_info = get_sampling_info(T, Z, C, self.sample_rate)
            sampling_indices = generate_structured_sampling_indices(
                T, Z, C, self.sample_rate, force_full=False
            )
            
            print(f"\n⚡ Large dataset detected: {sampling_info['total_slices']:,} total slices")
            print(f"   Using structured sampling (first/mid/last + every {self.sample_rate}th)")
            print(f"   Processing {sampling_info['sampled_slices']:,} representative slices " +
                  f"({sampling_info['percentage_processed']:.1f}%)")
            print(f"   Speed improvement: ~{sampling_info['reduction_factor']:.1f}x faster\n")
            
            # Store sampling info in results
            self.results['sampling'] = sampling_info
        else:
            sampling_indices = None
            self.results['sampling'] = {
                'sampling_enabled': False,
                'total_slices': T * Z * C
            }
        
        # Compute per-slice metrics
        if self.verbose:
            print("Computing per-slice metrics...")
        
        # Create iterator
        if sampling_indices:
            # Sampled processing
            indices_list = sampling_indices
            desc = "Processing slices (sampled)"
        else:
            # Full processing
            indices_list = [(t, z, c) for t in range(T) for z in range(Z) for c in range(C)]
            desc = "Processing slices (full)"
        
        # Smart decision: Use shared memory for large images only
        image_size_mb = self.image_data.nbytes / (1024 * 1024)
        num_slices = len(indices_list)
        use_shared_memory = (
            self.enable_parallel and 
            num_slices > 10 and
            (image_size_mb > 200 or num_slices > 1000)
        )
        
        if use_shared_memory:
            # Parallel processing with shared memory
            if self.verbose:
                print(f"Using {self.num_workers} parallel workers with shared memory (image: {image_size_mb:.1f}MB)")
            
            shm = None
            try:
                # Create shared memory for the image array
                shm = shared_memory.SharedMemory(create=True, size=self.image_data.nbytes)
                shared_array = np.ndarray(
                    self.image_data.shape, 
                    dtype=self.image_data.dtype, 
                    buffer=shm.buf
                )
                shared_array[:] = self.image_data[:]  # One-time copy
                
                # Prepare worker arguments with shared memory reference
                worker_args = [
                    (t, z, c, shm.name, self.image_data.shape, self.image_data.dtype, self.fast_mode)
                    for t, z, c in indices_list
                ]
                
                # Process in parallel
                with mp.Pool(processes=self.num_workers) as pool:
                    if TQDM_AVAILABLE:
                        slice_results = list(tqdm(
                            pool.imap(_compute_slice_metrics_worker, worker_args),
                            total=len(worker_args),
                            desc=desc,
                            unit="slice"
                        ))
                    else:
                        slice_results = pool.map(_compute_slice_metrics_worker, worker_args)
                
                self.results['per_slice_metrics'] = slice_results
                
            except Exception as e:
                if self.verbose:
                    print(f"Shared memory parallel processing failed ({e}), falling back to sequential...")
                # Fall back to sequential processing
                self._process_slices_sequential_direct(indices_list, desc)
            finally:
                # Clean up shared memory
                if shm is not None:
                    try:
                        shm.close()
                        shm.unlink()
                    except:
                        pass
        else:
            # Sequential processing for small images
            if self.verbose and self.enable_parallel:
                print(f"Using sequential processing (image: {image_size_mb:.1f}MB, {num_slices} slices)")
            self._process_slices_sequential_direct(indices_list, desc)
        
        # Sort results by (t, z, c) for deterministic ordering
        self.results['per_slice_metrics'].sort(key=lambda x: (x['t'], x['z'], x['c']))
        
        # Compute per-volume metrics (if 3D)
        if Z > 1:
            if self.verbose:
                print("Computing per-volume metrics...")
            
            for t, c, volume_3d in DimensionHandler.iterate_volumes(self.image_data):
                volume_metrics = self.compute_volume_metrics(volume_3d, t, c)
                volume_metrics['t'] = int(t)
                volume_metrics['c'] = int(c)
                self.results['per_volume_metrics'].append(volume_metrics)
        
        # Compute temporal metrics (if 4D)
        if T > 1:
            if self.verbose:
                print("Computing temporal metrics...")
            
            for c in range(C):
                timeseries = self.image_data[:, :, c, :, :]
                temporal_metrics = self.compute_temporal_metrics(timeseries, c)
                temporal_metrics['c'] = int(c)
                self.results['per_timepoint_metrics'].append(temporal_metrics)
        
        # Compute integrity metrics
        if self.verbose:
            print("Computing integrity metrics...")
        
        integrity_metrics = integrity.compute_integrity_metrics(
            self.image_data, 
            self.metadata
        )
        self.results['integrity'] = integrity_metrics
        
        # Aggregate metrics
        if self.verbose:
            print("Aggregating metrics...")
        
        if self.results['per_slice_metrics']:
            aggregated = aggregate_slice_metrics(self.results['per_slice_metrics'])
            self.results['aggregated_metrics'] = aggregated
        
        # Compute global summary
        self.results['global_summary'] = compute_global_summary(self.results)
        
        if self.verbose:
            print("QC analysis complete!")
        
        return self.results
    
    def _process_slices_sequential_direct(self, indices_list: List[Tuple], desc: str):
        """
        Process slices sequentially without copying data upfront.
        
        Args:
            indices_list: List of (t, z, c) tuples
            desc: Description for progress bar
        """
        if TQDM_AVAILABLE:
            iterator = tqdm(indices_list, desc=desc, unit="slice")
        else:
            iterator = indices_list
        
        slice_results = []
        for t, z, c in iterator:
            slice_2d = self.image_data[t, z, c, :, :]
            slice_metrics = self.compute_slice_metrics(slice_2d)
            slice_metrics['t'] = int(t)
            slice_metrics['z'] = int(z)
            slice_metrics['c'] = int(c)
            slice_results.append(slice_metrics)
        
        self.results['per_slice_metrics'] = slice_results
    
    def get_results(self) -> Dict:
        """Get QC results."""
        return self.results
