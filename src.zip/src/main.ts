import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { APP_INITIALIZER } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { PreloadAllModules, provideRouter, withPreloading } from '@angular/router';

import { AppComponent } from './app/app.component';
import { APP_ROUTES } from './app/app.routes';
import { authInterceptor } from './app/core/interceptors/auth.interceptor';
import { loggingInterceptor } from './app/core/interceptors/logging.interceptor';
import { AuthService } from './app/core/services/auth.service';

bootstrapApplication(AppComponent, {
  providers: [
    provideRouter(APP_ROUTES, withPreloading(PreloadAllModules)),
    // The logging interceptor stamps every outbound HttpClient request with
    // a per-request X-Request-ID, which nginx (docker/default.conf) forwards
    // to backend services. Each service threads the same id into its async
    // log context, so a Grafana query on request_id returns the full chain:
    // SPA -> nginx -> orchestrator -> WSS -> ServiceNow MCP -> Veeva MCP.
    provideHttpClient(withInterceptors([loggingInterceptor, authInterceptor])),
    // Silent-refresh the identity-service session before any component renders
    // so services (TicketService, JobsService) see a populated AuthService.user
    // on their first call. AuthService.load() never throws — it falls back to
    // ANONYMOUS on any error, keeping local dev / unauthenticated paths usable.
    {
      provide: APP_INITIALIZER,
      multi: true,
      useFactory: (auth: AuthService) => () => auth.load(),
      deps: [AuthService],
    },
  ],
}).catch((err) => console.error(err));
