"""
Blur and Focus Quality Metrics
"""

import numpy as np
import cv2
from typing import Dict
from scipy import ndimage
from scipy.fft import fft2, fftshift


def compute_laplacian_variance(image: np.ndarray) -> float:
    """
    Compute Laplacian variance as a focus measure.
    Higher values indicate sharper focus.
    
    Args:
        image: Input 2D image
        
    Returns:
        Laplacian variance
    """
    # Convert to uint8 or uint16 for OpenCV compatibility
    if image.dtype == np.uint8:
        image_cv = image
    elif image.dtype == np.uint16:
        image_cv = image
    else:
        # Normalize float to uint8 range
        img_min, img_max = image.min(), image.max()
        if img_max > img_min:
            image_normalized = ((image - img_min) / (img_max - img_min) * 255)
            image_cv = image_normalized.astype(np.uint8)
        else:
            image_cv = np.zeros_like(image, dtype=np.uint8)
    
    # Compute Laplacian
    laplacian = cv2.Laplacian(image_cv, cv2.CV_64F)
    variance = np.var(laplacian)
    
    return float(variance)


def compute_fft_high_frequency_energy(image: np.ndarray, 
                                      center_fraction: float = 0.5) -> float:
    """
    Compute high-frequency energy in FFT spectrum.
    
    Args:
        image: Input 2D image
        center_fraction: Fraction of spectrum considered as low-frequency (center)
        
    Returns:
        Ratio of high-frequency to total energy
    """
    # Compute FFT
    f_transform = fft2(image.astype(float))
    f_shift = fftshift(f_transform)
    magnitude_spectrum = np.abs(f_shift)
    
    # Calculate center region (low frequency)
    rows, cols = image.shape
    center_y, center_x = rows // 2, cols // 2
    
    # Define low-frequency region as center_fraction of the spectrum
    low_freq_radius_y = max(1, int(rows * center_fraction / 2))
    low_freq_radius_x = max(1, int(cols * center_fraction / 2))
    
    # Create mask for low-frequency region
    y, x = np.ogrid[:rows, :cols]
    mask = ((y - center_y) ** 2 / (low_freq_radius_y ** 2 + 1e-10) + 
            (x - center_x) ** 2 / (low_freq_radius_x ** 2 + 1e-10)) <= 1
    
    # Calculate energy
    total_energy = np.sum(magnitude_spectrum ** 2)
    low_freq_energy = np.sum((magnitude_spectrum * mask) ** 2)
    high_freq_energy = total_energy - low_freq_energy
    
    if total_energy == 0:
        return 0.0
    
    high_freq_ratio = high_freq_energy / total_energy
    return float(high_freq_ratio)


def compute_normalized_variance(image: np.ndarray) -> float:
    """
    Compute normalized variance as a focus measure.
    
    Args:
        image: Input 2D image
        
    Returns:
        Normalized variance
    """
    mean_val = np.mean(image)
    if mean_val == 0:
        return 0.0
    
    variance = np.var(image)
    normalized_var = variance / (mean_val ** 2) if mean_val != 0 else 0.0
    
    return float(normalized_var)


def compute_vollath_f4(image: np.ndarray) -> float:
    """
    Compute Vollath's F4 autocorrelation-based focus measure.
    
    Args:
        image: Input 2D image
        
    Returns:
        Vollath F4 value
    """
    image_float = image.astype(np.float64)
    
    # F4 = mean(I * shift(I, 1)) - mean(I * shift(I, 2))
    shifted_1 = np.roll(image_float, 1, axis=0)
    shifted_2 = np.roll(image_float, 2, axis=0)
    
    f4 = np.mean(image_float * shifted_1) - np.mean(image_float * shifted_2)
    
    return float(f4)


def compute_vollath_f5(image: np.ndarray) -> float:
    """
    Compute Vollath's F5 autocorrelation-based focus measure.
    
    Args:
        image: Input 2D image
        
    Returns:
        Vollath F5 value
    """
    image_float = image.astype(np.float64)
    mean_val = np.mean(image_float)
    
    # F5 = mean((I - mean) * shift(I, 1))
    shifted_1 = np.roll(image_float, 1, axis=0)
    f5 = np.mean((image_float - mean_val) * shifted_1)
    
    return float(f5)


def compute_brenner_gradient(image: np.ndarray) -> float:
    """
    Compute Brenner gradient focus measure.
    
    Args:
        image: Input 2D image
        
    Returns:
        Brenner gradient value
    """
    image_float = image.astype(np.float64)
    
    # Compute differences with 2-pixel shifts
    diff_y = image_float[2:, :] - image_float[:-2, :]
    diff_x = image_float[:, 2:] - image_float[:, :-2]
    
    brenner = np.sum(diff_y ** 2) + np.sum(diff_x ** 2)
    
    return float(brenner)


def compute_tenengrad(image: np.ndarray) -> float:
    """
    Compute Tenengrad focus measure using Sobel operator.
    
    Args:
        image: Input 2D image
        
    Returns:
        Tenengrad value
    """
    # Convert to appropriate type
    if image.dtype == np.uint8:
        image_input = image
    else:
        # Normalize to uint8 range for Sobel
        image_normalized = ((image - image.min()) / (image.max() - image.min() + 1e-10) * 255)
        image_input = image_normalized.astype(np.uint8)
    
    # Compute Sobel gradients
    sobelx = cv2.Sobel(image_input, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(image_input, cv2.CV_64F, 0, 1, ksize=3)
    
    # Compute gradient magnitude
    gradient_magnitude = np.sqrt(sobelx ** 2 + sobely ** 2)
    
    # Tenengrad is the sum of squared gradients above a threshold
    threshold = np.mean(gradient_magnitude)
    tenengrad = np.sum(gradient_magnitude[gradient_magnitude > threshold] ** 2)
    
    return float(tenengrad)


def compute_glvn(image: np.ndarray) -> float:
    """
    Compute Gray-Level Variance Normalized (GLVN) focus measure.
    
    Args:
        image: Input 2D image
        
    Returns:
        GLVN value
    """
    mean_val = np.mean(image)
    if mean_val == 0:
        return 0.0
    
    variance = np.var(image)
    glvn = variance / mean_val if mean_val != 0 else 0.0
    
    return float(glvn)


def find_best_focus_slice(z_stack: np.ndarray, method: str = 'laplacian') -> int:
    """
    Find the best-focused slice in a Z-stack.
    
    Args:
        z_stack: 3D array (Z, Y, X)
        method: Focus measure to use ('laplacian', 'fft', 'tenengrad', 'brenner')
        
    Returns:
        Index of best-focused slice
    """
    Z = z_stack.shape[0]
    focus_scores = []
    
    for z in range(Z):
        slice_2d = z_stack[z, :, :]
        
        if method == 'laplacian':
            score = compute_laplacian_variance(slice_2d)
        elif method == 'fft':
            score = compute_fft_high_frequency_energy(slice_2d)
        elif method == 'tenengrad':
            score = compute_tenengrad(slice_2d)
        elif method == 'brenner':
            score = compute_brenner_gradient(slice_2d)
        else:
            score = compute_laplacian_variance(slice_2d)
        
        focus_scores.append(score)
    
    best_focus_idx = int(np.argmax(focus_scores))
    return best_focus_idx


def compute_blur_focus_metrics(image: np.ndarray) -> Dict[str, float]:
    """
    Compute all blur/focus metrics for a 2D image.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary of blur/focus metrics
    """
    metrics = {
        'laplacian_variance': compute_laplacian_variance(image),
        'fft_high_freq_energy': compute_fft_high_frequency_energy(image),
        'normalized_variance': compute_normalized_variance(image),
        'vollath_f4': compute_vollath_f4(image),
        'vollath_f5': compute_vollath_f5(image),
        'brenner_gradient': compute_brenner_gradient(image),
        'tenengrad': compute_tenengrad(image),
        'glvn': compute_glvn(image),
    }
    
    return metrics
