"""
Noise Estimation Metrics
"""

import numpy as np
from typing import Dict, Tuple
from scipy import ndimage
from skimage.restoration import estimate_sigma


def estimate_gaussian_noise(image: np.ndarray, method: str = 'mad') -> float:
    """
    Estimate Gaussian noise level using Median Absolute Deviation.
    
    Args:
        image: Input 2D image
        method: Estimation method ('mad', 'laplacian', 'wavelet')
        
    Returns:
        Estimated noise standard deviation
    """
    if method == 'mad':
        # Use skimage's robust estimator
        try:
            sigma = estimate_sigma(image, channel_axis=None)
            return float(sigma)
        except:
            pass
    
    if method == 'laplacian' or method == 'mad':
        # Estimate from high-frequency components
        # Apply Laplacian to isolate noise
        laplacian = ndimage.laplace(image.astype(float))
        
        # Use MAD (Median Absolute Deviation)
        median = np.median(laplacian)
        mad = np.median(np.abs(laplacian - median))
        sigma = 1.4826 * mad  # Scale factor for normal distribution
        
        return float(sigma)
    
    elif method == 'wavelet':
        # Estimate from wavelet decomposition
        try:
            from skimage.restoration import denoise_wavelet
            sigma = estimate_sigma(image, average_sigmas=True, multichannel=False)
            return float(sigma)
        except:
            # Fallback to MAD method
            return estimate_gaussian_noise(image, method='mad')
    
    return 0.0


def detect_salt_pepper_noise(image: np.ndarray, 
                              sensitivity: float = 3.0) -> Dict[str, float]:
    """
    Detect salt-and-pepper noise (isolated extreme pixels).
    
    Args:
        image: Input 2D image
        sensitivity: Number of standard deviations for outlier detection
        
    Returns:
        Dictionary with salt-and-pepper noise statistics
    """
    # Compute local median
    median_filtered = ndimage.median_filter(image.astype(float), size=3)
    
    # Find pixels that differ significantly from local median
    diff = np.abs(image.astype(float) - median_filtered)
    
    # Threshold based on global statistics
    mean_diff = np.mean(diff)
    std_diff = np.std(diff)
    threshold = mean_diff + sensitivity * std_diff
    
    outliers = diff > threshold
    
    # Classify as salt (bright) or pepper (dark)
    salt_pixels = outliers & (image > median_filtered)
    pepper_pixels = outliers & (image < median_filtered)
    
    total_pixels = image.size
    
    return {
        'salt_pepper_noise_percent': float(100 * np.sum(outliers) / total_pixels),
        'salt_noise_percent': float(100 * np.sum(salt_pixels) / total_pixels),
        'pepper_noise_percent': float(100 * np.sum(pepper_pixels) / total_pixels),
        'outlier_count': int(np.sum(outliers))
    }


def estimate_poisson_noise(image: np.ndarray) -> Dict[str, float]:
    """
    Estimate Poisson noise characteristics.
    For Poisson noise, variance ≈ mean (in photon counts).
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with Poisson noise statistics
    """
    # For Poisson-distributed data, variance should equal mean
    # Calculate local variance and mean
    from scipy.ndimage import uniform_filter
    
    image_float = image.astype(float)
    
    # Compute local mean and variance using sliding window
    kernel_size = 7
    local_mean = uniform_filter(image_float, size=kernel_size)
    local_sq_mean = uniform_filter(image_float ** 2, size=kernel_size)
    local_variance = local_sq_mean - local_mean ** 2
    
    # For Poisson noise, variance/mean should be close to 1
    # Avoid division by zero
    mask = local_mean > 0
    if np.sum(mask) == 0:
        return {
            'poisson_noise_estimate': 0.0,
            'variance_to_mean_ratio': 0.0,
            'poisson_fit_quality': 0.0
        }
    
    variance_to_mean = local_variance[mask] / local_mean[mask]
    median_ratio = np.median(variance_to_mean)
    
    # Quality of Poisson fit (closer to 1 is better)
    poisson_fit = 1.0 - np.abs(median_ratio - 1.0)
    poisson_fit = max(0.0, poisson_fit)
    
    return {
        'poisson_noise_estimate': float(np.sqrt(np.mean(local_variance))),
        'variance_to_mean_ratio': float(median_ratio),
        'poisson_fit_quality': float(poisson_fit)
    }


def analyze_noise_spatial_distribution(image: np.ndarray, 
                                       grid_size: int = 4) -> Dict[str, float]:
    """
    Analyze spatial distribution of noise (uniform vs localized).
    
    Args:
        image: Input 2D image
        grid_size: Number of regions along each dimension
        
    Returns:
        Dictionary with spatial noise distribution metrics
    """
    rows, cols = image.shape
    region_height = rows // grid_size
    region_width = cols // grid_size
    
    region_stds = []
    
    for i in range(grid_size):
        for j in range(grid_size):
            y_start = i * region_height
            y_end = (i + 1) * region_height if i < grid_size - 1 else rows
            x_start = j * region_width
            x_end = (j + 1) * region_width if j < grid_size - 1 else cols
            
            region = image[y_start:y_end, x_start:x_end]
            region_stds.append(np.std(region))
    
    region_stds = np.array(region_stds)
    
    # Coefficient of variation of regional noise levels
    mean_std = np.mean(region_stds)
    if mean_std == 0:
        uniformity = 1.0
    else:
        cv = np.std(region_stds) / mean_std
        uniformity = 1.0 / (1.0 + cv)  # Higher = more uniform
    
    return {
        'noise_spatial_uniformity': float(uniformity),
        'noise_std_variation': float(np.std(region_stds)),
        'max_min_noise_ratio': float(np.max(region_stds) / (np.min(region_stds) + 1e-10))
    }


def compute_noise_metrics(image: np.ndarray) -> Dict[str, float]:
    """
    Compute all noise estimation metrics for a 2D image.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary of noise metrics
    """
    metrics = {}
    
    # Gaussian noise estimation
    metrics['gaussian_noise_sigma'] = estimate_gaussian_noise(image, method='mad')
    
    # Salt-and-pepper noise
    sp_metrics = detect_salt_pepper_noise(image)
    metrics.update(sp_metrics)
    
    # Poisson noise
    poisson_metrics = estimate_poisson_noise(image)
    metrics.update(poisson_metrics)
    
    # Spatial distribution
    spatial_metrics = analyze_noise_spatial_distribution(image)
    metrics.update(spatial_metrics)
    
    return metrics
