"""
Segmentability Assessment Metrics
"""

import numpy as np
from typing import Dict
from skimage.filters import threshold_otsu
from scipy import ndimage


def compute_foreground_separability(image: np.ndarray) -> float:
    """
    Compute how separable foreground is from background (Otsu criterion).
    
    Args:
        image: Input 2D image
        
    Returns:
        Separability score (0-1, higher is better)
    """
    try:
        threshold = threshold_otsu(image)
        
        foreground = image > threshold
        background = image <= threshold
        
        if np.sum(foreground) == 0 or np.sum(background) == 0:
            return 0.0
        
        # Calculate class probabilities
        prob_fg = np.sum(foreground) / image.size
        prob_bg = np.sum(background) / image.size
        
        # Calculate class means
        mean_fg = np.mean(image[foreground])
        mean_bg = np.mean(image[background])
        
        # Inter-class variance (Otsu's criterion)
        var_between = prob_fg * prob_bg * ((mean_fg - mean_bg) ** 2)
        
        # Total variance
        var_total = np.var(image)
        
        # Separability score (0-1, higher is better)
        if var_total > 0:
            separability = var_between / var_total
        else:
            separability = 0.0
        
        return float(separability)
    except:
        return 0.0


def compute_boundary_clarity(image: np.ndarray) -> Dict[str, float]:
    """
    Assess clarity of object boundaries.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with boundary clarity metrics
    """
    # Compute gradients at boundaries
    try:
        threshold = threshold_otsu(image)
        foreground = image > threshold
    except:
        foreground = image > np.mean(image)
    
    # Find boundary pixels (foreground pixels adjacent to background)
    from scipy.ndimage import binary_erosion
    eroded = binary_erosion(foreground)
    boundary = foreground & ~eroded
    
    if np.sum(boundary) == 0:
        return {
            'boundary_clarity_score': 0.0,
            'mean_boundary_gradient': 0.0,
            'boundary_sharpness': 0.0
        }
    
    # Compute gradient magnitude
    gradient_y = np.abs(ndimage.sobel(image.astype(float), axis=0))
    gradient_x = np.abs(ndimage.sobel(image.astype(float), axis=1))
    gradient_magnitude = np.sqrt(gradient_x ** 2 + gradient_y ** 2)
    
    # Boundary gradient statistics
    boundary_gradients = gradient_magnitude[boundary]
    mean_boundary_gradient = np.mean(boundary_gradients)
    
    # Compare to non-boundary gradients
    non_boundary_gradients = gradient_magnitude[~boundary]
    mean_non_boundary = np.mean(non_boundary_gradients)
    
    if mean_non_boundary > 0:
        sharpness = mean_boundary_gradient / mean_non_boundary
    else:
        sharpness = 0.0
    
    # Clarity score (normalized sharpness)
    clarity = min(1.0, sharpness / 5.0)  # Normalize assuming max useful ratio is 5
    
    return {
        'boundary_clarity_score': float(clarity),
        'mean_boundary_gradient': float(mean_boundary_gradient),
        'boundary_sharpness': float(sharpness)
    }


def estimate_touching_objects(image: np.ndarray) -> Dict[str, float]:
    """
    Estimate presence of touching/overlapping objects.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with touching object metrics
    """
    from skimage.measure import label, regionprops
    from skimage.segmentation import watershed
    from scipy.ndimage import distance_transform_edt
    
    try:
        # Threshold image
        threshold = threshold_otsu(image)
        binary = image > threshold
    except:
        binary = image > np.mean(image)
    
    if np.sum(binary) == 0:
        return {
            'touching_objects_estimate': 0.0,
            'object_count_simple': 0,
            'object_count_watershed': 0
        }
    
    # Simple labeling
    labeled_simple = label(binary)
    num_objects_simple = labeled_simple.max()
    
    try:
        # Watershed segmentation to separate touching objects
        distance = distance_transform_edt(binary)
        from skimage.feature import peak_local_max
        from scipy import ndimage as ndi
        
        # Find peaks
        coordinates = peak_local_max(distance, min_distance=5, labels=binary)
        
        if len(coordinates) > 0:
            # Create markers
            mask = np.zeros(distance.shape, dtype=bool)
            mask[tuple(coordinates.T)] = True
            markers, _ = ndi.label(mask)
            
            # Apply watershed
            labels_watershed = watershed(-distance, markers, mask=binary)
            num_objects_watershed = labels_watershed.max()
        else:
            num_objects_watershed = num_objects_simple
    except:
        num_objects_watershed = num_objects_simple
    
    # If watershed finds more objects, they were likely touching
    if num_objects_simple > 0:
        touching_ratio = (num_objects_watershed - num_objects_simple) / num_objects_simple
        touching_ratio = max(0.0, min(1.0, touching_ratio))
    else:
        touching_ratio = 0.0
    
    return {
        'touching_objects_estimate': float(touching_ratio),
        'object_count_simple': int(num_objects_simple),
        'object_count_watershed': int(num_objects_watershed)
    }


def compute_segmentation_feasibility(image: np.ndarray) -> Dict[str, float]:
    """
    Overall segmentation feasibility assessment.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with overall feasibility score
    """
    # Combine multiple factors
    separability = compute_foreground_separability(image)
    boundary_metrics = compute_boundary_clarity(image)
    touching_metrics = estimate_touching_objects(image)
    
    # Overall feasibility (weighted combination)
    feasibility = (
        0.5 * separability +
        0.3 * boundary_metrics['boundary_clarity_score'] +
        0.2 * (1.0 - touching_metrics['touching_objects_estimate'])
    )
    
    return {
        'segmentation_feasibility_score': float(feasibility),
        'is_segmentation_feasible': bool(feasibility > 0.5)
    }


def compute_segmentability_metrics(image: np.ndarray) -> Dict[str, float]:
    """
    Compute all segmentability assessment metrics.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary of segmentability metrics
    """
    metrics = {}
    
    # Foreground separability
    metrics['foreground_separability'] = compute_foreground_separability(image)
    
    # Boundary clarity
    boundary_metrics = compute_boundary_clarity(image)
    metrics.update(boundary_metrics)
    
    # Touching objects
    touching_metrics = estimate_touching_objects(image)
    metrics.update(touching_metrics)
    
    # Overall feasibility
    feasibility_metrics = compute_segmentation_feasibility(image)
    metrics.update(feasibility_metrics)
    
    return metrics
