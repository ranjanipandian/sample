"""
Contrast Metrics
"""

import numpy as np
from typing import Dict
from scipy import ndimage


def compute_rms_contrast(image: np.ndarray) -> float:
    """
    Compute RMS (Root Mean Square) contrast.
    
    Args:
        image: Input 2D image
        
    Returns:
        RMS contrast value
    """
    std = np.std(image)
    mean = np.mean(image)
    
    if mean == 0:
        return 0.0
    
    rms_contrast = std / mean
    return float(rms_contrast)


def compute_michelson_contrast(image: np.ndarray) -> float:
    """
    Compute Michelson contrast: (max - min) / (max + min).
    Suitable for patterns with uniform brightness.
    
    Args:
        image: Input 2D image
        
    Returns:
        Michelson contrast value
    """
    max_val = np.max(image)
    min_val = np.min(image)
    
    if max_val + min_val == 0:
        return 0.0
    
    michelson = (max_val - min_val) / (max_val + min_val)
    return float(michelson)


def compute_weber_contrast(image: np.ndarray) -> float:
    """
    Compute Weber contrast.
    Compares foreground to background.
    
    Args:
        image: Input 2D image
        
    Returns:
        Weber contrast value
    """
    from skimage.filters import threshold_otsu
    
    try:
        threshold = threshold_otsu(image)
        foreground = image > threshold
        background = image <= threshold
        
        if np.sum(foreground) == 0 or np.sum(background) == 0:
            return 0.0
        
        fg_mean = np.mean(image[foreground])
        bg_mean = np.mean(image[background])
        
        if bg_mean == 0:
            return float('inf') if fg_mean > 0 else 0.0
        
        weber = (fg_mean - bg_mean) / bg_mean
        return float(weber)
    except:
        return 0.0


def compute_local_contrast(image: np.ndarray, window_size: int = 7) -> Dict[str, float]:
    """
    Compute local contrast statistics.
    
    Args:
        image: Input 2D image
        window_size: Size of local window
        
    Returns:
        Dictionary with local contrast metrics
    """
    from scipy.ndimage import uniform_filter
    
    # Compute local mean and std
    local_mean = uniform_filter(image.astype(float), size=window_size)
    local_sq_mean = uniform_filter(image.astype(float) ** 2, size=window_size)
    local_std = np.sqrt(np.maximum(local_sq_mean - local_mean ** 2, 0))
    
    # Local contrast = local_std / local_mean
    mask = local_mean > 0
    if np.sum(mask) == 0:
        return {
            'local_contrast_mean': 0.0,
            'local_contrast_std': 0.0,
            'local_contrast_max': 0.0,
            'local_contrast_min': 0.0
        }
    
    local_contrast = np.zeros_like(image, dtype=float)
    local_contrast[mask] = local_std[mask] / local_mean[mask]
    
    return {
        'local_contrast_mean': float(np.mean(local_contrast)),
        'local_contrast_std': float(np.std(local_contrast)),
        'local_contrast_max': float(np.max(local_contrast)),
        'local_contrast_min': float(np.min(local_contrast[mask]))
    }


def compute_edge_contrast(image: np.ndarray) -> Dict[str, float]:
    """
    Compute edge-based contrast metrics.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with edge contrast metrics
    """
    # Compute gradients
    gradient_y = np.abs(ndimage.sobel(image.astype(float), axis=0))
    gradient_x = np.abs(ndimage.sobel(image.astype(float), axis=1))
    gradient_magnitude = np.sqrt(gradient_x ** 2 + gradient_y ** 2)
    
    # Edge strength statistics
    mean_gradient = np.mean(gradient_magnitude)
    max_gradient = np.max(gradient_magnitude)
    
    # Edge density (percentage of pixels with significant gradients)
    threshold = mean_gradient
    edge_pixels = gradient_magnitude > threshold
    edge_density = np.sum(edge_pixels) / image.size
    
    return {
        'edge_contrast_mean': float(mean_gradient),
        'edge_contrast_max': float(max_gradient),
        'edge_density': float(edge_density),
        'edge_strength_std': float(np.std(gradient_magnitude))
    }


def compute_global_contrast_factor(image: np.ndarray) -> float:
    """
    Compute Global Contrast Factor (GCF).
    
    Args:
        image: Input 2D image
        
    Returns:
        GCF value
    """
    # Use percentile-based approach for robustness
    p95 = np.percentile(image, 95)
    p5 = np.percentile(image, 5)
    
    if p95 + p5 == 0:
        return 0.0
    
    gcf = (p95 - p5) / (p95 + p5)
    return float(gcf)


def compute_contrast_metrics(image: np.ndarray) -> Dict[str, float]:
    """
    Compute all contrast metrics.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary of contrast metrics
    """
    metrics = {}
    
    # Global contrast metrics
    metrics['rms_contrast'] = compute_rms_contrast(image)
    metrics['michelson_contrast'] = compute_michelson_contrast(image)
    metrics['weber_contrast'] = compute_weber_contrast(image)
    metrics['global_contrast_factor'] = compute_global_contrast_factor(image)
    
    # Local contrast
    local_metrics = compute_local_contrast(image)
    metrics.update(local_metrics)
    
    # Edge-based contrast
    edge_metrics = compute_edge_contrast(image)
    metrics.update(edge_metrics)
    
    return metrics
