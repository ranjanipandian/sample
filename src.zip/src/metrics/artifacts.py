"""
Artifact Detection Metrics
"""

import numpy as np
from typing import Dict
from scipy import ndimage, signal


def detect_dead_pixels(image: np.ndarray, threshold: int = 0) -> Dict[str, float]:
    """
    Detect dead (zero-valued or stuck-at-value) pixels.
    
    Args:
        image: Input 2D image
        threshold: Value threshold for dead pixels
        
    Returns:
        Dictionary with dead pixel statistics
    """
    dead_pixels = image <= threshold
    dead_count = np.sum(dead_pixels)
    dead_percent = 100 * dead_count / image.size
    
    return {
        'dead_pixel_count': int(dead_count),
        'dead_pixel_percent': float(dead_percent)
    }


def detect_hot_pixels(image: np.ndarray, percentile: float = 99.9) -> Dict[str, float]:
    """
    Detect hot (abnormally bright) pixels.
    
    Args:
        image: Input 2D image
        percentile: Percentile threshold for hot pixels
        
    Returns:
        Dictionary with hot pixel statistics
    """
    threshold = np.percentile(image, percentile)
    hot_pixels = image >= threshold
    
    # Further refine: hot pixels should be isolated
    # Check if they're surrounded by much dimmer pixels
    from scipy.ndimage import median_filter
    median_filtered = median_filter(image.astype(float), size=3)
    
    # Hot pixels have large difference from local median
    diff = image.astype(float) - median_filtered
    median_diff = np.median(diff)
    std_diff = np.std(diff)
    
    hot_threshold = median_diff + 5 * std_diff
    isolated_hot = (diff > hot_threshold) & hot_pixels
    
    hot_count = np.sum(isolated_hot)
    hot_percent = 100 * hot_count / image.size
    
    return {
        'hot_pixel_count': int(hot_count),
        'hot_pixel_percent': float(hot_percent)
    }


def detect_line_noise(image: np.ndarray) -> Dict[str, float]:
    """
    Detect horizontal/vertical line noise patterns.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with line noise metrics
    """
    # Compute row and column profiles
    row_profile = np.mean(image, axis=1)
    col_profile = np.mean(image, axis=0)
    
    # Compute variance of profiles (high variance indicates line patterns)
    row_variance = np.var(row_profile)
    col_variance = np.var(col_profile)
    
    # Normalize by image variance
    image_variance = np.var(image)
    
    if image_variance > 0:
        row_noise_score = row_variance / image_variance
        col_noise_score = col_variance / image_variance
    else:
        row_noise_score = 0.0
        col_noise_score = 0.0
    
    # Overall line noise score
    line_noise_score = max(row_noise_score, col_noise_score)
    
    return {
        'line_noise_score': float(line_noise_score),
        'horizontal_line_noise': float(row_noise_score),
        'vertical_line_noise': float(col_noise_score)
    }


def detect_stripe_banding(image: np.ndarray) -> Dict[str, float]:
    """
    Detect stripe or banding artifacts using FFT analysis.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with stripe detection metrics
    """
    from scipy.fft import fft2, fftshift
    
    # Compute FFT
    f_transform = fft2(image.astype(float))
    f_shift = fftshift(f_transform)
    magnitude_spectrum = np.abs(f_shift)
    
    rows, cols = magnitude_spectrum.shape
    center_y, center_x = rows // 2, cols // 2
    
    # Check for peaks along horizontal and vertical axes in FFT
    # Horizontal stripes show up as vertical peaks in FFT
    vertical_strip = magnitude_spectrum[:, center_x-5:center_x+5]
    vertical_peak = np.max(vertical_strip)
    
    # Vertical stripes show up as horizontal peaks in FFT
    horizontal_strip = magnitude_spectrum[center_y-5:center_y+5, :]
    horizontal_peak = np.max(horizontal_strip)
    
    # Normalize by average spectrum magnitude
    avg_magnitude = np.mean(magnitude_spectrum)
    
    if avg_magnitude > 0:
        vertical_stripe_score = vertical_peak / avg_magnitude
        horizontal_stripe_score = horizontal_peak / avg_magnitude
    else:
        vertical_stripe_score = 0.0
        horizontal_stripe_score = 0.0
    
    # Overall banding score
    banding_score = max(vertical_stripe_score, horizontal_stripe_score) / 100  # Normalize
    
    return {
        'stripe_banding_score': float(min(banding_score, 1.0)),
        'vertical_stripe_score': float(min(vertical_stripe_score / 100, 1.0)),
        'horizontal_stripe_score': float(min(horizontal_stripe_score / 100, 1.0))
    }


def detect_ring_artifacts(image: np.ndarray) -> float:
    """
    Detect ring artifacts (common in some microscopy techniques).
    
    Args:
        image: Input 2D image
        
    Returns:
        Ring artifact score
    """
    from scipy.fft import fft2, fftshift
    
    # Ring artifacts appear as circular patterns in FFT
    f_transform = fft2(image.astype(float))
    f_shift = fftshift(f_transform)
    magnitude_spectrum = np.abs(f_shift)
    
    rows, cols = magnitude_spectrum.shape
    center_y, center_x = rows // 2, cols // 2
    
    # Create radial distance array
    y, x = np.ogrid[:rows, :cols]
    r = np.sqrt((y - center_y) ** 2 + (x - center_x) ** 2)
    
    # Compute radial profile
    max_radius = int(np.min([rows, cols]) / 2)
    radial_profile = []
    
    for radius in range(1, max_radius):
        mask = (r >= radius - 0.5) & (r < radius + 0.5)
        if np.sum(mask) > 0:
            radial_profile.append(np.mean(magnitude_spectrum[mask]))
    
    radial_profile = np.array(radial_profile)
    
    # Look for periodic peaks in radial profile
    if len(radial_profile) > 10:
        # Smooth profile
        from scipy.ndimage import gaussian_filter1d
        smoothed = gaussian_filter1d(radial_profile, sigma=2)
        
        # Compute variation from smoothed profile
        variation = np.std(radial_profile - smoothed)
        mean_val = np.mean(radial_profile)
        
        if mean_val > 0:
            ring_score = variation / mean_val
        else:
            ring_score = 0.0
    else:
        ring_score = 0.0
    
    return float(min(ring_score, 1.0))


def detect_dust_debris(image: np.ndarray) -> Dict[str, float]:
    """
    Detect dust or debris artifacts (small dark spots).
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with dust detection metrics
    """
    from skimage.morphology import opening, disk
    from skimage.measure import label, regionprops
    
    # Use morphological operations to detect small dark spots
    # Invert image to detect dark spots as bright regions
    inverted = np.max(image) - image
    
    # Threshold to find potential dust
    from skimage.filters import threshold_otsu
    try:
        threshold = threshold_otsu(inverted)
        binary = inverted > threshold
    except:
        binary = inverted > np.mean(inverted)
    
    # Remove large regions (likely not dust)
    # Clean up with opening
    cleaned = opening(binary, disk(1))
    
    # Label connected components
    labeled = label(cleaned)
    regions = regionprops(labeled)
    
    # Count small regions (likely dust)
    dust_count = 0
    max_dust_area = 100  # pixels
    
    for region in regions:
        if region.area < max_dust_area:
            dust_count += 1
    
    dust_percent = 100 * dust_count / (image.size / max_dust_area)  # Normalize
    
    return {
        'dust_debris_count': int(dust_count),
        'dust_debris_score': float(min(dust_percent, 100.0))
    }


def compute_motion_blur_score(image: np.ndarray) -> float:
    """
    Estimate motion blur score (for time-lapse data).
    
    Args:
        image: Input 2D image
        
    Returns:
        Motion blur score
    """
    # Motion blur causes directional smearing
    # Detect by analyzing gradient orientations
    
    # Compute gradients
    gradient_y = ndimage.sobel(image.astype(float), axis=0)
    gradient_x = ndimage.sobel(image.astype(float), axis=1)
    
    # Compute gradient magnitude and orientation
    magnitude = np.sqrt(gradient_x ** 2 + gradient_y ** 2)
    
    # Strong edges with consistent orientation suggest motion blur
    strong_edges = magnitude > np.percentile(magnitude, 75)
    
    if np.sum(strong_edges) > 0:
        angles = np.arctan2(gradient_y[strong_edges], gradient_x[strong_edges])
        
        # Compute orientation distribution
        # High concentration in one direction suggests motion blur
        hist, _ = np.histogram(angles, bins=36)  # 10-degree bins
        hist = hist.astype(float) / (np.sum(hist) + 1e-10)
        
        # Entropy of orientation distribution
        hist_nonzero = hist[hist > 0]
        orientation_entropy = -np.sum(hist_nonzero * np.log2(hist_nonzero))
        
        # Low entropy (high concentration) suggests motion blur
        max_entropy = np.log2(36)
        motion_blur_score = 1.0 - (orientation_entropy / max_entropy)
    else:
        motion_blur_score = 0.0
    
    return float(motion_blur_score)


def compute_artifact_metrics(image: np.ndarray) -> Dict[str, float]:
    """
    Compute all artifact detection metrics.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary of artifact metrics
    """
    metrics = {}
    
    # Dead pixels
    dead_metrics = detect_dead_pixels(image)
    metrics.update(dead_metrics)
    
    # Hot pixels
    hot_metrics = detect_hot_pixels(image)
    metrics.update(hot_metrics)
    
    # Line noise
    line_metrics = detect_line_noise(image)
    metrics.update(line_metrics)
    
    # Stripe/banding
    stripe_metrics = detect_stripe_banding(image)
    metrics.update(stripe_metrics)
    
    # Ring artifacts
    metrics['ring_artifact_score'] = detect_ring_artifacts(image)
    
    # Dust/debris
    dust_metrics = detect_dust_debris(image)
    metrics.update(dust_metrics)
    
    # Motion blur
    metrics['motion_blur_score'] = compute_motion_blur_score(image)
    
    return metrics
