"""
Signal Quality Metrics (SNR, PSNR, CNR, Background)
"""

import numpy as np
from typing import Dict, Tuple
from skimage.filters import threshold_otsu
from .validation import is_valid_for_stats, safe_divide, safe_mean, safe_std, is_valid_mask


def compute_snr(image: np.ndarray, mask: Optional[np.ndarray] = None) -> float:
    """
    Compute Signal-to-Noise Ratio.
    
    Args:
        image: Input 2D image
        mask: Optional foreground mask. If None, uses Otsu thresholding.
        
    Returns:
        SNR value
    """
    if mask is None:
        try:
            threshold = threshold_otsu(image)
            mask = image > threshold
        except:
            # If Otsu fails, use mean-based threshold
            mask = image > np.mean(image)
    
    if np.sum(mask) == 0 or np.sum(~mask) == 0:
        return 0.0
    
    signal = np.mean(image[mask])
    background_std = np.std(image[~mask])
    
    if background_std == 0:
        return float('inf') if signal > 0 else 0.0
    
    snr = signal / background_std
    return float(snr)


def compute_psnr(image: np.ndarray, reference: Optional[np.ndarray] = None) -> float:
    """
    Compute Peak Signal-to-Noise Ratio.
    
    Args:
        image: Input image
        reference: Reference image (if None, uses ideal reconstruction)
        
    Returns:
        PSNR value in dB
    """
    # Get max possible value based on dtype
    if image.dtype == np.uint8:
        max_val = 255.0
    elif image.dtype == np.uint16:
        max_val = 65535.0
    else:
        max_val = float(np.max(image))
    
    if reference is None:
        # Estimate noise from high-frequency components
        from scipy.ndimage import laplace
        noise_estimate = np.std(laplace(image.astype(float)))
        if noise_estimate == 0:
            return float('inf')
        mse = noise_estimate ** 2
    else:
        mse = np.mean((image.astype(float) - reference.astype(float)) ** 2)
    
    if mse == 0:
        return float('inf')
    
    psnr = 20 * np.log10(max_val / np.sqrt(mse))
    return float(psnr)


def compute_cnr(image: np.ndarray, mask: Optional[np.ndarray] = None) -> float:
    """
    Compute Contrast-to-Noise Ratio.
    
    Args:
        image: Input 2D image
        mask: Optional foreground mask
        
    Returns:
        CNR value
    """
    if mask is None:
        try:
            threshold = threshold_otsu(image)
            mask = image > threshold
        except:
            mask = image > np.mean(image)
    
    if np.sum(mask) == 0 or np.sum(~mask) == 0:
        return 0.0
    
    foreground_mean = np.mean(image[mask])
    background_mean = np.mean(image[~mask])
    background_std = np.std(image[~mask])
    
    if background_std == 0:
        return float('inf') if foreground_mean != background_mean else 0.0
    
    cnr = abs(foreground_mean - background_mean) / background_std
    return float(cnr)


def compute_background_stats(image: np.ndarray, 
                             method: str = 'otsu') -> Dict[str, float]:
    """
    Compute background statistics.
    
    Args:
        image: Input 2D image
        method: Background estimation method ('otsu', 'triangle', 'percentile')
        
    Returns:
        Dictionary with background statistics
    """
    from skimage.filters import threshold_triangle
    
    # Estimate background region
    if method == 'otsu':
        try:
            threshold = threshold_otsu(image)
        except:
            threshold = np.percentile(image, 50)
    elif method == 'triangle':
        try:
            threshold = threshold_triangle(image)
        except:
            threshold = np.percentile(image, 50)
    elif method == 'percentile':
        threshold = np.percentile(image, 25)
    else:
        threshold = np.mean(image)
    
    background_mask = image <= threshold
    
    if np.sum(background_mask) == 0:
        return {
            'background_mean': 0.0,
            'background_std': 0.0,
            'background_variance': 0.0,
            'background_median': 0.0,
            'background_percentage': 0.0
        }
    
    background_pixels = image[background_mask]
    
    return {
        'background_mean': float(np.mean(background_pixels)),
        'background_std': float(np.std(background_pixels)),
        'background_variance': float(np.var(background_pixels)),
        'background_median': float(np.median(background_pixels)),
        'background_percentage': float(100 * np.sum(background_mask) / image.size)
    }


def compute_signal_quality_metrics(image: np.ndarray, 
                                   background_method: str = 'otsu') -> Dict[str, float]:
    """
    Compute all signal quality metrics for a 2D image.
    
    Args:
        image: Input 2D image
        background_method: Method for background estimation
        
    Returns:
        Dictionary of signal quality metrics
    """
    # Get background mask
    try:
        if background_method == 'otsu':
            threshold = threshold_otsu(image)
        else:
            threshold = np.percentile(image, 25)
        mask = image > threshold
    except:
        mask = image > np.mean(image)
    
    metrics = {}
    
    # Core signal metrics
    metrics['snr'] = compute_snr(image, mask)
    metrics['psnr'] = compute_psnr(image)
    metrics['cnr'] = compute_cnr(image, mask)
    
    # Background statistics
    bg_stats = compute_background_stats(image, background_method)
    metrics.update(bg_stats)
    
    return metrics
