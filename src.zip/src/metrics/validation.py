"""
Validation helpers for safe metric computation.
Prevents NumPy warnings from invalid operations.
"""

import numpy as np


def is_valid_array(array, min_size=2):
    """
    Check if array is valid for operations.
    
    Args:
        array: Input array
        min_size: Minimum required size
        
    Returns:
        True if valid, False otherwise
    """
    if array is None:
        return False
    if not isinstance(array, np.ndarray):
        return False
    if array.size < min_size:
        return False
    if np.all(np.isnan(array)):
        return False
    if np.all(np.isinf(array)):
        return False
    return True


def is_valid_for_stats(array, min_size=2, check_variance=True):
    """
    Check if array is valid for statistical operations.
    
    Args:
        array: Input array
        min_size: Minimum required size
        check_variance: If True, reject uniform arrays
        
    Returns:
        True if valid for stats, False otherwise
    """
    if not is_valid_array(array, min_size):
        return False
    
    if check_variance:
        try:
            if np.std(array) < 1e-10:  # Uniform data
                return False
        except:
            return False
    
    return True


def safe_divide(numerator, denominator, default=np.nan):
    """
    Safe division with default for invalid results.
    
    Args:
        numerator: Numerator value
        denominator: Denominator value
        default: Default value if division invalid
        
    Returns:
        Result of division or default
    """
    if denominator == 0 or np.isnan(denominator) or np.isinf(denominator):
        return default
    
    result = numerator / denominator
    
    if np.isnan(result) or np.isinf(result):
        return default
    
    return float(result)


def safe_mean(array, default=np.nan):
    """Compute mean with validation."""
    if not is_valid_array(array, min_size=1):
        return default
    try:
        return float(np.mean(array))
    except:
        return default


def safe_std(array, default=np.nan):
    """Compute std with validation."""
    if not is_valid_array(array, min_size=2):
        return default
    try:
        return float(np.std(array))
    except:
        return default


def safe_var(array, default=np.nan):
    """Compute variance with validation."""
    if not is_valid_array(array, min_size=2):
        return default
    try:
        return float(np.var(array))
    except:
        return default


def safe_median(array, default=np.nan):
    """Compute median with validation."""
    if not is_valid_array(array, min_size=1):
        return default
    try:
        return float(np.median(array))
    except:
        return default


def safe_percentile(array, percentile, default=np.nan):
    """Compute percentile with validation."""
    if not is_valid_array(array, min_size=1):
        return default
    try:
        return float(np.percentile(array, percentile))
    except:
        return default


def is_valid_mask(mask, min_true=1):
    """
    Check if boolean mask is valid.
    
    Args:
        mask: Boolean array
        min_true: Minimum number of True values required
        
    Returns:
        True if valid mask
    """
    if not is_valid_array(mask, min_size=1):
        return False
    
    if not np.issubdtype(mask.dtype, np.bool_):
        return False
    
    if np.sum(mask) < min_true:
        return False
    
    return True


def is_valid_image_slice(image, min_pixels=100):
    """
    Check if image slice is valid for QC.
    
    Args:
        image: 2D image array
        min_pixels: Minimum number of pixels
        
    Returns:
        True if slice is processable
    """
    if not is_valid_array(image, min_size=min_pixels):
        return False
    
    # Check if uniform (all same value)
    if np.std(image) < 1e-10:
        return False
    
    # Check if all zeros
    if np.max(np.abs(image)) < 1e-10:
        return False
    
    return True
