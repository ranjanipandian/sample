"""
Dimensional Consistency Metrics (3D/4D)
"""

import numpy as np
from typing import Dict


def compute_defocused_slices_percentage(z_stack: np.ndarray, 
                                        focus_method: str = 'laplacian') -> Dict[str, float]:
    """
    Compute percentage of defocused slices in Z-stack.
    
    Args:
        z_stack: 3D array (Z, Y, X)
        focus_method: Focus measure to use
        
    Returns:
        Dictionary with defocus metrics
    """
    from ..metrics.blur_focus import compute_laplacian_variance, compute_tenengrad
    
    Z = z_stack.shape[0]
    focus_scores = []
    
    for z in range(Z):
        slice_2d = z_stack[z, :, :]
        
        if focus_method == 'laplacian':
            score = compute_laplacian_variance(slice_2d)
        elif focus_method == 'tenengrad':
            score = compute_tenengrad(slice_2d)
        else:
            score = compute_laplacian_variance(slice_2d)
        
        focus_scores.append(score)
    
    focus_scores = np.array(focus_scores)
    
    # Define defocused as below 50% of max focus
    max_focus = np.max(focus_scores)
    threshold = 0.5 * max_focus
    
    defocused = focus_scores < threshold
    defocused_percent = 100 * np.sum(defocused) / Z
    
    return {
        'defocused_slices_percent': float(defocused_percent),
        'defocused_slice_count': int(np.sum(defocused)),
        'total_slices': int(Z)
    }


def compute_z_consistency_score(z_stack: np.ndarray) -> float:
    """
    Compute Z-consistency score based on slice-to-slice similarity.
    
    Args:
        z_stack: 3D array (Z, Y, X)
        
    Returns:
        Z-consistency score (0-1, higher is better)
    """
    Z = z_stack.shape[0]
    
    if Z < 2:
        return 1.0
    
    # Compute correlation between adjacent slices
    correlations = []
    
    for z in range(Z - 1):
        slice1 = z_stack[z, :, :].flatten().astype(float)
        slice2 = z_stack[z + 1, :, :].flatten().astype(float)
        
        # Pearson correlation
        corr = np.corrcoef(slice1, slice2)[0, 1]
        if not np.isnan(corr):
            correlations.append(corr)
    
    if len(correlations) == 0:
        return 0.0
    
    # Consistency is mean correlation
    consistency = np.mean(correlations)
    consistency = max(0.0, min(1.0, consistency))  # Clip to [0, 1]
    
    return float(consistency)


def compute_frame_to_frame_snr_stability(timeseries: np.ndarray) -> Dict[str, float]:
    """
    Compute SNR stability across time frames.
    
    Args:
        timeseries: 4D array (T, Z, Y, X) or 3D array (T, Y, X)
        
    Returns:
        Dictionary with temporal SNR stability metrics
    """
    from ..metrics.signal_quality import compute_snr
    
    T = timeseries.shape[0]
    
    snr_values = []
    
    for t in range(T):
        if timeseries.ndim == 4:
            # Take middle Z-slice
            z_mid = timeseries.shape[1] // 2
            frame = timeseries[t, z_mid, :, :]
        else:
            frame = timeseries[t, :, :]
        
        snr = compute_snr(frame)
        snr_values.append(snr)
    
    snr_values = np.array(snr_values)
    
    # Stability metrics
    mean_snr = np.mean(snr_values)
    if mean_snr > 0:
        cv = np.std(snr_values) / mean_snr
        stability = 1.0 / (1.0 + cv)
    else:
        stability = 0.0
    
    return {
        'frame_snr_stability': float(stability),
        'frame_snr_mean': float(mean_snr),
        'frame_snr_std': float(np.std(snr_values)),
        'frame_snr_cv': float(cv) if mean_snr > 0 else 0.0
    }


def compute_temporal_blur_drift(timeseries: np.ndarray) -> Dict[str, float]:
    """
    Compute temporal drift in focus/blur.
    
    Args:
        timeseries: 4D array (T, Z, Y, X) or 3D array (T, Y, X)
        
    Returns:
        Dictionary with temporal blur drift metrics
    """
    from ..metrics.blur_focus import compute_laplacian_variance
    
    T = timeseries.shape[0]
    
    focus_values = []
    
    for t in range(T):
        if timeseries.ndim == 4:
            # Take middle Z-slice
            z_mid = timeseries.shape[1] // 2
            frame = timeseries[t, z_mid, :, :]
        else:
            frame = timeseries[t, :, :]
        
        focus = compute_laplacian_variance(frame)
        focus_values.append(focus)
    
    focus_values = np.array(focus_values)
    
    # Detect trend
    t_indices = np.arange(T)
    try:
        slope, intercept = np.polyfit(t_indices, focus_values, 1)
        mean_focus = np.mean(focus_values)
        normalized_slope = slope / (mean_focus + 1e-10)
    except:
        normalized_slope = 0.0
    
    return {
        'temporal_blur_drift': float(normalized_slope),
        'focus_trend_slope': float(slope) if 'slope' in locals() else 0.0
    }


def estimate_photobleaching_rate(timeseries: np.ndarray) -> Dict[str, float]:
    """
    Estimate photobleaching rate (intensity decay over time).
    
    Args:
        timeseries: 4D array (T, Z, Y, X) or 3D array (T, Y, X)
        
    Returns:
        Dictionary with photobleaching metrics
    """
    T = timeseries.shape[0]
    
    # Compute mean intensity for each timepoint
    intensity_values = []
    
    for t in range(T):
        if timeseries.ndim == 4:
            mean_intensity = np.mean(timeseries[t, :, :, :])
        else:
            mean_intensity = np.mean(timeseries[t, :, :])
        
        intensity_values.append(mean_intensity)
    
    intensity_values = np.array(intensity_values)
    
    # Fit exponential decay
    t_indices = np.arange(T)
    
    try:
        # Linear fit on log scale
        log_intensity = np.log(intensity_values + 1e-10)
        slope, intercept = np.polyfit(t_indices, log_intensity, 1)
        
        # Decay rate (negative slope indicates photobleaching)
        decay_rate = -slope
        
        # Half-life (frames until 50% intensity)
        if slope < 0:
            half_life = np.log(0.5) / slope
        else:
            half_life = float('inf')
        
        # R-squared for fit quality
        fitted = slope * t_indices + intercept
        ss_res = np.sum((log_intensity - fitted) ** 2)
        ss_tot = np.sum((log_intensity - np.mean(log_intensity)) ** 2)
        r_squared = 1 - (ss_res / (ss_tot + 1e-10))
    except:
        decay_rate = 0.0
        half_life = float('inf')
        r_squared = 0.0
    
    return {
        'photobleaching_rate': float(decay_rate),
        'photobleaching_half_life_frames': float(half_life) if half_life != float('inf') else -1.0,
        'photobleaching_fit_quality': float(r_squared)
    }


def detect_z_drift(timeseries_4d: np.ndarray) -> Dict[str, float]:
    """
    Detect Z-drift in 4D time-lapse data.
    
    Args:
        timeseries_4d: 4D array (T, Z, Y, X)
        
    Returns:
        Dictionary with Z-drift metrics
    """
    from ..metrics.blur_focus import find_best_focus_slice
    
    T, Z = timeseries_4d.shape[0], timeseries_4d.shape[1]
    
    if Z < 2:
        return {
            'z_drift_detected': False,
            'z_drift_range': 0.0,
            'z_drift_rate': 0.0
        }
    
    # Find best focus slice for each timepoint
    best_focus_indices = []
    
    for t in range(T):
        z_stack = timeseries_4d[t, :, :, :]
        best_z = find_best_focus_slice(z_stack)
        best_focus_indices.append(best_z)
    
    best_focus_indices = np.array(best_focus_indices)
    
    # Compute drift metrics
    drift_range = np.max(best_focus_indices) - np.min(best_focus_indices)
    drift_std = np.std(best_focus_indices)
    
    # Linear drift rate
    t_indices = np.arange(T)
    try:
        slope, _ = np.polyfit(t_indices, best_focus_indices, 1)
        drift_rate = slope
    except:
        drift_rate = 0.0
    
    # Drift detected if range > 2 slices or significant trend
    drift_detected = (drift_range > 2) or (abs(drift_rate) > 0.1)
    
    return {
        'z_drift_detected': bool(drift_detected),
        'z_drift_range': float(drift_range),
        'z_drift_rate': float(drift_rate),
        'z_drift_std': float(drift_std)
    }


def compute_channel_registration_score(multichannel_image: np.ndarray) -> float:
    """
    Compute channel registration/alignment score for multi-channel images.
    
    Args:
        multichannel_image: 3D array (C, Y, X) where C is channels
        
    Returns:
        Registration score (0-1, higher = better aligned)
    """
    C = multichannel_image.shape[0]
    
    if C < 2:
        return 1.0
    
    # Compute cross-correlation between channel pairs
    correlations = []
    
    for c1 in range(C - 1):
        for c2 in range(c1 + 1, C):
            ch1 = multichannel_image[c1, :, :].flatten().astype(float)
            ch2 = multichannel_image[c2, :, :].flatten().astype(float)
            
            # Normalize
            ch1 = (ch1 - np.mean(ch1)) / (np.std(ch1) + 1e-10)
            ch2 = (ch2 - np.mean(ch2)) / (np.std(ch2) + 1e-10)
            
            # Correlation
            corr = np.mean(ch1 * ch2)
            correlations.append(abs(corr))
    
    if len(correlations) == 0:
        return 1.0
    
    # Registration score is mean absolute correlation
    registration_score = np.mean(correlations)
    registration_score = max(0.0, min(1.0, registration_score))
    
    return float(registration_score)
