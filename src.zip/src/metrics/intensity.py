"""
Intensity Statistics Metrics
"""

import numpy as np
from typing import Dict, List
from scipy import stats


def compute_intensity_statistics(image: np.ndarray, 
                                 percentiles: List[float] = [1, 5, 25, 50, 75, 95, 99]) -> Dict[str, float]:
    """
    Compute comprehensive intensity statistics.
    
    Args:
        image: Input 2D image
        percentiles: List of percentiles to compute
        
    Returns:
        Dictionary of intensity statistics
    """
    metrics = {}
    
    # Basic statistics
    metrics['mean_intensity'] = float(np.mean(image))
    metrics['median_intensity'] = float(np.median(image))
    metrics['std_intensity'] = float(np.std(image))
    metrics['var_intensity'] = float(np.var(image))
    metrics['min_intensity'] = float(np.min(image))
    metrics['max_intensity'] = float(np.max(image))
    metrics['range_intensity'] = float(np.max(image) - np.min(image))
    
    # Percentiles
    for p in percentiles:
        metrics[f'percentile_{int(p)}'] = float(np.percentile(image, p))
    
    # Higher-order statistics
    try:
        metrics['skewness'] = float(stats.skew(image.flatten()))
        metrics['kurtosis'] = float(stats.kurtosis(image.flatten()))
    except:
        metrics['skewness'] = 0.0
        metrics['kurtosis'] = 0.0
    
    return metrics


def compute_bit_depth_utilization(image: np.ndarray) -> Dict[str, float]:
    """
    Compute bit-depth utilization statistics.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with bit-depth utilization metrics
    """
    # Determine theoretical max value based on dtype
    if image.dtype == np.uint8:
        max_possible = 255
        bit_depth = 8
    elif image.dtype == np.uint16:
        max_possible = 65535
        bit_depth = 16
    elif image.dtype == np.uint32:
        max_possible = 4294967295
        bit_depth = 32
    else:
        # For float types, use actual max
        max_possible = np.max(image)
        bit_depth = 32
    
    actual_max = np.max(image)
    actual_min = np.min(image)
    actual_range = actual_max - actual_min
    
    # Utilization percentage
    if max_possible > 0:
        utilization = 100 * actual_range / max_possible
    else:
        utilization = 0.0
    
    # Effective bit depth (how many bits are actually used)
    if actual_range > 0:
        effective_bits = np.log2(actual_range + 1)
    else:
        effective_bits = 0
    
    return {
        'bit_depth': bit_depth,
        'bit_depth_utilization_percent': float(utilization),
        'effective_bit_depth': float(effective_bits),
        'dynamic_range': float(actual_range),
        'max_possible_value': float(max_possible)
    }


def compute_histogram_distribution(image: np.ndarray, bins: int = 256) -> Dict[str, float]:
    """
    Analyze histogram distribution characteristics.
    
    Args:
        image: Input 2D image
        bins: Number of histogram bins
        
    Returns:
        Dictionary with histogram metrics
    """
    # Compute histogram
    hist, bin_edges = np.histogram(image.flatten(), bins=bins)
    hist = hist.astype(float)
    
    # Normalize histogram
    if np.sum(hist) > 0:
        hist_norm = hist / np.sum(hist)
    else:
        hist_norm = hist
    
    # Entropy
    hist_nonzero = hist_norm[hist_norm > 0]
    entropy = -np.sum(hist_nonzero * np.log2(hist_nonzero))
    
    # Peak analysis
    peak_idx = np.argmax(hist)
    peak_value = bin_edges[peak_idx]
    
    # Distribution spread
    # Find bins with significant content (>1% of max)
    significant_bins = hist > (0.01 * np.max(hist))
    spread = np.sum(significant_bins) / bins
    
    # Bimodality check (simplified)
    from scipy.signal import find_peaks
    peaks, _ = find_peaks(hist, height=0.01*np.max(hist))
    num_peaks = len(peaks)
    
    return {
        'histogram_entropy': float(entropy),
        'histogram_peak_value': float(peak_value),
        'histogram_spread': float(spread),
        'histogram_num_peaks': int(num_peaks),
        'histogram_bimodal': bool(num_peaks >= 2)
    }


def compute_intensity_uniformity(image: np.ndarray, grid_size: int = 4) -> Dict[str, float]:
    """
    Compute spatial uniformity of intensity.
    
    Args:
        image: Input 2D image
        grid_size: Number of regions along each dimension
        
    Returns:
        Dictionary with uniformity metrics
    """
    rows, cols = image.shape
    region_height = rows // grid_size
    region_width = cols // grid_size
    
    region_means = []
    region_stds = []
    
    for i in range(grid_size):
        for j in range(grid_size):
            y_start = i * region_height
            y_end = (i + 1) * region_height if i < grid_size - 1 else rows
            x_start = j * region_width
            x_end = (j + 1) * region_width if j < grid_size - 1 else cols
            
            region = image[y_start:y_end, x_start:x_end]
            region_means.append(np.mean(region))
            region_stds.append(np.std(region))
    
    region_means = np.array(region_means)
    region_stds = np.array(region_stds)
    
    # Coefficient of variation of regional means
    mean_of_means = np.mean(region_means)
    if mean_of_means > 0:
        cv_means = np.std(region_means) / mean_of_means
        uniformity = 1.0 / (1.0 + cv_means)
    else:
        uniformity = 0.0
    
    return {
        'intensity_uniformity': float(uniformity),
        'regional_mean_cv': float(cv_means) if mean_of_means > 0 else 0.0,
        'max_min_regional_ratio': float(np.max(region_means) / (np.min(region_means) + 1e-10))
    }


def compute_intensity_metrics(image: np.ndarray) -> Dict[str, float]:
    """
    Compute all intensity-related metrics.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary of intensity metrics
    """
    metrics = {}
    
    # Basic statistics
    stats_metrics = compute_intensity_statistics(image)
    metrics.update(stats_metrics)
    
    # Bit-depth utilization
    bitdepth_metrics = compute_bit_depth_utilization(image)
    metrics.update(bitdepth_metrics)
    
    # Histogram distribution
    histogram_metrics = compute_histogram_distribution(image)
    metrics.update(histogram_metrics)
    
    # Spatial uniformity
    uniformity_metrics = compute_intensity_uniformity(image)
    metrics.update(uniformity_metrics)
    
    return metrics
