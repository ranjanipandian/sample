"""
Structural Resolvability Metrics
"""

import numpy as np
from typing import Dict
from scipy import ndimage
from skimage.feature import graycomatrix, graycoprops
from scipy.stats import entropy as scipy_entropy


def compute_edge_density(image: np.ndarray) -> float:
    """
    Compute edge density (proportion of edge pixels).
    
    Args:
        image: Input 2D image
        
    Returns:
        Edge density (0-1)
    """
    # Compute gradients
    gradient_y = np.abs(ndimage.sobel(image.astype(float), axis=0))
    gradient_x = np.abs(ndimage.sobel(image.astype(float), axis=1))
    gradient_magnitude = np.sqrt(gradient_x ** 2 + gradient_y ** 2)
    
    # Threshold at mean gradient
    threshold = np.mean(gradient_magnitude)
    edge_pixels = gradient_magnitude > threshold
    
    edge_density = np.sum(edge_pixels) / image.size
    return float(edge_density)


def compute_frequency_rolloff(image: np.ndarray) -> Dict[str, float]:
    """
    Compute frequency roll-off characteristics.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with frequency metrics
    """
    from scipy.fft import fft2, fftshift
    
    # Compute FFT
    f_transform = fft2(image.astype(float))
    f_shift = fftshift(f_transform)
    magnitude_spectrum = np.abs(f_shift)
    
    # Compute radial frequency profile
    rows, cols = image.shape
    center_y, center_x = rows // 2, cols // 2
    
    # Create radial distance array
    y, x = np.ogrid[:rows, :cols]
    r = np.sqrt((y - center_y) ** 2 + (x - center_x) ** 2)
    
    # Bin by radius
    max_radius = int(np.min([rows, cols]) / 2)
    radial_profile = []
    
    for radius in range(1, max_radius):
        mask = (r >= radius - 0.5) & (r < radius + 0.5)
        if np.sum(mask) > 0:
            radial_profile.append(np.mean(magnitude_spectrum[mask]))
        else:
            radial_profile.append(0)
    
    radial_profile = np.array(radial_profile)
    
    # Compute roll-off rate (how fast high frequencies decay)
    if len(radial_profile) > 1:
        # Fit exponential decay
        frequencies = np.arange(len(radial_profile))
        log_profile = np.log(radial_profile + 1e-10)
        
        try:
            slope, _ = np.polyfit(frequencies, log_profile, 1)
            rolloff_rate = -slope  # Negative slope indicates decay
        except:
            rolloff_rate = 0.0
        
        # High-frequency content (last 25% of spectrum)
        cutoff = int(len(radial_profile) * 0.75)
        high_freq_energy = np.mean(radial_profile[cutoff:])
        total_energy = np.mean(radial_profile)
        
        if total_energy > 0:
            high_freq_ratio = high_freq_energy / total_energy
        else:
            high_freq_ratio = 0.0
    else:
        rolloff_rate = 0.0
        high_freq_ratio = 0.0
    
    return {
        'frequency_rolloff_rate': float(rolloff_rate),
        'high_frequency_content': float(high_freq_ratio)
    }


def compute_local_variance_map_stats(image: np.ndarray, window_size: int = 7) -> Dict[str, float]:
    """
    Compute statistics of local variance map.
    
    Args:
        image: Input 2D image
        window_size: Window size for local analysis
        
    Returns:
        Dictionary with local variance statistics
    """
    from scipy.ndimage import uniform_filter
    
    # Compute local variance
    local_mean = uniform_filter(image.astype(float), size=window_size)
    local_sq_mean = uniform_filter(image.astype(float) ** 2, size=window_size)
    local_variance = local_sq_mean - local_mean ** 2
    local_variance = np.maximum(local_variance, 0)
    
    return {
        'local_variance_mean': float(np.mean(local_variance)),
        'local_variance_std': float(np.std(local_variance)),
        'local_variance_max': float(np.max(local_variance)),
        'local_variance_coefficient_of_variation': float(np.std(local_variance) / (np.mean(local_variance) + 1e-10))
    }


def compute_entropy(image: np.ndarray, bins: int = 256) -> float:
    """
    Compute Shannon entropy of image histogram.
    
    Args:
        image: Input 2D image
        bins: Number of histogram bins
        
    Returns:
        Entropy value
    """
    hist, _ = np.histogram(image.flatten(), bins=bins)
    hist = hist.astype(float)
    hist = hist / (np.sum(hist) + 1e-10)
    hist = hist[hist > 0]
    
    ent = -np.sum(hist * np.log2(hist))
    return float(ent)


def compute_glcm_texture_features(image: np.ndarray, distances=[1], angles=[0]) -> Dict[str, float]:
    """
    Compute texture features using Gray-Level Co-occurrence Matrix (GLCM).
    
    Args:
        image: Input 2D image
        distances: List of pixel pair distances
        angles: List of angles (in radians)
        
    Returns:
        Dictionary with GLCM texture features
    """
    # Normalize image to 8-bit for GLCM computation
    if image.dtype != np.uint8:
        image_normalized = ((image - image.min()) / (image.max() - image.min() + 1e-10) * 255)
        image_uint8 = image_normalized.astype(np.uint8)
    else:
        image_uint8 = image
    
    try:
        # Compute GLCM
        glcm = graycomatrix(image_uint8, distances=distances, angles=angles, 
                           levels=256, symmetric=True, normed=True)
        
        # Compute properties
        contrast = graycoprops(glcm, 'contrast')[0, 0]
        dissimilarity = graycoprops(glcm, 'dissimilarity')[0, 0]
        homogeneity = graycoprops(glcm, 'homogeneity')[0, 0]
        energy = graycoprops(glcm, 'energy')[0, 0]
        correlation = graycoprops(glcm, 'correlation')[0, 0]
        
        return {
            'glcm_contrast': float(contrast),
            'glcm_dissimilarity': float(dissimilarity),
            'glcm_homogeneity': float(homogeneity),
            'glcm_energy': float(energy),
            'glcm_correlation': float(correlation)
        }
    except:
        return {
            'glcm_contrast': 0.0,
            'glcm_dissimilarity': 0.0,
            'glcm_homogeneity': 0.0,
            'glcm_energy': 0.0,
            'glcm_correlation': 0.0
        }


def estimate_minimum_resolvable_structure(image: np.ndarray) -> Dict[str, float]:
    """
    Estimate minimum resolvable structure size using FFT-based method.
    Fast alternative to spatial autocorrelation.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with structure size estimates
    """
    from scipy.fft import fft2, fftshift
    
    # Downsample to max 128x128 for speed
    max_size = 128
    if max(image.shape) > max_size:
        factor = max(image.shape) // max_size
        image_small = image[::factor, ::factor]
    else:
        image_small = image
        factor = 1
    
    # Compute FFT power spectrum
    f_transform = fft2(image_small.astype(float) - np.mean(image_small))
    power_spectrum = np.abs(fftshift(f_transform)) ** 2
    
    # Find radial power profile
    rows, cols = power_spectrum.shape
    center_y, center_x = rows // 2, cols // 2
    
    # Create radial distance array
    y, x = np.ogrid[:rows, :cols]
    r = np.sqrt((y - center_y) ** 2 + (x - center_x) ** 2)
    
    # Compute radial average
    max_radius = min(rows, cols) // 2
    radial_profile = []
    for radius in range(1, max_radius):
        mask = (r >= radius - 0.5) & (r < radius + 0.5)
        if np.sum(mask) > 0:
            radial_profile.append(np.mean(power_spectrum[mask]))
    
    if len(radial_profile) < 2:
        return {
            'min_resolvable_structure_size_px': 0.0,
            'structure_size_horizontal': 0.0,
            'structure_size_vertical': 0.0
        }
    
    radial_profile = np.array(radial_profile)
    
    # Find where power drops to 10% of max (characteristic scale)
    threshold = 0.1 * np.max(radial_profile)
    cutoff_idx = np.argmax(radial_profile < threshold) if np.any(radial_profile < threshold) else len(radial_profile)
    
    # Convert frequency to spatial scale
    if cutoff_idx > 0:
        # Structure size = image_size / cutoff_frequency
        estimated_size = (min(rows, cols) / cutoff_idx) * factor
    else:
        estimated_size = min(image.shape) * 0.1  # Default estimate
    
    return {
        'min_resolvable_structure_size_px': float(estimated_size),
        'structure_size_horizontal': float(estimated_size),
        'structure_size_vertical': float(estimated_size)
    }


def compute_structural_metrics(image: np.ndarray, enable_glcm: bool = False, 
                               enable_structure: bool = False) -> Dict[str, float]:
    """
    Compute all structural resolvability metrics.
    
    Args:
        image: Input 2D image
        enable_glcm: Enable GLCM texture features (slow)
        enable_structure: Enable structure size estimation (slow)
        
    Returns:
        Dictionary of structural metrics
    """
    metrics = {}
    
    # Edge density (fast)
    metrics['edge_density'] = compute_edge_density(image)
    
    # Frequency roll-off (fast)
    freq_metrics = compute_frequency_rolloff(image)
    metrics.update(freq_metrics)
    
    # Local variance (fast)
    variance_metrics = compute_local_variance_map_stats(image)
    metrics.update(variance_metrics)
    
    # Entropy (fast)
    metrics['entropy'] = compute_entropy(image)
    
    # GLCM texture features (SLOW - optional)
    if enable_glcm:
        glcm_metrics = compute_glcm_texture_features(image)
        metrics.update(glcm_metrics)
    else:
        metrics.update({
            'glcm_contrast': 0.0,
            'glcm_dissimilarity': 0.0,
            'glcm_homogeneity': 0.0,
            'glcm_energy': 0.0,
            'glcm_correlation': 0.0
        })
    
    # Minimum resolvable structure (SLOW - optional)
    if enable_structure:
        structure_metrics = estimate_minimum_resolvable_structure(image)
        metrics.update(structure_metrics)
    else:
        metrics.update({
            'min_resolvable_structure_size_px': 0.0,
            'structure_size_horizontal': 0.0,
            'structure_size_vertical': 0.0
        })
    
    return metrics
