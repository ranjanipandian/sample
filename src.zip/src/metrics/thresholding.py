"""
Thresholding Feasibility Metrics
"""

import numpy as np
from typing import Dict
from skimage.filters import (threshold_otsu, threshold_triangle, 
                              threshold_li, threshold_yen)
from .validation import is_valid_for_stats, safe_divide, safe_mean, is_valid_mask


def compute_otsu_metrics(image: np.ndarray) -> Dict[str, float]:
    """
    Compute Otsu thresholding metrics including separability score.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with Otsu metrics
    """
    try:
        threshold_value = threshold_otsu(image)
        
        # Compute inter-class variance (separability)
        foreground = image > threshold_value
        background = image <= threshold_value
        
        if np.sum(foreground) == 0 or np.sum(background) == 0:
            return {
                'otsu_threshold': float(threshold_value),
                'otsu_separability': 0.0,
                'foreground_background_ratio': 0.0
            }
        
        # Calculate class probabilities
        prob_fg = np.sum(foreground) / image.size
        prob_bg = np.sum(background) / image.size
        
        # Calculate class means
        mean_fg = np.mean(image[foreground])
        mean_bg = np.mean(image[background])
        mean_total = np.mean(image)
        
        # Inter-class variance (Otsu's criterion)
        var_between = prob_fg * prob_bg * ((mean_fg - mean_bg) ** 2)
        
        # Total variance
        var_total = np.var(image)
        
        # Separability score (0-1, higher is better)
        if var_total > 0:
            separability = var_between / var_total
        else:
            separability = 0.0
        
        # Foreground/background ratio
        fg_bg_ratio = np.sum(foreground) / (np.sum(background) + 1)
        
        return {
            'otsu_threshold': float(threshold_value),
            'otsu_separability': float(separability),
            'foreground_background_ratio': float(fg_bg_ratio)
        }
    except:
        return {
            'otsu_threshold': 0.0,
            'otsu_separability': 0.0,
            'foreground_background_ratio': 0.0
        }


def compute_multiple_thresholds(image: np.ndarray) -> Dict[str, float]:
    """
    Compute multiple threshold values using different methods.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with threshold values from different methods
    """
    thresholds = {}
    
    # Otsu
    try:
        thresholds['threshold_otsu'] = float(threshold_otsu(image))
    except:
        thresholds['threshold_otsu'] = float(np.mean(image))
    
    # Triangle
    try:
        thresholds['threshold_triangle'] = float(threshold_triangle(image))
    except:
        thresholds['threshold_triangle'] = float(np.mean(image))
    
    # Li
    try:
        thresholds['threshold_li'] = float(threshold_li(image))
    except:
        thresholds['threshold_li'] = float(np.mean(image))
    
    # Yen
    try:
        thresholds['threshold_yen'] = float(threshold_yen(image))
    except:
        thresholds['threshold_yen'] = float(np.mean(image))
    
    # Mean-based
    thresholds['threshold_mean'] = float(np.mean(image))
    
    # Median-based
    thresholds['threshold_median'] = float(np.median(image))
    
    # Percentile-based
    thresholds['threshold_p50'] = float(np.percentile(image, 50))
    thresholds['threshold_p75'] = float(np.percentile(image, 75))
    
    return thresholds


def compute_threshold_consistency(image: np.ndarray) -> float:
    """
    Compute consistency score across different thresholding methods.
    Higher score indicates methods agree on threshold.
    
    Args:
        image: Input 2D image
        
    Returns:
        Consistency score (0-1)
    """
    thresholds = compute_multiple_thresholds(image)
    
    # Get main threshold methods (excluding percentiles)
    main_thresholds = [
        thresholds['threshold_otsu'],
        thresholds['threshold_triangle'],
        thresholds['threshold_li'],
        thresholds['threshold_yen']
    ]
    
    # Compute coefficient of variation
    mean_threshold = np.mean(main_thresholds)
    std_threshold = np.std(main_thresholds)
    
    if mean_threshold == 0:
        return 0.0
    
    cv = std_threshold / mean_threshold
    
    # Convert to consistency score (lower CV = higher consistency)
    consistency = 1.0 / (1.0 + cv)
    
    return float(consistency)


def compute_adaptive_threshold_feasibility(image: np.ndarray, 
                                          block_size: int = 35) -> Dict[str, float]:
    """
    Assess feasibility of adaptive thresholding.
    
    Args:
        image: Input 2D image
        block_size: Block size for local analysis
        
    Returns:
        Dictionary with adaptive thresholding metrics
    """
    from scipy.ndimage import uniform_filter
    
    # Ensure block_size is odd
    if block_size % 2 == 0:
        block_size += 1
    
    # Compute local means
    local_mean = uniform_filter(image.astype(float), size=block_size)
    
    # Variance of local means indicates local contrast variation
    local_mean_variance = np.var(local_mean)
    global_variance = np.var(image)
    
    if global_variance == 0:
        feasibility = 0.0
    else:
        # High local variance suggests adaptive thresholding would help
        feasibility = min(1.0, local_mean_variance / global_variance)
    
    return {
        'adaptive_threshold_feasibility': float(feasibility),
        'local_mean_variance': float(local_mean_variance),
        'global_variance': float(global_variance)
    }


def compute_thresholding_metrics(image: np.ndarray) -> Dict[str, float]:
    """
    Compute all thresholding feasibility metrics.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary of thresholding metrics
    """
    metrics = {}
    
    # Otsu metrics
    otsu_metrics = compute_otsu_metrics(image)
    metrics.update(otsu_metrics)
    
    # Multiple threshold values
    threshold_values = compute_multiple_thresholds(image)
    metrics.update(threshold_values)
    
    # Threshold consistency
    metrics['threshold_consistency'] = compute_threshold_consistency(image)
    
    # Adaptive thresholding feasibility
    adaptive_metrics = compute_adaptive_threshold_feasibility(image)
    metrics.update(adaptive_metrics)
    
    return metrics
