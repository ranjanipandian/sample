"""Metric computation modules for image quality assessment."""
