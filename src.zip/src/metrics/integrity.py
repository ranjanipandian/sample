"""
Image and Data Integrity Metrics
"""

import numpy as np
from typing import Dict, List


def check_dimension_consistency(image: np.ndarray, expected_dims: Dict) -> Dict[str, bool]:
    """
    Check if image dimensions match expectations.
    
    Args:
        image: Image array in (T, Z, C, Y, X) format
        expected_dims: Expected dimensions dictionary
        
    Returns:
        Dictionary with consistency checks
    """
    T, Z, C, Y, X = image.shape
    
    checks = {
        'dimension_order_valid': True,  # Already normalized to TZCYX
        'has_spatial_dimensions': (Y > 0 and X > 0),
        'min_spatial_size_met': (Y >= 32 and X >= 32),  # Minimum reasonable size
        'aspect_ratio_reasonable': (0.1 <= Y/X <= 10.0)
    }
    
    return checks


def detect_missing_corrupted_slices(z_stack: np.ndarray, threshold: float = 0.5) -> Dict[str, any]:
    """
    Detect missing or corrupted slices in Z-stack.
    
    Args:
        z_stack: 3D array (Z, Y, X)
        threshold: Correlation threshold for detecting issues
        
    Returns:
        Dictionary with slice integrity metrics
    """
    Z = z_stack.shape[0]
    
    if Z < 2:
        return {
            'missing_corrupted_slices': [],
            'num_problematic_slices': 0,
            'slice_integrity_score': 1.0
        }
    
    problematic_slices = []
    
    for z in range(Z):
        slice_data = z_stack[z, :, :]
        
        # Check for all-zero or constant slices
        if np.std(slice_data) == 0:
            problematic_slices.append(z)
            continue
        
        # Check for NaN or Inf
        if np.any(np.isnan(slice_data)) or np.any(np.isinf(slice_data)):
            problematic_slices.append(z)
            continue
        
        # Check correlation with neighbors
        if z > 0:
            prev_slice = z_stack[z - 1, :, :].flatten().astype(float)
            curr_slice = slice_data.flatten().astype(float)
            
            if np.std(prev_slice) > 0 and np.std(curr_slice) > 0:
                corr = np.corrcoef(prev_slice, curr_slice)[0, 1]
                
                if corr < threshold:
                    problematic_slices.append(z)
    
    # Integrity score
    integrity = 1.0 - (len(problematic_slices) / Z)
    
    return {
        'missing_corrupted_slices': problematic_slices,
        'num_problematic_slices': len(problematic_slices),
        'slice_integrity_score': float(integrity)
    }


def detect_missing_corrupted_frames(timeseries: np.ndarray) -> Dict[str, any]:
    """
    Detect missing or corrupted frames in time-lapse data.
    
    Args:
        timeseries: 4D array (T, Z, Y, X) or 3D array (T, Y, X)
        
    Returns:
        Dictionary with frame integrity metrics
    """
    T = timeseries.shape[0]
    
    if T < 2:
        return {
            'missing_corrupted_frames': [],
            'num_problematic_frames': 0,
            'frame_integrity_score': 1.0
        }
    
    problematic_frames = []
    
    for t in range(T):
        if timeseries.ndim == 4:
            frame_data = timeseries[t, :, :, :]
        else:
            frame_data = timeseries[t, :, :]
        
        # Check for all-zero or constant frames
        if np.std(frame_data) == 0:
            problematic_frames.append(t)
            continue
        
        # Check for NaN or Inf
        if np.any(np.isnan(frame_data)) or np.any(np.isinf(frame_data)):
            problematic_frames.append(t)
            continue
    
    # Integrity score
    integrity = 1.0 - (len(problematic_frames) / T)
    
    return {
        'missing_corrupted_frames': problematic_frames,
        'num_problematic_frames': len(problematic_frames),
        'frame_integrity_score': float(integrity)
    }


def verify_channel_count(image: np.ndarray, expected_channels: int = None) -> Dict[str, any]:
    """
    Verify channel count.
    
    Args:
        image: Image array in (T, Z, C, Y, X) format
        expected_channels: Expected number of channels (optional)
        
    Returns:
        Dictionary with channel verification
    """
    C = image.shape[2]
    
    result = {
        'actual_channels': int(C),
        'channel_count_valid': True
    }
    
    if expected_channels is not None:
        result['expected_channels'] = int(expected_channels)
        result['channel_count_valid'] = (C == expected_channels)
    
    return result


def validate_data_type(image: np.ndarray) -> Dict[str, any]:
    """
    Validate image data type and value ranges.
    
    Args:
        image: Input image array
        
    Returns:
        Dictionary with data type validation
    """
    dtype = image.dtype
    
    # Check for valid numeric types
    valid_types = [np.uint8, np.uint16, np.uint32, np.int16, np.int32, 
                   np.float32, np.float64]
    is_valid_type = dtype in valid_types
    
    # Check for NaN or Inf in float types
    has_nan = False
    has_inf = False
    
    if np.issubdtype(dtype, np.floating):
        has_nan = np.any(np.isnan(image))
        has_inf = np.any(np.isinf(image))
    
    # Check value ranges
    min_val = float(np.min(image))
    max_val = float(np.max(image))
    
    # For integer types, check if within expected range
    range_valid = True
    if dtype == np.uint8:
        range_valid = (min_val >= 0 and max_val <= 255)
    elif dtype == np.uint16:
        range_valid = (min_val >= 0 and max_val <= 65535)
    
    return {
        'data_type': str(dtype),
        'data_type_valid': bool(is_valid_type),
        'has_nan_values': bool(has_nan),
        'has_inf_values': bool(has_inf),
        'value_range_valid': bool(range_valid),
        'min_value': min_val,
        'max_value': max_val
    }


def check_metadata_completeness(metadata: Dict) -> Dict[str, bool]:
    """
    Check completeness of image metadata.
    
    Args:
        metadata: Metadata dictionary
        
    Returns:
        Dictionary with completeness flags
    """
    required_fields = ['dtype', 'bit_depth', 'original_shape', 'dimension_order']
    
    completeness = {}
    
    for field in required_fields:
        completeness[f'has_{field}'] = field in metadata
    
    completeness['metadata_complete'] = all(completeness.values())
    
    return completeness


def compute_overall_integrity_score(image: np.ndarray, metadata: Dict) -> float:
    """
    Compute overall data integrity score.
    
    Args:
        image: Image array in (T, Z, C, Y, X) format
        metadata: Metadata dictionary
        
    Returns:
        Overall integrity score (0-1)
    """
    scores = []
    
    # Dimension consistency
    T, Z, C, Y, X = image.shape
    dim_checks = check_dimension_consistency(image, {})
    dim_score = sum(dim_checks.values()) / len(dim_checks)
    scores.append(dim_score)
    
    # Data type validation
    dtype_checks = validate_data_type(image)
    dtype_score = 1.0
    if dtype_checks['has_nan_values'] or dtype_checks['has_inf_values']:
        dtype_score = 0.0
    elif not dtype_checks['data_type_valid']:
        dtype_score = 0.5
    scores.append(dtype_score)
    
    # Slice/frame integrity (if applicable)
    if Z > 1:
        slice_integrity = detect_missing_corrupted_slices(image[0, :, 0, :, :])
        scores.append(slice_integrity['slice_integrity_score'])
    
    if T > 1:
        frame_integrity = detect_missing_corrupted_frames(image[:, 0, 0, :, :])
        scores.append(frame_integrity['frame_integrity_score'])
    
    # Metadata completeness
    meta_checks = check_metadata_completeness(metadata)
    meta_score = 1.0 if meta_checks['metadata_complete'] else 0.8
    scores.append(meta_score)
    
    # Overall score
    overall = np.mean(scores)
    
    return float(overall)


def compute_integrity_metrics(image: np.ndarray, metadata: Dict) -> Dict[str, any]:
    """
    Compute all integrity and validation metrics.
    
    Args:
        image: Image array in (T, Z, C, Y, X) format
        metadata: Metadata dictionary
        
    Returns:
        Dictionary of integrity metrics
    """
    T, Z, C, Y, X = image.shape
    
    metrics = {}
    
    # Dimension consistency
    dim_checks = check_dimension_consistency(image, {})
    metrics.update(dim_checks)
    
    # Data type validation
    dtype_checks = validate_data_type(image)
    metrics.update(dtype_checks)
    
    # Channel verification
    channel_checks = verify_channel_count(image)
    metrics.update(channel_checks)
    
    # Slice integrity (if 3D/4D)
    if Z > 1:
        slice_integrity = detect_missing_corrupted_slices(image[0, :, 0, :, :])
        metrics.update(slice_integrity)
    
    # Frame integrity (if time-lapse)
    if T > 1:
        frame_integrity = detect_missing_corrupted_frames(image[:, 0, 0, :, :])
        metrics.update(frame_integrity)
    
    # Metadata completeness
    meta_checks = check_metadata_completeness(metadata)
    metrics.update(meta_checks)
    
    # Overall integrity score
    metrics['overall_integrity_score'] = compute_overall_integrity_score(image, metadata)
    
    return metrics
