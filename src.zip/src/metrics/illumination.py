"""
Illumination and Uniformity Metrics
"""

import numpy as np
from typing import Dict, Tuple
from scipy import ndimage
from skimage.filters import gaussian


def estimate_background_field(image: np.ndarray, sigma: float = 50) -> np.ndarray:
    """
    Estimate background illumination field using Gaussian blur.
    
    Args:
        image: Input 2D image
        sigma: Sigma for Gaussian smoothing
        
    Returns:
        Estimated background field
    """
    # Use large Gaussian blur to estimate background
    background = gaussian(image.astype(float), sigma=sigma, preserve_range=True)
    return background


def compute_vignetting_score(image: np.ndarray) -> float:
    """
    Compute vignetting score (darkening at edges).
    
    Args:
        image: Input 2D image
        
    Returns:
        Vignetting score (0-1, higher = more vignetting)
    """
    rows, cols = image.shape
    
    # Define center and edge regions
    center_r = int(rows * 0.25)
    center_c = int(cols * 0.25)
    
    # Center region
    center_region = image[
        rows//2 - center_r : rows//2 + center_r,
        cols//2 - center_c : cols//2 + center_c
    ]
    center_mean = np.mean(center_region)
    
    # Edge regions (top, bottom, left, right)
    edge_width = int(min(rows, cols) * 0.1)
    
    top_edge = image[:edge_width, :]
    bottom_edge = image[-edge_width:, :]
    left_edge = image[:, :edge_width]
    right_edge = image[:, -edge_width:]
    
    edge_means = [
        np.mean(top_edge),
        np.mean(bottom_edge),
        np.mean(left_edge),
        np.mean(right_edge)
    ]
    
    edge_mean = np.mean(edge_means)
    
    if center_mean == 0:
        return 0.0
    
    # Vignetting score: (center - edge) / center
    vignetting = (center_mean - edge_mean) / center_mean
    vignetting = np.clip(vignetting, 0, 1)
    
    return float(vignetting)


def compute_flatfield_deviation(image: np.ndarray) -> Dict[str, float]:
    """
    Compute flat-field deviation metrics.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary with flat-field metrics
    """
    # Estimate background field
    background = estimate_background_field(image, sigma=50)
    
    # Compute deviation from uniform illumination
    mean_background = np.mean(background)
    
    if mean_background > 0:
        # Normalized background variation
        deviation = np.std(background) / mean_background
    else:
        deviation = 0.0
    
    # Spatial gradient of background (should be low for uniform illumination)
    grad_y = np.abs(ndimage.sobel(background, axis=0))
    grad_x = np.abs(ndimage.sobel(background, axis=1))
    gradient_magnitude = np.sqrt(grad_y ** 2 + grad_x ** 2)
    mean_gradient = np.mean(gradient_magnitude)
    
    return {
        'flatfield_deviation': float(deviation),
        'background_gradient': float(mean_gradient),
        'background_mean': float(mean_background),
        'background_std': float(np.std(background))
    }


def compute_background_uniformity(image: np.ndarray, grid_size: int = 5) -> float:
    """
    Compute background uniformity score using grid-based analysis.
    
    Args:
        image: Input 2D image
        grid_size: Number of regions along each dimension
        
    Returns:
        Uniformity score (0-1, higher = more uniform), or NaN if not computable
    """
    rows, cols = image.shape
    
    # Check if image is too small for meaningful grid analysis
    if rows < grid_size * 2 or cols < grid_size * 2:
        return float('nan')
    
    # Estimate background
    background = estimate_background_field(image, sigma=30)
    
    region_height = rows // grid_size
    region_width = cols // grid_size
    
    # Additional check: regions must have minimum size
    if region_height < 1 or region_width < 1:
        return float('nan')
    
    region_means = []
    
    for i in range(grid_size):
        for j in range(grid_size):
            y_start = i * region_height
            y_end = (i + 1) * region_height if i < grid_size - 1 else rows
            x_start = j * region_width
            x_end = (j + 1) * region_width if j < grid_size - 1 else cols
            
            region = background[y_start:y_end, x_start:x_end]
            region_means.append(np.mean(region))
    
    region_means = np.array(region_means)
    
    # Coefficient of variation
    mean_val = np.mean(region_means)
    if mean_val > 0:
        cv = np.std(region_means) / mean_val
        uniformity = 1.0 / (1.0 + cv)
    else:
        # Return NaN instead of 0.0 when metric cannot be computed
        uniformity = float('nan')
    
    return float(uniformity)


def compute_shading_correction_needed(image: np.ndarray, threshold: float = 0.15) -> bool:
    """
    Determine if shading correction is needed.
    
    Args:
        image: Input 2D image
        threshold: Threshold for deviation
        
    Returns:
        True if shading correction is recommended
    """
    flatfield_metrics = compute_flatfield_deviation(image)
    deviation = flatfield_metrics['flatfield_deviation']
    
    return deviation > threshold


def compute_z_illumination_stability(z_stack: np.ndarray) -> Dict[str, float]:
    """
    Compute illumination stability across Z-slices.
    
    Args:
        z_stack: 3D array (Z, Y, X)
        
    Returns:
        Dictionary with Z-stability metrics
    """
    Z = z_stack.shape[0]
    
    # Compute mean intensity for each slice
    slice_means = [np.mean(z_stack[z, :, :]) for z in range(Z)]
    slice_means = np.array(slice_means)
    
    # Stability metrics
    mean_of_means = np.mean(slice_means)
    if mean_of_means > 0:
        cv = np.std(slice_means) / mean_of_means
        stability = 1.0 / (1.0 + cv)
    else:
        stability = 0.0
    
    # Trend detection (linear fit)
    z_indices = np.arange(Z)
    try:
        slope, intercept = np.polyfit(z_indices, slice_means, 1)
        normalized_slope = slope / (mean_of_means + 1e-10)
    except:
        normalized_slope = 0.0
    
    return {
        'z_illumination_stability': float(stability),
        'z_illumination_trend': float(normalized_slope),
        'z_illumination_cv': float(cv) if mean_of_means > 0 else 0.0
    }


def compute_temporal_illumination_drift(timeseries: np.ndarray) -> Dict[str, float]:
    """
    Compute illumination drift over time (4D data).
    
    Args:
        timeseries: 4D array (T, Z, Y, X) or 3D array (T, Y, X)
        
    Returns:
        Dictionary with temporal drift metrics
    """
    T = timeseries.shape[0]
    
    # Compute mean intensity for each timepoint
    if timeseries.ndim == 4:
        time_means = [np.mean(timeseries[t, :, :, :]) for t in range(T)]
    else:
        time_means = [np.mean(timeseries[t, :, :]) for t in range(T)]
    
    time_means = np.array(time_means)
    
    # Drift metrics
    mean_intensity = np.mean(time_means)
    if mean_intensity > 0:
        cv = np.std(time_means) / mean_intensity
    else:
        cv = 0.0
    
    # Linear trend
    t_indices = np.arange(T)
    try:
        slope, intercept = np.polyfit(t_indices, time_means, 1)
        normalized_slope = slope / (mean_intensity + 1e-10)
        
        # R-squared for fit quality
        fitted = slope * t_indices + intercept
        ss_res = np.sum((time_means - fitted) ** 2)
        ss_tot = np.sum((time_means - mean_intensity) ** 2)
        r_squared = 1 - (ss_res / (ss_tot + 1e-10))
    except:
        normalized_slope = 0.0
        r_squared = 0.0
    
    return {
        'temporal_illumination_drift': float(normalized_slope),
        'temporal_illumination_cv': float(cv),
        'drift_trend_quality': float(r_squared)
    }


def compute_illumination_metrics(image: np.ndarray) -> Dict[str, float]:
    """
    Compute all illumination and uniformity metrics for a 2D image.
    
    Args:
        image: Input 2D image
        
    Returns:
        Dictionary of illumination metrics
    """
    metrics = {}
    
    # Vignetting
    metrics['vignetting_score'] = compute_vignetting_score(image)
    
    # Flat-field deviation
    flatfield_metrics = compute_flatfield_deviation(image)
    metrics.update(flatfield_metrics)
    
    # Background uniformity
    metrics['background_uniformity_score'] = compute_background_uniformity(image)
    
    # Shading correction flag
    metrics['shading_correction_needed'] = compute_shading_correction_needed(image)
    
    return metrics
