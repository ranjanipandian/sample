"""
JSON Output Writer - Generate machine-readable QC reports
"""

import json
import numpy as np
from pathlib import Path
from typing import Dict, Any


class NumpyEncoder(json.JSONEncoder):
    """Custom JSON encoder for NumPy types."""
    
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.bool_):
            return bool(obj)
        return super(NumpyEncoder, self).default(obj)


def write_json_report(results: Dict[str, Any], output_path: str):
    """
    Write QC results to JSON file.
    
    Args:
        results: QC results dictionary
        output_path: Path to output JSON file
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Convert any remaining non-serializable objects
    serializable_results = make_serializable(results)
    
    with open(output_path, 'w') as f:
        json.dump(serializable_results, f, indent=2, cls=NumpyEncoder)
    
    print(f"JSON report written to: {output_path}")


def make_serializable(obj: Any) -> Any:
    """
    Recursively convert objects to JSON-serializable format.
    
    Args:
        obj: Object to convert
        
    Returns:
        Serializable version
    """
    if isinstance(obj, dict):
        return {key: make_serializable(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [make_serializable(item) for item in obj]
    elif isinstance(obj, (np.integer, np.int32, np.int64)):
        return int(obj)
    elif isinstance(obj, (np.floating, np.float32, np.float64)):
        return float(obj)
    elif isinstance(obj, np.bool_):
        return bool(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    else:
        return str(obj)
