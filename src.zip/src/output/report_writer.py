"""
Text Report Writer - Generate human-readable QC reports
Stage-1: Measurement Engine (No Decisions)
"""

from pathlib import Path
from typing import Dict, Any
from datetime import datetime
import math


def write_text_report(results: Dict[str, Any], output_path: str):
    """
    Write human-readable text report.
    Stage-1 reports contain ONLY measurements, no decisions or recommendations.
    
    Args:
        results: QC results dictionary
        output_path: Path to output text file
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        # Header
        f.write("=" * 80 + "\n")
        f.write("STAGE-1 CLASSICAL IMAGE QC REPORT\n")
        f.write("Deterministic Measurement Engine\n")
        f.write("=" * 80 + "\n\n")
        
        # Metadata
        f.write("Image Information:\n")
        f.write("-" * 80 + "\n")
        metadata = results.get('metadata', {})
        f.write(f"  File: {metadata.get('image_path', 'N/A')}\n")
        f.write(f"  Analysis Time: {metadata.get('analysis_timestamp', 'N/A')}\n")
        
        dims = metadata.get('dimensions', {})
        f.write(f"  Dimensions: T={dims.get('T', 0)}, Z={dims.get('Z', 0)}, ")
        f.write(f"C={dims.get('C', 0)}, Y={dims.get('Y', 0)}, X={dims.get('X', 0)}\n")
        f.write(f"  Data Type: {metadata.get('dtype', 'N/A')}\n")
        f.write(f"  Bit Depth: {metadata.get('bit_depth', 'N/A')}\n\n")
        
        # Sampling Information
        sampling = results.get('sampling', {})
        if sampling.get('sampling_enabled', False):
            f.write("Sampling Strategy:\n")
            f.write("-" * 80 + "\n")
            f.write(f"  Total Slices: {sampling.get('total_slices', 'N/A'):,}\n")
            f.write(f"  Sampled Slices: {sampling.get('sampled_slices', 'N/A'):,}\n")
            f.write(f"  Percentage Processed: {sampling.get('percentage_processed', 0):.1f}%\n")
            f.write(f"  Sampling Method: Structured (first/mid/last + uniform)\n\n")
        
        # NaN Explanation
        f.write("NaN Metrics Information:\n")
        f.write("-" * 80 + "\n")
        f.write("Some QC metrics may be reported as NaN. This is expected behavior and indicates\n")
        f.write("that the metric was not computable for this image due to one or more of the\n")
        f.write("following reasons:\n\n")
        f.write("  - Insufficient spatial extent (e.g., very small X dimension)\n")
        f.write("  - Uniform background without measurable variation\n")
        f.write("  - No valid regions for min/max comparison\n")
        f.write("  - Metric not applicable to the detected image modality\n\n")
        f.write("NaN values in this report do NOT indicate a failure. They indicate the metric\n")
        f.write("could not be meaningfully calculated for this specific image configuration.\n\n")
        
        # Key Metrics Summary
        f.write("Key Quality Metrics:\n")
        f.write("-" * 80 + "\n")
        
        summary = results.get('global_summary', {})
        aggregated = results.get('aggregated_metrics', {})
        
        # SNR
        if 'mean_snr' in summary:
            f.write(f"  ℹ Signal-to-Noise Ratio: {format_value(summary['mean_snr'])}\n")
        
        # Focus Quality
        if 'mean_focus_quality' in summary:
            f.write(f"  ℹ Focus Quality (Laplacian Var): {format_value(summary['mean_focus_quality'])}\n")
        
        # Noise Level
        if 'mean_noise_level' in summary:
            f.write(f"  ℹ Noise Level (σ): {format_value(summary['mean_noise_level'])}\n")
        
        # Contrast
        if 'rms_contrast_mean' in aggregated:
            f.write(f"  ℹ RMS Contrast: {format_value(aggregated['rms_contrast_mean'], decimals=3)}\n")
        
        if 'michelson_contrast_mean' in aggregated:
            f.write(f"  ℹ Michelson Contrast: {format_value(aggregated['michelson_contrast_mean'], decimals=3)}\n")
        
        # Bit Depth Utilization
        if 'bit_depth_utilization_percent_mean' in aggregated:
            util = aggregated['bit_depth_utilization_percent_mean']
            f.write(f"  ℹ Bit Depth Utilization: {format_value(util, decimals=1)}%\n")
        
        f.write("\n")
        
        # Intensity Statistics
        f.write("Intensity Statistics:\n")
        f.write("-" * 80 + "\n")
        
        if 'mean_intensity_mean' in aggregated:
            f.write(f"  ℹ Mean Intensity: {format_value(aggregated['mean_intensity_mean'])}\n")
        
        if 'median_intensity_mean' in aggregated:
            f.write(f"  ℹ Median Intensity: {format_value(aggregated['median_intensity_mean'])}\n")
        
        if 'std_intensity_mean' in aggregated:
            f.write(f"  ℹ Std Dev: {format_value(aggregated['std_intensity_mean'])}\n")
        
        if 'percentile_1_mean' in aggregated and 'percentile_99_mean' in aggregated:
            f.write(f"  ℹ Intensity Range (1%-99%): {format_value(aggregated['percentile_1_mean'])} - {format_value(aggregated['percentile_99_mean'])}\n")
        
        f.write("\n")
        
        # Artifact Detection
        f.write("Artifact Detection:\n")
        f.write("-" * 80 + "\n")
        
        if 'dead_pixel_percent_mean' in aggregated:
            dead_pct = aggregated['dead_pixel_percent_mean']
            f.write(f"  ℹ Dead Pixels: {format_value(dead_pct, decimals=3)}%\n")
        
        if 'hot_pixel_percent_mean' in aggregated:
            hot_pct = aggregated['hot_pixel_percent_mean']
            f.write(f"  ℹ Hot Pixels: {format_value(hot_pct, decimals=3)}%\n")
        
        if 'line_noise_score_mean' in aggregated:
            line = aggregated['line_noise_score_mean']
            f.write(f"  ℹ Line Noise Score: {format_value(line, decimals=3)}\n")
        
        if 'vignetting_score_mean' in aggregated:
            vig = aggregated['vignetting_score_mean']
            f.write(f"  ℹ Vignetting Score: {format_value(vig, decimals=3)}\n")
        
        if 'stripe_artifact_score_mean' in aggregated:
            stripe = aggregated['stripe_artifact_score_mean']
            f.write(f"  ℹ Stripe Artifact Score: {format_value(stripe, decimals=3)}\n")
        
        f.write("\n")
        
        # Illumination
        f.write("Illumination Quality:\n")
        f.write("-" * 80 + "\n")
        
        if 'background_uniformity_score_mean' in aggregated:
            uniformity = aggregated['background_uniformity_score_mean']
            f.write(f"  ℹ Background Uniformity Score: {format_value(uniformity, decimals=3)}\n")
        
        if 'flatfield_deviation_mean' in aggregated:
            flatfield = aggregated['flatfield_deviation_mean']
            f.write(f"  ℹ Flat-field Deviation: {format_value(flatfield, decimals=3)}\n")
        
        f.write("\n")
        
        # Dimensional Quality (if 3D/4D)
        if results.get('per_volume_metrics'):
            f.write("3D/4D Quality Metrics:\n")
            f.write("-" * 80 + "\n")
            
            vol_metrics = results['per_volume_metrics'][0] if results['per_volume_metrics'] else {}
            
            if 'defocused_slices_percent' in vol_metrics:
                defocus_pct = vol_metrics['defocused_slices_percent']
                f.write(f"  ℹ Defocused Slices: {format_value(defocus_pct, decimals=1)}%\n")
            
            if 'z_consistency_score' in vol_metrics:
                z_consist = vol_metrics['z_consistency_score']
                f.write(f"  ℹ Z-Consistency Score: {format_value(z_consist, decimals=3)}\n")
            
            if 'best_focus_z_index' in vol_metrics:
                best_z = vol_metrics['best_focus_z_index']
                f.write(f"  ℹ Best Focus Z-Index: {best_z}\n")
            
            if results.get('per_timepoint_metrics'):
                temp_metrics = results['per_timepoint_metrics'][0]
                
                if 'photobleaching_rate' in temp_metrics:
                    bleach = temp_metrics['photobleaching_rate']
                    f.write(f"  ℹ Photobleaching Rate: {format_value(bleach, decimals=4)}\n")
                
                if 'temporal_illumination_drift' in temp_metrics:
                    drift = temp_metrics['temporal_illumination_drift']
                    f.write(f"  ℹ Temporal Illumination Drift: {format_value(drift, decimals=3)}\n")
                
                if 'z_drift_detected' in temp_metrics:
                    drift = temp_metrics['z_drift_detected']
                    f.write(f"  ℹ Z-Drift Detected: {drift}\n")
            
            f.write("\n")
        
        # Segmentability
        f.write("Segmentability Assessment:\n")
        f.write("-" * 80 + "\n")
        
        if 'foreground_separability_mean' in aggregated:
            sep = aggregated['foreground_separability_mean']
            f.write(f"  ℹ Foreground Separability Score: {format_value(sep, decimals=3)}\n")
        
        if 'segmentation_feasibility_score_mean' in aggregated:
            feas = aggregated['segmentation_feasibility_score_mean']
            f.write(f"  ℹ Segmentation Feasibility Score: {format_value(feas, decimals=3)}\n")
        
        if 'object_boundary_clarity_mean' in aggregated:
            clarity = aggregated['object_boundary_clarity_mean']
            f.write(f"  ℹ Object Boundary Clarity: {format_value(clarity, decimals=3)}\n")
        
        f.write("\n")
        
        # Data Integrity
        f.write("Data Integrity:\n")
        f.write("-" * 80 + "\n")
        
        integrity = results.get('integrity', {})
        
        if 'overall_integrity_score' in integrity:
            integ_score = integrity['overall_integrity_score']
            f.write(f"  ℹ Overall Integrity Score: {format_value(integ_score, decimals=3)}\n")
        
        if 'has_nan_values' in integrity:
            has_nan = integrity['has_nan_values']
            f.write(f"  ℹ No critical NaN values in image data: {not has_nan}\n")
        
        if 'has_inf_values' in integrity:
            has_inf = integrity['has_inf_values']
            f.write(f"  ℹ No Inf values in image data: {not has_inf}\n")
        
        if 'dimension_consistency_check' in integrity:
            dim_check = integrity['dimension_consistency_check']
            f.write(f"  ℹ Dimension Consistency: {dim_check}\n")
        
        f.write("\n")
        
        # Observed QC Findings
        f.write("Observed QC Findings:\n")
        f.write("-" * 80 + "\n")
        
        findings = generate_findings(results, aggregated, summary, integrity)
        
        if findings:
            for finding in findings:
                f.write(f"  • {finding}\n")
        else:
            f.write("  All metrics computed successfully.\n")
            f.write("  No significant deviations from typical threshold references observed.\n")
        
        f.write("\n")
        f.write("Note: These are measured observations. Final quality assessment\n")
        f.write("should be performed by domain experts or Stage-2 reasoning systems.\n")
        f.write("\n")
        
        # Footer
        f.write("=" * 80 + "\n")
        f.write("End of Stage-1 Measurement Report\n")
        f.write("For decision-making, please process this data through Stage-2 reasoning.\n")
        f.write("=" * 80 + "\n")
    
    print(f"Text report written to: {output_path}")


def format_value(value: Any, decimals: int = 2) -> str:
    """
    Format a value for display, handling NaN gracefully.
    
    Args:
        value: Value to format
        decimals: Number of decimal places
        
    Returns:
        Formatted string
    """
    if value is None:
        return "N/A"
    
    if isinstance(value, (int, float)):
        if math.isnan(value):
            return "NaN"
        elif math.isinf(value):
            return "Inf"
        else:
            return f"{value:.{decimals}f}"
    
    return str(value)


def generate_findings(results: Dict, aggregated: Dict, summary: Dict, integrity: Dict) -> list:
    """
    Generate neutral observed findings without making decisions.
    
    Args:
        results: Full results dictionary
        aggregated: Aggregated metrics
        summary: Global summary
        integrity: Integrity metrics
        
    Returns:
        List of finding strings
    """
    findings = []
    
    # Contrast observation
    if 'rms_contrast_mean' in aggregated:
        contrast = aggregated['rms_contrast_mean']
        if not math.isnan(contrast) and contrast < 0.1:
            findings.append(f"RMS Contrast measured at {contrast:.3f} (threshold reference: 0.1)")
    
    # Illumination observation
    if 'background_uniformity_score_mean' in aggregated:
        uniformity = aggregated['background_uniformity_score_mean']
        if not math.isnan(uniformity) and uniformity < 0.2:
            findings.append(f"Background uniformity score: {uniformity:.3f} (threshold reference: 0.2)")
    
    # Vignetting observation
    if 'vignetting_score_mean' in aggregated:
        vignetting = aggregated['vignetting_score_mean']
        if not math.isnan(vignetting) and vignetting > 0.3:
            findings.append(f"Vignetting score: {vignetting:.3f} (threshold reference: 0.3)")
    
    # SNR observation
    if 'mean_snr' in summary:
        snr = summary['mean_snr']
        if not math.isnan(snr) and snr < 10.0:
            findings.append(f"Signal-to-Noise Ratio: {snr:.2f} (threshold reference: 10.0)")
    
    # Defocus observation (3D)
    if results.get('per_volume_metrics'):
        vol_metrics = results['per_volume_metrics'][0]
        if 'defocused_slices_percent' in vol_metrics:
            defocus_pct = vol_metrics['defocused_slices_percent']
            if not math.isnan(defocus_pct) and defocus_pct > 30.0:
                findings.append(f"Defocused slices detected: {defocus_pct:.1f}% (threshold reference: 30%)")
    
    # Integrity observation
    if 'overall_integrity_score' in integrity:
        integ_score = integrity['overall_integrity_score']
        if not math.isnan(integ_score) and integ_score < 0.9:
            findings.append(f"Data integrity score: {integ_score:.3f} (threshold reference: 0.9)")
    
    # Separability observation
    if 'foreground_separability_mean' in aggregated:
        separability = aggregated['foreground_separability_mean']
        if not math.isnan(separability) and separability < 0.5:
            findings.append(f"Foreground separability score: {separability:.3f} (threshold reference: 0.5)")
    
    return findings
