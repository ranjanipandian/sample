"""Output modules for generating reports and visualizations."""
