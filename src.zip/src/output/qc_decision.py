"""
QC Decision Logic - Determine PASS/REVIEW/FAIL status
"""

from typing import Dict, List, Any
from ..core.config import get_threshold


def make_qc_decision(results: Dict[str, Any]) -> Dict[str, Any]:
    """
    Make QC decision based on metrics.
    
    Args:
        results: QC results dictionary
        
    Returns:
        QC decision dictionary with status, warnings, and failures
    """
    warnings = []
    critical_failures = []
    
    aggregated = results.get('aggregated_metrics', {})
    summary = results.get('global_summary', {})
    integrity = results.get('integrity', {})
    
    # Check Signal Quality
    if 'mean_snr' in summary:
        snr = summary['mean_snr']
        snr_pass = get_threshold('snr_min_pass')
        snr_review = get_threshold('snr_min_review')
        
        if snr < snr_review:
            critical_failures.append(f"SNR too low: {snr:.2f} (minimum: {snr_review})")
        elif snr < snr_pass:
            warnings.append(f"SNR below recommended: {snr:.2f} (recommended: {snr_pass})")
    
    # Check Noise
    if 'gaussian_noise_sigma_mean' in aggregated:
        noise = aggregated['gaussian_noise_sigma_mean']
        noise_pass = get_threshold('gaussian_noise_max_pass')
        noise_review = get_threshold('gaussian_noise_max_review')
        
        if noise > noise_review:
            critical_failures.append(f"Noise level too high: {noise:.2f} (maximum: {noise_review})")
        elif noise > noise_pass:
            warnings.append(f"Noise level elevated: {noise:.2f} (recommended max: {noise_pass})")
    
    # Check Saturation
    if 'percentile_99_mean' in aggregated and 'max_intensity_mean' in aggregated:
        p99 = aggregated['percentile_99_mean']
        max_int = aggregated['max_intensity_mean']
        
        if max_int > 0:
            saturation_pct = 100 * (max_int - p99) / max_int
            if saturation_pct < 1.0:
                warnings.append(f"Possible saturation detected (99th percentile near max)")
    
    # Check Contrast
    if 'rms_contrast_mean' in aggregated:
        contrast = aggregated['rms_contrast_mean']
        contrast_min = get_threshold('rms_contrast_min')
        
        if contrast < contrast_min:
            warnings.append(f"Low contrast: {contrast:.3f} (minimum: {contrast_min})")
    
    # Check Illumination
    if 'vignetting_score_mean' in aggregated:
        vignetting = aggregated['vignetting_score_mean']
        vig_max = get_threshold('vignetting_score_max')
        
        if vignetting > vig_max:
            warnings.append(f"Significant vignetting detected: {vignetting:.3f}")
    
    if 'background_uniformity_score_mean' in aggregated:
        uniformity = aggregated['background_uniformity_score_mean']
        unif_min = get_threshold('uniformity_min')
        
        if uniformity < unif_min:
            warnings.append(f"Non-uniform illumination: {uniformity:.3f}")
    
    # Check Artifacts
    if 'dead_pixel_percent_mean' in aggregated:
        dead_pct = aggregated['dead_pixel_percent_mean']
        dead_max = get_threshold('dead_pixel_percent_max')
        
        if dead_pct > dead_max:
            warnings.append(f"Excessive dead pixels: {dead_pct:.3f}%")
    
    if 'hot_pixel_percent_mean' in aggregated:
        hot_pct = aggregated['hot_pixel_percent_mean']
        hot_max = get_threshold('hot_pixel_percent_max')
        
        if hot_pct > hot_max:
            warnings.append(f"Excessive hot pixels: {hot_pct:.3f}%")
    
    # Check 3D/4D metrics
    if results.get('per_volume_metrics'):
        vol_metrics = results['per_volume_metrics'][0]
        
        if 'defocused_slices_percent' in vol_metrics:
            defocus_pct = vol_metrics['defocused_slices_percent']
            defocus_max = get_threshold('defocused_slices_percent_max')
            
            if defocus_pct > defocus_max:
                warnings.append(f"Too many defocused slices: {defocus_pct:.1f}%")
        
        if 'z_consistency_score' in vol_metrics:
            z_consist = vol_metrics['z_consistency_score']
            z_min = get_threshold('z_consistency_min')
            
            if z_consist < z_min:
                warnings.append(f"Low Z-consistency: {z_consist:.3f}")
    
    # Check Segmentability
    if 'foreground_separability_mean' in aggregated:
        separability = aggregated['foreground_separability_mean']
        sep_min = get_threshold('separability_min')
        
        if separability < sep_min:
            warnings.append(f"Poor foreground/background separation: {separability:.3f}")
    
    # Check Data Integrity
    if 'overall_integrity_score' in integrity:
        integ_score = integrity['overall_integrity_score']
        
        if integ_score < 0.7:
            critical_failures.append(f"Data integrity compromised: {integ_score:.3f}")
        elif integ_score < 0.9:
            warnings.append(f"Data integrity concerns: {integ_score:.3f}")
    
    if integrity.get('has_nan_values', False):
        critical_failures.append("NaN values detected in image data")
    
    if integrity.get('has_inf_values', False):
        critical_failures.append("Infinite values detected in image data")
    
    # Determine overall status
    if critical_failures:
        overall_status = "FAIL"
        recommendation = "Image has critical quality issues and should not be used for analysis."
    elif warnings:
        overall_status = "REVIEW"
        recommendation = "Image has some quality concerns. Manual review recommended before analysis."
    else:
        overall_status = "PASS"
        recommendation = "Image quality is acceptable for analysis."
    
    # Compute confidence score
    total_checks = len(warnings) + len(critical_failures) + 10  # Base checks
    failed_checks = len(warnings) + 2 * len(critical_failures)  # Failures weighted 2x
    confidence_score = max(0, 100 * (1 - failed_checks / total_checks))
    
    return {
        'overall_status': overall_status,
        'confidence_score': confidence_score,
        'warnings': warnings,
        'critical_failures': critical_failures,
        'recommendation': recommendation,
        'total_warnings': len(warnings),
        'total_failures': len(critical_failures)
    }
