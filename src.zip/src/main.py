"""
Main CLI Interface for Stage-1 Classical Image QC Engine
"""

import argparse
import sys
import warnings
from pathlib import Path
import numpy as np
import yaml

# Suppress NumPy warnings globally to prevent performance issues
warnings.filterwarnings('ignore', category=RuntimeWarning)
warnings.filterwarnings('ignore', category=UserWarning)
np.seterr(divide='ignore', invalid='ignore', over='ignore', under='ignore')

from .qc_engine import QCEngine
from .output.json_writer import write_json_report
from .output.report_writer import write_text_report


def load_config(config_path='config.yaml'):
    """
    Load configuration from YAML file.
    
    Args:
        config_path: Path to config file
        
    Returns:
        Configuration dictionary or empty dict if file doesn't exist
    """
    config_file = Path(config_path)
    if config_file.exists():
        try:
            with open(config_file, 'r') as f:
                config = yaml.safe_load(f)
                return config if config else {}
        except Exception as e:
            print(f"Warning: Could not load config file: {e}")
            return {}
    return {}


def main():
    """Main CLI entry point."""
    # Load configuration from file
    config = load_config()
    
    parser = argparse.ArgumentParser(
        description='Stage-1 Classical Image QC Engine for Microscopy Images',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run with config.yaml defaults
  python -m src.main
  
  # Override input path
  python -m src.main --input path/to/image.tif
  
  # Override output directory
  python -m src.main --input image.tif --output-dir ./my_results
  
  # Verbose mode
  python -m src.main --verbose
        """
    )
    
    parser.add_argument(
        '--input', '-i',
        type=str,
        default=config.get('input_path'),
        help='Path to input TIFF image (default: from config.yaml)'
    )
    
    parser.add_argument(
        '--output-dir', '-o',
        type=str,
        default=config.get('output_dir', './output'),
        help='Output directory for QC reports (default: from config.yaml or ./output)'
    )
    
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        default=config.get('verbose', False),
        help='Enable verbose output (default: from config.yaml)'
    )
    
    parser.add_argument(
        '--generate-visualizations',
        action='store_true',
        default=config.get('generate_visualizations', False),
        help='Generate visualization outputs (heatmaps, plots)'
    )
    
    parser.add_argument(
        '--fast-mode',
        action='store_true',
        default=config.get('fast_mode', False),
        help='Enable fast mode (sampling + skip heavy metrics for large datasets)'
    )
    
    parser.add_argument(
        '--full-analysis',
        action='store_true',
        default=config.get('full_analysis', False),
        help='Force full analysis - process every slice (slow for large datasets)'
    )
    
    parser.add_argument(
        '--sample-rate',
        type=int,
        default=config.get('sample_rate', 10),
        help='Sampling rate for large datasets (default: from config.yaml or 10)'
    )
    
    parser.add_argument(
        '--num-workers',
        type=int,
        default=config.get('num_workers', -1),
        help='Number of parallel workers: -1=auto, 0=disable, N=use N workers (default: from config.yaml)'
    )
    
    parser.add_argument(
        '--no-parallel',
        action='store_true',
        help='Disable parallel processing'
    )
    
    args = parser.parse_args()
    
    # Validate input file
    if args.input is None:
        print("Error: No input file specified. Please provide --input or set input_path in config.yaml")
        sys.exit(1)
    
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: Input file not found: {args.input}")
        sys.exit(1)
    
    if input_path.suffix.lower() not in ['.tif', '.tiff']:
        print(f"Error: Input file must be TIFF format (.tif or .tiff)")
        sys.exit(1)
    
    # Setup output directories
    output_dir = Path(args.output_dir)
    qc_results_dir = output_dir / 'qc_results'
    reports_dir = output_dir / 'reports'
    
    qc_results_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)
    
    # Get base filename
    base_name = input_path.stem
    
    print("=" * 80)
    print("STAGE-1 CLASSICAL IMAGE QC ENGINE")
    print("=" * 80)
    print()
    
    try:
        # Determine parallel settings
        enable_parallel = config.get('enable_parallel', True) and not args.no_parallel
        num_workers = 0 if args.no_parallel else args.num_workers
        
        # Initialize QC Engine
        engine = QCEngine(
            verbose=args.verbose,
            fast_mode=args.fast_mode,
            sample_rate=args.sample_rate,
            full_analysis=args.full_analysis,
            num_workers=num_workers,
            enable_parallel=enable_parallel
        )
        
        # Load image
        print("Loading image...")
        engine.load_image(str(input_path))
        
        # Run QC analysis
        print("Running QC analysis...")
        results = engine.run_qc()
        
        # Write JSON report
        json_path = qc_results_dir / f"{base_name}_qc.json"
        print(f"\nWriting JSON report...")
        write_json_report(results, str(json_path))
        
        # Write text report
        report_path = reports_dir / f"{base_name}_qc_report.txt"
        print(f"Writing text report...")
        write_text_report(results, str(report_path))
        
        # Print summary
        print("\n" + "=" * 80)
        print("QC MEASUREMENT COMPLETE")
        print("=" * 80)
        print("\nMetrics computed and exported to JSON format.")
        print("Text report generated for human review.")
        
        print("\n" + "=" * 80)
        print("Output Files:")
        print(f"  JSON: {json_path}")
        print(f"  Report: {report_path}")
        print("=" * 80 + "\n")
        
        sys.exit(0)
    
    except KeyboardInterrupt:
        print("\n\n⚠ Analysis interrupted by user.")
        print("Attempting to save partial results...")
        
        try:
            # Try to save whatever results we have
            if hasattr(engine, 'results') and engine.results:
                results = engine.results
                
                json_path = qc_results_dir / f"{base_name}_qc_partial.json"
                write_json_report(results, str(json_path))
                
                report_path = reports_dir / f"{base_name}_qc_report_partial.txt"
                write_text_report(results, str(report_path))
                
                print(f"\n✓ Partial results saved:")
                print(f"  JSON: {json_path}")
                print(f"  Report: {report_path}")
        except:
            print("✗ Could not save partial results")
        
        sys.exit(130)  # Standard exit code for SIGINT
    
    except Exception as e:
        print(f"\n✗ Error during QC analysis: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(3)


if __name__ == '__main__':
    main()
