"""Core modules for image loading and dimension handling."""
