"""
Dimension handling utilities for processing multi-dimensional images.
"""

import numpy as np
from typing import Iterator, Tuple


class DimensionHandler:
    """Utilities for iterating over image dimensions."""
    
    @staticmethod
    def iterate_slices(image: np.ndarray) -> Iterator[Tuple[int, int, int, np.ndarray]]:
        """
        Iterate over all 2D slices in a (T, Z, C, Y, X) image.
        
        Args:
            image: Image array in (T, Z, C, Y, X) format
            
        Yields:
            Tuple of (t, z, c, slice_2d)
        """
        T, Z, C, Y, X = image.shape
        
        for t in range(T):
            for z in range(Z):
                for c in range(C):
                    yield (t, z, c, image[t, z, c, :, :])
    
    @staticmethod
    def iterate_volumes(image: np.ndarray) -> Iterator[Tuple[int, int, np.ndarray]]:
        """
        Iterate over all 3D volumes in a (T, Z, C, Y, X) image.
        
        Args:
            image: Image array in (T, Z, C, Y, X) format
            
        Yields:
            Tuple of (t, c, volume_3d)
        """
        T, Z, C, Y, X = image.shape
        
        for t in range(T):
            for c in range(C):
                yield (t, c, image[t, :, c, :, :])
    
    @staticmethod
    def iterate_z_stacks(image: np.ndarray, t: int = 0, c: int = 0) -> Iterator[Tuple[int, np.ndarray]]:
        """
        Iterate over Z-slices for a specific timepoint and channel.
        
        Args:
            image: Image array in (T, Z, C, Y, X) format
            t: Time index
            c: Channel index
            
        Yields:
            Tuple of (z, slice_2d)
        """
        T, Z, C, Y, X = image.shape
        
        for z in range(Z):
            yield (z, image[t, z, c, :, :])
    
    @staticmethod
    def iterate_timepoints(image: np.ndarray, z: int = 0, c: int = 0) -> Iterator[Tuple[int, np.ndarray]]:
        """
        Iterate over timepoints for a specific Z-slice and channel.
        
        Args:
            image: Image array in (T, Z, C, Y, X) format
            z: Z-slice index
            c: Channel index
            
        Yields:
            Tuple of (t, slice_2d)
        """
        T, Z, C, Y, X = image.shape
        
        for t in range(T):
            yield (t, image[t, z, c, :, :])
    
    @staticmethod
    def get_z_projection(volume: np.ndarray, method: str = 'max') -> np.ndarray:
        """
        Create a Z-projection of a 3D volume.
        
        Args:
            volume: 3D array (Z, Y, X)
            method: Projection method ('max', 'mean', 'min')
            
        Returns:
            2D projection (Y, X)
        """
        if method == 'max':
            return np.max(volume, axis=0)
        elif method == 'mean':
            return np.mean(volume, axis=0)
        elif method == 'min':
            return np.min(volume, axis=0)
        else:
            raise ValueError(f"Unknown projection method: {method}")
    
    @staticmethod
    def get_time_projection(timeseries: np.ndarray, method: str = 'mean') -> np.ndarray:
        """
        Create a time projection from a time series.
        
        Args:
            timeseries: 4D array (T, Z, Y, X) or 3D array (T, Y, X)
            method: Projection method ('mean', 'max', 'std')
            
        Returns:
            Projection with time dimension collapsed
        """
        if method == 'mean':
            return np.mean(timeseries, axis=0)
        elif method == 'max':
            return np.max(timeseries, axis=0)
        elif method == 'std':
            return np.std(timeseries, axis=0)
        else:
            raise ValueError(f"Unknown projection method: {method}")
    
    @staticmethod
    def normalize_intensity(image: np.ndarray, 
                           percentile_low: float = 1.0, 
                           percentile_high: float = 99.0) -> np.ndarray:
        """
        Normalize image intensity using percentile clipping.
        
        Args:
            image: Input image
            percentile_low: Lower percentile for normalization
            percentile_high: Upper percentile for normalization
            
        Returns:
            Normalized image (float, 0-1 range)
        """
        p_low = np.percentile(image, percentile_low)
        p_high = np.percentile(image, percentile_high)
        
        if p_high - p_low == 0:
            return np.zeros_like(image, dtype=np.float32)
        
        normalized = (image.astype(np.float32) - p_low) / (p_high - p_low)
        normalized = np.clip(normalized, 0, 1)
        
        return normalized
    
    @staticmethod
    def estimate_foreground_mask(image: np.ndarray, method: str = 'otsu') -> np.ndarray:
        """
        Estimate foreground/background mask.
        
        Args:
            image: Input 2D image
            method: Thresholding method ('otsu', 'triangle', 'percentile')
            
        Returns:
            Binary mask (True = foreground)
        """
        from skimage.filters import threshold_otsu, threshold_triangle
        
        if method == 'otsu':
            try:
                threshold = threshold_otsu(image)
            except:
                threshold = np.mean(image)
        elif method == 'triangle':
            try:
                threshold = threshold_triangle(image)
            except:
                threshold = np.mean(image)
        elif method == 'percentile':
            threshold = np.percentile(image, 50)
        else:
            threshold = np.mean(image)
        
        return image > threshold
