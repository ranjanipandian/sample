"""
Configuration and threshold settings for QC metrics.
Provides sensible defaults with override capability.
"""

# QC Threshold Configuration
QC_THRESHOLDS = {
    # Signal Quality
    "snr_min_pass": 10.0,
    "snr_min_review": 5.0,
    "psnr_min_pass": 30.0,  # Informational only
    "cnr_min_pass": 3.0,
    
    # Blur/Focus
    "laplacian_variance_min": 100.0,
    "fft_high_freq_min": 0.15,
    
    # Noise
    "gaussian_noise_max_pass": 5.0,
    "gaussian_noise_max_review": 10.0,
    
    # Saturation/Clipping
    "overexposed_percent_max": 1.0,
    "underexposed_percent_max": 5.0,
    
    # Contrast
    "rms_contrast_min": 0.1,
    
    # Illumination
    "vignetting_score_max": 0.3,
    "uniformity_min": 0.7,
    
    # Artifacts
    "dead_pixel_percent_max": 0.1,
    "hot_pixel_percent_max": 0.1,
    
    # Dimensional (3D/4D)
    "defocused_slices_percent_max": 30.0,
    "z_consistency_min": 0.6,
    
    # Segmentability
    "separability_min": 0.5,
}

# Processing Configuration
PROCESSING_CONFIG = {
    "enable_parallel": False,  # Memory-efficient by default
    "chunk_size": 10,  # For streaming large 4D data
    "max_workers": 4,  # For parallel processing if enabled
    "enable_heavy_metrics": False,  # Disable expensive metrics by default
    "enable_glcm_texture": False,  # GLCM is slow for large images
    "enable_structure_estimation": False,  # Structure size estimation (slow)
}

# Visualization Configuration
VISUALIZATION_CONFIG = {
    "generate_by_default": False,
    "dpi": 150,
    "colormap": "viridis",
}

# Background estimation method
BACKGROUND_METHOD = "otsu"  # Options: "otsu", "triangle", "percentile"
BACKGROUND_PERCENTILE = 10  # Used if method is "percentile"

# Percentiles for intensity analysis
INTENSITY_PERCENTILES = [1, 5, 25, 50, 75, 95, 99]

# Artifact detection parameters
ARTIFACT_PARAMS = {
    "dead_pixel_threshold": 0,  # Pixels at this value are considered dead
    "hot_pixel_threshold_percentile": 99.9,
    "stripe_detection_sensitivity": 0.7,
}

def get_threshold(key):
    """Get a QC threshold value."""
    return QC_THRESHOLDS.get(key, None)

def update_threshold(key, value):
    """Update a QC threshold value."""
    QC_THRESHOLDS[key] = value

def get_config(key):
    """Get a processing configuration value."""
    return PROCESSING_CONFIG.get(key, None)

def update_config(key, value):
    """Update a processing configuration value."""
    PROCESSING_CONFIG[key] = value
