"""
Intelligent sampling strategies for large datasets.
"""

import numpy as np
from typing import List, Tuple, Dict


def generate_structured_sampling_indices(T: int, Z: int, C: int, 
                                         sample_rate: int = 10,
                                         force_full: bool = False) -> List[Tuple[int, int, int]]:
    """
    Generate structured sampling indices that ensure coverage of:
    - First, middle, and last Z-slices for each timepoint
    - Uniform subsampling of remaining slices
    
    This is scientifically safer than pure periodic sampling.
    
    Args:
        T: Number of timepoints
        Z: Number of Z-slices
        C: Number of channels
        sample_rate: Process every Nth slice (for uniform subsampling)
        force_full: If True, return all indices (no sampling)
        
    Returns:
        List of (t, z, c) tuples to process
    """
    total_slices = T * Z * C
    
    # If dataset is small or force_full, process everything
    if total_slices <= 1000 or force_full:
        indices = []
        for t in range(T):
            for z in range(Z):
                for c in range(C):
                    indices.append((t, z, c))
        return indices
    
    # Structured sampling for large datasets
    indices = []
    
    for t in range(T):
        for c in range(C):
            # Always include first, middle, last Z-slices
            critical_z = set()
            
            if Z > 0:
                critical_z.add(0)  # First
            if Z > 1:
                critical_z.add(Z // 2)  # Middle
            if Z > 2:
                critical_z.add(Z - 1)  # Last
            
            # Add critical slices
            for z in sorted(critical_z):
                indices.append((t, z, c))
            
            # Add uniform subsampling (skip already added critical slices)
            for z in range(0, Z, sample_rate):
                if z not in critical_z:
                    indices.append((t, z, c))
    
    return sorted(indices)


def get_sampling_info(T: int, Z: int, C: int, sample_rate: int = 10) -> Dict:
    """
    Get information about sampling strategy.
    
    Args:
        T: Number of timepoints
        Z: Number of Z-slices
        C: Number of channels
        sample_rate: Sampling rate
        
    Returns:
        Dictionary with sampling information
    """
    total_slices = T * Z * C
    sampled_indices = generate_structured_sampling_indices(T, Z, C, sample_rate, force_full=False)
    sampled_count = len(sampled_indices)
    
    return {
        'total_slices': total_slices,
        'sampled_slices': sampled_count,
        'sampling_enabled': sampled_count < total_slices,
        'sample_rate': sample_rate,
        'reduction_factor': total_slices / sampled_count if sampled_count > 0 else 1.0,
        'percentage_processed': 100.0 * sampled_count / total_slices if total_slices > 0 else 100.0
    }


def should_enable_sampling(T: int, Z: int, C: int, threshold: int = 1000) -> bool:
    """
    Determine if sampling should be automatically enabled.
    
    Args:
        T: Number of timepoints
        Z: Number of Z-slices
        C: Number of channels
        threshold: Slice count threshold for auto-sampling
        
    Returns:
        True if sampling should be enabled
    """
    return (T * Z * C) > threshold
