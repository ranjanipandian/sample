"""
Image loading module with support for TIFF and OME-TIFF formats.
Auto-detects image dimensions and normalizes to (T, Z, C, Y, X) format.
"""

import numpy as np
import tifffile
from pathlib import Path
from typing import Tuple, Dict, Optional


class ImageLoader:
    """Handles loading and dimension detection for microscopy images."""
    
    def __init__(self, image_path: str):
        """
        Initialize the image loader.
        
        Args:
            image_path: Path to the TIFF image file
        """
        self.image_path = Path(image_path)
        self.image_data = None
        self.metadata = {}
        self.original_shape = None
        self.normalized_shape = None
        self.dimension_order = None
        
        if not self.image_path.exists():
            raise FileNotFoundError(f"Image file not found: {image_path}")
        
        if self.image_path.suffix.lower() not in ['.tif', '.tiff']:
            raise ValueError(f"Unsupported file format: {self.image_path.suffix}")
    
    def load(self) -> np.ndarray:
        """
        Load the image and detect dimensions.
        
        Returns:
            Normalized image array in (T, Z, C, Y, X) format
        """
        # Load using tifffile (handles both regular TIFF and OME-TIFF)
        with tifffile.TiffFile(self.image_path) as tif:
            self.image_data = tif.asarray()
            self.original_shape = self.image_data.shape
            
            # Try to extract metadata from OME-TIFF
            if tif.is_ome:
                self._parse_ome_metadata(tif)
            else:
                # Fallback to shape-based detection
                self._detect_dimensions_from_shape()
            
            # Extract basic metadata
            self._extract_metadata(tif)
        
        # Normalize to (T, Z, C, Y, X) format
        self.image_data = self._normalize_dimensions(self.image_data)
        self.normalized_shape = self.image_data.shape
        
        return self.image_data
    
    def _parse_ome_metadata(self, tif):
        """Parse OME-TIFF metadata if available."""
        try:
            ome_metadata = tif.ome_metadata
            # Extract dimension order from OME-XML
            # This is a simplified parser - full OME-XML parsing can be complex
            if 'DimensionOrder' in str(ome_metadata):
                # Try to find dimension order in metadata
                self.dimension_order = "TZCYX"  # Common OME default
        except:
            # If OME parsing fails, fall back to shape detection
            self._detect_dimensions_from_shape()
    
    def _detect_dimensions_from_shape(self):
        """
        Detect dimensions from array shape.
        
        Logic:
        - 2D: (Y, X)
        - 3D: Could be (Z, Y, X) or (C, Y, X) - assume Z if shape[0] > 5, else C
        - 4D: (T, Z, Y, X) or (Z, C, Y, X)
        - 5D: (T, Z, C, Y, X)
        """
        ndim = len(self.original_shape)
        
        if ndim == 2:
            self.dimension_order = "YX"
        elif ndim == 3:
            # Heuristic: if first dimension is small (≤5), likely channels
            if self.original_shape[0] <= 5:
                self.dimension_order = "CYX"
            else:
                self.dimension_order = "ZYX"
        elif ndim == 4:
            # Assume (T, Z, Y, X) if both first dimensions are large
            # Otherwise (Z, C, Y, X) if first large and second small
            if self.original_shape[0] > 5 and self.original_shape[1] > 5:
                self.dimension_order = "TZYX"
            elif self.original_shape[1] <= 5:
                self.dimension_order = "ZCYX"
            else:
                self.dimension_order = "TZYX"
        elif ndim == 5:
            self.dimension_order = "TZCYX"
        else:
            raise ValueError(f"Unsupported number of dimensions: {ndim}")
    
    def _normalize_dimensions(self, image: np.ndarray) -> np.ndarray:
        """
        Normalize image to (T, Z, C, Y, X) format.
        
        Args:
            image: Input image array
            
        Returns:
            Normalized array
        """
        if self.dimension_order is None:
            self._detect_dimensions_from_shape()
        
        # Map current dimensions to target (T, Z, C, Y, X)
        normalized = image
        
        if self.dimension_order == "YX":
            # 2D: Add T, Z, C dimensions
            normalized = image[np.newaxis, np.newaxis, np.newaxis, :, :]
        
        elif self.dimension_order == "ZYX":
            # 3D Z-stack: Add T, C dimensions
            normalized = image[np.newaxis, :, np.newaxis, :, :]
        
        elif self.dimension_order == "CYX":
            # 3D with channels: Add T, Z dimensions
            normalized = image[np.newaxis, np.newaxis, :, :, :]
        
        elif self.dimension_order == "TZYX":
            # 4D time-lapse: Add C dimension
            normalized = image[:, :, np.newaxis, :, :]
        
        elif self.dimension_order == "ZCYX":
            # 4D with channels: Add T dimension
            normalized = image[np.newaxis, :, :, :, :]
        
        elif self.dimension_order == "TZCYX":
            # Already in correct format
            normalized = image
        
        else:
            raise ValueError(f"Unknown dimension order: {self.dimension_order}")
        
        return normalized
    
    def _extract_metadata(self, tif):
        """Extract metadata from TIFF file."""
        try:
            # Get dtype and bit depth
            self.metadata['dtype'] = str(self.image_data.dtype)
            
            if self.image_data.dtype == np.uint8:
                self.metadata['bit_depth'] = 8
            elif self.image_data.dtype == np.uint16:
                self.metadata['bit_depth'] = 16
            elif self.image_data.dtype == np.float32 or self.image_data.dtype == np.float64:
                self.metadata['bit_depth'] = 32
            else:
                self.metadata['bit_depth'] = 'unknown'
            
            # Try to get physical dimensions if available
            if hasattr(tif, 'imagej_metadata') and tif.imagej_metadata:
                ij_meta = tif.imagej_metadata
                self.metadata['imagej_metadata'] = ij_meta
            
            # Store original shape
            self.metadata['original_shape'] = self.original_shape
            self.metadata['dimension_order'] = self.dimension_order
            
        except Exception as e:
            print(f"Warning: Could not extract all metadata: {e}")
    
    def get_dimensions(self) -> Dict[str, int]:
        """
        Get image dimensions as a dictionary.
        
        Returns:
            Dictionary with T, Z, C, Y, X dimensions
        """
        if self.normalized_shape is None:
            raise ValueError("Image not loaded yet. Call load() first.")
        
        T, Z, C, Y, X = self.normalized_shape
        return {
            'T': T,
            'Z': Z,
            'C': C,
            'Y': Y,
            'X': X
        }
    
    def get_metadata(self) -> Dict:
        """Get image metadata."""
        return self.metadata.copy()
    
    def get_slice(self, t: int = 0, z: int = 0, c: int = 0) -> np.ndarray:
        """
        Get a specific 2D slice from the image.
        
        Args:
            t: Time index
            z: Z-slice index
            c: Channel index
            
        Returns:
            2D array (Y, X)
        """
        if self.image_data is None:
            raise ValueError("Image not loaded yet. Call load() first.")
        
        return self.image_data[t, z, c, :, :]
    
    def get_volume(self, t: int = 0, c: int = 0) -> np.ndarray:
        """
        Get a 3D volume at a specific timepoint and channel.
        
        Args:
            t: Time index
            c: Channel index
            
        Returns:
            3D array (Z, Y, X)
        """
        if self.image_data is None:
            raise ValueError("Image not loaded yet. Call load() first.")
        
        return self.image_data[t, :, c, :, :]
    
    def is_2d(self) -> bool:
        """Check if image is 2D (single Z-slice, single timepoint)."""
        dims = self.get_dimensions()
        return dims['T'] == 1 and dims['Z'] == 1
    
    def is_3d(self) -> bool:
        """Check if image is 3D (Z-stack, single timepoint)."""
        dims = self.get_dimensions()
        return dims['T'] == 1 and dims['Z'] > 1
    
    def is_4d(self) -> bool:
        """Check if image is 4D (time-lapse with Z-stack)."""
        dims = self.get_dimensions()
        return dims['T'] > 1 and dims['Z'] > 1
    
    def is_multichannel(self) -> bool:
        """Check if image has multiple channels."""
        dims = self.get_dimensions()
        return dims['C'] > 1


def load_image(image_path: str) -> Tuple[np.ndarray, Dict, ImageLoader]:
    """
    Convenience function to load an image.
    
    Args:
        image_path: Path to the image file
        
    Returns:
        Tuple of (normalized image array, metadata dict, loader object)
    """
    loader = ImageLoader(image_path)
    image_data = loader.load()
    metadata = loader.get_metadata()
    
    return image_data, metadata, loader
