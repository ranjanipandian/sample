import { CommonModule } from '@angular/common';
import { Component, HostListener } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

import { NotificationItem } from '@core/models/ticket.model';
import { AuthService } from '@core/services/auth.service';
import { ThemeService } from '@core/services/theme.service';
import { IntelService } from '@core/services/intel.service';
import { IntelligencePanelComponent } from '@features/intelligence/intelligence-panel/intelligence-panel.component';

const FALLBACK_DISPLAY_NAME = 'Support Engineer';
const FALLBACK_INITIALS = 'SE';

@Component({
  selector: 'app-settings-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, IntelligencePanelComponent],
  templateUrl: './settings-shell.component.html',
  styleUrls: ['./settings-shell.component.scss'],
})
export class SettingsShellComponent {
  notifOpen = false;
  profileOpen = false;
  sidebarOpen = true;

  notifications: NotificationItem[] = [
    {
      iconClass: 'ti ti-alert-triangle',
      iconBg: 'ni-r',
      title: 'P1 — CPU spike on prod-eu-02',
      sub: 'INC0042156 requires HITL intervention now',
      time: '2m ago',
      unread: true,
    },
    {
      iconClass: 'ti ti-clock',
      iconBg: 'ni-y',
      title: 'SLA breach warning — INC0042154',
      sub: 'Approaching SLA breach in 15 minutes',
      time: '10m ago',
      unread: true,
    },
    {
      iconClass: 'ti ti-circle-check',
      iconBg: 'ni-g',
      title: 'Auto-resolved — RITM0089234',
      sub: 'SSL cert renewed successfully by AI agent',
      time: '1h ago',
      unread: false,
    },
  ];

  constructor(
    public theme: ThemeService,
    public intel: IntelService,
    public auth: AuthService,
    private router: Router
  ) {}

  /** Display name for the top-bar avatar chip — falls back to a generic label
   *  when no identity is available (local dev without OIDC). */
  get displayName(): string {
    const u = this.auth.user;
    return u.name || u.email || FALLBACK_DISPLAY_NAME;
  }

  /** Two-character initials for the avatar circle. */
  get initials(): string {
    const u = this.auth.user;
    const source = u.name || u.email;
    if (!source) return FALLBACK_INITIALS;
    const parts = source.split(/[\s.@_-]+/).filter(Boolean);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return source.slice(0, 2).toUpperCase();
  }

  /** Subtitle under the name — email when available, role otherwise. */
  get displaySubtitle(): string {
    const u = this.auth.user;
    return u.authenticated && u.email ? u.email : FALLBACK_DISPLAY_NAME;
  }

  /** Role pill label — the logged-in user's role, or a generic fallback. */
  get roleLabel(): string {
    return this.auth.user.role || FALLBACK_DISPLAY_NAME;
  }

  get unreadCount(): number {
    return this.notifications.filter((n) => n.unread).length;
  }

  toggleSidebar(): void {
    this.sidebarOpen = !this.sidebarOpen;
  }

  toggleIntel(): void {
    this.intel.toggle();
  }

  toggleDark(): void {
    this.theme.toggle();
  }

  toggleNotif(event: MouseEvent): void {
    event.stopPropagation();
    this.profileOpen = false;
    this.notifOpen = !this.notifOpen;
  }

  toggleProfile(event: MouseEvent): void {
    event.stopPropagation();
    this.notifOpen = false;
    this.profileOpen = !this.profileOpen;
  }

  goDashboard(): void {
    this.profileOpen = false;
    this.router.navigateByUrl('/landscape');
  }


  openMySchedule(): void {
    this.profileOpen = false;
    this.router.navigateByUrl('/schedule/availability');
  }

  openScheduleApprovals(): void {
    this.profileOpen = false;
    this.router.navigateByUrl('/schedule/approvals');
  }

  openSettings(): void {
    this.profileOpen = false;
    this.router.navigateByUrl('/settings');
  }

  markAllRead(): void {
    this.notifications = this.notifications.map((n) => ({ ...n, unread: false }));
  }

  signOut(): void {
    // Revoke the identity-service session (POST /v1/auth/logout), clear the
    // in-memory token + stored refresh token, then redirect to /login.
    this.auth.logout();
  }

  closeDropdowns(): void {
    if (this.notifOpen) this.notifOpen = false;
    if (this.profileOpen) this.profileOpen = false;
  }

  @HostListener('document:click')
  onDocumentClick(): void {
    this.closeDropdowns();
  }
}
