import { CommonModule } from '@angular/common';
import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { Subscription } from 'rxjs';

import { PipelineStageRun, Stage, STAGES } from '@core/models/landscape.model';
import { NotificationItem } from '@core/models/ticket.model';
import { AuthService } from '@core/services/auth.service';
import { BatchJourneyService } from '@core/services/batch-journey.service';
import { IntelService } from '@core/services/intel.service';
import { ThemeService } from '@core/services/theme.service';
import { IntelligencePanelComponent } from '@features/intelligence/intelligence-panel/intelligence-panel.component';


const FALLBACK_DISPLAY_NAME = 'Support Engineer';
const FALLBACK_INITIALS = 'SE';

/** Per-stage sidebar icon — Tabler icon class keyed by stage id, so each of
 *  the 7 CMC Pipeline Stages nav items gets a distinct, meaningful glyph
 *  instead of a repeated generic one. */
const STAGE_ICONS: Record<string, string> = {
  'product-process-design': 'ti ti-flask-2',
  'drug-substance-mfg': 'ti ti-building-factory-2',
  'drug-product-mfg': 'ti ti-vaccine',
  'packaging-labelling': 'ti ti-box-seam',
  'logistics-distribution': 'ti ti-truck-delivery',
  'dispensing-clinical-interface': 'ti ti-stethoscope',
  'tech-transfer-mfg': 'ti ti-transfer',
};

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, IntelligencePanelComponent],
  templateUrl: './app-shell.component.html',
  styleUrls: ['./app-shell.component.scss'],
})
export class AppShellComponent implements OnInit, OnDestroy {
  notifOpen = false;
  profileOpen = false;
  sidebarOpen = true;

  /** The 7 CMC Pipeline Stages, in pipeline order — rendered as the
   *  "CMC Pipeline Stages" vertical stepper in the sidebar (status dot,
   *  date-range subtext, connecting line), each still routing to the same
   *  /landscape/stage/:id detail page as the Landscape Home "Configure"
   *  button and stage stepper. */
  readonly stages: Stage[] = STAGES;

  private journeySub?: Subscription;


  notifications: NotificationItem[] = [
    {
      iconClass: 'ti ti-alert-triangle',
      iconBg: 'ni-r',
      title: 'P1 — CPU spike on prod-eu-02',
      sub: 'INC0042156 requires HITL intervention now',
      time: '2m ago',
      unread: true,
    },
    {
      iconClass: 'ti ti-clock',
      iconBg: 'ni-y',
      title: 'SLA breach warning — INC0042154',
      sub: 'Approaching SLA breach in 15 minutes',
      time: '10m ago',
      unread: true,
    },
    {
      iconClass: 'ti ti-circle-check',
      iconBg: 'ni-g',
      title: 'Auto-resolved — RITM0089234',
      sub: 'SSL cert renewed successfully by AI agent',
      time: '1h ago',
      unread: false,
    },
    {
      iconClass: 'ti ti-topology-star',
      iconBg: 'ni-b',
      title: 'ServiceNow connector synced',
      sub: '42 new tickets imported successfully',
      time: '2h ago',
      unread: false,
    },
    {
      iconClass: 'ti ti-user-check',
      iconBg: 'ni-y',
      title: 'HITL approval needed — PRB0003421',
      sub: 'Agent awaiting approval for DB restart',
      time: '3h ago',
      unread: true,
    },
  ];

  constructor(
    public theme: ThemeService,
    public intel: IntelService,
    public auth: AuthService,
    private router: Router,
    private batchJourney: BatchJourneyService
  ) {}

  ngOnInit(): void {
    // Re-render the stepper whenever the journey changes (e.g. after an
    // "Upload Batch Data" action on the Memory Graph page advances a stage).
    this.journeySub = this.batchJourney.journey$.subscribe();
  }

  ngOnDestroy(): void {
    this.journeySub?.unsubscribe();
  }

  /** The batch-journey run for a given stage — drives the sidebar
   *  stepper's dot state (complete/current/upcoming) and date subtext. */
  stageRun(stage: Stage): PipelineStageRun | undefined {
    return this.batchJourney.getStageRun(stage.id);
  }

  stepDotClass(stage: Stage): string {
    const run = this.stageRun(stage);
    if (!run) return 'step-dot step-dot--upcoming';
    return 'step-dot step-dot--' + run.status;
  }

  stepLineClass(stage: Stage): string {
    const run = this.stageRun(stage);
    if (run && run.status === 'complete') return 'step-line step-line--complete';
    return 'step-line';
  }

  stepDateLabel(stage: Stage): string {
    return this.stageRun(stage)?.dateRange ?? 'Not yet started';
  }


  /** Display name for the top-bar avatar chip — falls back to a generic
   *  label when no ALB-OIDC identity is available (local dev). */
  get displayName(): string {
    const u = this.auth.user;
    return u.name || u.email || FALLBACK_DISPLAY_NAME;
  }

  /** Two-character initials for the avatar circle. */
  get initials(): string {
    const u = this.auth.user;
    const source = u.name || u.email;
    if (!source) return FALLBACK_INITIALS;
    const parts = source.split(/[\s.@_-]+/).filter(Boolean);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return source.slice(0, 2).toUpperCase();
  }

  /** Subtitle under the name on the profile button — always the user's role.
   *  (The dropdown panel still shows the email via its own binding.) */
  get displaySubtitle(): string {
    return 'Support Engineer';
  }

  get unreadCount(): number {
    return this.notifications.filter((n) => n.unread).length;
  }

  /** Icon class for a given pipeline stage's sidebar nav item. */
  stageIcon(stage: Stage): string {
    return STAGE_ICONS[stage.id] ?? 'ti ti-circle-dot';
  }

  toggleSidebar(): void {
    this.sidebarOpen = !this.sidebarOpen;
  }

  toggleIntel(): void {
    this.intel.toggle();
  }

  toggleDark(): void {
    this.theme.toggle();
  }

  toggleNotif(event: MouseEvent): void {
    event.stopPropagation();
    this.profileOpen = false;
    this.notifOpen = !this.notifOpen;
  }

  toggleProfile(event: MouseEvent): void {
    event.stopPropagation();
    this.notifOpen = false;
    this.profileOpen = !this.profileOpen;
  }

  /** True on the My Schedule pages — they live under this shell but have no
   *  Dashboard tile in the sidebar, so we surface a Home button up top. */
  get isScheduleRoute(): boolean {
    return this.router.url.startsWith('/schedule');
  }

  goHome(): void {
    this.router.navigateByUrl('/landscape');
  }

  openMySchedule(): void {
    this.profileOpen = false;
    this.router.navigateByUrl('/schedule/availability');
  }

  openTeamSchedule(): void {
    this.profileOpen = false;
    this.router.navigateByUrl('/schedule/team');
  }

  openScheduleApprovals(): void {
    this.profileOpen = false;
    this.router.navigateByUrl('/schedule/approvals');
  }

  openSettings(): void {
    this.profileOpen = false;
    this.router.navigateByUrl('/settings');
  }

  markAllRead(): void {
    this.notifications = this.notifications.map((n) => ({ ...n, unread: false }));
  }

  signOut(): void {
    // Revoke the identity-service session (POST /v1/auth/logout), clear the
    // in-memory token + stored refresh token, then redirect to /login.
    this.auth.logout();
  }

  closeDropdowns(): void {
    if (this.notifOpen) this.notifOpen = false;
    if (this.profileOpen) this.profileOpen = false;
  }

  @HostListener('document:click')
  onDocumentClick(): void {
    this.closeDropdowns();
  }
}
