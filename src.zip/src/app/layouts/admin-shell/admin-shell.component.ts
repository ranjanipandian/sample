import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

import { AuthService } from '@core/services/auth.service';
import { IntelService } from '@core/services/intel.service';
import { ThemeService } from '@core/services/theme.service';
import { IntelligencePanelComponent } from '@features/intelligence/intelligence-panel/intelligence-panel.component';

const FALLBACK_DISPLAY_NAME = 'Admin User';
const FALLBACK_INITIALS = 'A';
const FALLBACK_ROLE = 'System Administrator';

@Component({
  selector: 'app-admin-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, IntelligencePanelComponent],
  templateUrl: './admin-shell.component.html',
  styleUrls: ['./admin-shell.component.scss'],
})
export class AdminShellComponent {
  sidebarOpen = true;

  constructor(
    public theme: ThemeService,
    public intel: IntelService,
    public auth: AuthService,
    private router: Router
  ) {}

  get displayName(): string {
    const u = this.auth.user;
    return u.name || u.email || FALLBACK_DISPLAY_NAME;
  }

  get initials(): string {
    const u = this.auth.user;
    const source = u.name || u.email;
    if (!source) return FALLBACK_INITIALS;
    const parts = source.split(/[\s.@_-]+/).filter(Boolean);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return source.slice(0, 2).toUpperCase();
  }

  get displaySubtitle(): string {
    const u = this.auth.user;
    return u.authenticated && u.email ? u.email : FALLBACK_ROLE;
  }

  toggleSidebar(): void {
    this.sidebarOpen = !this.sidebarOpen;
  }

  toggleIntel(): void {
    this.intel.toggle();
  }

  toggleDark(): void {
    this.theme.toggle();
  }

  signOut(): void {
    // Same shape as AppShellComponent.signOut() — full session teardown
    // lives at nginx /logout but isn't wired to this button; rely on the
    // 8h ALB session timeout to prompt re-auth via Cognito.
    this.router.navigateByUrl('/login');
  }
}
