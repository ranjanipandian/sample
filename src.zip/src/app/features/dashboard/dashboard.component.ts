import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { BatchJourneyService } from '@core/services/batch-journey.service';

import {
  AgentOpportunity,
  AI_AGENT_OPPORTUNITIES,
  getStageSystemCounts,
  Stage,
  StageSystemCounts,
  STAGES,
} from '@core/models/landscape.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent {
  readonly stages: Stage[] = STAGES;
  readonly agentOpportunities: AgentOpportunity[] = AI_AGENT_OPPORTUNITIES;

  constructor(
    private router: Router,
    private batchJourney: BatchJourneyService
  ) {}

  counts(stage: Stage): StageSystemCounts {
    return getStageSystemCounts(stage);
  }

  statusLabel(stage: Stage): string {
    return this.batchJourney.getStageStatusLabel(stage.id);
  }

  statusPillClass(stage: Stage): string {
    const label = this.statusLabel(stage);
    if (label === 'Active') return 'stage-pill stage-pill--active';
    if (label === 'In Progress') return 'stage-pill stage-pill--progress';
    return 'stage-pill stage-pill--upcoming';
  }

  dateRange(stage: Stage): string | null {
    return this.batchJourney.getStageRun(stage.id)?.dateRange ?? null;
  }


  agentStatusPillClass(status: string): string {
    if (status === 'Active') return 'agent-pill agent-pill--active';
    if (status === 'In Progress') return 'agent-pill agent-pill--progress';
    return 'agent-pill agent-pill--upcoming';
  }

  stageName(stageId: string): string {
    return this.stages.find((s) => s.id === stageId)?.name ?? stageId;
  }

  configureStage(stage: Stage): void {
    this.router.navigateByUrl('/landscape/stage/' + stage.id);
  }
}


