import { Routes } from '@angular/router';

export const WHITEPAPER_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./whitepaper-home/whitepaper-home.component').then(
        (m) => m.WhitepaperHomeComponent
      ),
  },
];
