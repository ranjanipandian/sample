import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


import {
  ATTRIBUTION_CHAIN,
  AttributionNode,
  CONFIDENTIALITY_LAYERS,
  CONFIDENTIALITY_SPECIAL_CASES,
  ConfidentialityLayer,
  DELIVERY_REALITIES,
  LEDGER_PROPERTIES,
  MEDALLION_LAYERS,
  MedallionLayer,
  MedallionLayerId,
  SAMPLE_QUERIES,
  SampleQuery,
  STRATEGIC_IMPLICATIONS,
} from '@core/models/whitepaper.model';

import {
  ARCHITECTURE_CORE_SHIFT,

  ARCHITECTURE_PRINCIPLE,
  CAPABILITY_COMPARISON,
  CAPABILITY_COMPARISON_TAKEAWAY,
  EXTRACTION_IMPLEMENTATION_RULE,
  EXTRACTION_JSON_EXAMPLE,
  EXTRACTION_PASSES,
  EXTRACTION_TARGETS,
  FAILURE_INTELLIGENCE_TRIPLE_EXAMPLE,
  FINAL_RECOMMENDATION_CLOSING,
  FINAL_RECOMMENDATION_POINTS,
  FINAL_RECOMMENDATION_TITLE,
  getMviCoverageSummary,
  INGESTION_AGENTS,
  LAYER_RULES,
  LAYERED_ARCHITECTURE,
  LLM_EXTRACTION_ROLE_NOTE,
  MEMORY_POISONING_SOURCE_NOTE,
  MVI_STEPS,
  ONTOLOGY_CLASSES,
  ONTOLOGY_RELATIONSHIPS,
  QUALIFIED_INFLUENCE_NOTE,
  REASONING_GAP_DEFINITION,
  REASONING_GAP_TRIPLE_EXAMPLE,
  REASONING_GAP_TYPES,
  REASONING_MODES,
  REFERENCE_STACK,
  REFERENCE_STACK_NOTE,
  WORKFLOW_B_PURPOSE,
  WORKFLOW_B_CAPABILITIES,
  WORKFLOW_B_FLAGSHIP_NOTE,
  DOCUMENT_SEARCH_VS_MEMORY_GRAPH,
  DOCUMENT_SEARCH_VS_MEMORY_GRAPH_NOTE,
  WORKFLOW_C_NOTE,
  WRITE_BACK_STATES,
  WRITE_BACK_TRIPLE_BREAKDOWN,
  WRITE_BACK_NOTIFICATION_HEADLINE,
  WRITE_BACK_PROVENANCE_EXAMPLE,
  WRITE_BACK_PROVENANCE_RULE,
  WRITE_BACK_FILTER_NOTE,
  TACIT_CAPTURE_MECHANISMS,
  TACIT_CAPTURE_WARNING,
} from '@core/models/memory-graph-blueprint.model';




type SectionId =
  | 'architecture'
  | 'confidentiality'
  | 'strategy'
  | 'attribution'
  | 'workflows'
  | 'reference';



@Component({
  selector: 'app-whitepaper-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './whitepaper-home.component.html',
  styleUrls: ['./whitepaper-home.component.scss'],
})
export class WhitepaperHomeComponent implements OnInit {

  readonly sections: { id: SectionId; label: string; icon: string }[] = [
    { id: 'architecture', label: 'Semantic Architecture', icon: 'ti ti-stack-2' },
    { id: 'workflows', label: 'Agent Workflows', icon: 'ti ti-git-branch' },
    { id: 'confidentiality', label: 'Confidentiality & Governance', icon: 'ti ti-shield-lock' },
    { id: 'strategy', label: 'Strategic Value', icon: 'ti ti-bulb' },
    { id: 'attribution', label: 'Attribution & ROI', icon: 'ti ti-git-commit' },
    { id: 'reference', label: 'Reference & Roadmap', icon: 'ti ti-map-2' },
  ];



  activeSection: SectionId = 'architecture';

  /** Collapsible "Implementation Detail" block under Semantic Architecture. */
  showExtractionDetail = false;


  readonly medallionLayers: MedallionLayer[] = MEDALLION_LAYERS;
  activeLayerId: MedallionLayerId = 'bronze';

  readonly sampleQueries: SampleQuery[] = SAMPLE_QUERIES;
  activeQueryId: string = SAMPLE_QUERIES[0].id;

  readonly confidentialityLayers: ConfidentialityLayer[] = CONFIDENTIALITY_LAYERS;
  readonly specialCases = CONFIDENTIALITY_SPECIAL_CASES;

  readonly strategicImplications = STRATEGIC_IMPLICATIONS;
  readonly deliveryRealities = DELIVERY_REALITIES;

  readonly attributionChain: AttributionNode[] = ATTRIBUTION_CHAIN;
  readonly ledgerProperties = LEDGER_PROPERTIES;

  // ── §1/§2 Extraction Pipeline (memory-graph-blueprint.model.ts) ──────
  readonly layeredArchitecture = LAYERED_ARCHITECTURE;
  readonly architecturePrinciple = ARCHITECTURE_PRINCIPLE;
  readonly architectureCoreShift = ARCHITECTURE_CORE_SHIFT;
  readonly layerRules = LAYER_RULES;
  readonly extractionTargets = EXTRACTION_TARGETS;
  readonly extractionPasses = EXTRACTION_PASSES;
  readonly extractionJsonExample = EXTRACTION_JSON_EXAMPLE;
  readonly extractionImplementationRule = EXTRACTION_IMPLEMENTATION_RULE;
  readonly ontologyClasses = ONTOLOGY_CLASSES;
  readonly ontologyRelationships = ONTOLOGY_RELATIONSHIPS;
  readonly reasoningGapTypes = REASONING_GAP_TYPES;
  readonly reasoningGapDefinition = REASONING_GAP_DEFINITION;
  readonly reasoningGapTripleExample = REASONING_GAP_TRIPLE_EXAMPLE;
  readonly failureIntelligenceTripleExample = FAILURE_INTELLIGENCE_TRIPLE_EXAMPLE;
  readonly llmExtractionRoleNote = LLM_EXTRACTION_ROLE_NOTE;
  readonly qualifiedInfluenceNote = QUALIFIED_INFLUENCE_NOTE;

  // ── §3 Agent Workflows ─────────────────────────────────────────────
  readonly ingestionAgents = INGESTION_AGENTS;

  readonly reasoningModes = REASONING_MODES;
  readonly workflowBPurpose = WORKFLOW_B_PURPOSE;
  readonly workflowBCapabilities = WORKFLOW_B_CAPABILITIES;
  readonly workflowBFlagshipNote = WORKFLOW_B_FLAGSHIP_NOTE;
  readonly docSearchVsMemoryGraph = DOCUMENT_SEARCH_VS_MEMORY_GRAPH;
  readonly docSearchVsMemoryGraphNote = DOCUMENT_SEARCH_VS_MEMORY_GRAPH_NOTE;
  readonly writeBackStates = WRITE_BACK_STATES;

  readonly workflowCNote = WORKFLOW_C_NOTE;
  readonly memoryPoisoningSourceNote = MEMORY_POISONING_SOURCE_NOTE;
  readonly writeBackTripleBreakdown = WRITE_BACK_TRIPLE_BREAKDOWN;
  readonly writeBackNotificationHeadline = WRITE_BACK_NOTIFICATION_HEADLINE;
  readonly writeBackProvenanceExample = WRITE_BACK_PROVENANCE_EXAMPLE;
  readonly writeBackProvenanceRule = WRITE_BACK_PROVENANCE_RULE;
  readonly writeBackFilterNote = WRITE_BACK_FILTER_NOTE;
  readonly tacitCaptureMechanisms = TACIT_CAPTURE_MECHANISMS;
  readonly tacitCaptureWarning = TACIT_CAPTURE_WARNING;
  showWriteBackNotification = false;



  // ── §6/§7 Reference & Roadmap ──────────────────────────────────────
  readonly referenceStack = REFERENCE_STACK;
  readonly referenceStackNote = REFERENCE_STACK_NOTE;
  readonly mviSteps = MVI_STEPS;
  readonly mviCoverage = getMviCoverageSummary();
  readonly capabilityComparison = CAPABILITY_COMPARISON;
  readonly capabilityComparisonTakeaway = CAPABILITY_COMPARISON_TAKEAWAY;
  readonly finalRecommendationTitle = FINAL_RECOMMENDATION_TITLE;
  readonly finalRecommendationPoints = FINAL_RECOMMENDATION_POINTS;
  readonly finalRecommendationClosing = FINAL_RECOMMENDATION_CLOSING;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
  ) {}

  ngOnInit(): void {
    const requested = this.route.snapshot.queryParamMap.get('section') as SectionId | null;
    if (requested && this.sections.some((s) => s.id === requested)) {
      this.activeSection = requested;
    }
  }

  setSection(id: SectionId): void {

    this.activeSection = id;
  }

  setLayer(id: MedallionLayerId): void {
    this.activeLayerId = id;
  }

  toggleExtractionDetail(): void {
    this.showExtractionDetail = !this.showExtractionDetail;
  }


  get activeLayer(): MedallionLayer | undefined {
    return this.medallionLayers.find((l) => l.id === this.activeLayerId);
  }

  setQuery(id: string): void {
    this.activeQueryId = id;
  }

  get activeQuery(): SampleQuery | undefined {
    return this.sampleQueries.find((q) => q.id === this.activeQueryId);
  }

  capabilityBadgeClass(capability: string): string {
    switch (capability) {
      case 'retrieval':
        return 'cap-badge cap-badge--retrieval';
      case 'reasoning':
        return 'cap-badge cap-badge--reasoning';
      default:
        return 'cap-badge cap-badge--writeback';
    }
  }

  writeBackStateClass(state: string): string {
    switch (state) {
      case 'accepted':
        return 'wb-state wb-state--accepted';
      case 'quarantined':
        return 'wb-state wb-state--quarantined';
      default:
        return 'wb-state wb-state--pending';
    }
  }

  writeBackLifecycleClass(id: string): string {
    return 'wb-life wb-life--' + id;
  }

  toggleWriteBackNotification(): void {
    this.showWriteBackNotification = !this.showWriteBackNotification;
  }


  back(): void {

    this.router.navigateByUrl('/landscape');
  }

  goToIngestionDemo(): void {
    this.router.navigateByUrl('/landscape/memory-graph/ingestion');
  }

}


