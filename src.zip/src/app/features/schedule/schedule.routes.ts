import { Routes } from '@angular/router';

import { supervisorGuard } from '@core/guards/supervisor.guard';

/**
 * Schedule-management routes (mounted under the authenticated app-shell).
 *   /schedule/availability  every engineer's own weekly availability editor
 *   /schedule/team           supervisor-only team weekly operating schedule
 *   /schedule/approvals      supervisor-only approval queue
 */
export const SCHEDULE_ROUTES: Routes = [
  { path: '', redirectTo: 'availability', pathMatch: 'full' },
  {
    path: 'availability',
    loadComponent: () =>
      import('./engineer-availability/engineer-availability.component').then(
        (m) => m.EngineerAvailabilityComponent
      ),
  },
  {
    path: 'team',
    canActivate: [supervisorGuard],
    loadComponent: () =>
      import('./team-schedule/team-schedule.component').then((m) => m.TeamScheduleComponent),
  },
  {
    path: 'approvals',
    canActivate: [supervisorGuard],
    loadComponent: () =>
      import('./supervisor-approval/supervisor-approval.component').then(
        (m) => m.SupervisorApprovalComponent
      ),
  },
];
