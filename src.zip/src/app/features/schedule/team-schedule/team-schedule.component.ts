import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

import { ScheduleService } from '../services/schedule.service';
import {
  DayStatusType,
  GridResponse,
  RosterGroupSummary,
  ShiftDefinition,
} from '../models/schedule.model';

/** A single day column header. */
interface DayCol {
  iso: string; // YYYY-MM-DD
  label: string; // "Mon"
  dayNum: string; // "09 Jun"
  weekend: boolean;
}

/** Provenance bucket used to flag default vs engineer-changed cells. */
type CellKind = 'default' | 'changed' | 'manual';

/** A rendered grid cell for one resource on one day. */
interface RenderCell {
  code: string; // shift/status code shown in the cell
  title: string; // hover tooltip
  color: string | null; // background colour
  onsite: boolean;
  onCall: boolean;
  kind: CellKind; // how the cell was set (drives the deviation marker)
  empty: boolean;
}

interface RenderRow {
  name: string;
  cells: RenderCell[];
}

/**
 * Supervisor-only weekly operating schedule for the whole team. Renders the
 * committed roster grid (GET /shift-roster/grid) and can materialise the
 * default-shift roster for the displayed week with one click.
 */
@Component({
  selector: 'app-team-schedule',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './team-schedule.component.html',
  styleUrls: ['./team-schedule.component.scss'],
})
export class TeamScheduleComponent implements OnInit {
  loading = false;
  applying = false;
  error: string | null = null;
  notice: string | null = null;
  /** Supervisor owns no active triage config / roster group — nothing to show. */
  noTeamGroups = false;

  /** Every roster group the supervisor owns; drives the group selector. */
  groups: RosterGroupSummary[] = [];
  groupId: string | null = null;
  groupName = '';
  weekStart!: Date;

  cols: DayCol[] = [];
  rows: RenderRow[] = [];
  shifts: ShiftDefinition[] = [];
  statuses: DayStatusType[] = [];

  constructor(private schedule: ScheduleService) {}

  ngOnInit(): void {
    this.weekStart = mondayOf(new Date());
    this.loading = true;
    // The groups the supervisor owns (via their triage config) define the teams
    // they can view — not just the single group their own roster row sits in.
    // This matches how incident management scopes a supervisor's team.
    this.schedule.supervisorGroups().subscribe({
      next: (groups) => {
        this.groups = groups;
        if (!groups.length) {
          this.loading = false;
          this.noTeamGroups = true;
          return;
        }
        this.groupId = groups[0].group_id;
        this.loadGrid();
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.error = describe(
          err,
          'Could not reach the scheduler service to resolve your roster groups.'
        );
      },
    });
  }

  /** Switch the displayed team when the supervisor picks another group. */
  onGroupChange(groupId: string): void {
    if (!groupId || groupId === this.groupId) return;
    this.groupId = groupId;
    this.loadGrid();
  }

  // ── Week state ─────────────────────────────────────────────────────────────

  get weekStartIso(): string {
    return toIso(this.weekStart);
  }

  get weekEndIso(): string {
    return toIso(addDays(this.weekStart, 6));
  }

  loadGrid(): void {
    if (!this.groupId) return;
    this.loading = true;
    this.error = null;
    this.notice = null;
    this.schedule.getTeamGrid(this.groupId, this.weekStartIso, this.weekEndIso).subscribe({
      next: (grid) => {
        this.render(grid);
        this.loading = false;
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.error = describe(err, 'Could not load the team schedule.');
      },
    });
  }

  prevWeek(): void {
    this.weekStart = addDays(this.weekStart, -7);
    this.loadGrid();
  }

  nextWeek(): void {
    this.weekStart = addDays(this.weekStart, 7);
    this.loadGrid();
  }

  thisWeek(): void {
    this.weekStart = mondayOf(new Date());
    this.loadGrid();
  }

  applyDefault(): void {
    if (!this.groupId || this.applying) return;
    this.applying = true;
    this.error = null;
    this.notice = null;
    this.schedule.applyDefaultWeek(this.groupId, this.weekStartIso).subscribe({
      next: (res) => {
        this.applying = false;
        this.notice =
          res.created > 0
            ? `Default roster applied — ${res.created} shift${res.created === 1 ? '' : 's'} added (${res.skipped} day${res.skipped === 1 ? '' : 's'} already set).`
            : 'Nothing to fill — every weekday already has a shift or entry.';
        this.loadGrid();
      },
      error: (err: HttpErrorResponse) => {
        this.applying = false;
        this.error = describe(err, 'Could not apply the default roster.');
      },
    });
  }

  // ── Rendering ──────────────────────────────────────────────────────────────

  private render(grid: GridResponse): void {
    this.groupName = grid.group_name;
    this.shifts = grid.shifts;
    this.statuses = grid.statuses;

    this.cols = Array.from({ length: 7 }, (_, i) => {
      const d = addDays(this.weekStart, i);
      return {
        iso: toIso(d),
        label: WEEKDAYS[i],
        dayNum: `${pad(d.getDate())} ${MONTHS[d.getMonth()]}`,
        weekend: i >= 5,
      };
    });

    const shiftById = new Map(grid.shifts.map((s) => [s.shift_id, s]));
    const statusById = new Map(grid.statuses.map((s) => [s.status_id, s]));

    this.rows = grid.resources.map((r) => {
      const byDate = new Map(r.cells.map((c) => [c.work_date, c]));
      return {
        name: r.full_name,
        cells: this.cols.map((col) => {
          const c = byDate.get(col.iso);
          if (!c) {
            return {
              code: '',
              title: '',
              color: null,
              onsite: false,
              onCall: false,
              kind: 'manual' as CellKind,
              empty: true,
            };
          }
          // A leave/holiday status wins the cell's identity; otherwise the shift.
          const status = c.status_id ? statusById.get(c.status_id) : undefined;
          const shift = c.shift_id ? shiftById.get(c.shift_id) : undefined;
          const code = status?.code ?? c.status_code ?? shift?.code ?? c.shift_code ?? '—';
          const color = status?.color_hex ?? shift?.color_hex ?? null;
          const label = status?.label ?? shift?.label ?? '';
          const kind = cellKind(c.source);
          return {
            code,
            title: `${label ? `${code} — ${label}` : code} · ${KIND_LABEL[kind]}`,
            color,
            onsite: c.onsite,
            onCall: c.on_call,
            kind,
            empty: false,
          };
        }),
      };
    });
  }

  /** Readable text colour for a cell given its background. */
  textOn(bg: string | null): string {
    if (!bg) return 'inherit';
    const hex = bg.replace('#', '');
    if (hex.length !== 6) return 'inherit';
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    // Perceived luminance — dark text on light backgrounds, white on dark.
    const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return lum > 0.6 ? '#1f2937' : '#ffffff';
  }
}

// ── Date / error utilities ─────────────────────────────────────────────────────

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const KIND_LABEL: Record<CellKind, string> = {
  default: 'Default roster',
  changed: 'Engineer change (approved)',
  manual: 'Manual edit',
};

/**
 * Bucket an assignment's source for display: the seeded default roster, an
 * engineer's approved self-service change, or any manual/other edit.
 */
function cellKind(source: string | null): CellKind {
  if (source === 'DEFAULT') return 'default';
  if (source === 'SELF_SERVICE') return 'changed';
  return 'manual';
}

function pad(n: number): string {
  return n < 10 ? `0${n}` : `${n}`;
}

/** Monday of the week containing `d`, at local midnight. */
function mondayOf(d: Date): Date {
  const out = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const dow = (out.getDay() + 6) % 7; // Mon=0 … Sun=6
  out.setDate(out.getDate() - dow);
  return out;
}

function addDays(d: Date, days: number): Date {
  const out = new Date(d);
  out.setDate(out.getDate() + days);
  return out;
}

function toIso(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function describe(err: HttpErrorResponse, fallback: string): string {
  const d = err?.error?.detail;
  if (d) {
    if (typeof d === 'object' && !Array.isArray(d) && d.error) {
      return `${fallback} (${d.error})`;
    }
    if (Array.isArray(d) && d.length) {
      const f = d[0];
      const where = Array.isArray(f?.loc) ? f.loc.slice(1).join('.') : '';
      const msg = f?.msg || f?.type || 'validation error';
      return `${fallback} (${where ? where + ': ' : ''}${msg})`;
    }
    if (typeof d === 'string') return `${fallback} (${d})`;
  }
  if (err?.status === 0) return `${fallback} (scheduler unreachable)`;
  if (err?.status) return `${fallback} (HTTP ${err.status})`;
  return fallback;
}
