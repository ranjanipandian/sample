import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

import { ScheduleService } from '../services/schedule.service';
import {
  AvailabilityRequest,
  DayStatusType,
  PendingRequestSummary,
  RosterGroupSummary,
  ShiftDefinition,
} from '../models/schedule.model';

interface DayReview {
  iso: string;
  label: string;
  shiftCode: string;
  statusCode: string;
  onsite: boolean;
  onCall: boolean;
  onCallShiftCode: string; // on-call window code (OC1/OC2), '' when none
  notes: string | null;
  decision: 'APPROVED' | 'REJECTED';
  comment: string;
}

@Component({
  selector: 'app-supervisor-approval',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './supervisor-approval.component.html',
  styleUrls: ['./supervisor-approval.component.scss'],
})
export class SupervisorApprovalComponent implements OnInit {
  loading = false;
  submitting = false;
  error: string | null = null;
  notice: string | null = null;
  /** Supervisor owns no active triage config / roster group — nothing to triage. */
  noTeamGroups = false;

  /** Every roster group the supervisor owns; drives the group selector. */
  groups: RosterGroupSummary[] = [];
  groupId: string | null = null;
  queue: PendingRequestSummary[] = [];

  /** Currently expanded request under review. */
  selected: AvailabilityRequest | null = null;
  selectedEngineer: PendingRequestSummary | null = null;
  dayReviews: DayReview[] = [];
  reviewComment = '';

  private shiftById = new Map<string, ShiftDefinition>();
  private statusById = new Map<string, DayStatusType>();

  constructor(private schedule: ScheduleService) {}

  ngOnInit(): void {
    this.loading = true;
    // The groups the supervisor owns (via their triage config) define the teams
    // they can triage — not just the single group their own roster row sits in.
    this.schedule.supervisorGroups().subscribe({
      next: (groups) => {
        this.groups = groups;
        if (!groups.length) {
          this.loading = false;
          this.noTeamGroups = true;
          return;
        }
        this.groupId = groups[0].group_id;
        this.loadQueue();
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.error = describe(
          err,
          'Could not reach the scheduler service to resolve your roster groups.'
        );
      },
    });
  }

  /** Switch the triage queue when the supervisor picks another group. */
  onGroupChange(groupId: string): void {
    if (!groupId || groupId === this.groupId) return;
    this.groupId = groupId;
    this.close();
    this.notice = null;
    this.loadQueue();
  }

  loadQueue(): void {
    if (!this.groupId) return;
    this.loading = true;
    this.error = null;
    this.schedule.pendingQueue(this.groupId).subscribe({
      next: (q) => {
        this.queue = q.requests;
        this.loading = false;
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.error = describe(err, 'Could not load the approval queue.');
      },
    });
  }

  open(summary: PendingRequestSummary): void {
    if (this.selected?.request_id === summary.request_id) {
      this.close();
      return;
    }
    this.error = null;
    this.notice = null;
    this.selectedEngineer = summary;
    this.schedule.getRequest(summary.request_id).subscribe({
      next: (req) => {
        this.selected = req;
        this.reviewComment = '';
        // The detail endpoint doesn't carry the vocab, so we fetch the
        // engineer's week to resolve shift/status codes for display.
        this.schedule.getMyWeek(req.resource_id, req.week_start_date).subscribe({
          next: (wk) => {
            this.shiftById = new Map(wk.shifts.map((s) => [s.shift_id, s]));
            this.statusById = new Map(wk.statuses.map((s) => [s.status_id, s]));
            this.buildDayReviews(req);
          },
          error: () => {
            // Fall back to ids-as-codes if vocab can't be loaded.
            this.shiftById = new Map();
            this.statusById = new Map();
            this.buildDayReviews(req);
          },
        });
      },
      error: (err: HttpErrorResponse) => {
        this.error = describe(err, 'Could not open this request.');
      },
    });
  }

  close(): void {
    this.selected = null;
    this.selectedEngineer = null;
    this.dayReviews = [];
  }

  private buildDayReviews(req: AvailabilityRequest): void {
    this.dayReviews = req.days.map((d) => ({
      iso: d.work_date,
      label: weekdayLabel(d.work_date),
      shiftCode: d.shift_id ? (this.shiftById.get(d.shift_id)?.code ?? d.shift_id.slice(0, 6)) : '',
      statusCode: d.status_id
        ? (this.statusById.get(d.status_id)?.code ?? d.status_id.slice(0, 6))
        : '',
      onsite: d.onsite,
      onCall: d.on_call,
      onCallShiftCode: d.on_call_shift_id
        ? (this.shiftById.get(d.on_call_shift_id)?.code ?? d.on_call_shift_id.slice(0, 6))
        : '',
      notes: d.notes,
      decision: 'APPROVED',
      comment: '',
    }));
  }

  setAll(decision: 'APPROVED' | 'REJECTED'): void {
    this.dayReviews.forEach((d) => (d.decision = decision));
  }

  get approvedCount(): number {
    return this.dayReviews.filter((d) => d.decision === 'APPROVED').length;
  }

  get rejectedCount(): number {
    return this.dayReviews.filter((d) => d.decision === 'REJECTED').length;
  }

  submitReview(): void {
    if (!this.selected) return;
    this.submitting = true;
    this.error = null;
    this.schedule
      .review(this.selected.request_id, {
        decisions: this.dayReviews.map((d) => ({
          work_date: d.iso,
          decision: d.decision,
          comment: d.comment.trim() || null,
        })),
        comment: this.reviewComment.trim() || null,
      })
      .subscribe({
        next: (res) => {
          this.submitting = false;
          this.notice = `${this.selectedEngineer?.full_name ?? 'Request'}: ${res.status.replace('_', ' ')}.`;
          this.close();
          this.loadQueue();
        },
        error: (err: HttpErrorResponse) => {
          this.submitting = false;
          this.error = describe(err, 'Could not submit your decision.');
        },
      });
  }

  tierClass(tier: string | null): string {
    switch (tier) {
      case 'L1':
        return 'b-blue';
      case 'L1.5':
        return 'b-yellow';
      case 'L2':
        return 'b-green';
      default:
        return 'b-gray';
    }
  }
}

// ── utilities ────────────────────────────────────────────────────────────────

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function weekdayLabel(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return `${WEEKDAYS[date.getDay()]} ${iso.slice(5)}`;
}

function describe(err: HttpErrorResponse, fallback: string): string {
  const d = err?.error?.detail;
  if (d) {
    if (typeof d === 'object' && !Array.isArray(d) && d.error) {
      return `${fallback} (${d.error})`;
    }
    if (Array.isArray(d) && d.length) {
      const f = d[0];
      const where = Array.isArray(f?.loc) ? f.loc.slice(1).join('.') : '';
      const msg = f?.msg || f?.type || 'validation error';
      return `${fallback} (${where ? where + ': ' : ''}${msg})`;
    }
    if (typeof d === 'string') return `${fallback} (${d})`;
  }
  if (err?.status === 0) return `${fallback} (scheduler unreachable)`;
  if (err?.status) return `${fallback} (HTTP ${err.status})`;
  return fallback;
}
