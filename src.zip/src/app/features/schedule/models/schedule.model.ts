/**
 * Types for the schedule-management feature. These mirror the scheduler
 * service's availability schemas (app/schemas/availability.py +
 * app/schemas/shift_roster.py) — keep them in sync with the backend.
 */

/** Header lifecycle of an availability request. */
export type RequestStatus =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'APPROVED'
  | 'PARTIALLY_APPROVED'
  | 'REJECTED'
  | 'WITHDRAWN';

/** Per-day supervisor decision. */
export type DayDecision = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface ShiftDefinition {
  shift_id: string;
  account: string;
  code: string;
  label: string;
  start_time: string;
  end_time: string;
  crosses_midnight: boolean;
  timezone: string;
  is_on_call: boolean;
  color_hex: string | null;
  notes: string | null;
}

export interface DayStatusType {
  status_id: string;
  account: string;
  code: string;
  label: string;
  category: string;
  counts_as_available: boolean;
  is_paid: boolean;
  color_hex: string | null;
}

export interface RosterResource {
  resource_id: string;
  engineer_id: string | null;
  full_name: string;
  email: string | null;
  tier: string | null;
  group_id: string;
  holiday_calendar_id: string | null;
  default_shift_id: string | null;
  employment_type: string | null;
  active: boolean;
}

/** A roster group the supervisor owns (GET /shift-roster/supervisor-groups). */
export interface RosterGroupSummary {
  group_id: string;
  name: string;
  account: string;
  parent_group_id: string | null;
  default_timezone: string;
  active: boolean;
}

/** A committed roster grid cell (system of record). */
export interface RosterAssignment {
  assignment_id: string;
  resource_id: string;
  work_date: string;
  shift_id: string | null;
  status_id: string | null;
  onsite: boolean;
  on_call: boolean;
  on_call_shift_id: string | null;
  source: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

/** One proposed day on an availability request. */
export interface AvailabilityDay {
  day_id: string;
  work_date: string;
  shift_id: string | null;
  status_id: string | null;
  onsite: boolean;
  on_call: boolean;
  on_call_shift_id: string | null;
  notes: string | null;
  decision: DayDecision;
  decision_comment: string | null;
}

export interface AvailabilityRequest {
  request_id: string;
  resource_id: string;
  group_id: string;
  week_start_date: string;
  status: RequestStatus;
  submitted_by: string;
  submitted_at: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  review_comment: string | null;
  created_at: string;
  updated_at: string;
  days: AvailabilityDay[];
}

/** GET /availability/my — everything the weekly editor needs in one call. */
export interface MyWeek {
  resource: RosterResource;
  week_start_date: string;
  editable: boolean;
  request: AvailabilityRequest | null;
  committed: RosterAssignment[];
  shifts: ShiftDefinition[];
  statuses: DayStatusType[];
}

/** One proposed cell sent up when saving/submitting. */
export interface AvailabilityCellInput {
  work_date: string;
  shift_id?: string | null;
  status_id?: string | null;
  onsite?: boolean;
  on_call?: boolean;
  on_call_shift_id?: string | null;
  notes?: string | null;
}

export interface SaveAvailabilityRequest {
  resource_id: string;
  week_start_date: string;
  cells: AvailabilityCellInput[];
  actor_engineer_id: string;
  actor_role?: string | null;
  submit?: boolean;
}

/** A row in the supervisor review queue. */
export interface PendingRequestSummary {
  request_id: string;
  resource_id: string;
  engineer_id: string | null;
  full_name: string;
  tier: string | null;
  week_start_date: string;
  submitted_at: string | null;
  day_count: number;
}

export interface PendingQueue {
  group_id: string;
  requests: PendingRequestSummary[];
  total: number;
}

export interface DayDecisionInput {
  work_date: string;
  decision: 'APPROVED' | 'REJECTED';
  comment?: string | null;
}

export interface ReviewRequest {
  actor_engineer_id: string;
  actor_role: string;
  action?: 'APPROVE_ALL' | 'REJECT_ALL' | null;
  decisions?: DayDecisionInput[];
  default_decision?: 'APPROVED' | 'REJECTED';
  comment?: string | null;
}

// ── Team grid (supervisor weekly view) ───────────────────────────────────────

/** One committed cell in the team grid (GET /shift-roster/grid). */
export interface GridCell {
  work_date: string;
  shift_id: string | null;
  shift_code: string | null;
  status_id: string | null;
  status_code: string | null;
  onsite: boolean;
  on_call: boolean;
  on_call_shift_id: string | null;
  /** Provenance: DEFAULT | SELF_SERVICE | MANUAL | … — used to flag deviations. */
  source: string | null;
  notes: string | null;
}

export interface GridResource {
  resource_id: string;
  full_name: string;
  email: string | null;
  engineer_id: string | null;
  cells: GridCell[];
}

/** GET /shift-roster/grid — the whole team's week in one call. */
export interface GridResponse {
  group_id: string;
  group_name: string;
  account: string;
  date_from: string;
  date_to: string;
  shifts: ShiftDefinition[];
  statuses: DayStatusType[];
  resources: GridResource[];
}

/** Per-resource outcome of applying the default-shift roster to a week. */
export interface ApplyDefaultResourceResult {
  resource_id: string;
  full_name: string;
  created: number;
  skipped: number;
  no_default: boolean;
}

/** POST /shift-roster/apply-default-week response. */
export interface ApplyDefaultWeekResponse {
  group_id: string;
  week_start: string;
  date_to: string;
  created: number;
  skipped: number;
  resources: ApplyDefaultResourceResult[];
}
