import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

import { ScheduleService } from '../services/schedule.service';
import {
  AvailabilityDay,
  AvailabilityRequest,
  DayStatusType,
  MyWeek,
  RosterResource,
  ShiftDefinition,
} from '../models/schedule.model';

/** One editable row in the week grid. */
interface DayEdit {
  iso: string; // YYYY-MM-DD
  label: string; // e.g. "Mon"
  dayNum: string; // e.g. "09 Jun"
  shiftId: string | null;
  statusId: string | null;
  onsite: boolean;
  onCall: boolean;
  onCallShiftId: string | null; // the on-call window (an is_on_call shift) the overlay covers
  notes: string;
  decision: AvailabilityDay['decision'] | null;
  decisionComment: string | null;
  committed: boolean; // already on the roster grid
}

@Component({
  selector: 'app-engineer-availability',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './engineer-availability.component.html',
  styleUrls: ['./engineer-availability.component.scss'],
})
export class EngineerAvailabilityComponent implements OnInit {
  loading = false;
  saving = false;
  error: string | null = null;
  notice: string | null = null;

  /** Engineer is not on any roster — nothing to manage. */
  notRostered = false;

  /** Some blank weekday cells were seeded from the resource's default shift. */
  prefilledDefault = false;

  resource: RosterResource | null = null;
  weekStart!: Date;
  myWeek: MyWeek | null = null;

  rows: DayEdit[] = [];
  shifts: ShiftDefinition[] = [];
  /** Worked-shift options for the primary Shift dropdown (excludes on-call shifts). */
  workShifts: ShiftDefinition[] = [];
  /** On-call window options (is_on_call shifts, e.g. OC1/OC2) for the overlay dropdown. */
  onCallShifts: ShiftDefinition[] = [];
  statuses: DayStatusType[] = [];
  private shiftById = new Map<string, ShiftDefinition>();
  private statusById = new Map<string, DayStatusType>();

  constructor(private schedule: ScheduleService) {}

  ngOnInit(): void {
    this.weekStart = mondayOf(new Date());
    this.loading = true;
    this.schedule.resolveResource().subscribe({
      next: (res) => {
        this.resource = res;
        this.loadWeek();
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        if (isNotRostered(err)) {
          this.notRostered = true;
        } else {
          this.error = describe(
            err,
            'Could not reach the scheduler service. Check that it is running and that you are signed in.'
          );
        }
      },
    });
  }

  // ── Week state ───────────────────────────────────────────────────────────

  get weekStartIso(): string {
    return toIso(this.weekStart);
  }

  get request(): AvailabilityRequest | null {
    return this.myWeek?.request ?? null;
  }

  get status(): string | null {
    return this.request?.status ?? null;
  }

  /** Past weeks are read-only; so is a week already awaiting review. */
  get readOnly(): boolean {
    if (!this.myWeek?.editable) return true;
    return this.status === 'SUBMITTED';
  }

  /** A terminal/absent request means a fresh draft (amendment) is being built. */
  get isAmendment(): boolean {
    return !this.readOnly && (!this.request || this.request.status !== 'DRAFT');
  }

  loadWeek(): void {
    if (!this.resource) return;
    this.loading = true;
    this.error = null;
    this.notice = null;
    this.schedule.getMyWeek(this.resource.resource_id, this.weekStartIso).subscribe({
      next: (wk) => {
        this.myWeek = wk;
        this.shifts = wk.shifts;
        this.workShifts = wk.shifts.filter((s) => !s.is_on_call);
        this.onCallShifts = wk.shifts.filter((s) => s.is_on_call);
        this.statuses = wk.statuses;
        this.shiftById = new Map(wk.shifts.map((s) => [s.shift_id, s]));
        this.statusById = new Map(wk.statuses.map((s) => [s.status_id, s]));
        this.buildRows(wk);
        this.loading = false;
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.error = describe(err, 'Could not load this week.');
      },
    });
  }

  prevWeek(): void {
    this.weekStart = addDays(this.weekStart, -7);
    this.loadWeek();
  }

  nextWeek(): void {
    this.weekStart = addDays(this.weekStart, 7);
    this.loadWeek();
  }

  thisWeek(): void {
    this.weekStart = mondayOf(new Date());
    this.loadWeek();
  }

  /**
   * Seed the seven editable rows: a request day wins, else the committed grid
   * cell, else — for a fresh, editable week with no request at all — the
   * resource's default shift on weekdays (Mon–Fri), so a new week starts from
   * the engineer's standard pattern instead of blank. Weekends and any day that
   * is already proposed/committed are left untouched.
   */
  private buildRows(wk: MyWeek): void {
    const dayByDate = new Map<string, AvailabilityDay>();
    if (wk.request) {
      for (const d of wk.request.days) dayByDate.set(d.work_date, d);
    }
    const committedByDate = new Map(wk.committed.map((c) => [c.work_date, c]));

    // Only suggest a default when the week is editable and the engineer hasn't
    // already curated it (no in-flight or prior request), and the default shift
    // is a real entry in this account's active vocabulary.
    const workShiftIds = new Set(this.workShifts.map((s) => s.shift_id));
    const defaultShiftId =
      wk.editable &&
      !wk.request &&
      wk.resource.default_shift_id &&
      workShiftIds.has(wk.resource.default_shift_id)
        ? wk.resource.default_shift_id
        : null;
    this.prefilledDefault = false;

    this.rows = Array.from({ length: 7 }, (_, i) => {
      const date = addDays(this.weekStart, i);
      const iso = toIso(date);
      const proposed = dayByDate.get(iso);
      const committed = committedByDate.get(iso);
      const src = proposed ?? committed;
      const isWeekday = i < 5; // i=0 is Monday
      let shiftId = src?.shift_id ?? null;
      if (!src && !shiftId && isWeekday && defaultShiftId) {
        shiftId = defaultShiftId;
        this.prefilledDefault = true;
      }
      return {
        iso,
        label: WEEKDAYS[i],
        dayNum: `${pad(date.getDate())} ${MONTHS[date.getMonth()]}`,
        shiftId,
        statusId: src?.status_id ?? null,
        onsite: src?.onsite ?? false,
        onCall: src?.on_call ?? false,
        onCallShiftId: src?.on_call_shift_id ?? null,
        notes: src?.notes ?? '',
        decision: proposed?.decision ?? null,
        decisionComment: proposed?.decision_comment ?? null,
        committed: !!committed,
      };
    });
  }

  // ── Display helpers ────────────────────────────────────────────────────────

  shiftCode(id: string | null): string {
    return id ? (this.shiftById.get(id)?.code ?? '—') : '';
  }

  statusCode(id: string | null): string {
    return id ? (this.statusById.get(id)?.code ?? '—') : '';
  }

  statusBadgeClass(status: string | null): string {
    switch (status) {
      case 'APPROVED':
        return 'b-green';
      case 'PARTIALLY_APPROVED':
        return 'b-yellow';
      case 'SUBMITTED':
        return 'b-blue';
      case 'REJECTED':
      case 'WITHDRAWN':
        return 'b-red';
      default:
        return 'b-gray';
    }
  }

  // ── Mutations ────────────────────────────────────────────────────────────

  /** Clear/seed the on-call window when the overlay is toggled. */
  onCallToggled(row: DayEdit): void {
    if (row.onCall) {
      if (!row.onCallShiftId && this.onCallShifts.length) {
        row.onCallShiftId = this.onCallShifts[0].shift_id;
      }
    } else {
      row.onCallShiftId = null;
    }
  }

  /**
   * A row contributes a cell when it carries a shift, a status, or an on-call
   * overlay. On-call is an overlay on the worked shift; for an on-call-only day
   * (no base shift/status) the on-call window doubles as the worked block so the
   * cell still satisfies the backend's shift-or-status rule.
   */
  private cellsFromRows() {
    return this.rows
      .filter((r) => r.shiftId || r.statusId || (r.onCall && r.onCallShiftId))
      .map((r) => {
        const onCallShiftId = r.onCall ? r.onCallShiftId : null;
        const shiftId = r.shiftId ?? (r.statusId ? null : onCallShiftId);
        return {
          work_date: r.iso,
          shift_id: shiftId,
          status_id: r.statusId,
          onsite: r.onsite,
          on_call: r.onCall,
          on_call_shift_id: onCallShiftId,
          notes: r.notes.trim() || null,
        };
      });
  }

  private hasEditableContent(): boolean {
    return this.rows.some((r) => r.shiftId || r.statusId || (r.onCall && r.onCallShiftId));
  }

  save(submit: boolean): void {
    if (!this.resource || this.readOnly) return;
    if (!this.hasEditableContent()) {
      this.error = 'Add at least one shift or leave entry before saving.';
      return;
    }
    this.saving = true;
    this.error = null;
    this.notice = null;
    this.schedule
      .saveWeek({
        resource_id: this.resource.resource_id,
        week_start_date: this.weekStartIso,
        cells: this.cellsFromRows(),
        submit,
      })
      .subscribe({
        next: () => {
          this.saving = false;
          this.notice = submit ? 'Submitted for supervisor approval.' : 'Draft saved.';
          this.loadWeek();
        },
        error: (err: HttpErrorResponse) => {
          this.saving = false;
          this.error = describe(err, 'Could not save your availability.');
        },
      });
  }

  submitExisting(): void {
    // Save + submit in one call covers both fresh drafts and edits.
    this.save(true);
  }

  withdraw(): void {
    if (!this.request) return;
    this.saving = true;
    this.error = null;
    this.schedule.withdraw(this.request.request_id).subscribe({
      next: () => {
        this.saving = false;
        this.notice = 'Submission withdrawn — you can edit and resubmit.';
        this.loadWeek();
      },
      error: (err: HttpErrorResponse) => {
        this.saving = false;
        this.error = describe(err, 'Could not withdraw your submission.');
      },
    });
  }
}

// ── Date / error utilities ───────────────────────────────────────────────────

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function pad(n: number): string {
  return n < 10 ? `0${n}` : `${n}`;
}

/** Monday of the week containing `d`, at local midnight. */
function mondayOf(d: Date): Date {
  const out = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const dow = (out.getDay() + 6) % 7; // Mon=0 … Sun=6
  out.setDate(out.getDate() - dow);
  return out;
}

function addDays(d: Date, days: number): Date {
  const out = new Date(d);
  out.setDate(out.getDate() + days);
  return out;
}

function toIso(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function describe(err: HttpErrorResponse, fallback: string): string {
  const d = err?.error?.detail;
  if (d) {
    // Our handlers: {"detail": {"error": "CODE"}}
    if (typeof d === 'object' && !Array.isArray(d) && d.error) {
      return `${fallback} (${d.error})`;
    }
    // FastAPI validation: {"detail": [{loc, msg, type}, ...]}
    if (Array.isArray(d) && d.length) {
      const f = d[0];
      const where = Array.isArray(f?.loc) ? f.loc.slice(1).join('.') : '';
      const msg = f?.msg || f?.type || 'validation error';
      return `${fallback} (${where ? where + ': ' : ''}${msg})`;
    }
    if (typeof d === 'string') return `${fallback} (${d})`;
  }
  if (err?.status === 0) return `${fallback} (scheduler unreachable)`;
  if (err?.status) return `${fallback} (HTTP ${err.status})`;
  return fallback;
}

/**
 * True only for the backend's deliberate "you have no roster row" signal
 * (404 with detail.error === 'NOT_ROSTERED'). A bare 404 from an unreachable
 * route/service, or any other error, is NOT this — it should surface as an
 * error, not the "not on a managed roster" empty state.
 */
function isNotRostered(err: HttpErrorResponse): boolean {
  return err?.status === 404 && err?.error?.detail?.error === 'NOT_ROSTERED';
}
