import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { AuthService } from '@core/services/auth.service';
import { environment } from '../../../../environments/environment';
import {
  ApplyDefaultWeekResponse,
  AvailabilityRequest,
  GridResponse,
  MyWeek,
  PendingQueue,
  ReviewRequest,
  RosterGroupSummary,
  RosterResource,
  SaveAvailabilityRequest,
} from '../models/schedule.model';

/** Scheduler base URL — runtime-overridable via window.__env for Helm. */
function schedulerBaseUrl(): string {
  const env = (window as unknown as { __env?: { schedulerBaseUrl?: string } }).__env;
  return env?.schedulerBaseUrl || environment.schedulerBaseUrl;
}

/**
 * Thin client over the scheduler service's /v1/scheduler/availability API.
 * The session JWT is attached by authInterceptor; this service additionally
 * forwards the caller's engineer_id/role in request bodies because the
 * scheduler enforces ownership/approval rules from those fields.
 */
@Injectable({ providedIn: 'root' })
export class ScheduleService {
  constructor(
    private http: HttpClient,
    private auth: AuthService
  ) {}

  /** Identity the scheduler keys ownership on — the engineer's email. */
  get actorId(): string {
    return this.auth.user.email || this.auth.user.userId;
  }

  get actorRole(): string {
    return this.auth.user.role;
  }

  private base(): string {
    return `${schedulerBaseUrl()}/availability`;
  }

  /** System-of-record shift-roster API (the committed grid). */
  private shiftRosterBase(): string {
    return `${schedulerBaseUrl()}/shift-roster`;
  }

  /**
   * The roster groups the signed-in supervisor owns via their triage config(s).
   * Drives the team-schedule group selector — a supervisor who manages several
   * groups picks which one's weekly grid to view, rather than being pinned to
   * the group their own roster row sits in. Empty when they own none.
   */
  supervisorGroups(supervisorEmail = this.actorId): Observable<RosterGroupSummary[]> {
    const params = new HttpParams().set('supervisor_email', supervisorEmail);
    return this.http.get<RosterGroupSummary[]>(`${this.shiftRosterBase()}/supervisor-groups`, {
      params,
    });
  }

  /**
   * The whole team's committed week for a roster group — the supervisor's
   * read-only operating-schedule grid.
   */
  getTeamGrid(groupId: string, dateFrom: string, dateTo: string): Observable<GridResponse> {
    const params = new HttpParams()
      .set('group_id', groupId)
      .set('date_from', dateFrom)
      .set('date_to', dateTo);
    return this.http.get<GridResponse>(`${this.shiftRosterBase()}/grid`, { params });
  }

  /**
   * Materialise the default-shift roster for a group's week — fills every
   * uncovered day with each engineer's default shift (the roster everyone
   * operates by default). Never overwrites existing cells.
   */
  applyDefaultWeek(
    groupId: string,
    weekStart: string,
    includeWeekends = false
  ): Observable<ApplyDefaultWeekResponse> {
    return this.http.post<ApplyDefaultWeekResponse>(
      `${this.shiftRosterBase()}/apply-default-week`,
      {
        group_id: groupId,
        week_start: weekStart,
        include_weekends: includeWeekends,
        changed_by: this.actorId,
      }
    );
  }

  /** Resolve the signed-in engineer's roster resource (404 if not rostered). */
  resolveResource(engineerId = this.actorId): Observable<RosterResource> {
    const params = new HttpParams().set('engineer_id', engineerId);
    return this.http.get<RosterResource>(`${this.base()}/resource`, { params });
  }

  /** The engineer's week: committed cells, in-flight request, and vocab. */
  getMyWeek(resourceId: string, weekStart: string): Observable<MyWeek> {
    const params = new HttpParams().set('resource_id', resourceId).set('week_start', weekStart);
    return this.http.get<MyWeek>(`${this.base()}/my`, { params });
  }

  /** Create or replace the caller's DRAFT for a week (optionally submit). */
  saveWeek(
    body: Omit<SaveAvailabilityRequest, 'actor_engineer_id' | 'actor_role'>
  ): Observable<AvailabilityRequest> {
    return this.http.put<AvailabilityRequest>(this.base(), {
      ...body,
      actor_engineer_id: this.actorId,
      actor_role: this.actorRole,
    });
  }

  submit(requestId: string): Observable<AvailabilityRequest> {
    return this.http.post<AvailabilityRequest>(`${this.base()}/${requestId}/submit`, {
      actor_engineer_id: this.actorId,
      actor_role: this.actorRole,
    });
  }

  withdraw(requestId: string): Observable<AvailabilityRequest> {
    return this.http.post<AvailabilityRequest>(`${this.base()}/${requestId}/withdraw`, {
      actor_engineer_id: this.actorId,
      actor_role: this.actorRole,
    });
  }

  /** Supervisor review queue for a roster group. */
  pendingQueue(groupId: string): Observable<PendingQueue> {
    const params = new HttpParams().set('group_id', groupId);
    return this.http.get<PendingQueue>(`${this.base()}/pending`, { params });
  }

  getRequest(requestId: string): Observable<AvailabilityRequest> {
    return this.http.get<AvailabilityRequest>(`${this.base()}/${requestId}`);
  }

  /** Supervisor decision (per-day or whole-week). */
  review(
    requestId: string,
    decision: Omit<ReviewRequest, 'actor_engineer_id' | 'actor_role'>
  ): Observable<AvailabilityRequest> {
    return this.http.post<AvailabilityRequest>(`${this.base()}/${requestId}/review`, {
      actor_engineer_id: this.actorId,
      actor_role: this.actorRole,
      ...decision,
    });
  }
}
