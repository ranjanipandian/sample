import { CommonModule } from '@angular/common';
import { AfterViewChecked, Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { ChatMessage } from '@core/models/ticket.model';
import { AuthService } from '@core/services/auth.service';
import { IntelService } from '@core/services/intel.service';

@Component({
  selector: 'app-intelligence-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './intelligence-panel.component.html',
  styleUrls: ['./intelligence-panel.component.scss'],
})
export class IntelligencePanelComponent implements AfterViewChecked {
  @ViewChild('msgsScroll') msgsScroll!: ElementRef<HTMLDivElement>;

  draft = '';

  /** Initialised in the constructor so the greeting uses the user's first
   *  name when ALB OIDC is on, and a generic salutation otherwise. */
  messages: ChatMessage[] = [];

  private readonly aiReplies: string[] = [
    "I've analysed TKT-4821 — the CPU spike is linked to a runaway Java process on prod-eu-02. Recommend restarting the service with a 2-minute cooldown.",
    'Current HITL queue: 7 tickets. Top priority is TKT-4818 (disk >90%). I can trigger an auto-cleanup script if you approve.',
    'Argus is reporting 3 anomalies in the last hour. All are low severity except the prod-eu-02 incident.',
    'ServiceNow sync completed 15 minutes ago — 42 tickets imported, 38 auto-triaged, 4 flagged for manual review.',
    'Based on historical patterns, TKT-4820 (DB replication lag) typically resolves within 20 minutes with an automatic failover. Monitoring now.',
    'VEEVA connector status: healthy. Last sync was 8 minutes ago with no errors reported.',
  ];

  private replyIdx = 0;
  private shouldScroll = false;

  constructor(
    public intel: IntelService,
    private auth: AuthService
  ) {
    const firstName = this.firstNameOrFallback();
    this.messages = [
      {
        author: 'ai',
        meta: 'AMS Agent · just now',
        text: `👋 Hi ${firstName}! I'm your AMS Intelligence assistant. I can help you with ticket analysis, RCA summaries, HITL decisions, and connector status. What do you need?`,
      },
      {
        author: 'ai',
        meta: 'AMS Agent · just now',
        text: '⚠️ You currently have <strong>7 tickets pending HITL</strong> review — 2 are overdue. Would you like me to summarise them?',
      },
    ];
  }

  private firstNameOrFallback(): string {
    const u = this.auth.user;
    if (u.name) return u.name.split(/\s+/)[0];
    if (u.email)
      return u.email
        .split('@')[0]
        .split('.')[0]
        .replace(/^./, (c) => c.toUpperCase());
    return 'there';
  }

  ngAfterViewChecked(): void {
    if (this.shouldScroll && this.msgsScroll) {
      const el = this.msgsScroll.nativeElement;
      el.scrollTop = el.scrollHeight;
      this.shouldScroll = false;
    }
  }

  close(): void {
    this.intel.set(false);
  }

  sendMsg(): void {
    const txt = this.draft.trim();
    if (!txt) return;
    this.messages.push({ author: 'user', meta: 'You · just now', text: txt });
    this.draft = '';
    this.shouldScroll = true;

    setTimeout(() => {
      this.messages.push({
        author: 'ai',
        meta: 'AMS Agent · just now',
        text: this.aiReplies[this.replyIdx % this.aiReplies.length],
      });
      this.replyIdx += 1;
      this.shouldScroll = true;
    }, 800);
  }
}
