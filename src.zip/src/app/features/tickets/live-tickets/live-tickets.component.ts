import { CommonModule } from '@angular/common';
import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { Ticket, TicketColumn, TicketColumnKey } from '@core/models/ticket.model';
import { TicketService } from '@core/services/ticket.service';
import { TicketUiStateService } from '@core/services/ticket-ui-state.service';

@Component({
  selector: 'app-live-tickets',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './live-tickets.component.html',
  styleUrls: ['./live-tickets.component.scss'],
})
export class LiveTicketsComponent implements OnInit, OnDestroy {
  readonly maxColumns = 7;

  allColumns: TicketColumn[] = [];

  loading = false;
  error: string | null = null;

  searchQuery = '';
  rowsPerPage = 7;
  currentPage = 1;

  activeCols: TicketColumnKey[] = [];
  tempCols: TicketColumnKey[] = [];

  colFilters: Partial<Record<TicketColumnKey, string>> = {};
  openColFilterKey: TicketColumnKey | null = null;
  colPickerOpen = false;

  /** Type filter from route data: 'Incident' | 'Service Request' | 'Problem' | 'Change' | null */
  ticketTypeFilter: string | null = null;

  private subs: Subscription[] = [];

  constructor(
    private ticketService: TicketService,
    private router: Router,
    private route: ActivatedRoute,
    private uiState: TicketUiStateService
  ) {}

  openTicket(t: Ticket): void {
    if (!t?.number) return;
    this.router.navigateByUrl('/tickets/' + encodeURIComponent(t.number));
  }

  /**
   * Click handler for the Action button cell.
   * - Resolve theme (New tickets): kick off the orchestration job, then navigate.
   * - View theme (Resolved/Closed): fetch the historical job + steps, then navigate.
   * - Resume: just navigate (state is already in memory).
   * Always stops propagation so the row click doesn't fire twice.
   */
  onActionClick(event: Event, t: Ticket): void {
    event.stopPropagation();
    if (!t?.number) return;
    const num = t.number;
    const theme = this.actionFor(t).theme;

    if (theme === 'resolve') {
      // New ticket → Plan Approval page before execution. Remember it's been
      // started so the action becomes "View Ticket" from now on (even after a
      // refresh) and we never re-trigger resolve/approve for the same ticket.
      this.uiState.markStarted(num);
      this.router.navigateByUrl('/tickets/' + encodeURIComponent(num) + '/approve');
      return;
    }

    // Started but the engineer never finished the plan gate (and ServiceNow
    // hasn't resolved it) → resume at the Plan Approval page, not the workflow.
    const snowResolved = this.ticketService.actionFor(t).theme === 'view';
    if (this.uiState.hasStarted(num) && !this.uiState.isApproved(num) && !snowResolved) {
      this.router.navigateByUrl('/tickets/' + encodeURIComponent(num) + '/approve');
      return;
    }

    // Approved / resolved ticket → workflow page showing current progress.
    this.openTicket(t);
  }

  /** Page title derived from the route's ticketType filter. */
  get pageTitle(): string {
    switch (this.ticketTypeFilter) {
      case 'Incident':
        return 'Incidents';
      case 'Service Request':
        return 'Service Requests';
      case 'Problem':
        return 'Problems';
      case 'Change':
        return 'Changes';
      default:
        return 'All Tickets';
    }
  }

  ngOnInit(): void {
    this.allColumns = this.ticketService.columns;
    this.activeCols = this.allColumns.filter((c) => c.default).map((c) => c.key);
    this.tempCols = [...this.activeCols];

    // Restore the engineer's saved table prefs (rows-per-page + chosen columns)
    // so they survive tab switches and a full refresh.
    const prefs = this.uiState.getPrefs();
    if (prefs) {
      if (prefs.rowsPerPage && [7, 10, 25].includes(prefs.rowsPerPage)) {
        this.rowsPerPage = prefs.rowsPerPage;
      }
      const validKeys = new Set(this.allColumns.map((c) => c.key));
      const savedCols = (prefs.activeCols || []).filter((k) => validKeys.has(k));
      if (savedCols.length) {
        this.activeCols = savedCols;
        this.tempCols = [...savedCols];
      }
    }

    // React to route changes (sidebar can switch between Incidents/Requests/etc.
    // without unmounting this component since the same component is reused).
    // Each route swap triggers a fresh, server-side-scoped query — we pass
    // ticketType to the backend so it queries only the matching ServiceNow
    // table instead of iterating ALL_TABLES (which 403s as soon as it hits
    // a table the integration user can't read, e.g. change_request).
    this.subs.push(
      this.route.data.subscribe((d) => {
        this.ticketTypeFilter = (d['ticketType'] as string) || null;
        this.currentPage = 1;
        this.colFilters = {};
        this.ticketService.refresh({ ticketType: this.ticketTypeFilter ?? undefined }).subscribe();
      }),
      this.ticketService.tickets$.subscribe(() => {
        if (this.currentPage > this.totalPages) this.currentPage = this.totalPages;
      }),
      this.ticketService.loading$.subscribe((v) => (this.loading = v)),
      this.ticketService.error$.subscribe((v) => (this.error = v))
    );
  }

  /** Tickets filtered by the route's ticketType (or all if none). */
  get tickets(): Ticket[] {
    const all = this.ticketService.tickets;
    return this.ticketTypeFilter ? all.filter((t) => t.type === this.ticketTypeFilter) : all;
  }

  ngOnDestroy(): void {
    this.subs.forEach((s) => s.unsubscribe());
  }

  reload(): void {
    this.ticketService.refresh({ ticketType: this.ticketTypeFilter ?? undefined }).subscribe();
  }

  /* ─── filtering ─── */

  get filteredData(): Ticket[] {
    const q = this.searchQuery.toLowerCase();
    return this.tickets.filter((t) => {
      const gMatch = !q || Object.values(t).some((v) => String(v).toLowerCase().includes(q));
      const cMatch = (Object.entries(this.colFilters) as [TicketColumnKey, string][]).every(
        ([k, v]) => !v || String(t[k]).toLowerCase().includes(v.toLowerCase())
      );
      return gMatch && cMatch;
    });
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.filteredData.length / this.rowsPerPage));
  }

  get pageData(): Ticket[] {
    if (this.currentPage > this.totalPages) {
      this.currentPage = this.totalPages;
    }
    const start = (this.currentPage - 1) * this.rowsPerPage;
    return this.filteredData.slice(start, start + this.rowsPerPage);
  }

  get pageInfo(): string {
    const total = this.filteredData.length;
    if (total === 0) return '0 of 0';
    const start = (this.currentPage - 1) * this.rowsPerPage;
    const end = Math.min(start + this.rowsPerPage, total);
    return `${start + 1}–${end} of ${total}`;
  }

  get countLabel(): string {
    return `${this.filteredData.length} of ${this.tickets.length}`;
  }

  onSearchInput(): void {
    this.currentPage = 1;
  }

  onRowsChange(): void {
    this.currentPage = 1;
    this.savePrefs();
  }

  private savePrefs(): void {
    this.uiState.savePrefs({ rowsPerPage: this.rowsPerPage, activeCols: this.activeCols });
  }

  goPage(dir: 'first' | 'prev' | 'next' | 'last'): void {
    if (dir === 'first') this.currentPage = 1;
    else if (dir === 'prev') this.currentPage = Math.max(1, this.currentPage - 1);
    else if (dir === 'next') this.currentPage = Math.min(this.totalPages, this.currentPage + 1);
    else if (dir === 'last') this.currentPage = this.totalPages;
  }

  /* ─── cell rendering ─── */

  columnLabel(key: TicketColumnKey): string {
    return this.allColumns.find((c) => c.key === key)?.label ?? key;
  }

  isIdCol(key: TicketColumnKey): boolean {
    return key === 'number';
  }

  isActionCol(key: TicketColumnKey): boolean {
    return key === 'action';
  }

  actionFor(t: Ticket): { label: string; icon: string; theme: 'resolve' | 'resume' | 'view' } {
    const base = this.ticketService.actionFor(t);
    // Once the engineer has kicked off resolution for a ticket, never offer
    // "Resolve" again (that would re-trigger the approve/execute flow). Show
    // "View Ticket" so they can watch the progress instead.
    if (base.theme === 'resolve' && t?.number && this.uiState.hasStarted(t.number)) {
      return { label: 'View Ticket', icon: 'ti ti-eye', theme: 'view' };
    }
    return base;
  }

  /** True while a started ticket is still being worked (drives the blinking
   *  View button) — stops once ServiceNow shows it resolved OR the workflow
   *  page has recorded a terminal success for it. */
  isProcessing(t: Ticket): boolean {
    if (!t?.number || !this.uiState.hasStarted(t.number)) return false;
    const snowResolved = this.ticketService.actionFor(t).theme === 'view';
    return !snowResolved && !this.uiState.isResolvedLocally(t.number);
  }

  /* ─── column-level filter dropdown ─── */

  toggleColFilter(event: Event, key: TicketColumnKey): void {
    event.stopPropagation();
    this.openColFilterKey = this.openColFilterKey === key ? null : key;
  }

  applyColFilter(key: TicketColumnKey, val: string): void {
    if (val) {
      this.colFilters[key] = val;
    } else {
      delete this.colFilters[key];
    }
    this.currentPage = 1;
  }

  clearColFilter(key: TicketColumnKey): void {
    delete this.colFilters[key];
    this.currentPage = 1;
  }

  hasColFilter(key: TicketColumnKey): boolean {
    return !!this.colFilters[key];
  }

  getColFilter(key: TicketColumnKey): string {
    return this.colFilters[key] ?? '';
  }

  getColValues(key: TicketColumnKey, query: string): string[] {
    const set = new Set(this.tickets.map((t) => t[key]));
    const vals = Array.from(set);
    return query ? vals.filter((v) => v.toLowerCase().includes(query.toLowerCase())) : vals;
  }

  /* ─── columns picker ─── */

  toggleColPicker(event: Event): void {
    event.stopPropagation();
    this.colPickerOpen = !this.colPickerOpen;
    this.openColFilterKey = null;
    if (this.colPickerOpen) {
      this.tempCols = [...this.activeCols];
    }
  }

  isAtMax(): boolean {
    return this.tempCols.length >= this.maxColumns;
  }

  isCheckedTemp(key: TicketColumnKey): boolean {
    return this.tempCols.includes(key);
  }

  isDisabledTemp(col: TicketColumn): boolean {
    return col.locked || (!this.isCheckedTemp(col.key) && this.isAtMax());
  }

  tempColToggle(col: TicketColumn, checked: boolean): void {
    if (col.locked) return;
    if (checked) {
      if (this.tempCols.length >= this.maxColumns) return;
      if (!this.tempCols.includes(col.key)) this.tempCols.push(col.key);
    } else {
      this.tempCols = this.tempCols.filter((k) => k !== col.key);
    }
  }

  applyColPicker(): void {
    this.activeCols = this.allColumns
      .filter((c) => this.tempCols.includes(c.key))
      .map((c) => c.key);
    this.colFilters = {};
    this.colPickerOpen = false;
    this.savePrefs();
  }

  resetCols(): void {
    this.tempCols = this.allColumns.filter((c) => c.default).map((c) => c.key);
  }

  /* ─── CSV export ─── */

  downloadCSV(): void {
    const headers = this.activeCols.map(
      (k) => this.allColumns.find((c) => c.key === k)?.label ?? k
    );
    const rows = this.filteredData.map((t) => this.activeCols.map((k) => `"${t[k]}"`).join(','));
    const csv = [headers.join(','), ...rows].join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'cognizant-ams-tickets.csv';
    a.click();
  }

  /* ─── close on outside click ─── */

  @HostListener('document:click')
  onDocumentClick(): void {
    if (this.colPickerOpen) this.colPickerOpen = false;
    if (this.openColFilterKey) this.openColFilterKey = null;
  }

  stop(event: Event): void {
    event.stopPropagation();
  }
}
