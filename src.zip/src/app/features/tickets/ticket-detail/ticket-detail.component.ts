import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription, of, timer } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';

import { ViewJobResponse } from '@core/models/api.model';
import { Ticket } from '@core/models/ticket.model';
import { AuthService } from '@core/services/auth.service';
import { JobsService, WorkflowGroupUi } from '@core/services/jobs.service';
import { TicketService } from '@core/services/ticket.service';
import { TicketUiStateService } from '@core/services/ticket-ui-state.service';

/** Execution status for a rail step. */
type WfStepStatus = 'done' | 'active' | 'pending' | 'hitl' | 'failed';

/** One workflow step with its execution-log INPUT / ACTION / OUTPUT payloads. */
interface WfStep {
  id: string;
  label: string;
  hitl: boolean;
  desc: string;
  input?: Record<string, unknown>;
  output?: Record<string, unknown>;
  status: WfStepStatus;
}

interface WfData {
  ticket: string;
  type: string;
  title: string;
  eyebrow: string;
  steps: WfStep[];
}

interface WfMeta {
  priority: string;
  status: string;
  requester: string;
  category: string;
}

interface WfComment {
  av: string;
  name: string;
  msg: string;
}

/** Live execution overlay for one capability, keyed from the job-status response. */
interface StepOverlay {
  status: WfStepStatus;
  input?: Record<string, unknown>;
  output?: Record<string, unknown>;
  /** Descriptive "what this step does" sentence (preferred for the header). */
  action?: string;
  /** Terse "what happened" summary. */
  actionTaken?: string;
}

@Component({
  selector: 'app-ticket-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './ticket-detail.component.html',
  styleUrls: ['./ticket-detail.component.scss'],
})
export class TicketDetailComponent implements OnInit, OnDestroy {
  data: WfData = {
    ticket: '',
    type: 'Incident',
    title: 'Loading workflow…',
    eyebrow: 'WORKFLOW · INCIDENT',
    steps: [],
  };
  meta: WfMeta = { priority: '—', status: 'Executing', requester: '—', category: '—' };

  loading = true;
  error: string | null = null;
  ticketNumber = '';
  jobId = '';

  currentStepIdx = 0;
  railCollapsed = false;

  showRejectPanel = false;
  rejectReason = '';
  rejected = false;
  rejectedReason = '';

  /* ── HITL approval dialog (opens when the job is AWAITING_HITL) ───────── */
  hitlOpen = false;
  hitlInput = '';
  hitlDate: Date | null = null;
  hitlStepLabel = '';
  hitlStepDesc = '';
  hitlSubmitting = false;
  /** Capability of the gate we last approved/rejected — prevents the dialog
   *  re-opening on the lag poll right after the user acts. */
  private handledHitlStep = '';

  activeTab: 'activity' | 'attachments' = 'activity';
  comments: WfComment[] = [];
  commentInput = '';

  barOpen: Record<'input' | 'action' | 'output', boolean> = {
    input: true,
    action: true,
    output: true,
  };
  inputHtml: SafeHtml = '';
  outputHtml: SafeHtml = '';
  /** True while a step's INPUT/OUTPUT has no content yet and the step is still
   *  running — drives the "loading" spinner in those bars. */
  inputLoading = false;
  outputLoading = false;

  private pollSub?: Subscription;
  private firstStatusApplied = false;
  /** True once the user manually selects a step — disables auto-follow so the
   *  poll no longer yanks the right pane away from what they're viewing. */
  private userPinned = false;
  /** capability / step_name → display label, taken from the resolve planned_steps. */
  private displayNames: Record<string, string> = {};
  /** Planned blueprint (from resolve) — the stable rail skeleton. */
  private plannedGroups: WorkflowGroupUi[] = [];

  private readonly stepIcons: Record<string, string> = {
    classification: 'ti-tag',
    parse_incident_context: 'ti-file-search',
    parse_ticket_context: 'ti-file-search',
    lookup_vault_user: 'ti-user-search',
    determine_uam_action: 'ti-route',
    execute_access_change: 'ti-key',
    verify_access_applied: 'ti-shield-check',
    close_ticket: 'ti-circle-check',
    confirm_application: 'ti-apps',
    resolve_document_scope: 'ti-database-search',
    hitl_approval_gate: 'ti-user-check',
    execute_document_updates: 'ti-file-export',
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private auth: AuthService,
    private sanitizer: DomSanitizer,
    private jobs: JobsService,
    private ticketService: TicketService,
    private uiState: TicketUiStateService
  ) {}

  ngOnInit(): void {
    const num = this.route.snapshot.paramMap.get('number') || '';
    this.ticketNumber = num;
    this.data.ticket = num;

    const cachedJobId = this.jobs.jobIdFor(num);
    if (cachedJobId) {
      // Resolve → Approve flow in this session: we already have the job_id.
      this.startWithJob(num, cachedJobId);
      return;
    }

    // "View Ticket" on a resolved ticket (or a direct URL): no cached job_id —
    // look it up by ticket number, then poll its status to show history.
    this.loading = true;
    this.meta = this.metaFromTicketRow(num, 'In Progress');
    this.jobs.lookupJobId(num).subscribe({
      next: (jobId) => {
        if (jobId) {
          this.startWithJob(num, jobId);
        } else {
          this.loading = false;
          this.error = 'No workflow found for this ticket yet.';
        }
      },
      error: () => {
        this.loading = false;
        this.error = "Could not load this ticket's history. Please retry.";
      },
    });
  }

  /** Set up the rail skeleton + start the 20s status polling for a known job. */
  private startWithJob(num: string, jobId: string): void {
    this.jobId = jobId;
    this.plannedGroups = this.jobs.plannedGroups(num);
    this.displayNames = this.buildDisplayNames(this.plannedGroups);
    this.meta = this.metaFromTicketRow(num, 'Executing');
    // Render the stable skeleton up-front so the rail mirrors the approved plan
    // while the first status poll is in flight. (Empty for View Ticket, where
    // the first poll's response builds the rail instead.)
    this.data = {
      ticket: num,
      type: 'Incident',
      title: this.titleFromTicketRow(num),
      eyebrow: 'WORKFLOW · INCIDENT',
      steps: this.skeletonSteps(),
    };
    this.startPolling(jobId);
  }

  ngOnDestroy(): void {
    this.pollSub?.unsubscribe();
  }

  /* ── Polling (every 2s until terminal) ──────────────────────────────────
   * A failed poll is swallowed (catchError → null) so one transient error
   * never tears down the timer — polling keeps going until the job reaches a
   * terminal state. */
  private startPolling(jobId: string): void {
    this.pollSub = timer(0, 2000)
      .pipe(switchMap(() => this.jobs.getJobStatus(jobId).pipe(catchError(() => of(null)))))
      .subscribe((res) => {
        if (!res) {
          this.loading = false;
          if (!this.firstStatusApplied) {
            this.error = 'Could not load job status. Retrying…';
          }
          return;
        }
        this.applyStatus(res);
      });
  }

  private applyStatus(res: ViewJobResponse): void {
    this.loading = false;
    this.error = null;

    const overlay = this.buildOverlay(res);
    const base = this.plannedGroups.length ? this.skeletonSteps() : this.stepsFromResponse(res);
    const steps = base.map((s) => {
      const o = overlay[s.id];
      if (!o) return s;
      return {
        ...s,
        status: o.status,
        input: o.input ?? s.input,
        output: o.output ?? s.output,
        // Header description: prefer the planned "what this step does" sentence
        // (matches the Plan Approval wording); fall back to the job's action /
        // action_taken. Never let the terse result summary clobber a good desc.
        desc: s.desc || o.action || o.actionTaken || '',
      };
    });

    // Job-level terminal state. When the whole job succeeded, the rail is
    // connected end-to-end — mark every step done so it never stops short just
    // because a per-step row was sparse or arrived in a later poll.
    const js = (res.job_status || '').toUpperCase();
    const succeeded = ['RESOLVED', 'SUCCEEDED', 'SUCCESS', 'COMPLETED', 'CLOSED'].includes(js);
    const failed = ['FAILED', 'CANCELLED', 'REJECTED', 'ERROR'].includes(js);
    const awaitingHitl = js === 'AWAITING_HITL' || js === 'PENDING_APPROVAL';
    if (succeeded) {
      for (const s of steps) s.status = 'done';
      // Record terminal success so the Incidents list stops blinking the
      // "View Ticket" button for this ticket.
      this.uiState.markResolved(res.ticket_id || this.ticketNumber);
    } else if (awaitingHitl) {
      // Paused at a Human-in-the-Loop gate → stop the rail there and flag that
      // step as 'hitl' (awaiting), leaving the following steps pending.
      const gateIdx =
        (res.current_step ? steps.findIndex((s) => s.id === res.current_step) : -1) >= 0
          ? steps.findIndex((s) => s.id === res.current_step)
          : steps.findIndex((s) => s.status !== 'done');
      if (gateIdx >= 0) steps[gateIdx].status = 'hitl';
    } else if (!failed) {
      // Job still executing → the first not-yet-done step is the one currently
      // running. Mark it 'active' so the rail shows a blue spinner on it; it
      // flips to a green tick on the next poll once its status is SUCCEEDED.
      // (A HITL gate stays 'hitl' — we only promote a plain 'pending' step.)
      const runningIdx = steps.findIndex((s) => s.status === 'pending');
      if (runningIdx >= 0) steps[runningIdx].status = 'active';
    }

    this.data = {
      ticket: res.ticket_id || this.ticketNumber,
      type: 'Incident',
      title: this.titleFromStatus(res),
      eyebrow: 'WORKFLOW · INCIDENT',
      steps,
    };
    this.meta = this.metaFromStatus(res);

    const prevIdx = this.currentStepIdx;
    if (this.userPinned) {
      // User is browsing manually — keep their selection (clamped to range).
      this.currentStepIdx = Math.min(this.currentStepIdx, Math.max(0, steps.length - 1));
    } else {
      // Auto-follow: show the step the rail is currently working on (first
      // not-done). When everything is done (job resolved), findIndex returns
      // -1 → fall back to the last step.
      const target = steps.findIndex((s) => s.status !== 'done');
      this.currentStepIdx = target >= 0 ? target : Math.max(0, steps.length - 1);
    }
    this.firstStatusApplied = true;

    // Re-open the three bars only when auto-follow actually moves to a different
    // step (a fresh step's content) — never on a same-step poll, so a manual
    // collapse still sticks.
    if (this.currentStepIdx !== prevIdx) {
      this.barOpen = { input: true, action: true, output: true };
    }
    this.renderStep();

    // Stop polling once the job is terminal (succeeded OR failed).
    if (succeeded || failed) {
      this.pollSub?.unsubscribe();
      this.pollSub = undefined;
    } else if (awaitingHitl) {
      // Paused for human approval: halt polling and open the HITL dialog — but
      // only for a gate we haven't just handled (avoids re-opening on the lag
      // poll right after Approve, while still opening for a *new* gate).
      const gateStep = res.current_step || this.step?.id || '';
      if (!this.hitlOpen && gateStep !== this.handledHitlStep) {
        this.pollSub?.unsubscribe();
        this.pollSub = undefined;
        this.openHitl(gateStep);
      }
    }
  }

  /* ── Rail skeleton from the approved plan ───────────────────────────────
   * Flatten exactly like the Plan Approval page: first group (Classification)
   * and last group (Close Ticket) each stay a single step; every group in
   * between is expanded so each sub-step becomes its own major step. The
   * classification sub-steps are intentionally NOT shown. */
  private skeletonSteps(): WfStep[] {
    const groups = this.plannedGroups;
    const out: WfStep[] = [];
    groups.forEach((g, gi) => {
      const isEdge = gi === 0 || gi === groups.length - 1;
      if (isEdge) {
        const id = gi === 0 ? 'classification' : g.substeps[0]?.capability || 'close_ticket';
        out.push({
          id,
          label: g.name,
          hitl: false,
          // Edges (Classification / Close Ticket) take their description from
          // the job's `action` once it arrives; blank until then.
          desc: '',
          status: 'pending',
        });
      } else {
        for (const ss of g.substeps) {
          out.push({
            id: ss.capability,
            label: ss.name,
            hitl: false,
            desc: ss.description || '',
            status: 'pending',
          });
        }
      }
    });
    return out;
  }

  /** Map capability / step_name → live status + input/output from the status payload. */
  private buildOverlay(res: ViewJobResponse): Record<string, StepOverlay> {
    const map: Record<string, StepOverlay> = {};
    const all = res.steps || [];

    // 1) Top-level + child rows (keyed by capability).
    for (const s of all) {
      const os = this.asObj(s.outcome?.output_summary);
      map[s.capability] = {
        status: this.mapStatus(String(s.status || '')),
        input: this.asObj(s.outcome?.input_summary),
        output: this.asObj(s.outcome?.output_summary),
        action: String(os?.['action'] || '') || undefined,
        actionTaken: s.outcome?.action_taken || undefined,
      };
    }

    // 2) execution_steps inside an agent step carry the richest object I/O —
    //    let them override the keyed entries.
    for (const s of all) {
      const os = this.asObj(s.outcome?.output_summary);
      const exec = Array.isArray(os?.['execution_steps'])
        ? (os!['execution_steps'] as Record<string, unknown>[])
        : null;
      if (!exec) continue;
      for (const e of exec) {
        const sn = String(e['step_name'] || '');
        if (!sn) continue;
        map[sn] = {
          status: this.mapStatus(String(e['status'] || '')),
          input: this.asObj(e['input']),
          output: this.asObj(e['output']),
          action: String(e['action'] || '') || undefined,
          actionTaken: String(e['action_taken'] || '') || undefined,
        };
      }
    }
    return map;
  }

  /** Fallback skeleton when no planned blueprint is cached (e.g. page reload). */
  private stepsFromResponse(res: ViewJobResponse): WfStep[] {
    const all = res.steps || [];
    const tops = all.filter((s) => !s.parent_step_id);
    const out: WfStep[] = [];
    for (const top of tops) {
      const cap = top.capability;
      if (cap === 'classification') {
        out.push({ id: cap, label: 'Classification', hitl: false, desc: '', status: 'pending' });
        continue;
      }
      // Prefer the granular CHILD step rows (parent_step_id === this top): they
      // are the complete, authoritative list with their own status + I/O. Only
      // fall back to the parent's execution_steps summary when there are no
      // children, then to the top step itself. (The summary can be partial —
      // e.g. a HITL document-update job lists only execute_document_updates in
      // execution_steps but has 4 child rows — which previously collapsed the
      // rail to 3 steps on View Ticket.)
      const kids = all.filter((s) => s.parent_step_id === top.step_id);
      if (kids.length) {
        for (const kid of kids) {
          out.push({
            id: kid.capability,
            label: this.displayNames[kid.capability] || this.humanize(kid.capability),
            hitl: false,
            desc: '',
            status: 'pending',
          });
        }
        continue;
      }
      const os = this.asObj(top.outcome?.output_summary);
      const exec = Array.isArray(os?.['execution_steps'])
        ? (os!['execution_steps'] as Record<string, unknown>[])
        : null;
      if (exec && exec.length) {
        for (const e of exec) {
          const sn = String(e['step_name'] || '');
          out.push({
            id: sn,
            label: this.displayNames[sn] || this.humanize(sn),
            hitl: false,
            desc: '',
            status: 'pending',
          });
        }
        continue;
      }
      out.push({
        id: cap,
        label: this.displayNames[cap] || this.humanize(cap),
        hitl: false,
        desc: '',
        status: 'pending',
      });
    }
    return out;
  }

  private buildDisplayNames(groups: WorkflowGroupUi[]): Record<string, string> {
    const m: Record<string, string> = {};
    for (const g of groups) for (const ss of g.substeps) m[ss.capability] = ss.name;
    return m;
  }

  /* ── Status mapping ─────────────────────────────────────────────────── */
  private mapStatus(raw: string): WfStepStatus {
    const v = raw.toUpperCase();
    if (['SUCCEEDED', 'SUCCESS', 'COMPLETE', 'COMPLETED'].includes(v)) return 'done';
    if (v === 'PENDING_APPROVAL' || v === 'AWAITING_HITL') return 'hitl';
    if (v === 'FAILED' || v === 'ERROR') return 'failed';
    if (['IN_PROGRESS', 'RUNNING', 'CURRENT', 'EXECUTING'].includes(v)) return 'active';
    return 'pending';
  }

  private mapJobStatusLabel(raw: string | undefined): string {
    const v = (raw || '').toUpperCase();
    if (['RESOLVED', 'SUCCEEDED', 'SUCCESS', 'COMPLETED', 'CLOSED'].includes(v)) return 'Resolved';
    if (v === 'AWAITING_HITL') return 'Awaiting HITL';
    if (['FAILED', 'CANCELLED', 'REJECTED', 'ERROR'].includes(v)) return 'Failed';
    if (v === 'EXECUTING' || v === 'IN_PROGRESS') return 'In Progress';
    return raw || 'In Progress';
  }

  /* ── Meta / title from ticket row + classification ──────────────────── */
  private ticketRow(num: string): Ticket | undefined {
    return this.ticketService.tickets.find((t) => t['number'] === num);
  }

  private titleFromTicketRow(num: string): string {
    return this.ticketRow(num)?.['short_desc'] || num;
  }

  private titleFromStatus(res: ViewJobResponse): string {
    const row = this.ticketRow(res.ticket_id || this.ticketNumber);
    if (row?.['short_desc']) return row['short_desc'];
    const cls = (res.steps || []).find((s) => s.capability === 'classification');
    const clsIn = this.asObj(cls?.outcome?.input_summary);
    return (clsIn?.['short_description'] as string) || res.ticket_id || this.ticketNumber;
  }

  private metaFromStatus(res: ViewJobResponse): WfMeta {
    const num = res.ticket_id || this.ticketNumber;
    const row = this.ticketRow(num);
    const cls = (res.steps || []).find((s) => s.capability === 'classification');
    const clsOut = this.asObj(cls?.outcome?.output_summary);
    const ctx = this.asObj(this.asObj(clsOut?.['ticket_context'])?.['context']);

    const requester =
      (row?.['assigned_to'] as string) ||
      (ctx?.['requestor_name'] as string) ||
      (ctx?.['beneficiary_name'] as string) ||
      '—';
    const useCase = (clsOut?.['use_case'] as string) || '';
    const appId = (clsOut?.['application_identifier'] as string) || '';
    const category = appId
      ? `${useCase || 'Workflow'} (${appId})`
      : useCase || (row?.['category'] as string) || '—';

    return {
      priority: (row?.['priority'] as string) || res.complexity_tier || 'P4 Low',
      status: this.mapJobStatusLabel(res.job_status),
      requester,
      category,
    };
  }

  private metaFromTicketRow(num: string, statusLabel: string): WfMeta {
    const row = this.ticketRow(num);
    return {
      priority: (row?.['priority'] as string) || 'P4 Low',
      status: statusLabel,
      requester: (row?.['assigned_to'] as string) || '—',
      category: (row?.['category'] as string) || '—',
    };
  }

  /* ── Selected step / breadcrumb ─────────────────────────────────────── */
  get step(): WfStep | undefined {
    return this.data.steps[this.currentStepIdx];
  }

  get breadcrumb(): string {
    return `${this.data.ticket} · ${this.data.type.toUpperCase()} · STEP ${this.currentStepIdx + 1} OF ${this.data.steps.length}`;
  }

  get isLastStep(): boolean {
    return this.currentStepIdx >= this.data.steps.length - 1;
  }

  get nextLabel(): string {
    const next = this.data.steps[this.currentStepIdx + 1];
    return next ? `Next: ${next.label}` : '';
  }

  /* ── Rail rendering helpers (status-driven) ─────────────────────────── */
  circleClass(i: number): string {
    const st = this.data.steps[i]?.status;
    if (st === 'done') return 'done';
    if (st === 'active' || st === 'hitl' || st === 'failed') return 'active';
    return 'pending';
  }

  circleIcon(i: number): string {
    const st = this.data.steps[i]?.status;
    if (st === 'done') return 'ti-check';
    // Active (currently executing) step → spinning loader in the blue circle.
    if (st === 'active') return 'ti-loader-2 wfp-spin';
    return this.stepIcons[this.data.steps[i]?.id] || 'ti-circle-dot';
  }

  connectorColor(i: number): string {
    return this.data.steps[i]?.status === 'done' ? '#059669' : 'rgba(0,0,0,0.08)';
  }

  stepBadge(i: number): string {
    const st = this.data.steps[i]?.status;
    if (st === 'done') return 'COMPLETED';
    if (st === 'hitl') return 'AWAITING HITL';
    if (st === 'active') return 'RUNNING';
    if (st === 'failed') return 'FAILED';
    return '';
  }

  stepBadgeClass(i: number): string {
    const st = this.data.steps[i]?.status;
    if (st === 'done') return 'wfp-sbadge-approved';
    if (st === 'hitl') return 'wfp-sbadge-hitl';
    if (st === 'failed') return 'wfp-sbadge-hitl';
    return 'wfp-sbadge-running';
  }

  /* ── Navigation (view-only stepping) ────────────────────────────────── */
  selectStep(idx: number): void {
    if (idx < 0 || idx >= this.data.steps.length) return;
    // Manual navigation (rail click / Prev / Continue) → take over from
    // auto-follow so subsequent polls don't move the right pane.
    this.userPinned = true;
    this.currentStepIdx = idx;
    this.showRejectPanel = false;
    // Reset the three bars to open only when the user switches steps — NOT on
    // every poll (renderStep runs each 2s), otherwise a collapsed bar would
    // re-open itself a couple of seconds later.
    this.barOpen = { input: true, action: true, output: true };
    this.renderStep();
  }

  next(): void {
    this.selectStep(this.currentStepIdx + 1);
  }

  back(): void {
    this.router.navigateByUrl('/tickets/incidents');
  }

  /** Deep-link to this ticket's audit trail (events filtered by ticket_ref). */
  viewAuditTrail(): void {
    const ticket = this.data.ticket || this.ticketNumber;
    this.router.navigate(['/audit/events'], { queryParams: { ticket } });
  }

  /* ── HITL approval dialog ───────────────────────────────────────────── */
  private openHitl(gateStep: string): void {
    this.handledHitlStep = gateStep;
    const gate = this.step;
    this.hitlStepLabel = gate?.label || 'Approval required';
    this.hitlStepDesc = gate?.desc || '';
    this.hitlDate = new Date();
    this.hitlInput = '';
    this.hitlSubmitting = false;
    this.hitlOpen = true;
  }

  /** Approve the gate: log the note, call the approve API, resume polling. */
  hitlApprove(): void {
    const note = this.hitlInput.trim();
    if (!note || this.hitlSubmitting) return;
    this.hitlSubmitting = true;
    this.addComment(`✅ Approved at ${this.hitlStepLabel}: ${note}`);
    this.activeTab = 'activity';
    this.jobs.approveJob(this.jobId).subscribe({
      next: () => {
        this.hitlOpen = false;
        this.hitlInput = '';
        this.hitlSubmitting = false;
        // Resume the 2s polling so the rail continues past the gate.
        this.startPolling(this.jobId);
      },
      error: (e: unknown) => {
        this.hitlSubmitting = false;
        this.error = (e as { message?: string })?.message || 'Failed to submit approval. Retry.';
      },
    });
  }

  /** Reject the gate: log the note, stop here, free the ticket to be resolved
   *  again from the Incidents list. */
  hitlReject(): void {
    const note = this.hitlInput.trim();
    if (!note || this.hitlSubmitting) return;
    this.addComment(`❌ Rejected at ${this.hitlStepLabel}: ${note}`);
    this.activeTab = 'activity';
    this.rejected = true;
    this.rejectedReason = note;
    this.hitlOpen = false;
    this.hitlInput = '';
    // Polling is already stopped (halted when the gate opened). Clear the
    // ticket's started/approved flags so its action reverts to "Resolve Ticket".
    this.uiState.clearTicket(this.ticketNumber);
  }

  closeHitl(): void {
    this.hitlOpen = false;
  }

  /* ── HITL reject (local only for now) ───────────────────────────────── */
  showReject(): void {
    this.showRejectPanel = true;
    this.rejected = false;
  }

  cancelReject(): void {
    this.showRejectPanel = false;
    this.rejectReason = '';
  }

  submitReject(): void {
    const reason = this.rejectReason.trim();
    if (!reason) return;
    this.rejected = true;
    this.rejectedReason = reason;
    this.showRejectPanel = false;
    this.addComment(`❌ Rejected at ${this.step?.label || 'this step'}: ${reason}`);
    this.activeTab = 'activity';
  }

  /* ── Execution-log bars ─────────────────────────────────────────────── */
  toggleBar(name: 'input' | 'action' | 'output'): void {
    this.barOpen[name] = !this.barOpen[name];
  }

  private renderStep(): void {
    const step = this.step;
    if (!step) {
      this.inputLoading = false;
      this.outputLoading = false;
      this.inputHtml = '';
      this.outputHtml = '';
      return;
    }
    // A step that hasn't finished yet and has no payload is still executing —
    // show the loading spinner rather than a bare dash. A finished step with no
    // payload shows the dash.
    const stillRunning = step.status !== 'done' && step.status !== 'failed';
    this.inputLoading = !step.input && stillRunning;
    this.outputLoading = !step.output && stillRunning;

    this.inputHtml = this.sanitizer.bypassSecurityTrustHtml(
      step.input ? this.renderKVRows(step.input) : '<span class="wfp-bar-val">—</span>'
    );
    this.outputHtml = this.sanitizer.bypassSecurityTrustHtml(
      step.output ? this.renderKVRows(step.output) : '<span class="wfp-bar-val">—</span>'
    );
  }

  /* ── Comments ───────────────────────────────────────────────────────── */
  get avatarInitials(): string {
    const name = this.auth.user?.name || this.auth.user?.email || 'Support Engineer';
    const parts = name.split(/[\s.@_-]+/).filter(Boolean);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return name.slice(0, 2).toUpperCase();
  }

  get displayName(): string {
    return this.auth.user?.name || this.auth.user?.email || 'Support Engineer';
  }

  submitComment(): void {
    const text = this.commentInput.trim();
    if (!text) return;
    this.addComment(text);
    this.commentInput = '';
  }

  private addComment(msg: string): void {
    this.comments.push({ av: this.avatarInitials, name: this.displayName, msg });
  }

  /* ── KV → HTML (recursive execution-log render) ─────────────────────── */
  private renderKVRows(obj: Record<string, unknown>): string {
    return Object.keys(obj)
      .map((k) => this.kvRow(k, obj[k]))
      .join('');
  }

  /**
   * One row. Scalars render as key | value. Objects/arrays render STACKED —
   * an uppercase label on its own line, with the nested block full-width
   * below — so deep nesting never squeezes a value into a sliver that wraps
   * character-by-character.
   */
  private kvRow(key: string, val: unknown): string {
    if (val !== null && typeof val === 'object') {
      return (
        '<div class="wfp-kv-block">' +
        '<div class="wfp-kv-blabel">' +
        this.esc(key) +
        '</div><div class="wfp-kv-bbody">' +
        this.barVal(val) +
        '</div></div>'
      );
    }
    return (
      '<div class="wfp-bar-kv"><span class="wfp-bar-key">' +
      this.esc(key) +
      '</span>' +
      this.barVal(val) +
      '</div>'
    );
  }

  private barVal(val: unknown): string {
    if (val === null || val === undefined) return '<span class="wfp-bar-val">—</span>';
    if (Array.isArray(val)) {
      if (!val.length) return '<span class="wfp-bar-val">[]</span>';
      if (typeof val[0] === 'object' && val[0] !== null) {
        return val
          .map(
            (item) =>
              '<div class="wfp-bar-nested">' +
              Object.keys(item as Record<string, unknown>)
                .map((k) => this.kvRow(k, (item as Record<string, unknown>)[k]))
                .join('') +
              '</div>'
          )
          .join('');
      }
      return (
        '<ul class="wfp-bar-list">' +
        val.map((v2) => '<li>' + this.esc(String(v2)) + '</li>').join('') +
        '</ul>'
      );
    }
    if (typeof val === 'object') {
      const o = val as Record<string, unknown>;
      return (
        '<div class="wfp-bar-nested">' +
        Object.keys(o)
          .map((k) => this.kvRow(k, o[k]))
          .join('') +
        '</div>'
      );
    }
    return (
      '<span class="wfp-bar-val ' + this.valCls(val) + '">' + this.esc(String(val)) + '</span>'
    );
  }

  private valCls(v: unknown): string {
    const s = String(v);
    if (
      v === true ||
      [
        'SUCCESS',
        'SUCCEEDED',
        'COMPLETED',
        'Resolved',
        'authenticated',
        'compliant',
        'true',
      ].includes(s)
    )
      return 'green';
    if (v === false || s === 'false' || s === 'FAILED') return 'red';
    if (s === 'HITL' || s === 'HITL_PENDING' || s === 'PENDING_APPROVAL') return 'orange';
    return '';
  }

  private esc(s: string): string {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /** Coerce an input/output summary (object OR JSON string) into a plain object. */
  private asObj(v: unknown): Record<string, unknown> | undefined {
    if (v === null || v === undefined) return undefined;
    if (typeof v === 'object' && !Array.isArray(v)) return v as Record<string, unknown>;
    if (Array.isArray(v)) return { items: v };
    if (typeof v === 'string') {
      const t = v.trim();
      if (!t) return undefined;
      try {
        const p = JSON.parse(t);
        if (p && typeof p === 'object' && !Array.isArray(p)) return p as Record<string, unknown>;
        return { value: p };
      } catch {
        return { value: v };
      }
    }
    return { value: v };
  }

  /* ── snake_case / dotted capability → Title Case ────────────────────── */
  private humanize(s: string): string {
    if (!s) return '';
    return s
      .replace(/[_.]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .replace(/\b\w/g, (c) => c.toUpperCase())
      .replace(/\bHitl\b/g, 'HITL')
      .replace(/\bUam\b/g, 'UAM');
  }
}
