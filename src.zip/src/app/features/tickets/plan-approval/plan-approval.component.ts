import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { JobState, JobsService } from '@core/services/jobs.service';
import { TicketUiStateService } from '@core/services/ticket-ui-state.service';

/** One numbered group shown in the plan (1 row per planned-step group). */
interface PlanStep {
  num: number;
  name: string;
  /** Sub-step display names joined for the one-line subtitle. */
  sub: string;
}

@Component({
  selector: 'app-plan-approval',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './plan-approval.component.html',
  styleUrls: ['./plan-approval.component.scss'],
})
export class PlanApprovalComponent implements OnInit, OnDestroy {
  ticketNumber = '';

  /** Live state from the Resolve API (POST /v1/jobs/resolve). */
  loading = true;
  error: string | null = null;

  jobId = '';
  steps: PlanStep[] = [];
  ref = '';
  category = '—';
  useCase = 'this';

  showRejectPanel = false;
  rejectReason = '';
  /** null = pending; set once the engineer approves/rejects. */
  result: 'approved' | 'rejected' | null = null;
  /** True while the /approve call is in flight. */
  approving = false;

  private sub?: Subscription;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private jobs: JobsService,
    private uiState: TicketUiStateService
  ) {}

  ngOnInit(): void {
    this.ticketNumber = this.route.snapshot.paramMap.get('number') || '';
    // Subscribe first so we catch the pending → resolved transition, then fire
    // the Resolve call. The backend auto-runs Classification and returns the
    // job_id + planned_steps blueprint we render below.
    this.sub = this.jobs.getJobForTicket(this.ticketNumber).subscribe((s) => this.applyState(s));
    this.jobs.resolveTicket(this.ticketNumber);
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  private applyState(s: JobState | null): void {
    if (!s) return;

    if (s.phase === 'pending') {
      this.loading = true;
      this.error = null;
      return;
    }
    if (s.phase === 'error') {
      this.loading = false;
      this.error = s.errorMessage || 'Failed to generate the resolution plan.';
      return;
    }

    this.loading = false;
    this.error = null;
    this.jobId = s.jobId;

    // Flatten into numbered steps: the FIRST group (Classification) and the
    // LAST group (Close Ticket) each stay as a single step (subtitle = their
    // sub-steps joined). Every group IN BETWEEN (the use-case group, e.g.
    // "User Access Management" / "Document Update") is expanded so each of its
    // sub-steps becomes its own major numbered step. Result for UAM:
    //   1) Classification 2) Parse Incident Context … 6) Verify Access Applied
    //   7) Close Ticket
    const groups = s.groups;
    const steps: PlanStep[] = [];
    let num = 1;
    groups.forEach((g, gi) => {
      const isEdge = gi === 0 || gi === groups.length - 1;
      if (isEdge) {
        steps.push({
          num: num++,
          name: g.name,
          sub: g.substeps.map((ss) => ss.name).join(' → '),
        });
      } else {
        for (const ss of g.substeps) {
          steps.push({ num: num++, name: ss.name, sub: ss.description || '' });
        }
      }
    });
    this.steps = steps;

    const c = s.classification;
    this.useCase = c?.use_case || s.groups[1]?.name || 'this';
    this.category = c?.application_identifier
      ? `${c.use_case || this.useCase} (${c.application_identifier})`
      : c?.use_case || '—';
    this.ref = c?.application_identifier
      ? `${this.ticketNumber} — ${c.application_identifier}`
      : this.ticketNumber;
  }

  back(): void {
    this.router.navigateByUrl('/tickets/incidents');
  }

  /**
   * Approve → POST /approve (kicks off background execution), then land on the
   * workflow detail page which polls job status until resolved.
   */
  approve(): void {
    if (this.loading || this.error || this.approving) return;
    this.approving = true;
    this.jobs.approvePlan(this.ticketNumber).subscribe({
      next: () => {
        this.result = 'approved';
        // Past the plan gate now → from the Incidents list, View Ticket should
        // open the workflow page, not resume the plan-approval page.
        this.uiState.markApproved(this.ticketNumber);
        this.router.navigateByUrl('/tickets/' + encodeURIComponent(this.ticketNumber));
      },
      error: (e: unknown) => {
        this.approving = false;
        this.error =
          (e as { message?: string })?.message || 'Failed to approve the plan. Please retry.';
      },
    });
  }

  showReject(): void {
    this.showRejectPanel = true;
  }

  cancelReject(): void {
    this.showRejectPanel = false;
    this.rejectReason = '';
  }

  submitReject(): void {
    const reason = this.rejectReason.trim();
    if (!reason) return;
    this.result = 'rejected';
    this.showRejectPanel = false;
    this.jobs.reject(this.ticketNumber, reason);
  }
}
