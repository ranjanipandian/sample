import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';

import { McpCatalogServer, McpConnectionStatus } from '@core/models/mcp.model';
import { McpToolsService } from '@core/services/mcp-tools.service';

interface Connector {
  serverName: string;
  label: string;
  description: string;
  icon: string;
  iconColor: string;
  iconBg: string;
  status: McpConnectionStatus;
  toolCount: number;
  style: string;
}

/** Curated presentation metadata, matched by server_name prefix. The connection
 *  status itself comes live from the orchestrator — never hardcoded. */
interface ConnectorMeta {
  label: string;
  description: string;
  icon: string;
  iconColor: string;
  iconBg: string;
}

const META: Record<string, ConnectorMeta> = {
  servicenow: {
    label: 'ServiceNow',
    description: 'Enterprise ITSM platform — incident management, change control, and CMDB sync.',
    icon: 'ti ti-settings-automation',
    iconColor: '#EA580C',
    iconBg: '#FFF7ED',
  },
  argus: {
    label: 'Argus',
    description: 'Pharmacovigilance / drug-safety case management.',
    icon: 'ti ti-shield-half',
    iconColor: '#1B3FCC',
    iconBg: '#E8F0FE',
  },
  benchling: {
    label: 'Benchling',
    description: 'R&D cloud platform for biotech — ELN, registry, and workflow automation.',
    icon: 'ti ti-flask',
    iconColor: '#059669',
    iconBg: '#ECFDF5',
  },
  veeva: {
    label: 'Veeva Vault',
    description: 'Life-sciences cloud — clinical, regulatory, and quality content management.',
    icon: 'ti ti-database',
    iconColor: '#4F46E5',
    iconBg: '#F0F4FF',
  },
};

const FALLBACK_META: ConnectorMeta = {
  label: '',
  description: 'Connected MCP server.',
  icon: 'ti ti-plug-connected',
  iconColor: '#475569',
  iconBg: '#F1F5F9',
};

@Component({
  selector: 'app-connectors',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './connectors.component.html',
  styleUrls: ['./connectors.component.scss'],
})
export class ConnectorsComponent implements OnInit, OnDestroy {
  loading = false;
  error: string | null = null;
  connectors: Connector[] = [];

  private subs: Subscription[] = [];

  constructor(private mcp: McpToolsService) {}

  ngOnInit(): void {
    this.refresh();
  }

  ngOnDestroy(): void {
    this.subs.forEach((s) => s.unsubscribe());
  }

  refresh(): void {
    this.loading = true;
    this.error = null;
    this.subs.push(
      // health=true → orchestrator runs a live reachability probe per server.
      this.mcp.getCatalog(true).subscribe({
        next: (res) => {
          this.connectors = (res.servers ?? [])
            .map((s) => this.toConnector(s))
            .sort((a, b) => a.label.localeCompare(b.label));
          this.loading = false;
        },
        error: () => {
          this.connectors = [];
          this.error = 'Cannot reach the orchestrator to determine MCP server status.';
          this.loading = false;
        },
      })
    );
  }

  private toConnector(s: McpCatalogServer): Connector {
    const key = Object.keys(META).find((k) => s.server_name.startsWith(k));
    const meta = key ? META[key] : { ...FALLBACK_META, label: s.server_name };
    return {
      serverName: s.server_name,
      // Veeva is segregated per Vault (veeva_etmf, veeva_qd, …) — keep the
      // specific server_name visible so each connection is distinguishable.
      label:
        key === 'veeva'
          ? `Veeva — ${s.server_name.replace(/^veeva_/, '').toUpperCase()}`
          : meta.label,
      description: meta.description,
      icon: meta.icon,
      iconColor: meta.iconColor,
      iconBg: meta.iconBg,
      status: s.status,
      toolCount: s.tool_count,
      style: s.style,
    };
  }

  pillClass(status: McpConnectionStatus): string {
    return status === 'connected' ? 'pill-g' : status === 'disconnected' ? 'pill-r' : 'pill-y';
  }

  dotClass(status: McpConnectionStatus): string {
    return status === 'connected' ? 'sdot-g' : status === 'disconnected' ? 'sdot-r' : 'sdot-y';
  }

  pillLabel(status: McpConnectionStatus): string {
    return status === 'connected'
      ? 'Connected'
      : status === 'disconnected'
        ? 'Disconnected'
        : 'Unknown';
  }
}
