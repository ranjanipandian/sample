import { HttpErrorResponse } from '@angular/common/http';

/** Map an audit level to one of the global tkt-badge colour classes. */
export function levelBadgeClass(level: string): string {
  switch (level) {
    case 'INFO':
      return 'b-blue';
    case 'WARN':
      return 'b-yellow';
    case 'VIOLATION':
    case 'CRITICAL':
      return 'b-red';
    default:
      return 'b-blue';
  }
}

/** Map an incident/ticket status to a global tkt-badge colour class. */
export function statusBadgeClass(status: string): string {
  switch (status) {
    case 'open':
      return 'b-yellow';
    case 'investigating':
    case 'in_progress':
      return 'b-blue';
    case 'resolved':
    case 'closed':
      return 'b-green';
    default:
      return 'b-red';
  }
}

/** Human-friendly message for an audit API failure (RBAC-aware). */
export function describeAuditError(err: unknown): string {
  if (err instanceof HttpErrorResponse) {
    if (err.status === 401) return 'Not authenticated — please sign in again.';
    if (err.status === 403) return 'Your role is not permitted to view this audit data.';
    if (err.status === 0) return 'Audit server unreachable.';
    const detail = (err.error as { detail?: string } | null)?.detail;
    if (detail) return detail;
  }
  return 'Failed to load audit data.';
}
