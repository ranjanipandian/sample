import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AuditSummary } from '../models/audit.model';
import { AuditService } from '../services/audit.service';
import { describeAuditError, levelBadgeClass } from '../audit.util';

@Component({
  selector: 'app-audit-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './audit-dashboard.component.html',
  styleUrl: './audit-dashboard.component.scss',
})
export class AuditDashboardComponent implements OnInit {
  loading = true;
  error = '';
  summary: AuditSummary | null = null;

  readonly levels: ReadonlyArray<string> = ['INFO', 'WARN', 'VIOLATION', 'CRITICAL'];

  constructor(private audit: AuditService) {}

  ngOnInit(): void {
    this.audit.summary().subscribe({
      next: (s) => {
        this.summary = s;
        this.loading = false;
      },
      error: (e) => {
        this.error = describeAuditError(e);
        this.loading = false;
      },
    });
  }

  levelCount(level: string): number {
    return this.summary?.events_by_level?.[level] ?? 0;
  }

  entries(map: Record<string, number> | undefined): { key: string; val: number }[] {
    return Object.entries(map ?? {}).map(([key, val]) => ({ key, val }));
  }

  levelClass(level: string): string {
    return levelBadgeClass(level);
  }
}
