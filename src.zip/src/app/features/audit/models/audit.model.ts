/** Types for the Cognizant Audit Server query API (/api/audit/*). */

export type AuditLevel = 'INFO' | 'WARN' | 'VIOLATION' | 'CRITICAL';

export interface AuditEvent {
  event_id: string;
  created_at: string;
  source: string;
  actor: string | null;
  action: string;
  resource: string | null;
  level: AuditLevel;
  correlation_id: string | null;
  ticket_ref?: string | null;
  meta: Record<string, unknown> | null;
}

export interface AuditIncident {
  incident_id: string;
  correlation_id: string;
  title: string | null;
  status: string; // open | investigating | resolved | dismissed
  severity: AuditLevel;
  opened_at: string;
  resolved_at: string | null;
  resolved_by: string | null;
  resolution_note: string | null;
  meta: Record<string, unknown> | null;
}

export interface AuditSummary {
  window: string;
  events_by_level: Record<string, number>;
  incidents_by_status: Record<string, number>;
  tickets_by_status: Record<string, number>;
}

/** Query params accepted by GET /events. All optional. */
export interface EventsQuery {
  since?: string;
  until?: string;
  level?: AuditLevel;
  source?: string;
  actor?: string;
  correlation_id?: string;
  ticket_ref?: string;
  limit?: number;
  offset?: number;
}
