import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AuditEvent, AuditIncident } from '../models/audit.model';
import { AuditService } from '../services/audit.service';
import { describeAuditError, levelBadgeClass, statusBadgeClass } from '../audit.util';

@Component({
  selector: 'app-incidents-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './incidents-list.component.html',
  styleUrl: './incidents-list.component.scss',
})
export class IncidentsListComponent implements OnInit {
  loading = true;
  error = '';
  incidents: AuditIncident[] = [];

  // Drill-down: one incident's event thread expanded at a time.
  expandedCid: string | null = null;
  threadLoading = false;
  threadError = '';
  thread: AuditEvent[] = [];

  constructor(private audit: AuditService) {}

  ngOnInit(): void {
    this.audit.incidents({ limit: 100 }).subscribe({
      next: (rows) => {
        this.incidents = rows;
        this.loading = false;
      },
      error: (e) => {
        this.error = describeAuditError(e);
        this.loading = false;
      },
    });
  }

  toggle(inc: AuditIncident): void {
    if (this.expandedCid === inc.correlation_id) {
      this.expandedCid = null;
      return;
    }
    this.expandedCid = inc.correlation_id;
    this.thread = [];
    this.threadError = '';
    this.threadLoading = true;
    this.audit.incidentEvents(inc.correlation_id).subscribe({
      next: (rows) => {
        this.thread = rows;
        this.threadLoading = false;
      },
      error: (e) => {
        this.threadError = describeAuditError(e);
        this.threadLoading = false;
      },
    });
  }

  isExpanded(inc: AuditIncident): boolean {
    return this.expandedCid === inc.correlation_id;
  }

  sevClass(level: string): string {
    return levelBadgeClass(level);
  }

  statusClass(status: string): string {
    return statusBadgeClass(status);
  }
}
