import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';

import { AuditEvent, AuditLevel, EventsQuery } from '../models/audit.model';
import { AuditService } from '../services/audit.service';
import { describeAuditError, levelBadgeClass } from '../audit.util';

@Component({
  selector: 'app-events-table',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './events-table.component.html',
  styleUrl: './events-table.component.scss',
})
export class EventsTableComponent implements OnInit {
  loading = false;
  error = '';
  events: AuditEvent[] = [];

  /** event_ids whose Meta cell is expanded. A Set lets any number of rows
   *  stay expanded at once for side-by-side analysis. */
  readonly expandedMeta = new Set<string>();

  readonly levels: AuditLevel[] = ['INFO', 'WARN', 'VIOLATION', 'CRITICAL'];
  readonly pageSize = 100;

  // Filters (bound to the form). `since` is a datetime-local value.
  since = this.daysAgoLocal(7);
  level: AuditLevel | '' = '';
  source = '';
  actor = '';
  ticket = '';
  offset = 0;

  constructor(
    private audit: AuditService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Deep links (e.g. from a ticket view → /audit/events?ticket=INC0012345)
    // pre-fill the filters. A ticket trail can span far back, so widen the
    // default time window when arriving by ticket and no explicit since.
    const q = this.route.snapshot.queryParamMap;
    const ticket = q.get('ticket') ?? q.get('ticket_ref');
    if (ticket) {
      this.ticket = ticket;
      this.since = this.daysAgoLocal(365);
    }
    if (q.get('source')) this.source = q.get('source') as string;
    if (q.get('actor')) this.actor = q.get('actor') as string;
    const level = q.get('level');
    if (level && (this.levels as string[]).includes(level)) {
      this.level = level as AuditLevel;
    }
    if (q.get('since')) this.since = q.get('since') as string;
    this.load();
  }

  apply(): void {
    this.offset = 0;
    this.load();
  }

  next(): void {
    if (this.hasMore) {
      this.offset += this.pageSize;
      this.load();
    }
  }

  prev(): void {
    if (this.offset > 0) {
      this.offset = Math.max(0, this.offset - this.pageSize);
      this.load();
    }
  }

  /** The server caps at pageSize; a full page implies there may be more. */
  get hasMore(): boolean {
    return this.events.length === this.pageSize;
  }

  get pageLabel(): string {
    const start = this.events.length === 0 ? 0 : this.offset + 1;
    return `${start}–${this.offset + this.events.length}`;
  }

  levelClass(level: string): string {
    return levelBadgeClass(level);
  }

  /** Compact single-line form shown when a Meta cell is collapsed. */
  metaText(meta: Record<string, unknown> | null): string {
    if (!this.hasMeta(meta)) return '';
    return JSON.stringify(meta);
  }

  /** Indented multi-line form shown when a Meta cell is expanded. */
  metaPretty(meta: Record<string, unknown> | null): string {
    if (!this.hasMeta(meta)) return '';
    return JSON.stringify(meta, null, 2);
  }

  hasMeta(meta: Record<string, unknown> | null): boolean {
    return !!meta && Object.keys(meta).length > 0;
  }

  isMetaExpanded(id: string): boolean {
    return this.expandedMeta.has(id);
  }

  /** Toggle one row's Meta cell; others stay as they are. */
  toggleMeta(id: string): void {
    if (this.expandedMeta.has(id)) this.expandedMeta.delete(id);
    else this.expandedMeta.add(id);
  }

  private load(): void {
    this.loading = true;
    this.error = '';
    this.expandedMeta.clear();
    const query: EventsQuery = {
      since: this.toIso(this.since),
      level: this.level || undefined,
      source: this.source.trim() || undefined,
      actor: this.actor.trim() || undefined,
      ticket_ref: this.ticket.trim() || undefined,
      limit: this.pageSize,
      offset: this.offset,
    };
    this.audit.events(query).subscribe({
      next: (rows) => {
        this.events = rows;
        this.loading = false;
      },
      error: (e) => {
        this.error = describeAuditError(e);
        this.events = [];
        this.loading = false;
      },
    });
  }

  /** datetime-local value (yyyy-MM-ddThh:mm) for `days` ago, in local time. */
  private daysAgoLocal(days: number): string {
    const d = new Date(Date.now() - days * 86_400_000);
    const off = d.getTimezoneOffset() * 60_000;
    return new Date(d.getTime() - off).toISOString().slice(0, 16);
  }

  private toIso(localValue: string): string {
    if (!localValue) return new Date(Date.now() - 7 * 86_400_000).toISOString();
    return new Date(localValue).toISOString();
  }
}
