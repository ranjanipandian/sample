import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '@env/environment';

import { AuditEvent, AuditIncident, AuditSummary, EventsQuery } from '../models/audit.model';

/**
 * Calls the Cognizant Audit Server query API via the same-origin /api/audit
 * proxy. The session JWT is attached by authInterceptor; the audit server maps
 * the caller's identity role to its RBAC and returns only what that role may see.
 */
@Injectable({ providedIn: 'root' })
export class AuditService {
  private readonly base = environment.auditBaseUrl;

  constructor(private http: HttpClient) {}

  summary(): Observable<AuditSummary> {
    return this.http.get<AuditSummary>(`${this.base}/summary`);
  }

  events(query: EventsQuery): Observable<AuditEvent[]> {
    return this.http.get<AuditEvent[]>(`${this.base}/events`, {
      params: this.toParams(query as Record<string, unknown>),
    });
  }

  incidents(
    opts: { status?: string; severity?: string; limit?: number; offset?: number } = {}
  ): Observable<AuditIncident[]> {
    return this.http.get<AuditIncident[]>(`${this.base}/incidents`, {
      params: this.toParams(opts as Record<string, unknown>),
    });
  }

  incidentEvents(correlationId: string): Observable<AuditEvent[]> {
    return this.http.get<AuditEvent[]>(
      `${this.base}/incidents/${encodeURIComponent(correlationId)}/events`
    );
  }

  /** Drop empty/undefined values so they don't become "?x=" noise. */
  private toParams(obj: Record<string, unknown>): HttpParams {
    let params = new HttpParams();
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined && value !== null && value !== '') {
        params = params.set(key, String(value));
      }
    }
    return params;
  }
}
