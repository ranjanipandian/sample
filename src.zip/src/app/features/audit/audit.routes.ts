import { Routes } from '@angular/router';

export const AUDIT_ROUTES: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  {
    path: 'dashboard',
    loadComponent: () =>
      import('./audit-dashboard/audit-dashboard.component').then((m) => m.AuditDashboardComponent),
  },
  {
    path: 'events',
    loadComponent: () =>
      import('./events-table/events-table.component').then((m) => m.EventsTableComponent),
  },
  {
    path: 'incidents',
    loadComponent: () =>
      import('./incidents-list/incidents-list.component').then((m) => m.IncidentsListComponent),
  },
];
