import { Routes } from '@angular/router';

export const MEMORY_GRAPH_ROUTES: Routes = [
  {
    path: 'ingestion',
    loadComponent: () =>
      import('./ingestion-pipeline/ingestion-pipeline.component').then(
        (m) => m.IngestionPipelineComponent
      ),
  },
];
