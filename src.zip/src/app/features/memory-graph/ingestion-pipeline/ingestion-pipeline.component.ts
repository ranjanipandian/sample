import { CommonModule } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';

import { INGESTION_AGENTS, IngestionAgent, EXTRACTION_JSON_EXAMPLE } from '@core/models/memory-graph-blueprint.model';
import {
  SAMPLE_GRAPH_EDGES,
  SAMPLE_GRAPH_NODES,
  GraphNode,
} from '@core/models/memory-graph-data.model';
import { GraphViewComponent } from '@shared/components/graph-view/graph-view.component';

/**
 * Workflow A — continuous ingestion & graph update, animated end to end.
 *
 * Walks the same 9-agent pipeline defined in the TL's blueprint
 * (INGESTION_AGENTS) against one concrete document — the mAb-114 18-month
 * stability report that produced the DEV-2291 story already used across
 * stability.model.ts and the Provenance Trail. As each stage "completes,"
 * a callout shows what that agent actually did on this document, and once
 * the Graph Publisher stage fires, nodes progressively appear in the
 * embedded graph-view component — visually closing the loop from
 * "raw report" to "queryable graph."
 *
 * This is a scripted, deterministic animation (no backend, no real LLM
 * calls) — the same "reference architecture rendered as UI" approach used
 * throughout the rest of the virtual lab.
 */

type StageStatus = 'pending' | 'active' | 'done';

interface StageCallout {
  title: string;
  body: string;
}

@Component({
  selector: 'app-ingestion-pipeline',
  standalone: true,
  imports: [CommonModule, GraphViewComponent],
  templateUrl: './ingestion-pipeline.component.html',
  styleUrls: ['./ingestion-pipeline.component.scss'],
})
export class IngestionPipelineComponent implements OnDestroy {
  readonly agents: IngestionAgent[] = INGESTION_AGENTS;
  readonly extractionJsonExample = EXTRACTION_JSON_EXAMPLE;

  readonly graphNodes: GraphNode[] = SAMPLE_GRAPH_NODES;
  readonly graphEdges = SAMPLE_GRAPH_EDGES;

  /**
   * Nodes revealed early — around the Entity Resolution / Ontology Alignment
   * stages (5–6) — representing context the graph already "knows" (prior
   * results, the people/agents involved) so the graph pane feels alive
   * well before the Graph Publisher stage fires.
   */
  private readonly earlyRevealOrder: string[] = [
    'result-12m-hmw',
    'agent-fischer',
    'result-18m-r1-hmw',
    'dev-2291',
  ];

  /** Remaining nodes, written once the Graph Publisher agent (stage 8) actually runs. */
  private readonly publisherRevealOrder: string[] = [
    'evidence-acc-trend',
    'result-18m-r2-hmw',
    'hyp-114lt-18m-01',
    'decision-114lt-18m',
    'agent-kessler',
    'agent-mg-reasoning',
  ];


  running = false;
  finished = false;
  currentStageIndex = -1;
  revealedIds: string[] = [];
  selectedNode: GraphNode | null = null;

  readonly sourceDocument = {
    title: 'mAb-114 Long-Term Stability Report — 18-Month Pull',
    subtitle: 'DEV-2291 column-performance deviation, SEC-HMW OOS investigation',
  };

  private timers: ReturnType<typeof setTimeout>[] = [];

  readonly stageCallouts: Record<string, StageCallout> = {
    'source-monitor': {
      title: 'New source detected',
      body: '18-Month Stability Report (PDF export from IDBS) picked up from the ELN watch folder, alongside the linked DEV-2291 deviation record.',
    },
    classifier: {
      title: 'Classified as',
      body: '"Stability report + linked deviation record" — routed to the scientific-document extraction path, not the generic-document path.',
    },
    parser: {
      title: 'Parsed into',
      body: 'Canonical text sections, the SEC results table (12M/18M-R1/18M-R2), and deviation metadata — original units and column headers preserved.',
    },
    extractor: {
      title: 'Candidate JSON produced',
      body: 'Grounded + reasoning-object extraction passes over section 4.2 produced typed candidates for Result, FailureEvent and Hypothesis objects (see JSON below).',
    },
    'entity-resolution': {
      title: 'Entities reconciled',
      body: '"mAb-114", "OpenLab-HPLC-04" and "DEV-2291" resolved against existing graph entities from the 12-month run and the accelerated study — same molecule, same instrument, same deviation.',
    },
    'ontology-alignment': {
      title: 'Mapped to ontology',
      body: 'Extracted items aligned to mg:Result, mg:FailureEvent, mg:Hypothesis, mg:Decision and prov:Agent classes from the Memory Graph ontology.',
    },
    validation: {
      title: 'Validated',
      body: 'Schema + unit checks passed; confidence thresholds met for the hypothesis (0.87); no duplicate or contradiction detected against existing graph state.',
    },
    'graph-publisher': {
      title: 'Writing to graph',
      body: 'Approved triples published to the named graph with full PROV-O provenance — watch the nodes appear on the right.',
    },
    reflection: {
      title: 'Reflection complete',
      body: 'No unmapped concepts or recurring extraction errors found this run — ontology v0.1 remains sufficient for this document type.',
    },
  };

  activeCallout: StageCallout | null = null;

  constructor(private router: Router) {}

  stageStatus(agent: IngestionAgent): StageStatus {
    const idx = this.agents.findIndex((a) => a.id === agent.id);
    if (idx < this.currentStageIndex) return 'done';
    if (idx === this.currentStageIndex) return 'active';
    return 'pending';
  }

  runIngestion(): void {
    if (this.running) return;
    this.clearTimers();
    this.running = true;
    this.finished = false;
    this.currentStageIndex = -1;
    this.revealedIds = [];
    this.activeCallout = null;
    this.selectedNode = null;

    const stepDurationMs = 1400;

    this.agents.forEach((agent, i) => {
      const t = setTimeout(() => {
        this.currentStageIndex = i;
        this.activeCallout = this.stageCallouts[agent.id] ?? null;

        // Reveal "already known" context nodes early — as soon as Entity
        // Resolution runs — so the graph pane feels alive well before the
        // Graph Publisher stage, instead of sitting empty for ~10s.
        if (agent.id === 'entity-resolution') {
          this.revealNodesProgressively(this.earlyRevealOrder);
        }

        if (agent.id === 'graph-publisher') {
          this.revealNodesProgressively(this.publisherRevealOrder);
        }

        if (i === this.agents.length - 1) {
          const doneT = setTimeout(() => {
            this.running = false;
            this.finished = true;
          }, stepDurationMs);
          this.timers.push(doneT);
        }
      }, i * stepDurationMs);
      this.timers.push(t);
    });
  }

  private revealNodesProgressively(ids: string[]): void {
    const perNodeMs = 220;
    ids.forEach((id, idx) => {
      const t = setTimeout(() => {
        if (!this.revealedIds.includes(id)) {
          this.revealedIds = [...this.revealedIds, id];
        }
      }, idx * perNodeMs);
      this.timers.push(t);
    });
  }


  reset(): void {
    this.clearTimers();
    this.running = false;
    this.finished = false;
    this.currentStageIndex = -1;
    this.revealedIds = [];
    this.activeCallout = null;
    this.selectedNode = null;
  }

  onNodeSelected(node: GraphNode): void {
    this.selectedNode = node;
  }

  private clearTimers(): void {
    this.timers.forEach((t) => clearTimeout(t));
    this.timers = [];
  }

  ngOnDestroy(): void {
    this.clearTimers();
  }

  back(): void {
    this.router.navigate(['/landscape/whitepaper'], { queryParams: { section: 'workflows' } });
  }

}
