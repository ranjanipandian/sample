import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { forkJoin, Subscription } from 'rxjs';

import {
  McpCatalogResponse,
  McpServerView,
  McpToolRow,
  McpToolStatus,
  MyToolsResponse,
  ToolAccessAction,
} from '@core/models/mcp.model';
import { AuthService } from '@core/services/auth.service';
import { McpToolsService } from '@core/services/mcp-tools.service';

@Component({
  selector: 'app-mcp-tools',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './mcp-tools.component.html',
  styleUrls: ['./mcp-tools.component.scss'],
})
export class McpToolsComponent implements OnInit, OnDestroy {
  loading = false;
  error: string | null = null;

  role = '';
  selfServiceEnabled = true;
  servers: McpServerView[] = [];

  /** Free-text filter over tool + server names. */
  query = '';

  private subs: Subscription[] = [];

  constructor(
    private api: McpToolsService,
    private auth: AuthService
  ) {}

  /** Logged-in user's email — whose access this page manages. */
  get email(): string {
    return this.auth.user.email;
  }

  ngOnInit(): void {
    this.refresh();
  }

  ngOnDestroy(): void {
    this.subs.forEach((s) => s.unsubscribe());
  }

  refresh(): void {
    this.loading = true;
    this.error = null;
    this.subs.push(
      forkJoin({
        catalog: this.api.getCatalog(),
        mine: this.api.getMyTools(),
      }).subscribe({
        next: ({ catalog, mine }) => {
          this.role = mine.role;
          this.selfServiceEnabled = mine.self_service_enabled;
          this.servers = this.merge(catalog, mine);
          this.loading = false;
        },
        error: () => {
          this.error =
            'Cannot load MCP tools. Check that the orchestrator and identity services are reachable.';
          this.loading = false;
        },
      })
    );
  }

  /**
   * Catalog drives the full tool list + descriptions; identity supplies the
   * caller's per-tool status. Keyed by server_name + tool name. Anything that
   * exists only in identity is appended so nothing the user already controls
   * is hidden.
   */
  private merge(catalog: McpCatalogResponse, mine: MyToolsResponse): McpServerView[] {
    const mineByServer = new Map(mine.servers.map((s) => [s.server_name, s]));
    const views: McpServerView[] = [];

    for (const cat of catalog.servers) {
      const myServer = mineByServer.get(cat.server_name);
      const statusByTool = new Map((myServer?.tools ?? []).map((t) => [t.name, t]));
      const tools: McpToolRow[] = cat.tools.map((t) => {
        const mt = statusByTool.get(t.name);
        return {
          name: t.name,
          description: t.description,
          status: mt?.status ?? 'requestable',
          in_role_envelope: mt?.in_role_envelope ?? false,
        };
      });
      // Tools identity knows about but the catalog didn't surface.
      for (const mt of myServer?.tools ?? []) {
        if (!tools.some((t) => t.name === mt.name)) {
          tools.push({
            name: mt.name,
            description: '',
            status: mt.status,
            in_role_envelope: mt.in_role_envelope,
          });
        }
      }
      tools.sort((a, b) => a.name.localeCompare(b.name));
      views.push({ server_name: cat.server_name, style: cat.style, tools, expanded: true });
      mineByServer.delete(cat.server_name);
    }

    // Servers only identity knows about (no live catalog entry).
    for (const myServer of mineByServer.values()) {
      const tools: McpToolRow[] = myServer.tools
        .map((mt) => ({
          name: mt.name,
          description: '',
          status: mt.status,
          in_role_envelope: mt.in_role_envelope,
        }))
        .sort((a, b) => a.name.localeCompare(b.name));
      views.push({ server_name: myServer.server_name, style: 'unknown', tools, expanded: true });
    }

    views.sort((a, b) => a.server_name.localeCompare(b.server_name));
    return views;
  }

  toggle(server: McpServerView): void {
    server.expanded = !server.expanded;
  }

  filteredTools(server: McpServerView): McpToolRow[] {
    const q = this.query.trim().toLowerCase();
    if (!q) return server.tools;
    if (server.server_name.toLowerCase().includes(q)) return server.tools;
    return server.tools.filter(
      (t) => t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)
    );
  }

  /** Which segmented button is highlighted for the row's current status. */
  isActive(row: McpToolRow, action: ToolAccessAction): boolean {
    switch (action) {
      case 'enable':
        return row.status === 'enabled';
      case 'require_approval':
        return row.status === 'needs_approval' || row.status === 'pending_approval';
      case 'disable':
        // The red "Deny" segment reflects both a user opt-out and a governed
        // (supervisor/admin) role-level deny.
        return row.status === 'self_disabled' || row.status === 'denied';
    }
  }

  setAccess(server: McpServerView, row: McpToolRow, action: ToolAccessAction): void {
    if (!this.selfServiceEnabled || row.saving || this.isActive(row, action)) return;
    row.saving = true;
    row.note = undefined;
    this.subs.push(
      this.api.updateTool(server.server_name, row.name, action).subscribe({
        next: (res) => {
          row.status = res.status;
          row.note = res.message;
          row.saving = false;
        },
        error: () => {
          row.note = 'Update failed — please try again.';
          row.saving = false;
        },
      })
    );
  }

  pillClass(status: McpToolStatus): string {
    switch (status) {
      case 'enabled':
        return 'pill-g';
      case 'needs_approval':
      case 'pending_approval':
        return 'pill-y';
      case 'denied':
        return 'pill-r';
      default:
        return 'pill-gray';
    }
  }

  pillLabel(status: McpToolStatus): string {
    switch (status) {
      case 'enabled':
        return 'Allowed';
      case 'needs_approval':
        return 'Needs approval';
      case 'pending_approval':
        return 'Pending approval';
      case 'denied':
        return 'Denied';
      case 'self_disabled':
        return 'Disabled (you)';
      default:
        return 'Not granted';
    }
  }
}
