import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';

import { McpServerInfo, MyCredentialInfo } from '@core/models/credentials.model';
import { AuthService } from '@core/services/auth.service';
import { CredentialsService } from '@core/services/credentials.service';

/** One server card plus per-row form + UI state. */
interface ServerRow {
  server: McpServerInfo;
  configured: boolean;
  updatedAt: string | null;
  username: string;
  password: string;
  apiKey: string;
  applyToAll: boolean;
  saving: boolean;
}

@Component({
  selector: 'app-credentials',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './credentials.component.html',
  styleUrls: ['./credentials.component.scss'],
})
export class CredentialsComponent implements OnInit {
  loading = false;
  error: string | null = null;
  notice: string | null = null;
  rows: ServerRow[] = [];
  /** Supervisors may opt to apply a credential to every user. */
  isSupervisor = false;

  constructor(
    private api: CredentialsService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    this.isSupervisor = this.auth.user.role === 'SUPERVISOR';
    this.load();
  }

  load(): void {
    this.loading = true;
    this.error = null;
    forkJoin({
      catalog: this.api.listServers(),
      mine: this.api.getMyCredentials(),
    }).subscribe({
      next: ({ catalog, mine }) => {
        const byServer = new Map<string, MyCredentialInfo>(
          mine.credentials.map((c) => [c.server_name, c])
        );
        this.rows = catalog.servers.map((server) => {
          const cred = byServer.get(server.server_name);
          return {
            server,
            configured: !!cred?.is_active,
            updatedAt: cred?.updated_at ?? null,
            username: '',
            password: '',
            apiKey: '',
            applyToAll: false,
            saving: false,
          };
        });
        this.loading = false;
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.error = describe(err, 'Could not load your credentials.');
      },
    });
  }

  save(row: ServerRow): void {
    if (row.saving) return;
    const plaintext: Record<string, string> =
      row.server.auth_type === 'api_key'
        ? { api_key: row.apiKey }
        : { username: row.username, password: row.password };

    // The apply-to-all toggle is supervisor-only; ignore it for anyone else.
    const applyToAll = this.isSupervisor && row.applyToAll;

    row.saving = true;
    this.error = null;
    this.notice = null;
    this.api.updateCredential(row.server.server_name, plaintext, applyToAll).subscribe({
      next: (res) => {
        row.saving = false;
        row.configured = true;
        row.updatedAt = res.updated_at;
        row.username = '';
        row.password = '';
        row.apiKey = '';
        row.applyToAll = false;
        this.notice = `${row.server.display_name}: ${res.message}`;
      },
      error: (err: HttpErrorResponse) => {
        row.saving = false;
        this.error = describe(err, `Could not save ${row.server.display_name} credentials.`);
      },
    });
  }

  canSave(row: ServerRow): boolean {
    if (row.saving) return false;
    if (row.server.auth_type === 'api_key') return row.apiKey.trim().length > 0;
    return row.username.trim().length > 0 && row.password.trim().length > 0;
  }

  formatUpdated(iso: string | null): string {
    if (!iso) return '';
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? '' : d.toLocaleDateString();
  }
}

// ── utilities ────────────────────────────────────────────────────────────────

function describe(err: HttpErrorResponse, fallback: string): string {
  const d = err?.error?.detail;
  if (d && typeof d === 'object' && !Array.isArray(d)) {
    if (d.message) return `${fallback} (${d.message})`;
    if (d.error) return `${fallback} (${d.error})`;
  }
  if (typeof d === 'string') return `${fallback} (${d})`;
  if (err?.status === 0) return `${fallback} (identity service unreachable)`;
  if (err?.status) return `${fallback} (HTTP ${err.status})`;
  return fallback;
}
