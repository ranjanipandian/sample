import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { PendingApproval } from '@core/models/approvals.model';
import { ApprovalsService } from '@core/services/approvals.service';

/** A pending request plus per-row UI state (reason input + in-flight flag). */
interface ApprovalRow extends PendingApproval {
  reason: string;
  saving: boolean;
}

@Component({
  selector: 'app-tool-approvals',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './tool-approvals.component.html',
  styleUrls: ['./tool-approvals.component.scss'],
})
export class ToolApprovalsComponent implements OnInit {
  loading = false;
  error: string | null = null;
  notice: string | null = null;
  rows: ApprovalRow[] = [];

  constructor(private approvals: ApprovalsService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.error = null;
    this.approvals.listPending().subscribe({
      next: (res) => {
        this.rows = res.pending.map((p) => ({ ...p, reason: '', saving: false }));
        this.loading = false;
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.error = describe(err, 'Could not load the approval queue.');
      },
    });
  }

  approve(row: ApprovalRow): void {
    this.decide(row, 'approve');
  }

  reject(row: ApprovalRow): void {
    this.decide(row, 'reject');
  }

  private decide(row: ApprovalRow, decision: 'approve' | 'reject'): void {
    if (row.saving) return;
    row.saving = true;
    this.error = null;
    this.notice = null;
    this.approvals.decide(row.auth_id, decision, row.reason).subscribe({
      next: (res) => {
        this.rows = this.rows.filter((r) => r.auth_id !== row.auth_id);
        const verb = decision === 'approve' ? 'approved' : 'rejected';
        this.notice = `${res.tool_name} on ${res.server_name} ${verb} for ${row.user_email} (now ${res.effective_access}).`;
      },
      error: (err: HttpErrorResponse) => {
        row.saving = false;
        this.error = describe(err, `Could not ${decision} this request.`);
      },
    });
  }

  roleClass(role: string): string {
    switch (role) {
      case 'L1':
        return 'b-blue';
      case 'L1.5':
        return 'b-yellow';
      case 'L2':
        return 'b-green';
      default:
        return 'b-gray';
    }
  }

  /** Human-friendly request age, e.g. "2h ago" / "3d ago". */
  requestedAgo(iso: string): string {
    const then = new Date(iso).getTime();
    if (Number.isNaN(then)) return iso;
    const mins = Math.max(0, Math.round((Date.now() - then) / 60000));
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.round(hrs / 24)}d ago`;
  }
}

// ── utilities ────────────────────────────────────────────────────────────────

function describe(err: HttpErrorResponse, fallback: string): string {
  const d = err?.error?.detail;
  if (d) {
    if (typeof d === 'object' && !Array.isArray(d) && d.error) {
      return `${fallback} (${d.error})`;
    }
    if (typeof d === 'string') return `${fallback} (${d})`;
  }
  if (err?.status === 403) return `${fallback} (supervisor role required)`;
  if (err?.status === 0) return `${fallback} (identity service unreachable)`;
  if (err?.status) return `${fallback} (HTTP ${err.status})`;
  return fallback;
}
