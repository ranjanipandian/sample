import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

import { SUPPORT_TIERS, SupportEngineer, SupportTier } from '@core/models/team-roles.model';
import { TeamRolesService } from '@core/services/team-roles.service';

/** A support engineer plus per-row UI state (in-flight flag). */
interface UserRow extends SupportEngineer {
  saving: boolean;
}

@Component({
  selector: 'app-team-roles',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './team-roles.component.html',
  styleUrls: ['./team-roles.component.scss'],
})
export class TeamRolesComponent implements OnInit {
  readonly tiers = SUPPORT_TIERS;
  loading = false;
  error: string | null = null;
  notice: string | null = null;
  rows: UserRow[] = [];

  constructor(private api: TeamRolesService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.error = null;
    this.api.getSupportEngineers().subscribe({
      next: (res) => {
        this.rows = res.users.map((u) => ({ ...u, saving: false }));
        this.loading = false;
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.error = describe(err, 'Could not load support engineers.');
      },
    });
  }

  setTier(row: UserRow, tier: SupportTier): void {
    if (row.saving || row.current_role === tier) return;
    row.saving = true;
    this.error = null;
    this.notice = null;
    const previous = row.current_role;
    this.api.setRole(row.email, tier).subscribe({
      next: (res) => {
        row.current_role = res.role;
        row.saving = false;
        this.notice = `${row.name || row.email} moved ${res.previous_role} → ${res.role}. Takes effect on their next sign-in refresh.`;
      },
      error: (err: HttpErrorResponse) => {
        row.current_role = previous;
        row.saving = false;
        this.error = describe(err, `Could not change ${row.email}'s tier.`);
      },
    });
  }

  roleClass(role: string): string {
    switch (role) {
      case 'L1':
        return 'b-blue';
      case 'L1.5':
        return 'b-yellow';
      case 'L2':
        return 'b-green';
      default:
        return 'b-gray';
    }
  }

  initials(name: string, email: string): string {
    const src = (name || email || '').trim();
    if (!src) return '?';
    const parts = src.split(/\s+/);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return src.slice(0, 2).toUpperCase();
  }
}

// ── utilities ────────────────────────────────────────────────────────────────

function describe(err: HttpErrorResponse, fallback: string): string {
  const d = err?.error?.detail;
  if (d && typeof d === 'object' && !Array.isArray(d) && d.error) {
    if (d.error === 'TIER_SCOPE') return `${fallback} (supervisors can only set L1/L1.5/L2)`;
    return `${fallback} (${d.error})`;
  }
  if (typeof d === 'string') return `${fallback} (${d})`;
  if (err?.status === 403) return `${fallback} (supervisor role required)`;
  if (err?.status === 0) return `${fallback} (identity service unreachable)`;
  if (err?.status) return `${fallback} (HTTP ${err.status})`;
  return fallback;
}
