import { Routes } from '@angular/router';

import { supervisorGuard } from '@core/guards/supervisor.guard';

export const SETTINGS_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('@layouts/settings-shell/settings-shell.component').then(
        (m) => m.SettingsShellComponent
      ),
    children: [
      { path: '', redirectTo: 'connectors', pathMatch: 'full' },
      {
        path: 'connectors',
        loadComponent: () =>
          import('@features/connectors/connectors.component').then((m) => m.ConnectorsComponent),
      },
      {
        path: 'mcp-tools',
        loadComponent: () =>
          import('@features/settings/mcp-tools/mcp-tools.component').then(
            (m) => m.McpToolsComponent
          ),
      },
      {
        path: 'tool-approvals',
        canActivate: [supervisorGuard],
        loadComponent: () =>
          import('@features/settings/tool-approvals/tool-approvals.component').then(
            (m) => m.ToolApprovalsComponent
          ),
      },
      {
        path: 'credentials',
        loadComponent: () =>
          import('@features/settings/credentials/credentials.component').then(
            (m) => m.CredentialsComponent
          ),
      },
      {
        path: 'team-roles',
        canActivate: [supervisorGuard],
        loadComponent: () =>
          import('@features/settings/team-roles/team-roles.component').then(
            (m) => m.TeamRolesComponent
          ),
      },
    ],
  },
];
