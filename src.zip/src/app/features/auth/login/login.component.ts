import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  Component,
  ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { AuthService, AuthUser } from '@core/services/auth.service';

type LoginTab = 'sso' | 'user';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
}

interface TabDef {
  id: LoginTab;
  label: string;
  icon: 'briefcase' | 'user';
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('bgCanvas') bgCanvas!: ElementRef<HTMLCanvasElement>;

  activeTab: LoginTab = 'sso';
  loading = false;
  error = '';

  emailInput = '';
  passwordInput = '';

  /** Current ALB-OIDC identity (kept for forward-compat; not gated on for navigation). */
  user: AuthUser;

  readonly tabs: TabDef[] = [
    { id: 'sso', label: 'SSO Login', icon: 'briefcase' },
    { id: 'user', label: 'User Login', icon: 'user' },
  ];

  readonly complianceTags = ['ITIL v4', 'ISO 20000', 'AIOps', 'HITL Enabled'];

  /** Role labels only — no emails (demo accounts are visual placeholders). */
  readonly demoRoles = ['Admin', 'Support Engineer', 'Engineer', 'Guest'];

  private ctx: CanvasRenderingContext2D | null = null;
  private points: Particle[] = [];
  private width = 0;
  private height = 0;
  private rafId = 0;
  private authSub?: Subscription;

  constructor(
    private router: Router,
    private authService: AuthService
  ) {
    this.user = this.authService.user;
  }

  ngOnInit(): void {
    // The silent-refresh bootstrap (APP_INITIALIZER in main.ts) already ran, so
    // user is populated here. Subscribe for live updates only.
    this.authSub = this.authService.user$.subscribe((u) => (this.user = u));
  }

  ngAfterViewInit(): void {
    const canvas = this.bgCanvas.nativeElement;
    this.ctx = canvas.getContext('2d');
    this.resize();
    this.draw();
  }

  ngOnDestroy(): void {
    cancelAnimationFrame(this.rafId);
    this.authSub?.unsubscribe();
  }

  switchTab(id: LoginTab): void {
    this.activeTab = id;
    this.error = '';
  }

  /**
   * Virtual-lab SSO login. This demo app is not wired to a real enterprise
   * IdP, so "Continue with SSO" establishes a local mock session directly
   * (see AuthService.mockLogin) instead of redirecting to an external OIDC
   * authorize page, then takes the user straight into the Dashboard.
   */
  doSsoLogin(): void {
    this.loading = true;
    this.error = '';
    this.authService.mockLogin('Admin', 'Demo User');
    this.router.navigateByUrl('/dashboard');
  }

  /**
   * The demo email/password login is retired — all sign-in now flows through
   * the same virtual-lab SSO session as the SSO tab.
   */
  doUserLogin(): void {
    this.doSsoLogin();
  }

  @HostListener('window:resize')
  resize(): void {
    const canvas = this.bgCanvas?.nativeElement;
    if (!canvas) return;
    this.width = canvas.width = window.innerWidth;
    this.height = canvas.height = window.innerHeight;
    this.points = Array.from({ length: 55 }, () => ({
      x: Math.random() * this.width,
      y: Math.random() * this.height,
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      r: Math.random() * 1.8 + 0.8,
    }));
  }

  private draw = (): void => {
    const ctx = this.ctx;
    if (!ctx) return;
    const W = this.width;
    const H = this.height;

    // Transparent canvas — CSS gradient on .ls-root shows through underneath.
    ctx.clearRect(0, 0, W, H);

    this.points.forEach((p) => {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1;
      if (p.y < 0 || p.y > H) p.vy *= -1;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(155, 180, 255, 0.55)';
      ctx.fill();
    });

    for (let i = 0; i < this.points.length; i++) {
      for (let j = i + 1; j < this.points.length; j++) {
        const a = this.points[i];
        const b = this.points[j];
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < 130) {
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.strokeStyle = `rgba(155, 180, 255, ${0.15 * (1 - d / 130)})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }

    this.rafId = requestAnimationFrame(this.draw);
  };
}
