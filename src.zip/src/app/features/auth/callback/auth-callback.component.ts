import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthService } from '@core/services/auth.service';

/**
 * OIDC redirect landing route (/auth/callback). The enterprise IdP redirected
 * the browser here with ?code & ?state. We hand those to AuthService, which
 * exchanges them (same-origin, via the nginx-proxied identity callback) for the
 * session token, then navigate to the remembered post-login URL.
 */
@Component({
  selector: 'app-auth-callback',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="callback">
      <p *ngIf="!error">Signing you in…</p>
      <p *ngIf="error" class="error">Sign-in failed. Redirecting to login…</p>
    </div>
  `,
  styles: [
    `
      .callback {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        font-family: sans-serif;
      }
      .error {
        color: #b00020;
      }
    `,
  ],
})
export class AuthCallbackComponent implements OnInit {
  error = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private auth: AuthService
  ) {}

  async ngOnInit(): Promise<void> {
    const code = this.route.snapshot.queryParamMap.get('code');
    const state = this.route.snapshot.queryParamMap.get('state');

    if (!code || !state) {
      this.fail();
      return;
    }

    try {
      await this.auth.handleCallback(code, state);
      const target = this.auth.consumePostLoginRedirect();
      // Replace history so the callback URL (with code/state) isn't re-triggered
      // on a back navigation.
      await this.router.navigateByUrl(target, { replaceUrl: true });
    } catch {
      this.fail();
    }
  }

  private fail(): void {
    this.error = true;
    setTimeout(() => this.router.navigateByUrl('/login', { replaceUrl: true }), 1500);
  }
}
