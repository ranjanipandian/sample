import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { BatchJourneyService } from '@core/services/batch-journey.service';

import {
  BANDS,
  Band,
  BatchJourney,
  isBandActiveForStage,
  PipelineStageRun,
  STAGES,
  Stage,
  SYSTEM_INFO,
  TOP_BANNER,
} from '@core/models/landscape.model';

@Component({
  selector: 'app-landscape-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './landscape-home.component.html',
  styleUrls: ['./landscape-home.component.scss'],
})
export class LandscapeHomeComponent implements OnInit, OnDestroy {
  readonly banner = TOP_BANNER;
  readonly stages: Stage[] = STAGES;
  readonly bands: Band[] = BANDS;

  /** Live batch journey — reflects the mock "Upload Batch Data" action
   *  instantly, here and in the sidebar's "CMC Pipeline Stages" stepper. */
  journey: BatchJourney;

  /** Which stage's detail panel is currently expanded below the stepper. */
  selectedStageOrder: number;

  // ── Upload Batch Data modal (mock — no real backend/parsing yet) ──
  uploadOpen = false;
  uploadMolecule = '';
  uploadLotNumber = '';
  uploadModality = '';
  uploadFileName = '';

  private journeySub?: Subscription;

  constructor(
    private router: Router,
    public batchJourney: BatchJourneyService
  ) {
    this.journey = this.batchJourney.journey;
    this.selectedStageOrder = this.journey.currentStageOrder;
  }

  ngOnInit(): void {
    this.journeySub = this.batchJourney.journey$.subscribe((j) => {
      this.journey = j;
      this.selectedStageOrder = j.currentStageOrder;
    });
  }

  ngOnDestroy(): void {
    this.journeySub?.unsubscribe();
  }

  systemName(key: string): string {
    return SYSTEM_INFO[key]?.name ?? key;
  }

  isAi(key: string): boolean {
    return !!SYSTEM_INFO[key]?.aiEnabled;
  }

  stageRun(stage: Stage): PipelineStageRun | undefined {
    return this.batchJourney.getStageRun(stage.id);
  }

  selectStage(stage: Stage): void {
    this.selectedStageOrder = stage.order;
  }

  get selectedStage(): Stage | undefined {
    return this.stages.find((s) => s.order === this.selectedStageOrder);
  }

  get selectedStageRun(): PipelineStageRun | undefined {
    const stage = this.selectedStage;
    return stage ? this.stageRun(stage) : undefined;
  }

  stepDotClass(stage: Stage): string {
    const run = this.stageRun(stage);
    const base = 'step-dot';
    if (!run) return base + ' step-dot--upcoming';
    if (stage.order === this.selectedStageOrder) return base + ' step-dot--selected';
    return base + ' step-dot--' + run.status;
  }

  stepLineClass(stage: Stage): string {
    const run = this.stageRun(stage);
    if (run && run.status === 'complete') return 'step-line step-line--complete';
    return 'step-line';
  }

  gateBadgeClass(run: PipelineStageRun | undefined): string {
    if (!run?.gateDecision) return '';
    switch (run.gateDecision.verdict) {
      case 'passed':
        return 'gate-pill gate-pill--passed';
      case 'hold':
        return 'gate-pill gate-pill--hold';
      default:
        return 'gate-pill gate-pill--deviation';
    }
  }

  isBandActive(band: Band): boolean {
    return isBandActiveForStage(band, this.selectedStageOrder);
  }

  openStageDetail(stage: Stage): void {
    this.router.navigateByUrl('/landscape/stage/' + stage.id);
  }

  openBand(band: Band): void {
    this.router.navigateByUrl('/landscape/band/' + band.id);
  }

  openSystem(key: string, event: Event): void {
    event.stopPropagation();
    this.router.navigateByUrl('/landscape/system/' + key);
  }

  goToStability(): void {
    this.router.navigateByUrl('/landscape/stability');
  }

  goToWhitepaper(): void {
    this.router.navigateByUrl('/landscape/whitepaper');
  }

  // ── Upload Batch Data (mock) ─────────────────────────────────────────

  openUpload(): void {
    this.uploadMolecule = '';
    this.uploadLotNumber = '';
    this.uploadModality = '';
    this.uploadFileName = '';
    this.uploadOpen = true;
  }

  closeUpload(): void {
    this.uploadOpen = false;
  }

  onUploadFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.uploadFileName = input.files && input.files.length ? input.files[0].name : '';
  }

  get canSubmitUpload(): boolean {
    return this.uploadMolecule.trim().length > 0 && this.uploadLotNumber.trim().length > 0;
  }

  submitUpload(): void {
    if (!this.canSubmitUpload) return;
    this.batchJourney.uploadBatch({
      molecule: this.uploadMolecule.trim(),
      lotNumber: this.uploadLotNumber.trim(),
      modality: this.uploadModality.trim() || undefined,
      fileName: this.uploadFileName || undefined,
    });
    this.uploadOpen = false;
  }

  /** Demo control — simulates the batch completing its current stage and
   *  moving into the next one, without a real backend driving transitions. */
  advanceStage(): void {
    this.batchJourney.advanceStage();
  }

  get hasActiveStage(): boolean {
    return this.batchJourney.hasActiveStage;
  }
}
