import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { BANDS, STAGES, SYSTEM_INFO, SystemInfo } from '@core/models/landscape.model';

@Component({
  selector: 'app-system-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './system-detail.component.html',
  styleUrls: ['./system-detail.component.scss'],
})
export class SystemDetailComponent implements OnInit, OnDestroy {
  system: SystemInfo | null = null;
  usedInStages: string[] = [];
  usedInBands: string[] = [];

  private routeSub?: Subscription;

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Subscribe to paramMap (not just the snapshot) — the router reuses
    // this component instance when navigating between sibling
    // /landscape/system/:key routes (e.g. clicking a different system link),
    // so ngOnInit alone would only ever populate the first system visited.
    this.routeSub = this.route.paramMap.subscribe((params) => {
      const key = params.get('key') || '';
      this.loadSystem(key);
    });
  }

  ngOnDestroy(): void {
    this.routeSub?.unsubscribe();
  }

  private loadSystem(key: string): void {
    this.system = SYSTEM_INFO[key] || null;

    this.usedInStages = STAGES.filter(
      (s) => s.systems.includes(key) || (s.aiSystems || []).includes(key)
    ).map((s) => s.name);

    this.usedInBands = BANDS.filter(
      (b) => b.systems.includes(key) || (b.aiSystems || []).includes(key)
    ).map((b) => b.name);
  }


  back(): void {
    this.router.navigateByUrl('/landscape');
  }

  gapBadgeClass(status: string): string {
    switch (status) {
      case 'captured':
        return 'gap-pill gap-pill--ok';
      case 'partial':
        return 'gap-pill gap-pill--partial';
      default:
        return 'gap-pill gap-pill--none';
    }
  }

  gapBadgeLabel(status: string): string {
    switch (status) {
      case 'captured':
        return 'Reasoning Captured';
      case 'partial':
        return 'Reasoning Partially Captured';
      default:
        return 'Reasoning Gap';
    }
  }
}
