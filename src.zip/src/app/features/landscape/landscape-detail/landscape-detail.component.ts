import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { BatchJourneyService } from '@core/services/batch-journey.service';

import {
  BANDS,
  Band,
  BatchJourney,
  isBandActiveForStage,
  PipelineStageRun,
  STAGES,
  Stage,
  SYSTEM_INFO,
  SystemInfo,
  TOP_BANNER,
} from '@core/models/landscape.model';


import {
  Experiment,
  FailureEvent,
  getExperimentsForStudy,
  getFailureEventsForStudy,
  getInsightComparison,
  getLab,
  InsightComparison,
  Lab,
  STUDIES,
  StabilityStudy,
} from '@core/models/stability.model';

interface DetailSystem extends SystemInfo {}

/** Stage IDs that carry the embedded Stability pilot deep-dive content. */
const STABILITY_STAGE_IDS = new Set(['drug-substance-mfg', 'drug-product-mfg']);

@Component({
  selector: 'app-landscape-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './landscape-detail.component.html',
  styleUrls: ['./landscape-detail.component.scss'],
})
export class LandscapeDetailComponent implements OnInit, OnDestroy {

  kind: 'stage' | 'band' = 'stage';
  stageId: string | null = null;
  title = '';
  order: number | null = null;
  systems: DetailSystem[] = [];
  aiSystems: DetailSystem[] = [];

  stageRun: PipelineStageRun | undefined;

  // ── Full Memory Graph journey view (batch strip, ticker, stepper, bands, CTAs) ──
  readonly banner = TOP_BANNER;
  readonly allStages: Stage[] = STAGES;
  readonly bands: Band[] = BANDS;
  journey: BatchJourney;
  /** Which stage's panel is expanded in the stepper — defaults to this page's own stage. */
  selectedStageOrder = 0;



  /** Whether this stage carries the embedded Stability pilot content. */
  hasStabilityContent = false;
  stabilityStudies: StabilityStudy[] = [];
  selectedStudy: StabilityStudy | null = null;
  selectedLab: Lab | null = null;
  selectedExperiments: Experiment[] = [];
  selectedFailures: FailureEvent[] = [];
  selectedComparison: InsightComparison | null = null;
  expandedFailureId: string | null = null;
  stabilityTab: 'experiments' | 'insights' | 'failures' = 'experiments';

  private routeSub?: Subscription;
  private journeySub?: Subscription;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private batchJourney: BatchJourneyService
  ) {
    this.journey = this.batchJourney.journey;
  }

  ngOnInit(): void {
    // Subscribe (not just snapshot) — the router reuses this component
    // instance when navigating between sibling routes of the same pattern
    // (e.g. clicking from one sidebar stage link to another), so ngOnInit
    // only fires once. Reading paramMap as an observable ensures the detail
    // content re-populates on every navigation, not just the first.
    this.routeSub = this.route.paramMap.subscribe((params) => {
      this.kind = (this.route.snapshot.data['kind'] as 'stage' | 'band') || 'stage';
      const id = params.get('id') || '';
      this.loadDetail(id);
    });

    this.journeySub = this.batchJourney.journey$.subscribe((j) => {
      this.journey = j;
      if (this.stageId) {
        this.stageRun = this.batchJourney.getStageRun(this.stageId);
      }
    });
  }

  ngOnDestroy(): void {
    this.routeSub?.unsubscribe();
    this.journeySub?.unsubscribe();
  }


  private loadDetail(id: string): void {
    // Reset state so stale content from a previous stage/band never lingers
    // while the new one is being populated.
    this.stageId = null;
    this.title = '';
    this.order = null;
    this.systems = [];
    this.aiSystems = [];
    this.stageRun = undefined;
    this.hasStabilityContent = false;
    this.stabilityStudies = [];
    this.selectedStudy = null;
    this.selectedLab = null;
    this.selectedExperiments = [];
    this.selectedFailures = [];
    this.selectedComparison = null;
    this.expandedFailureId = null;
    this.stabilityTab = 'experiments';

    if (this.kind === 'stage') {
      const stage = STAGES.find((s) => s.id === id);
      if (stage) {
        this.stageId = stage.id;
        this.title = stage.name;
        this.order = stage.order;
        this.systems = stage.systems.map((k) => SYSTEM_INFO[k]).filter(Boolean);
        this.aiSystems = (stage.aiSystems || []).map((k) => SYSTEM_INFO[k]).filter(Boolean);
        this.stageRun = this.batchJourney.getStageRun(stage.id);


        this.hasStabilityContent = STABILITY_STAGE_IDS.has(stage.id);
        if (this.hasStabilityContent) {
          this.stabilityStudies = STUDIES;
          this.selectStudy(STUDIES[0]);
        }

        // Journey stepper defaults to this page's own stage.
        this.selectedStageOrder = stage.order;
      }
    } else {

      const band = BANDS.find((b) => b.id === id);
      if (band) {
        this.title = band.name;
        this.systems = band.systems.map((k) => SYSTEM_INFO[k]).filter(Boolean);
        this.aiSystems = (band.aiSystems || []).map((k) => SYSTEM_INFO[k]).filter(Boolean);
      }
    }
  }


  openSystem(key: string, event?: Event): void {
    event?.stopPropagation();
    this.router.navigateByUrl('/landscape/system/' + key);
  }

  back(): void {
    this.router.navigateByUrl('/landscape');
  }

  openStageDetail(stage: Stage): void {
    this.router.navigateByUrl('/landscape/stage/' + stage.id);
  }


  gapBadgeClass(status: string): string {
    switch (status) {
      case 'captured':
        return 'gap-pill gap-pill--ok';
      case 'partial':
        return 'gap-pill gap-pill--partial';
      default:
        return 'gap-pill gap-pill--none';
    }
  }

  gapBadgeLabel(status: string): string {
    switch (status) {
      case 'captured':
        return 'Reasoning Captured';
      case 'partial':
        return 'Reasoning Partially Captured';
      default:
        return 'Reasoning Gap';
    }
  }

  gateBadgeClass(run: PipelineStageRun | undefined): string {
    if (!run?.gateDecision) return '';
    switch (run.gateDecision.verdict) {
      case 'passed':
        return 'gate-pill gate-pill--passed';
      case 'hold':
        return 'gate-pill gate-pill--hold';
      default:
        return 'gate-pill gate-pill--deviation';
    }
  }

  runStatusLabel(run: PipelineStageRun | undefined): string {
    if (!run) return 'Upcoming';
    if (run.status === 'complete') return 'Complete';
    if (run.status === 'current') return 'In Progress';
    return 'Upcoming';
  }

  runStatusClass(run: PipelineStageRun | undefined): string {
    if (!run) return 'run-status-pill run-status-pill--upcoming';
    if (run.status === 'complete') return 'run-status-pill run-status-pill--complete';
    if (run.status === 'current') return 'run-status-pill run-status-pill--current';
    return 'run-status-pill run-status-pill--upcoming';
  }

  isAi(key: string): boolean {
    return !!SYSTEM_INFO[key]?.aiEnabled;
  }

  systemName(key: string): string {
    return SYSTEM_INFO[key]?.name ?? key;
  }

  // ── Journey stepper (mirrors Memory Graph page) ──────────────────────

  stageRunFor(stage: Stage): PipelineStageRun | undefined {
    return this.batchJourney.getStageRun(stage.id);
  }


  selectJourneyStage(stage: Stage): void {
    this.selectedStageOrder = stage.order;
  }

  get selectedJourneyStage(): Stage | undefined {
    return this.allStages.find((s) => s.order === this.selectedStageOrder);
  }

  get selectedJourneyStageRun(): PipelineStageRun | undefined {
    const stage = this.selectedJourneyStage;
    return stage ? this.stageRunFor(stage) : undefined;
  }

  stepDotClass(stage: Stage): string {
    const run = this.stageRunFor(stage);
    const base = 'step-dot';
    if (!run) return base + ' step-dot--upcoming';
    if (stage.order === this.selectedStageOrder) return base + ' step-dot--selected';
    return base + ' step-dot--' + run.status;
  }

  stepLineClass(stage: Stage): string {
    const run = this.stageRunFor(stage);
    if (run && run.status === 'complete') return 'step-line step-line--complete';
    return 'step-line';
  }

  isBandActive(band: Band): boolean {
    return isBandActiveForStage(band, this.selectedStageOrder);
  }

  openBand(band: Band): void {
    this.router.navigateByUrl('/landscape/band/' + band.id);
  }

  goToStability(): void {
    this.router.navigateByUrl('/landscape/stability');
  }

  goToWhitepaper(): void {
    this.router.navigateByUrl('/landscape/whitepaper');
  }

  // ── Embedded Stability pilot content (Drug Substance / Drug Product stages) ──


  selectStudy(study: StabilityStudy): void {
    this.selectedStudy = study;
    this.selectedLab = getLab(study.labId) || null;
    this.selectedExperiments = getExperimentsForStudy(study.id);
    this.selectedFailures = getFailureEventsForStudy(study.id);
    this.selectedComparison = getInsightComparison(study.id) || null;
    this.expandedFailureId = null;
    this.stabilityTab = 'experiments';
  }

  setStabilityTab(tab: 'experiments' | 'insights' | 'failures'): void {
    this.stabilityTab = tab;
  }

  toggleFailure(id: string): void {
    this.expandedFailureId = this.expandedFailureId === id ? null : id;
  }

  expStatusPill(status: string): string {
    switch (status) {
      case 'pass':
        return 'exp-pill exp-pill--pass';
      case 'oos':
        return 'exp-pill exp-pill--oos';
      case 'oot':
        return 'exp-pill exp-pill--oot';
      default:
        return 'exp-pill exp-pill--fail';
    }
  }

  studyStatusPill(status: string): string {
    switch (status) {
      case 'ongoing':
        return 'st-pill st-pill--ongoing';
      case 'completed':
        return 'st-pill st-pill--completed';
      default:
        return 'st-pill st-pill--hold';
    }
  }

  openFullStabilityPilot(): void {
    this.router.navigateByUrl('/landscape/stability');
  }

  openProvenance(): void {
    if (this.selectedStudy) {
      this.router.navigateByUrl('/landscape/stability/provenance/' + this.selectedStudy.id);
    }
  }

  openRoi(): void {
    this.router.navigateByUrl('/landscape/stability/roi');
  }
}
