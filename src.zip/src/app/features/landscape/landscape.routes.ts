import { Routes } from '@angular/router';

export const LANDSCAPE_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./landscape-home/landscape-home.component').then((m) => m.LandscapeHomeComponent),
  },
  {
    path: 'stage/:id',
    loadComponent: () =>
      import('./landscape-detail/landscape-detail.component').then(
        (m) => m.LandscapeDetailComponent
      ),
    data: { kind: 'stage' },
  },
  {
    path: 'band/:id',
    loadComponent: () =>
      import('./landscape-detail/landscape-detail.component').then(
        (m) => m.LandscapeDetailComponent
      ),
    data: { kind: 'band' },
  },
  {
    path: 'system/:key',
    loadComponent: () =>
      import('./system-detail/system-detail.component').then((m) => m.SystemDetailComponent),
  },
  {
    path: 'stability',
    loadChildren: () => import('@features/stability/stability.routes').then((m) => m.STABILITY_ROUTES),
  },
  {
    path: 'whitepaper',
    loadChildren: () =>
      import('@features/whitepaper/whitepaper.routes').then((m) => m.WHITEPAPER_ROUTES),
  },
  {
    path: 'memory-graph',
    loadChildren: () =>
      import('@features/memory-graph/memory-graph.routes').then((m) => m.MEMORY_GRAPH_ROUTES),
  },
];




