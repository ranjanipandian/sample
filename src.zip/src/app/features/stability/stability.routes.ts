import { Routes } from '@angular/router';

export const STABILITY_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./stability-home/stability-home.component').then((m) => m.StabilityHomeComponent),
  },
  {
    path: 'study/:id',
    loadComponent: () =>
      import('./study-detail/study-detail.component').then((m) => m.StudyDetailComponent),
  },
  {
    path: 'roi',
    loadComponent: () =>
      import('./roi-impact/roi-impact.component').then((m) => m.RoiImpactComponent),
  },
  {
    path: 'provenance/:id',
    loadComponent: () =>
      import('./provenance-trail/provenance-trail.component').then(
        (m) => m.ProvenanceTrailComponent
      ),
  },
];
