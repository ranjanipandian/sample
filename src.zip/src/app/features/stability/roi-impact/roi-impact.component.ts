import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { PERSONA_IMPACTS, PersonaImpact, ROI_METRICS, RoiMetric } from '@core/models/stability.model';

@Component({
  selector: 'app-roi-impact',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './roi-impact.component.html',
  styleUrls: ['./roi-impact.component.scss'],
})
export class RoiImpactComponent {
  readonly roiMetrics: RoiMetric[] = ROI_METRICS;
  readonly personas: PersonaImpact[] = PERSONA_IMPACTS;

  constructor(private router: Router) {}

  back(): void {
    this.router.navigateByUrl('/landscape/stability');
  }

  goToWhitepaper(): void {
    this.router.navigateByUrl('/landscape/whitepaper');
  }
}


