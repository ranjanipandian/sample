import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { getProvenanceForStudy, getStudy, ProvenanceEvent, StabilityStudy } from '@core/models/stability.model';

@Component({
  selector: 'app-provenance-trail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './provenance-trail.component.html',
  styleUrls: ['./provenance-trail.component.scss'],
})
export class ProvenanceTrailComponent implements OnInit {
  study: StabilityStudy | null = null;
  events: ProvenanceEvent[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id') || '';
    this.study = getStudy(id) || null;
    this.events = getProvenanceForStudy(id);
  }

  actorIcon(type: string): string {
    return type === 'agent' ? 'ti ti-robot' : 'ti ti-user';
  }

  actorClass(type: string): string {
    return type === 'agent' ? 'prov-actor prov-actor--agent' : 'prov-actor prov-actor--human';
  }

  back(): void {
    if (this.study) {
      this.router.navigateByUrl('/landscape/stability/study/' + this.study.id);
    } else {
      this.router.navigateByUrl('/landscape/stability');
    }
  }
}
