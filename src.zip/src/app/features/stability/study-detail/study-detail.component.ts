import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import {
  Experiment,
  FailureEvent,
  getExperimentsForStudy,
  getFailureEventsForStudy,
  getInsightComparison,
  getLab,
  getStudy,
  InsightComparison,
  Lab,
  StabilityStudy,
} from '@core/models/stability.model';

@Component({
  selector: 'app-study-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './study-detail.component.html',
  styleUrls: ['./study-detail.component.scss'],
})
export class StudyDetailComponent implements OnInit {
  study: StabilityStudy | null = null;
  lab: Lab | null = null;
  experiments: Experiment[] = [];
  failures: FailureEvent[] = [];
  comparison: InsightComparison | null = null;

  activeTab: 'experiments' | 'insights' | 'failures' = 'experiments';
  expandedFailureId: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id') || '';
    this.study = getStudy(id) || null;
    if (this.study) {
      this.lab = getLab(this.study.labId) || null;
      this.experiments = getExperimentsForStudy(id);
      this.failures = getFailureEventsForStudy(id);
      this.comparison = getInsightComparison(id) || null;
    }
  }

  setTab(tab: 'experiments' | 'insights' | 'failures'): void {
    this.activeTab = tab;
  }

  toggleFailure(id: string): void {
    this.expandedFailureId = this.expandedFailureId === id ? null : id;
  }

  statusPill(status: string): string {
    switch (status) {
      case 'pass':
        return 'exp-pill exp-pill--pass';
      case 'oos':
        return 'exp-pill exp-pill--oos';
      case 'oot':
        return 'exp-pill exp-pill--oot';
      default:
        return 'exp-pill exp-pill--fail';
    }
  }

  openProvenance(): void {
    if (this.study) {
      this.router.navigateByUrl('/landscape/stability/provenance/' + this.study.id);
    }
  }

  back(): void {
    this.router.navigateByUrl('/landscape/stability');
  }
}
