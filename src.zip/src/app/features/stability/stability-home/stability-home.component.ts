import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { LABS, Lab, STUDIES, StabilityStudy } from '@core/models/stability.model';

@Component({
  selector: 'app-stability-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './stability-home.component.html',
  styleUrls: ['./stability-home.component.scss'],
})
export class StabilityHomeComponent {
  readonly labs: Lab[] = LABS;
  readonly studies: StabilityStudy[] = STUDIES;

  constructor(private router: Router) {}

  studiesForLab(lab: Lab): StabilityStudy[] {
    return this.studies.filter((s) => lab.studyIds.includes(s.id));
  }

  openStudy(study: StabilityStudy): void {
    this.router.navigateByUrl('/landscape/stability/study/' + study.id);
  }

  statusPill(status: string): string {
    switch (status) {
      case 'ongoing':
        return 'st-pill st-pill--ongoing';
      case 'completed':
        return 'st-pill st-pill--completed';
      default:
        return 'st-pill st-pill--hold';
    }
  }

  goToRoi(): void {
    this.router.navigateByUrl('/landscape/stability/roi');
  }

  back(): void {
    this.router.navigateByUrl('/landscape');
  }
}
