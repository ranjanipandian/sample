import { Routes } from '@angular/router';

export const ADMIN_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('@layouts/admin-shell/admin-shell.component').then((m) => m.AdminShellComponent),
    children: [
      { path: '', redirectTo: 'agents', pathMatch: 'full' },
      {
        path: 'agents',
        loadComponent: () =>
          import('@features/admin/agent-dashboard/agent-dashboard.component').then(
            (m) => m.AgentDashboardComponent
          ),
      },
      {
        path: 'mcp',
        loadComponent: () =>
          import('@features/admin/mcp-dashboard/mcp-dashboard.component').then(
            (m) => m.McpDashboardComponent
          ),
      },
      {
        path: 'command',
        loadComponent: () =>
          import('@features/admin/command-center/command-center.component').then(
            (m) => m.CommandCenterComponent
          ),
      },
    ],
  },
];
