import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

interface UserRow {
  name: string;
  role: 'Admin' | 'Engineer' | 'Guest';
  ticketsAccess: boolean;
  hitlAccess: boolean;
  adminAccess: boolean;
  status: 'Active' | 'Read-only';
}

interface HealthRow {
  component: string;
  status: 'Healthy' | 'Degraded';
  uptime: string;
  lastCheck: string;
}

interface AuditRow {
  time: string;
  user: string;
  action: string;
}

@Component({
  selector: 'app-command-center',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './command-center.component.html',
  styleUrls: ['./command-center.component.scss'],
})
export class CommandCenterComponent {
  users: UserRow[] = [
    {
      name: 'Admin User',
      role: 'Admin',
      ticketsAccess: true,
      hitlAccess: true,
      adminAccess: true,
      status: 'Active',
    },
    {
      name: 'Sarah Chen',
      role: 'Admin',
      ticketsAccess: true,
      hitlAccess: true,
      adminAccess: true,
      status: 'Active',
    },
    {
      name: 'Ravi Kumar',
      role: 'Engineer',
      ticketsAccess: true,
      hitlAccess: true,
      adminAccess: false,
      status: 'Active',
    },
    {
      name: 'Anita Singh',
      role: 'Engineer',
      ticketsAccess: true,
      hitlAccess: true,
      adminAccess: false,
      status: 'Active',
    },
    {
      name: 'Guest User 1',
      role: 'Guest',
      ticketsAccess: false,
      hitlAccess: false,
      adminAccess: false,
      status: 'Read-only',
    },
  ];

  health: HealthRow[] = [
    { component: 'AMS Core Engine', status: 'Healthy', uptime: '99.9%', lastCheck: '1m ago' },
    { component: 'AI Agent Runtime', status: 'Healthy', uptime: '99.7%', lastCheck: '1m ago' },
    { component: 'MCP Orchestrator', status: 'Healthy', uptime: '98.5%', lastCheck: '2m ago' },
    { component: 'Notification Svc', status: 'Degraded', uptime: '94.2%', lastCheck: '5m ago' },
    { component: 'Audit Logger', status: 'Healthy', uptime: '100%', lastCheck: '1m ago' },
  ];

  auditLog: AuditRow[] = [
    {
      time: '2m ago',
      user: 'Admin User',
      action: 'Approved HITL request for INC0042154 — disk cleanup',
    },
    {
      time: '18m ago',
      user: 'Sarah Chen',
      action: 'Updated role for Ravi Kumar — added HITL approval access',
    },
    {
      time: '1h ago',
      user: 'Admin User',
      action: 'Connected Benchling — pending configuration review',
    },
    { time: '2h ago', user: 'Sarah Chen', action: 'Escalated PRB0003421 to Level 2 support team' },
    { time: '3h ago', user: 'Admin User', action: 'Added Guest User 1 — read-only access granted' },
    {
      time: '5h ago',
      user: 'Admin User',
      action: 'System maintenance window completed — all services healthy',
    },
  ];

  rolePill(r: UserRow['role']): string {
    return r === 'Admin'
      ? 'pill pill-admin'
      : r === 'Engineer'
        ? 'pill pill-eng'
        : 'pill pill-guest';
  }

  statusPill(s: UserRow['status']): string {
    return s === 'Active' ? 'pill pill-online' : 'pill pill-away';
  }

  statusDot(s: UserRow['status']): string {
    return s === 'Active' ? '#1D9E75' : '#AEAEC0';
  }

  healthPill(s: HealthRow['status']): string {
    return s === 'Healthy' ? 'pill pill-online' : 'pill pill-busy';
  }

  healthDot(s: HealthRow['status']): string {
    return s === 'Healthy' ? '#1D9E75' : '#EF9F27';
  }

  uptimeColor(s: HealthRow['status']): string {
    return s === 'Healthy' ? '#1D9E75' : '#EF9F27';
  }
}
