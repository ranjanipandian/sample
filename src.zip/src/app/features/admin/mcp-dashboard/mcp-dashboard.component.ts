import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

interface McpAgent {
  name: string;
  task: string;
  status: 'Running' | 'HITL Wait';
  icon: string;
  iconColor: string;
  iconBg: string;
  confidence: number;
  tasksDone: number;
  tasksDonePct: number;
}

interface ConnectorRow {
  name: string;
  status: 'Healthy' | 'Degraded';
  lastSync: string;
  recordsSynced: number;
  errors: number;
}

@Component({
  selector: 'app-mcp-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './mcp-dashboard.component.html',
  styleUrls: ['./mcp-dashboard.component.scss'],
})
export class McpDashboardComponent {
  agents: McpAgent[] = [
    {
      name: 'cognizant_ams_orchestrator_agent',
      task: 'Orchestrating INC0042156 — CPU spike resolution pipeline',
      status: 'Running',
      icon: 'ti ti-robot',
      iconColor: '#1B3FCC',
      iconBg: '#EEF2FF',
      confidence: 92,
      tasksDone: 148,
      tasksDonePct: 75,
    },
    {
      name: 'cognizant_llm_context_service',
      task: 'Building context window for PRB0003421 RCA analysis',
      status: 'Running',
      icon: 'ti ti-brain',
      iconColor: '#3B6D11',
      iconBg: '#EAF3DE',
      confidence: 85,
      tasksDone: 92,
      tasksDonePct: 68,
    },
    {
      name: 'cognizant_scheduler_service',
      task: 'Scheduling CHG0012345 maintenance window — 02:00 UTC',
      status: 'Running',
      icon: 'ti ti-calendar-time',
      iconColor: '#EA580C',
      iconBg: '#FFF7ED',
      confidence: 97,
      tasksDone: 56,
      tasksDonePct: 82,
    },
    {
      name: 'cognizant_workflow_state_service',
      task: 'Holding workflow state for INC0042154 — awaiting HITL approval',
      status: 'HITL Wait',
      icon: 'ti ti-git-branch',
      iconColor: '#BA7517',
      iconBg: '#FAEEDA',
      confidence: 71,
      tasksDone: 23,
      tasksDonePct: 40,
    },
    {
      name: 'sentinel-servicenow-mcp-server',
      task: 'Syncing ServiceNow — 42 tickets imported, 38 auto-triaged',
      status: 'Running',
      icon: 'ti ti-settings-automation',
      iconColor: '#059669',
      iconBg: '#ECFDF5',
      confidence: 99,
      tasksDone: 204,
      tasksDonePct: 90,
    },
    {
      name: 'veeva-mcp-server',
      task: 'Fetching documents for RITM0089234 from VEEVA Vault',
      status: 'Running',
      icon: 'ti ti-database',
      iconColor: '#4F46E5',
      iconBg: '#F0F4FF',
      confidence: 88,
      tasksDone: 31,
      tasksDonePct: 55,
    },
  ];

  connectors: ConnectorRow[] = [
    { name: 'ServiceNow', status: 'Healthy', lastSync: '8 min ago', recordsSynced: 42, errors: 0 },
    { name: 'Argus', status: 'Healthy', lastSync: '2 min ago', recordsSynced: 128, errors: 0 },
    { name: 'VEEVA', status: 'Healthy', lastSync: '15 min ago', recordsSynced: 67, errors: 0 },
    { name: 'Benchling', status: 'Degraded', lastSync: '42 min ago', recordsSynced: 12, errors: 3 },
  ];

  statusPill(s: McpAgent['status']): string {
    return s === 'Running' ? 'pill pill-active' : 'pill pill-busy';
  }

  confidenceColor(pct: number): string {
    if (pct >= 95) return '#1D9E75';
    if (pct >= 80) return '#1B3FCC';
    return '#EF9F27';
  }

  connectorPill(s: ConnectorRow['status']): string {
    return s === 'Healthy' ? 'pill pill-online' : 'pill pill-busy';
  }

  connectorDot(s: ConnectorRow['status']): string {
    return s === 'Healthy' ? '#1D9E75' : '#EF9F27';
  }
}
