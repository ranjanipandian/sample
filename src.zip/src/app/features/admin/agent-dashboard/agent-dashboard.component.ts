import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

interface Engineer {
  name: string;
  status: 'Online' | 'Busy' | 'Away';
  activeTickets: number;
  resolvedToday: number;
  slaPct: number;
  task: string;
}

interface HitlRow {
  name: string;
  pending: number;
  overdue: number;
  avgResponse: string;
}

interface ResolutionRow {
  name: string;
  resolved: number;
  escalated: number;
  autoResolved: number;
}

@Component({
  selector: 'app-agent-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './agent-dashboard.component.html',
  styleUrls: ['./agent-dashboard.component.scss'],
})
export class AgentDashboardComponent {
  engineers: Engineer[] = [
    {
      name: 'Ravi Kumar',
      status: 'Online',
      activeTickets: 4,
      resolvedToday: 8,
      slaPct: 94,
      task: 'INC0042156 — CPU spike',
    },
    {
      name: 'Anita Singh',
      status: 'Busy',
      activeTickets: 6,
      resolvedToday: 5,
      slaPct: 87,
      task: 'INC0042155 — DB lag',
    },
    {
      name: 'Tom Lee',
      status: 'Online',
      activeTickets: 2,
      resolvedToday: 11,
      slaPct: 98,
      task: 'RITM0089234 — SSL cert',
    },
    {
      name: 'Suresh R',
      status: 'Busy',
      activeTickets: 5,
      resolvedToday: 4,
      slaPct: 78,
      task: 'INC0042154 — Disk issue',
    },
    {
      name: 'Maya Patel',
      status: 'Online',
      activeTickets: 3,
      resolvedToday: 6,
      slaPct: 91,
      task: 'PRB0003421 — Memory leak',
    },
    {
      name: 'Carlos M',
      status: 'Away',
      activeTickets: 1,
      resolvedToday: 3,
      slaPct: 82,
      task: 'CHG0012345 — VPN timeout',
    },
    {
      name: 'Nina Roy',
      status: 'Online',
      activeTickets: 2,
      resolvedToday: 7,
      slaPct: 96,
      task: 'RITM0089201 — Backup',
    },
  ];

  hitlByEngineer: HitlRow[] = [
    { name: 'Ravi Kumar', pending: 2, overdue: 1, avgResponse: '12 min' },
    { name: 'Anita Singh', pending: 3, overdue: 1, avgResponse: '18 min' },
    { name: 'Suresh R', pending: 2, overdue: 0, avgResponse: '8 min' },
    { name: 'Maya Patel', pending: 0, overdue: 0, avgResponse: '6 min' },
  ];

  resolutionStats: ResolutionRow[] = [
    { name: 'Tom Lee', resolved: 11, escalated: 0, autoResolved: 4 },
    { name: 'Ravi Kumar', resolved: 8, escalated: 1, autoResolved: 3 },
    { name: 'Nina Roy', resolved: 7, escalated: 0, autoResolved: 2 },
    { name: 'Anita Singh', resolved: 5, escalated: 2, autoResolved: 1 },
  ];

  pillClass(s: Engineer['status']): string {
    return s === 'Online' ? 'pill pill-online' : s === 'Busy' ? 'pill pill-busy' : 'pill pill-away';
  }

  dotColor(s: Engineer['status']): string {
    return s === 'Online' ? '#1D9E75' : s === 'Busy' ? '#EF9F27' : '#AEAEC0';
  }

  slaBarColor(pct: number): string {
    if (pct >= 95) return '#1D9E75';
    if (pct >= 85) return '#1B3FCC';
    return '#EF9F27';
  }
}
