import { Routes } from '@angular/router';

import { authGuard } from '@core/guards/auth.guard';

export const APP_ROUTES: Routes = [
  /* Root → /login so a fresh visit to localhost:4200 lands on the login page
     instead of falling straight into the app-shell. pathMatch: 'full' so this
     ONLY fires on the bare '/' URL — child paths like /dashboard still match
     the app-shell route below. */
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {
    path: 'login',
    loadComponent: () =>
      import('@features/auth/login/login.component').then((m) => m.LoginComponent),
  },
  {
    // OIDC redirect landing — exchanges code/state for the session token.
    path: 'auth/callback',
    loadComponent: () =>
      import('@features/auth/callback/auth-callback.component').then(
        (m) => m.AuthCallbackComponent
      ),
  },
  {
    path: 'admin',
    canActivate: [authGuard],
    loadChildren: () => import('@features/admin/admin.routes').then((m) => m.ADMIN_ROUTES),
  },
  {
    path: 'settings',
    canActivate: [authGuard],
    loadChildren: () => import('@features/settings/settings.routes').then((m) => m.SETTINGS_ROUTES),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () =>
      import('@layouts/app-shell/app-shell.component').then((m) => m.AppShellComponent),
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('@features/dashboard/dashboard.component').then((m) => m.DashboardComponent),
      },
      {
        path: 'schedule',
        loadChildren: () =>
          import('@features/schedule/schedule.routes').then((m) => m.SCHEDULE_ROUTES),
      },
      { path: 'tickets', redirectTo: 'tickets/incidents', pathMatch: 'full' },
      {
        path: 'tickets/incidents',
        loadComponent: () =>
          import('@features/tickets/live-tickets/live-tickets.component').then(
            (m) => m.LiveTicketsComponent
          ),
        data: { ticketType: 'Incident' },
      },
      {
        path: 'tickets/requests',
        loadComponent: () =>
          import('@features/tickets/live-tickets/live-tickets.component').then(
            (m) => m.LiveTicketsComponent
          ),
        data: { ticketType: 'Service Request' },
      },
      {
        path: 'tickets/problems',
        loadComponent: () =>
          import('@features/tickets/live-tickets/live-tickets.component').then(
            (m) => m.LiveTicketsComponent
          ),
        data: { ticketType: 'Problem' },
      },
      {
        path: 'tickets/changes',
        loadComponent: () =>
          import('@features/tickets/live-tickets/live-tickets.component').then(
            (m) => m.LiveTicketsComponent
          ),
        data: { ticketType: 'Change' },
      },
      {
        path: 'tickets/:number/approve',
        loadComponent: () =>
          import('@features/tickets/plan-approval/plan-approval.component').then(
            (m) => m.PlanApprovalComponent
          ),
      },
      {
        path: 'tickets/:number',
        loadComponent: () =>
          import('@features/tickets/ticket-detail/ticket-detail.component').then(
            (m) => m.TicketDetailComponent
          ),
      },
      {
        path: 'audit',
        loadChildren: () => import('@features/audit/audit.routes').then((m) => m.AUDIT_ROUTES),
      },
      {
        path: 'landscape',
        loadChildren: () =>
          import('@features/landscape/landscape.routes').then((m) => m.LANDSCAPE_ROUTES),
      },
    ],
  },

  { path: '**', redirectTo: 'login' },
];
