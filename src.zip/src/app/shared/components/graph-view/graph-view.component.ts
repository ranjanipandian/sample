import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';

import { GraphEdge, GraphNode } from '@core/models/memory-graph-data.model';

/**
 * Reusable canvas-based force-directed graph visualization.
 *
 * Hand-rolled physics (repulsion + spring attraction + center gravity),
 * animated via requestAnimationFrame — same technique already used for the
 * particle background on the login screen (login.component.ts), so this
 * introduces zero new npm dependencies and stays consistent with the
 * existing codebase style.
 *
 * Nodes are colored/shaped by entityType, with a dashed border for
 * agent-asserted nodes vs solid for human-asserted ones. Clicking a node
 * emits it via (nodeSelected) so the host can show a provenance panel;
 * this component also renders its own built-in panel by default.
 */

interface SimNode extends GraphNode {
  x: number;
  y: number;
  vx: number;
  vy: number;
  /** Set once the node has "arrived" during the ingestion reveal animation. */
  revealed: boolean;
}

@Component({
  selector: 'app-graph-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './graph-view.component.html',
  styleUrls: ['./graph-view.component.scss'],
})
export class GraphViewComponent implements AfterViewInit, OnChanges, OnDestroy {
  @ViewChild('graphCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;

  /** Full node set. Use `revealedIds` to progressively reveal during an ingestion animation. */
  @Input() nodes: GraphNode[] = [];
  @Input() edges: GraphEdge[] = [];
  /**
   * Optional: restrict rendering/simulation to only these node ids (and any
   * edges whose endpoints are both revealed). If omitted, all nodes render.
   * Used by the ingestion-pipeline component to animate the graph "growing".
   */
  @Input() revealedIds: string[] | null = null;
  /** Show the built-in provenance side panel when a node is clicked. */
  @Input() showPanel = true;

  @Output() nodeSelected = new EventEmitter<GraphNode>();

  selectedNode: GraphNode | null = null;

  private ctx: CanvasRenderingContext2D | null = null;
  private width = 0;
  private height = 0;
  private rafId = 0;
  private simNodes: SimNode[] = [];
  private hoverEdge: { edge: GraphEdge; x: number; y: number } | null = null;
  private draggingNode: SimNode | null = null;

  ngAfterViewInit(): void {
    this.resize();
    this.rebuildSim();
    this.tick();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ((changes['nodes'] || changes['edges'] || changes['revealedIds']) && this.ctx) {
      this.rebuildSim();
    }
  }

  ngOnDestroy(): void {
    cancelAnimationFrame(this.rafId);
  }

  @HostListener('window:resize')
  resize(): void {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;
    const wrap = canvas.parentElement;
    this.width = canvas.width = wrap ? wrap.clientWidth : 600;
    this.height = canvas.height = wrap ? wrap.clientHeight : 420;
    this.ctx = canvas.getContext('2d');
  }

  private get activeNodeIds(): Set<string> {
    return this.revealedIds ? new Set(this.revealedIds) : new Set(this.nodes.map((n) => n.id));
  }

  private rebuildSim(): void {
    const activeIds = this.activeNodeIds;
    const existing = new Map(this.simNodes.map((n) => [n.id, n]));
    this.simNodes = this.nodes
      .filter((n) => activeIds.has(n.id))
      .map((n) => {
        const prev = existing.get(n.id);
        if (prev) return { ...prev, ...n };
        return {
          ...n,
          x: this.width / 2 + (Math.random() - 0.5) * 120,
          y: this.height / 2 + (Math.random() - 0.5) * 120,
          vx: 0,
          vy: 0,
          revealed: true,
        };
      });
  }

  private get activeEdges(): GraphEdge[] {
    const activeIds = this.activeNodeIds;
    return this.edges.filter((e) => activeIds.has(e.source) && activeIds.has(e.target));
  }

  private tick = (): void => {
    this.step();
    this.render();
    this.rafId = requestAnimationFrame(this.tick);
  };

  private step(): void {
    const nodes = this.simNodes;
    const edges = this.activeEdges;
    const W = this.width;
    const H = this.height;
    const cx = W / 2;
    const cy = H / 2;

    // Repulsion between all node pairs.
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i];
      for (let j = i + 1; j < nodes.length; j++) {
        const b = nodes[j];
        let dx = a.x - b.x;
        let dy = a.y - b.y;
        let distSq = dx * dx + dy * dy;
        if (distSq < 1) distSq = 1;
        const dist = Math.sqrt(distSq);
        const force = 2200 / distSq;
        dx /= dist;
        dy /= dist;
        a.vx += dx * force;
        a.vy += dy * force;
        b.vx -= dx * force;
        b.vy -= dy * force;
      }
      // Center gravity, keeps graph from drifting off-canvas.
      a.vx += (cx - a.x) * 0.0016;
      a.vy += (cy - a.y) * 0.0016;
    }

    // Spring attraction along edges.
    const byId = new Map(nodes.map((n) => [n.id, n]));
    for (const e of edges) {
      const a = byId.get(e.source);
      const b = byId.get(e.target);
      if (!a || !b) continue;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const dist = Math.max(Math.sqrt(dx * dx + dy * dy), 1);
      const targetLen = 150;
      const force = (dist - targetLen) * 0.02;
      const fx = (dx / dist) * force;
      const fy = (dy / dist) * force;
      a.vx += fx;
      a.vy += fy;
      b.vx -= fx;
      b.vy -= fy;
    }

    // Integrate + damping.
    for (const n of nodes) {
      if (this.draggingNode === n) continue;
      n.vx *= 0.82;
      n.vy *= 0.82;
      n.x += n.vx;
      n.y += n.vy;
      n.x = Math.max(40, Math.min(W - 40, n.x));
      n.y = Math.max(30, Math.min(H - 30, n.y));
    }
  }

  private render(): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const W = this.width;
    const H = this.height;
    ctx.clearRect(0, 0, W, H);

    const byId = new Map(this.simNodes.map((n) => [n.id, n]));

    // Edges.
    for (const e of this.activeEdges) {
      const a = byId.get(e.source);
      const b = byId.get(e.target);
      if (!a || !b) continue;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      const isContradict = e.relationship === 'mg:contradicts';
      ctx.strokeStyle = isContradict ? 'rgba(214, 69, 69, 0.55)' : 'rgba(120, 140, 200, 0.45)';
      ctx.lineWidth = 1.2;
      if (e.relationship.startsWith('prov:')) {
        ctx.setLineDash([3, 4]);
      } else {
        ctx.setLineDash([]);
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // Arrowhead.
      const angle = Math.atan2(b.y - a.y, b.x - a.x);
      const ah = 6;
      const tx = b.x - Math.cos(angle) * 16;
      const ty = b.y - Math.sin(angle) * 16;
      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.lineTo(tx - ah * Math.cos(angle - 0.4), ty - ah * Math.sin(angle - 0.4));
      ctx.lineTo(tx - ah * Math.cos(angle + 0.4), ty - ah * Math.sin(angle + 0.4));
      ctx.closePath();
      ctx.fillStyle = isContradict ? 'rgba(214, 69, 69, 0.6)' : 'rgba(120, 140, 200, 0.6)';
      ctx.fill();
    }

    // Hovered edge label.
    if (this.hoverEdge) {
      const { edge, x, y } = this.hoverEdge;
      ctx.font = '11px Inter, sans-serif';
      const text = edge.relationship;
      const padding = 6;
      const tw = ctx.measureText(text).width;
      ctx.fillStyle = 'rgba(20, 24, 40, 0.9)';
      ctx.fillRect(x - tw / 2 - padding, y - 10, tw + padding * 2, 20);
      ctx.fillStyle = '#fff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, x, y);
      ctx.textAlign = 'start';
      ctx.textBaseline = 'alphabetic';
    }

    // Nodes.
    for (const n of this.simNodes) {
      const isSelected = this.selectedNode?.id === n.id;
      const { fill, stroke } = this.colorForType(n.entityType);
      const r = isSelected ? 15 : 12;

      ctx.beginPath();
      ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.lineWidth = isSelected ? 3 : 2;
      ctx.strokeStyle = stroke;
      if (n.assertionOrigin === 'agent') {
        ctx.setLineDash([4, 3]);
      } else {
        ctx.setLineDash([]);
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // Label.
      ctx.font = isSelected ? 'bold 11px Inter, sans-serif' : '10.5px Inter, sans-serif';
      ctx.fillStyle = '#1b2436';
      ctx.textAlign = 'center';
      const label = n.label.length > 30 ? n.label.slice(0, 28) + '…' : n.label;
      ctx.fillText(label, n.x, n.y + r + 14);
      ctx.textAlign = 'start';
    }
  }

  private colorForType(type: GraphNode['entityType']): { fill: string; stroke: string } {
    switch (type) {
      case 'mg:Hypothesis':
        return { fill: '#fde9c8', stroke: '#c98a1f' };
      case 'mg:Result':
        return { fill: '#dbe9fb', stroke: '#1f5fa8' };
      case 'mg:FailureEvent':
        return { fill: '#fadcdc', stroke: '#b23a3a' };
      case 'mg:Decision':
        return { fill: '#dff0da', stroke: '#3f7a2a' };
      case 'mg:EvidenceClaim':
        return { fill: '#e6dcf7', stroke: '#6c3fb0' };
      case 'prov:Agent':
        return { fill: '#e0e0e0', stroke: '#555' };
      default:
        return { fill: '#eee', stroke: '#888' };
    }
  }

  onCanvasClick(evt: MouseEvent): void {
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const x = evt.clientX - rect.left;
    const y = evt.clientY - rect.top;
    const hit = this.simNodes.find((n) => Math.hypot(n.x - x, n.y - y) <= 15);
    if (hit) {
      this.selectedNode = hit;
      this.nodeSelected.emit(hit);
    } else {
      this.selectedNode = null;
    }
  }

  onCanvasMouseMove(evt: MouseEvent): void {
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const x = evt.clientX - rect.left;
    const y = evt.clientY - rect.top;

    if (this.draggingNode) {
      this.draggingNode.x = x;
      this.draggingNode.y = y;
      this.draggingNode.vx = 0;
      this.draggingNode.vy = 0;
      return;
    }

    const byId = new Map(this.simNodes.map((n) => [n.id, n]));
    let found: { edge: GraphEdge; x: number; y: number } | null = null;
    for (const e of this.activeEdges) {
      const a = byId.get(e.source);
      const b = byId.get(e.target);
      if (!a || !b) continue;
      const mx = (a.x + b.x) / 2;
      const my = (a.y + b.y) / 2;
      if (Math.hypot(mx - x, my - y) <= 14) {
        found = { edge: e, x: mx, y: my };
        break;
      }
    }
    this.hoverEdge = found;
  }

  onCanvasMouseDown(evt: MouseEvent): void {
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const x = evt.clientX - rect.left;
    const y = evt.clientY - rect.top;
    const hit = this.simNodes.find((n) => Math.hypot(n.x - x, n.y - y) <= 15);
    if (hit) this.draggingNode = hit;
  }

  @HostListener('window:mouseup')
  onWindowMouseUp(): void {
    this.draggingNode = null;
  }

  closePanel(): void {
    this.selectedNode = null;
  }

  reviewStatusLabel(status: string): string {
    return status.replace(/-/g, ' ');
  }
}
