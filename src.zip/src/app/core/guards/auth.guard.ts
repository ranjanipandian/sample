import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { AuthService } from '@core/services/auth.service';

/**
 * Protects authenticated routes. When there is no valid session, sends the
 * user to our own /login page (remembering the intended URL so a successful
 * login can return them there). The full-page redirect to the enterprise
 * OIDC identity service only happens when the user explicitly clicks
 * "Login as SSO" on that page — never on a bare/direct navigation to a
 * protected URL.
 */
export const authGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isAuthenticated()) return true;

  try {
    sessionStorage.setItem('ams.postLoginRedirect', state.url);
  } catch {
    /* sessionStorage unavailable — proceed without remembering the target */
  }
  return router.parseUrl('/login');
};


