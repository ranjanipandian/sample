import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { AuthService } from '@core/services/auth.service';

/**
 * Restricts a route to supervisors. Runs after authGuard (which guarantees a
 * session), so an authenticated non-supervisor is bounced to their own schedule
 * rather than into the login flow.
 */
export const supervisorGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.user.role === 'SUPERVISOR') return true;

  return router.parseUrl('/schedule/availability');
};
