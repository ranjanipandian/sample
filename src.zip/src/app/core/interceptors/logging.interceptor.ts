import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { tap } from 'rxjs';

import { LoggingService } from '@core/services/logging.service';

/**
 * For every outbound HttpClient request:
 *   1. Generate a per-request X-Request-ID (UUIDv4) and add it to the request
 *      headers. nginx forwards it via `proxy_set_header X-Request-ID` to the
 *      backend service, which binds it to its async log context — so the
 *      same id appears on log lines emitted by the SPA, nginx, the backend,
 *      and any downstream MCP servers.
 *   2. Time the round-trip and emit one structured INFO line on completion
 *      (or one ERROR line on failure) via LoggingService.
 *
 * The /api/me identity probe is excluded from logging — it fires on every
 * page load and would drown signal in noise.
 */
const SKIP_PATHS = new Set(['/api/me']);

export const loggingInterceptor: HttpInterceptorFn = (req, next) => {
  const log = inject(LoggingService);
  const requestId = log.newRequestId();
  const started = performance.now();
  const skip = SKIP_PATHS.has(stripQuery(req.url));

  const stamped = req.clone({ setHeaders: { 'X-Request-ID': requestId } });

  if (!skip) {
    log.debug('http', 'request_started', {
      request_id: requestId,
      method: req.method,
      url: req.url,
    });
  }

  return next(stamped).pipe(
    tap({
      next: (event) => {
        // HttpResponse is the final event in the stream (event.type === 4).
        // Earlier events (sent/headers) are progress and we ignore them.
        if (skip || event.type !== 4) return;
        const elapsed = Math.round(performance.now() - started);
        const status = (event as { status?: number }).status;
        log.info('http', 'request_completed', {
          request_id: requestId,
          method: req.method,
          url: req.url,
          status,
          duration_ms: elapsed,
        });
      },
      error: (err) => {
        if (skip) return;
        const elapsed = Math.round(performance.now() - started);
        log.error('http', 'request_failed', {
          request_id: requestId,
          method: req.method,
          url: req.url,
          status: err?.status,
          duration_ms: elapsed,
          // err.message is the safe summary; full body is in err.error.
          error: err?.message ?? 'unknown',
        });
      },
    })
  );
};

function stripQuery(url: string): string {
  const q = url.indexOf('?');
  return q < 0 ? url : url.slice(0, q);
}
