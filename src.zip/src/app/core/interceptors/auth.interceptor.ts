import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { switchMap, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { AuthService } from '@core/services/auth.service';

/**
 * Attaches the identity-service session JWT as `Authorization: Bearer <token>`
 * to backend calls (orchestrator, WSS view, ServiceNow MCP) so the orchestrator
 * can verify the user and mint per-user MCP credential tokens.
 *
 * Identity-service *auth* endpoints (authorize / callback / token / refresh /
 * logout / jwks under /v1/auth/) are skipped — they establish or rotate the
 * session and must not carry a stale bearer. Other identity endpoints that act
 * on the logged-in user (e.g. /v1/me/tools) DO need the bearer, so only the
 * /v1/auth/ subtree is skipped. On a 401 the session is refreshed once and the
 * request retried.
 */
const SKIP_PREFIXES = ['/api/identity/v1/auth/'];

function shouldAttach(url: string): boolean {
  if (SKIP_PREFIXES.some((p) => url.startsWith(p) || url.includes(p))) return false;
  return url.startsWith('/api/') || url.includes('/api/');
}

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);

  if (!shouldAttach(req.url)) {
    return next(req);
  }

  const token = auth.getSessionToken();
  const authedReq = token ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;

  return next(authedReq).pipe(
    catchError((err: unknown) => {
      if (err instanceof HttpErrorResponse && err.status === 401 && token) {
        // Session may have just expired — refresh once and retry.
        return auth.refresh().pipe(
          switchMap((user) => {
            const fresh = auth.getSessionToken();
            if (!user.authenticated || !fresh) {
              return throwError(() => err);
            }
            return next(req.clone({ setHeaders: { Authorization: `Bearer ${fresh}` } }));
          })
        );
      }
      return throwError(() => err);
    })
  );
};
