import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { AuthService, AuthUser } from '@core/services/auth.service';
import { LoggingService } from '@core/services/logging.service';
import { loggingInterceptor } from './logging.interceptor';

const anon: AuthUser = {
  authenticated: false,
  sub: '',
  userId: '',
  email: '',
  name: '',
  role: '',
  sessionId: '',
  groups: [],
};

describe('loggingInterceptor', () => {
  let http: HttpClient;
  let httpMock: HttpTestingController;
  let log: jasmine.SpyObj<LoggingService>;

  beforeEach(() => {
    log = jasmine.createSpyObj<LoggingService>('LoggingService', [
      'debug',
      'info',
      'warn',
      'error',
      'newRequestId',
    ]);
    log.newRequestId.and.returnValue('test-request-id-1234');

    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([loggingInterceptor])),
        provideHttpClientTesting(),
        { provide: AuthService, useValue: { user: anon } },
        { provide: LoggingService, useValue: log },
      ],
    });
    http = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => httpMock.verify());

  it('adds X-Request-ID to outbound requests', () => {
    http.get('/api/jobs/abc/orch-steps').subscribe();
    const req = httpMock.expectOne('/api/jobs/abc/orch-steps');
    expect(req.request.headers.get('X-Request-ID')).toBe('test-request-id-1234');
    req.flush({});
  });

  it('logs request_started (debug) and request_completed (info) on success', () => {
    http.get('/api/jobs/abc/orch-steps').subscribe();
    const req = httpMock.expectOne('/api/jobs/abc/orch-steps');
    req.flush({}, { status: 200, statusText: 'OK' });

    expect(log.debug).toHaveBeenCalled();
    const debugExtra = log.debug.calls.mostRecent().args[2] as Record<string, unknown>;
    expect(debugExtra['request_id']).toBe('test-request-id-1234');
    expect(debugExtra['method']).toBe('GET');

    expect(log.info).toHaveBeenCalled();
    const infoExtra = log.info.calls.mostRecent().args[2] as Record<string, unknown>;
    expect(infoExtra['status']).toBe(200);
    expect(infoExtra['request_id']).toBe('test-request-id-1234');
    expect(typeof infoExtra['duration_ms']).toBe('number');
  });

  it('logs request_failed (error) on HTTP error', () => {
    http.get('/api/servicenow/tools/fetch_ticket').subscribe({
      next: () => fail('should not succeed'),
      error: () => void 0,
    });
    const req = httpMock.expectOne('/api/servicenow/tools/fetch_ticket');
    req.flush({ error: 'boom' }, { status: 500, statusText: 'Server Error' });

    expect(log.error).toHaveBeenCalled();
    const extra = log.error.calls.mostRecent().args[2] as Record<string, unknown>;
    expect(extra['status']).toBe(500);
    expect(extra['request_id']).toBe('test-request-id-1234');
  });

  it('skips /api/me to keep boot noise down', () => {
    http.get('/api/me').subscribe();
    httpMock.expectOne('/api/me').flush({});
    expect(log.debug).not.toHaveBeenCalled();
    expect(log.info).not.toHaveBeenCalled();
  });

  it('still adds X-Request-ID to /api/me even when logging is skipped', () => {
    http.get('/api/me').subscribe();
    const req = httpMock.expectOne('/api/me');
    expect(req.request.headers.get('X-Request-ID')).toBe('test-request-id-1234');
    req.flush({});
  });
});
