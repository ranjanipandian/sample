/**
 * Wire types for the Cognizant fetch_ticket API
 * (POST {apiBaseUrl}/fetch_ticket).
 */

/**
 * Flat body — the MCP HTTP dispatcher in apps/server/server.py kwargs-spreads
 * the body directly into FetchTicketInput(**body). Any extra fields (assigned_to,
 * state, priority, etc.) become filter criteria via the Pydantic extra="allow"
 * config and are mapped to ServiceNow columns by core/.../field_mapper.py.
 */
export interface FetchTicketRequest {
  ticket_id?: string;
  ticket_type?: string;
  assigned_to?: string;
  state?: string;
  page: number;
  page_size: number;
  [key: string]: unknown;
}

/**
 * Loose interface for a ServiceNow ticket row.
 * The adapter returns display values (display_value=true), so reference fields
 * arrive as readable strings ("Ravi Kumar") rather than sys_ids.
 * Fields are optional because not every table populates every column.
 */
export interface ServiceNowTicket {
  number?: string;
  short_description?: string;
  description?: string;
  priority?: string;
  state?: string;
  stage?: string;
  category?: string;
  subcategory?: string;
  assignment_group?: string;
  assigned_to?: string;
  opened_at?: string;
  sys_created_on?: string;
  opened_by?: string;
  caller_id?: string;
  sys_class_name?: string;
  sys_id?: string;
  classification?: { type?: string; application_identifier?: string };
  [key: string]: unknown;
}

export interface FetchTicketResponse {
  tickets: ServiceNowTicket[];
  count?: number;
  page?: number;
  page_size?: number;
  filters_applied?: Record<string, unknown>;
  warnings?: string[];
}

/**
 * Legacy MCP envelope ({status, data, meta}). Some tool responses still arrive
 * in this shape; `data` carries the tool payload. SentinelApiService unwraps it.
 */
export interface McpEnvelope<T> {
  status: 'ok' | 'error';
  data?: T;
  errors?: { code?: string; message: string; field?: string }[];
  warnings?: string[];
  meta?: Record<string, unknown>;
}

/**
 * Orchestrator-shaped envelope the Go ServiceNow MCP server actually returns
 * from POST /tools/{name} (internal/httpapi/orch_response.go). The tool payload
 * — including the tickets array for fetch_ticket — lives under `output_result`;
 * `outcome_status` is 'success' or 'failed' (on failure `output_result.error`
 * carries the message). SentinelApiService unwraps it to the bare payload.
 */
export interface OrchEnvelope<T> {
  outcome_status: 'success' | 'failed' | string;
  action_taken?: string;
  output_result?: T & { error?: string };
  retry_eligible?: boolean;
  execution_steps?: unknown[];
}

/**
 * Response from GET /health (apps/server/server.py).
 * 200 + status: 'ok' means the MCP server is up and connected to ServiceNow.
 */
export interface HealthResponse {
  status: string;
  service?: string;
  servicenow_url?: string;
  environment?: string;
  otel_enabled?: boolean;
  audit_enabled?: boolean;
}

/* ── Resolve / Resume job orchestration APIs ─────────────────────────
 * POST {jobsResolveUrl}                    → ResolveJobResponse
 * POST {jobsOrchStepsBase}/{job_id}/resume → ResumeJobResponse
 *
 * Flow:
 *   1. Click "Resolve" on a new ticket → Resolve API returns the job_id
 *      and `planned_steps` (the workflow blueprint). Classification has
 *      already auto-completed by the time we receive this response, so
 *      the UI marks it done and surfaces Approve/Reject on the next
 *      group (typically Document Remediation).
 *   2. Click Approve → Resume API runs the next group's substeps and
 *      either returns AWAITING_HITL with another `current_step` (more
 *      approval needed) or RESOLVED (workflow complete).
 *   3. Click Reject anywhere → local-only: capture comment, append to
 *      ticket comments, halt the workflow.
 */

export interface ResolveJobUserContext {
  engineer_id: string;
  engineer_name: string;
  engineer_mail: string;
  role: string;
  lead_id: string;
  session_id: string;
  ticket_categories: string[];
  priority_rules: Record<string, unknown>;
}

export interface ResolveJobRequest {
  ticket_id: string;
  source: string;
  trigger: string;
  user_context: ResolveJobUserContext;
}

/** One sub-step inside a planned-step group (e.g. "parse_ticket"). */
export interface PlannedSubstep {
  step_name: string;
  /** Human-facing label when the backend supplies one (e.g. "Parse Incident Context").
   *  Falls back to a humanized step_name when absent. */
  display_name?: string;
  description: string;
}

/** Classification output the Resolve API auto-runs before returning. */
export interface ResolveClassificationOutput {
  classification?: string;
  complexity_tier?: string;
  use_case?: string;
  application_identifier?: string;
  rationale?: string;
}

/** One entry in the Resolve response's `executed_steps` (only classification
 *  has run by the time Resolve returns). */
export interface ResolveExecutedStep {
  classification?: {
    input?: Record<string, unknown>;
    action_taken?: string;
    output?: ResolveClassificationOutput;
  };
}

/**
 * Each entry in `planned_steps` is a single-key object where the key
 * is the human-readable group name (e.g. "Classification") and the
 * value is its ordered substep list. The backend ships them this way
 * to preserve order without forcing the client to use a Map.
 */
export type PlannedStepGroup = Record<string, PlannedSubstep[]>;

export interface ResolveJobResponse {
  job_id: string;
  status: string;
  executed_steps?: ResolveExecutedStep[];
  planned_steps?: PlannedStepGroup[];
}

/* ── Resume API ──────────────────────────────────────────────────── */

export interface ResumeJobUserContext {
  engineer_id: string;
  engineer_name: string;
  engineer_mail: string;
  role: string;
  lead_id: string;
  session_id: string;
}

export interface ResumeJobRequest {
  user_context: ResumeJobUserContext;
}

/**
 * Both top-level groups (step_id="STEP-001") and their substeps
 * (step_id="STEP-001.parse_ticket_context") arrive in the same `steps`
 * array. Group rows have parent_step_id=null; substep rows reference
 * their parent. The top-level outcome.output_summary can be a string
 * OR a rich object (the workflow-executed report).
 */
export interface ResumeStep {
  step_id: string;
  capability: string;
  mcp_server?: string;
  status: 'PENDING' | 'SUCCEEDED' | 'FAILED' | 'BYPASSED' | string;
  parent_step_id?: string | null;
  planned_at?: string | null;
  executed_at?: string | null;
  outcome?: {
    input_summary?: string | Record<string, unknown>;
    output_summary?: string | ResumeOutputSummary;
    outcome_status?: string | null;
  } | null;
}

/** Rich payload returned on the top-level STEP-N once it has run. */
export interface ResumeOutputSummary {
  workflow_executed?: string;
  steps_completed?: string[];
  outcome?: string;
  routing?: 'STP' | 'HITL' | string;
  confidence?: number;
  notes?: string;
  actions_taken?: Array<{
    tool?: string;
    input_summary?: string;
    result_summary?: string;
  }>;
  execution_steps?: Array<{
    name: string;
    status: 'complete' | 'pending_approval' | 'not_started' | 'bypassed' | string;
    input_summary?: string;
    result_summary?: string;
  }>;
  pending_state?: Record<string, unknown>;
  veeva_record_url?: string;
  veeva_record_urls?: string[];
  [key: string]: unknown;
}

export type ResumeJobStatus = 'AWAITING_HITL' | 'RESOLVED' | 'FAILED' | string;

export interface ResumeJobResponse {
  job_id: string;
  ticket_id: string;
  status: ResumeJobStatus;
  trigger?: string;
  steps: ResumeStep[];
  /** Capability name of the substep currently awaiting HITL, or null when complete. */
  current_step: string | null;
  created_at?: string;
  updated_at?: string;
}

/* ── Approve Plan API ─────────────────────────────────────────────────
 * POST {jobsOrchStepsBase}/{job_id}/approve
 * Fired when the engineer clicks "Approve Plan & Continue" on the Plan
 * Approval page. Kicks off background execution; the workflow page then
 * polls the View/Status endpoint until job_status is terminal.
 */
export interface ApproveJobRequest {
  user_context: ResumeJobUserContext;
}

export interface ApproveJobResponse {
  job_id: string;
  /** e.g. "executing". */
  status: string;
  message?: string;
}

/* ── View Job API ────────────────────────────────────────────────────
 * Two endpoints back the "View Ticket" button on resolved/closed tickets:
 *   - jobsLookupUrl: GET ?ticket_id={ticketNumber} → returns the job_id(s)
 *     associated with this ticket so we can call view next.
 *   - jobsViewUrlBase: GET {base}/{job_id}?include_steps=true → returns
 *     the full historical job + all executed steps for display.
 *
 * Step IDs in the View response are UUIDs (not the STEP-N format used by
 * Resume). The parent/child hierarchy is built via parent_step_id alone:
 *   - parent_step_id === null   → top-level group row (one per phase)
 *   - parent_step_id === uuid   → substep belonging to that parent group
 */

export interface ViewJobStep {
  step_id: string;
  capability: string;
  mcp_server?: string;
  status: 'PENDING' | 'SUCCEEDED' | 'FAILED' | 'BYPASSED' | string;
  parent_step_id?: string | null;
  planned_at?: string | null;
  executed_at?: string | null;
  outcome?: {
    input_summary?: string | Record<string, unknown>;
    output_summary?: string | Record<string, unknown> | null;
    outcome_status?: string | null;
    /** Short human-readable summary of what the step did. */
    action_taken?: string | null;
  } | null;
}

export interface ViewJobResponse {
  job_id: string;
  ticket_id: string;
  session_id?: string;
  engineer_id?: string;
  role?: string;
  lead_id?: string;
  trigger_mode?: string;
  pull_mode?: string;
  /** Mirrors Resume status; for finished jobs typically "RESOLVED". */
  job_status: string;
  classification?: string | null;
  complexity_tier?: string | null;
  retry_count?: number;
  mcp_dispatch_count?: number;
  mcp_servers_invoked?: string[] | null;
  retry_of_job_id?: string | null;
  created_at?: string;
  resolved_at?: string;
  resolution_mins?: number;
  sla_breach_ts?: string;
  sla_met?: boolean;
  snow_close_ref?: string;
  error_code?: string | null;
  error_summary?: string | null;
  current_step?: string | null;
  steps: ViewJobStep[];
}

/**
 * Lookup response shape — kept intentionally loose because backends vary.
 * Three commonly-seen shapes are all tolerated by JobsService.extractJobId():
 *   { "job_id": "abc..." }
 *   { "jobs": [{ "job_id": "abc...", "status": "RESOLVED", ... }, ...] }
 *   [{ "job_id": "abc...", ... }, ...]
 *
 * If your backend returns something different, adjust extractJobId() in
 * jobs.service.ts to match.
 */
export interface JobLookupResponse {
  job_id?: string;
  jobs?: Array<{ job_id?: string; status?: string; resolved_at?: string }>;
  [key: string]: unknown;
}

/* ── Jobs Listing API ────────────────────────────────────────────────
 * GET {jobsViewUrlBase}?include_steps=true&page=1&limit=10
 * Drives the AI Agent Activity table on the dashboard. Each item carries
 * both job-level fields (job_status, elapsed_mins, resolution_mins) and
 * a ticket_info block with the human-facing ticket status (RESOLVED /
 * IN_PROGRESS) used in the table's Status column.
 */

export interface JobListTicketInfo {
  ticket_number: string;
  ticket_type?: string;
  priority?: string;
  category?: string;
  short_description?: string;
  /** "RESOLVED" / "IN_PROGRESS" / "AWAITING_HITL" / etc. */
  ticket_status: string;
  created_at?: string;
  resolved_at?: string | null;
  modified_at?: string | null;
}

export interface JobListItem {
  job_id: string;
  ticket_id: string;
  engineer_id?: string;
  job_status: string;
  pull_mode?: string;
  classification?: string | null;
  mcp_dispatch_count?: number;
  sla_met?: boolean | null;
  /** Duration fields arrive as a pre-formatted string from the backend
   *  (e.g. "2 mins"), or sometimes a raw number of minutes — handle both. */
  resolution_mins?: number | string | null;
  elapsed_mins?: number | string | null;
  /** Minutes the workflow has spent blocked on a HITL approval gate. */
  hitl_waiting_mins?: number | string | null;
  /** Minutes the agent was actively executing (excludes HITL waits). */
  processing_mins?: number | string | null;
  created_at?: string;
  resolved_at?: string | null;
  activity_label?: string;
  ticket_info: JobListTicketInfo;
  parent_steps?: unknown[];
}

export interface JobListResponse {
  jobs: JobListItem[];
  total: number;
  page: number;
  page_size: number;
  /** Aggregate counters returned alongside the paged jobs — drive the
   *  dashboard widgets (Open / Auto-Resolved / HITL Required). */
  resolved_count?: number;
  hitl_count?: number;
  open_count?: number;
}

/** A single functional step inside an agent's run — shown on the step-details pane. */
export interface FunctionalStep {
  step_name: string;
  visible: boolean;
  input_summary?: string;
  output_summary?: string;
}

/**
 * One orchestration step. Loose typing on step_output because the agent
 * payload varies per tool (Veeva user-management vs ServiceNow close_ticket
 * return very different shapes).
 */
export interface OrchStep {
  orch_step_id: string;
  orch_workflow_id?: string;
  job_id: string;
  ticket_id: string;
  step_seq: number;
  step_type: string;
  status: string;
  depends_on_step_seq?: number[];
  mcp_server?: string;
  tool_name?: string;
  step_output?: {
    mcp_outcome?: {
      outcome_status?: string;
      output_result?: {
        workflow_executed?: string;
        steps_completed?: string[];
        outcome?: string;
        routing?: string;
        confidence?: number;
        notes?: string;
        veeva_record_url?: string;
        [key: string]: unknown;
      };
      execution_steps?: Array<{
        step_name: string;
        status: string;
        timestamp?: string | null;
        duration_ms?: number | null;
        output?: { input_summary?: string; result_summary?: string };
      }>;
      /** Human-readable narrative of the agent's logical sub-steps. */
      functional_steps?: FunctionalStep[];
      retry_eligible?: boolean;
      error?: unknown;
      [key: string]: unknown;
    };
    [key: string]: unknown;
  };
  hitl_notified_to?: string | null;
  hitl_approved_by?: string | null;
  hitl_approved_at?: string | null;
  hitl_decision?: string | null;
  started_at?: string;
  completed_at?: string;
  duration_ms?: number | null;
  error_code?: string | null;
  created_at?: string;
}

export interface OrchStepsResponse {
  job_id: string;
  steps: OrchStep[];
}
