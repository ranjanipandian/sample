/**
 * CMC Stability Studies (Large Molecules) — virtual lab sample data.
 *
 * This is the GSK pilot program area named in Nandini's email: take up
 * Stability Studies in large molecules, show the labs + experiments as they
 * exist in the ELN today, then show the Reasoning Gap — the hypothesis,
 * decision and failure-investigation context that never makes it into IDBS —
 * and what Agentic AI can surface once that reasoning is captured as
 * first-class data in the Memory Graph (per the white paper).
 *
 * All entity names/ids are illustrative (virtual lab), not real GSK data.
 */

export interface Lab {
  id: string;
  name: string;
  location: string;
  focus: string;
  studyIds: string[];
}

export interface Experiment {
  id: string;
  studyId: string;
  parameter: string;
  timepoint: string;
  result: string;
  status: 'pass' | 'fail' | 'oos' | 'oot';
  /** The literal fact as recorded in IDBS (the ELN) today. */
  elnRecordedFact: string;
}

export interface StabilityStudy {
  id: string;
  name: string;
  molecule: string;
  modality: string;
  labId: string;
  condition: string; // e.g. "Long-Term 5°C", "Accelerated 25°C/60%RH", "Stressed 40°C"
  status: 'ongoing' | 'completed' | 'on-hold';
  startDate: string;
  durationMonths: number;
  summary: string;
}

export interface FailureEvent {
  id: string;
  studyId: string;
  parameter: string;
  timepoint: string;
  observedResult: string;
  /** What IDBS records today — the bare fact. */
  elnRecordedFact: string;
  /** What is missing — the reasoning gap for this specific failure. */
  missingReasoning: string;
  /** What an agent grounded on a Memory Graph (results + reasoning) could
   *  surface by walking prior decisions, change-control, and analyst notes. */
  recoveredHypothesis: string;
  /** The recommended action once reasoning is available. */
  recommendedDecision: string;
  personaInvolved: string;

  /* ── Structured failure-intelligence fields ────────────────────────────
   * Optional, additive fields mirroring the mg:FailureReason shape from the
   * TL's Memory Graph implementation blueprint (memory-graph-blueprint.model.ts
   * → FAILURE_INTELLIGENCE_TRIPLE_EXAMPLE): a failure reason is not just a red
   * table cell, it is reusable scientific memory with its own category,
   * confidence, evidence basis and provenance. Populated here so the Study
   * Detail → Failures tab can render the same structured shape the graph
   * would actually publish, not just prose. */

  /** Short, queryable classification of the root cause — mirrors mg:reasonCategory. */
  reasonCategory?: string;
  /** Agent/graph-walk confidence in the recovered hypothesis, 0–1 — mirrors mg:confidenceScore. */
  confidenceScore?: number;
  /** The specific prior evidence entity the hypothesis rests on — mirrors mg:evidenceBasis. */
  evidenceBasis?: string;
  /** Source artefact the reasoning was derived from — mirrors prov:wasDerivedFrom. */
  wasDerivedFrom?: string;
  /** Who/what asserted the hypothesis — mirrors prov:wasAttributedTo. */
  wasAttributedTo?: string;
}

export interface InsightComparison {
  studyId: string;
  elnOnlyInsights: string[];

  withReasoningInsights: string[];
}

export interface RoiMetric {
  metric: string;
  elnOnly: string;
  withReasoning: string;
  improvement: string;
  narrative: string;
}

export interface PersonaImpact {
  persona: string;
  role: string;
  painPointToday: string;
  benefitWithReasoning: string;
}

export interface ProvenanceEvent {
  id: string;
  timestamp: string;
  actor: string;
  actorType: 'human' | 'agent';
  action: string;
  entity: string;
  studyId?: string;
}

export const LABS: Lab[] = [
  {
    id: 'lab-analytical-stability',
    name: 'Analytical Stability Lab (Site A)',
    location: 'Upper Providence, PA',
    focus: 'Long-term & accelerated stability testing for monoclonal antibodies and fusion proteins',
    studyIds: ['study-mab114-lt', 'study-mab114-acc'],
  },
  {
    id: 'lab-formulation-stability',
    name: 'Formulation Stability Lab (Site B)',
    location: 'Stevenage, UK',
    focus: 'Forced-degradation and thermal-stress studies to inform formulation robustness',
    studyIds: ['study-fp207-stress'],
  },
];

export const STUDIES: StabilityStudy[] = [
  {
    id: 'study-mab114-lt',
    name: 'mAb-114 Long-Term Stability',
    molecule: 'mAb-114',
    modality: 'Monoclonal Antibody (IgG1)',
    labId: 'lab-analytical-stability',
    condition: 'Long-Term 5°C ± 3°C',
    status: 'ongoing',
    startDate: '2024-02-01',
    durationMonths: 36,
    summary:
      'Real-time stability study supporting shelf-life claim for mAb-114 drug product, pulled at 0/3/6/9/12/18/24/36 months.',
  },
  {
    id: 'study-mab114-acc',
    name: 'mAb-114 Accelerated Stability',
    molecule: 'mAb-114',
    modality: 'Monoclonal Antibody (IgG1)',
    labId: 'lab-analytical-stability',
    condition: 'Accelerated 25°C/60%RH',
    status: 'completed',
    startDate: '2023-08-01',
    durationMonths: 6,
    summary:
      'Accelerated-condition study used to predict degradation trends ahead of the long-term readout and support the initial filing timeline.',
  },
  {
    id: 'study-fp207-stress',
    name: 'Fusion Protein-207 Thermal Stress',
    molecule: 'FP-207',
    modality: 'Fc-Fusion Protein',
    labId: 'lab-formulation-stability',
    condition: 'Stressed 40°C/75%RH',
    status: 'completed',
    startDate: '2024-01-15',
    durationMonths: 3,
    summary:
      'Forced-degradation study used to identify the most sensitive quality attributes ahead of formulation lock for FP-207.',
  },
];

export const EXPERIMENTS: Experiment[] = [
  {
    id: 'exp-114lt-t12-scf',
    studyId: 'study-mab114-lt',
    parameter: 'SEC — % High Molecular Weight Species',
    timepoint: '12 months',
    result: '2.8% HMW (spec ≤ 3.0%)',
    status: 'pass',
    elnRecordedFact: 'SEC run 12M-R2 logged: 2.8% HMW, within specification. Analyst: R. Fischer. Instrument: OpenLab-HPLC-04.',
  },
  {
    id: 'exp-114lt-t18-scf',
    studyId: 'study-mab114-lt',
    parameter: 'SEC — % High Molecular Weight Species',
    timepoint: '18 months',
    result: '3.4% HMW (spec ≤ 3.0%)',
    status: 'oos',
    elnRecordedFact: 'SEC run 18M-R1 logged: 3.4% HMW, OOS against 3.0% spec. Analyst: R. Fischer. Instrument: OpenLab-HPLC-04. Retest triggered per SOP-QC-014.',
  },
  {
    id: 'exp-114lt-t18-cex',
    studyId: 'study-mab114-lt',
    parameter: 'CEX — % Acidic Variants',
    timepoint: '18 months',
    result: '18.2% acidic (spec ≤ 20%)',
    status: 'pass',
    elnRecordedFact: 'CEX run 18M-CEX-01 logged: 18.2% acidic variants, within specification.',
  },
  {
    id: 'exp-114acc-t3-potency',
    studyId: 'study-mab114-acc',
    parameter: 'Relative Potency (Cell-Based Bioassay)',
    timepoint: '3 months',
    result: '92% relative potency (spec 80–120%)',
    status: 'pass',
    elnRecordedFact: 'Bioassay run ACC-3M-BA02 logged: 92% relative potency, within specification.',
  },
  {
    id: 'exp-114acc-t6-potency',
    studyId: 'study-mab114-acc',
    parameter: 'Relative Potency (Cell-Based Bioassay)',
    timepoint: '6 months',
    result: '76% relative potency (spec 80–120%)',
    status: 'oos',
    elnRecordedFact: 'Bioassay run ACC-6M-BA05 logged: 76% relative potency, OOS against 80% lower spec limit. Flagged for QA review.',
  },
  {
    id: 'exp-fp207-t1-oxidation',
    studyId: 'study-fp207-stress',
    parameter: 'Met-Oxidation (%, Peptide Map/MS)',
    timepoint: '1 month',
    result: '4.1% oxidation (alert ≥ 3.5%)',
    status: 'oot',
    elnRecordedFact: 'Peptide map run STR-1M-PM03 logged: 4.1% Met-oxidation, exceeds internal alert limit of 3.5%. No spec breach — informational OOT.',
  },
  {
    id: 'exp-fp207-t3-aggregation',
    studyId: 'study-fp207-stress',
    parameter: 'SEC — % Aggregates',
    timepoint: '3 months',
    result: '5.6% aggregates (spec ≤ 5.0%)',
    status: 'oos',
    elnRecordedFact: 'SEC run STR-3M-SEC01 logged: 5.6% aggregates, OOS against 5.0% spec.',
  },
];

export const FAILURE_EVENTS: FailureEvent[] = [
  {
    id: 'fail-114lt-18m-hmw',
    studyId: 'study-mab114-lt',
    parameter: 'SEC — % High Molecular Weight Species',
    timepoint: '18 months',
    observedResult: '3.4% HMW vs 3.0% specification',
    elnRecordedFact:
      'IDBS record: "18M-R1: 3.4% HMW, OOS. Retest 18M-R2 initiated per SOP-QC-014." No further narrative attached.',
    missingReasoning:
      'IDBS does not record that the same lot showed a comparable HMW uptick at 12 months in a related accelerated study, that a column-performance deviation was open on OpenLab-HPLC-04 the week of the run, or that the analyst\'s working hypothesis was instrument-related, not product-related — all of which lived in a Teams thread and the analyst\'s personal notes.',
    recoveredHypothesis:
      'Cross-study graph walk shows: (1) OpenLab-HPLC-04 had an open column-performance deviation (DEV-2291) overlapping the run date; (2) the accelerated study on the same lot (study-mab114-acc) showed no comparable HMW trend at an equivalent aging point; (3) the retest on a qualified column (18M-R2) returned 2.9% HMW, in spec. Combined evidence points to an instrument/column artifact, not real product degradation.',
    recommendedDecision:
      'Disposition the 18M-R1 result as invalid due to assignable instrument cause (DEV-2291), accept 18M-R2 as the reportable result, and flag OpenLab-HPLC-04 for preventive-maintenance review before the next stability pull — closing the loop the ELN alone never surfaces.',
    personaInvolved: 'QC Analyst / Stability Scientist',
    reasonCategory: 'Instrument/Column Artifact',
    confidenceScore: 0.87,
    evidenceBasis: 'DEV-2291 (open column-performance deviation, OpenLab-HPLC-04) + concordant accelerated-study trend + qualified-column retest 18M-R2',
    wasDerivedFrom: 'DEV-2291; exp-114lt-t18-scf; study-mab114-acc HMW trend',
    wasAttributedTo: 'Memory Graph Reasoning Agent (agent-asserted); approved by Dr. A. Kessler, QA Reviewer',
  },

  {
    id: 'fail-114acc-6m-potency',
    studyId: 'study-mab114-acc',
    parameter: 'Relative Potency (Cell-Based Bioassay)',
    timepoint: '6 months',
    observedResult: '76% relative potency vs 80% lower spec limit',
    elnRecordedFact:
      'IDBS record: "ACC-6M-BA05: 76% relative potency, OOS. Escalated to QA." No linkage to assay history or prior decisions.',
    missingReasoning:
      'The ELN does not capture that this cell-based bioassay had failed system-suitability twice in the preceding month for unrelated products, that the reference standard lot used was within 2 weeks of its requalification date, or that a prior deviation (DEV-2114) had already linked assay drift to reference-standard age for a different program.',
    recoveredHypothesis:
      'Graph walk across the bioassay platform (shared reference standard, shared analysts, shared instrument) surfaces DEV-2114\'s prior conclusion: aging reference standard correlates with a downward potency bias of 4–8%. The current reference-standard lot is 2 weeks from requalification, consistent with the observed 76% result being a reference-standard artifact rather than true product loss of potency.',
    recommendedDecision:
      'Repeat the assay against a freshly qualified reference-standard lot before accepting the 6-month potency trend as a genuine stability signal; if potency normalizes, disposition ACC-6M-BA05 as reference-standard-attributable and update the reference-standard qualification interval SOP.',
    personaInvolved: 'Bioassay Scientist / QA Reviewer',
    reasonCategory: 'Reference-Standard Aging Artifact',
    confidenceScore: 0.74,
    evidenceBasis: 'DEV-2114 (prior deviation linking reference-standard age to 4–8% potency bias) + reference-standard lot 2 weeks from requalification',
    wasDerivedFrom: 'DEV-2114; exp-114acc-t6-potency',
    wasAttributedTo: 'Memory Graph Reasoning Agent (agent-asserted); pending SME review',
  },

  {
    id: 'fail-fp207-3m-aggregates',
    studyId: 'study-fp207-stress',
    parameter: 'SEC — % Aggregates',
    timepoint: '3 months',
    observedResult: '5.6% aggregates vs 5.0% specification',
    elnRecordedFact:
      'IDBS record: "STR-3M-SEC01: 5.6% aggregates, OOS under stress condition (40°C)." Logged as an expected stress-study finding, no further annotation.',
    missingReasoning:
      'The ELN does not capture the formulation team\'s working hypothesis — discussed in a governance slide deck, not IDBS — that the aggregation onset correlates with the polysorbate-80 lot change introduced at month 1, and that this same PS-80 lot had already been flagged informally in a different program\'s forced-degradation study.',
    recoveredHypothesis:
      'Linking the 1-month oxidation OOT (exp-fp207-t1-oxidation) and the 3-month aggregation OOS through shared lot metadata reveals both quality attributes shifted after the same PS-80 lot change — consistent with a formulation-related root cause (surfactant oxidative degradation products promoting aggregation) rather than a purely thermal-stress artifact.',
    recommendedDecision:
      'Flag the PS-80 lot for investigation before formulation lock; consider re-running the thermal-stress arm with the prior qualified PS-80 lot to isolate lot-effect from thermal-stress effect ahead of the formulation decision.',
    personaInvolved: 'Formulation Scientist / CMC Program Lead',
    reasonCategory: 'Excipient Lot-Linked Degradation',
    confidenceScore: 0.69,
    evidenceBasis: 'Shared PS-80 lot change at month 1 correlated across two independent quality attributes (Met-oxidation OOT + SEC aggregation OOS)',
    wasDerivedFrom: 'exp-fp207-t1-oxidation; exp-fp207-t3-aggregation; governance slide deck (informal cross-program PS-80 flag)',
    wasAttributedTo: 'Memory Graph Reasoning Agent (agent-asserted); pending SME review',
  },
];


export const INSIGHT_COMPARISONS: InsightComparison[] = [
  {
    studyId: 'study-mab114-lt',
    elnOnlyInsights: [
      'HMW species rose from 2.8% (12M) to 3.4% (18M), breaching the 3.0% spec.',
      'A retest was performed per SOP-QC-014.',
      'CEX acidic variants remain within specification through 18 months.',
    ],
    withReasoningInsights: [
      'The 18M HMW excursion correlates with an open column-performance deviation (DEV-2291) on the exact instrument used — an assignable, non-product cause, not a genuine degradation trend.',
      'A parallel accelerated study on the same lot shows no comparable HMW trend at an equivalent aging point, corroborating the instrument-artifact hypothesis rather than confirming real degradation.',
      'Confidence in the shelf-life claim increases, not decreases, once the reasoning chain is walked — the opposite conclusion an ELN-only read would suggest.',
    ],
  },
  {
    studyId: 'study-mab114-acc',
    elnOnlyInsights: [
      'Relative potency dropped from 92% (3M) to 76% (6M), breaching the 80% lower limit.',
      'The result was escalated to QA as an OOS.',
    ],
    withReasoningInsights: [
      'The reference-standard lot used for the 6-month assay was 2 weeks from requalification — a known bias pattern documented in a prior, unrelated deviation (DEV-2114).',
      'A retest against a freshly qualified reference standard is the recommended next step before treating the 6-month result as a true stability signal.',
      'Without this reasoning, the accelerated-stability trend risks over-stating degradation risk to the filing timeline.',
    ],
  },
  {
    studyId: 'study-fp207-stress',
    elnOnlyInsights: [
      'Met-oxidation exceeded the internal alert limit at 1 month (4.1% vs 3.5%).',
      'SEC aggregates breached specification at 3 months (5.6% vs 5.0%).',
      'Both findings were logged as separate, expected stress-study observations.',
    ],
    withReasoningInsights: [
      'Both quality-attribute shifts trace back to the same polysorbate-80 lot change at month 1 — a shared root cause, not two independent stress artifacts.',
      'This reframes the finding from "thermal stress degrades FP-207 as expected" to "a specific excipient lot may be driving degradation," which changes the formulation-lock decision materially.',
      'The recommended next study design (re-run with prior PS-80 lot) only emerges once the two findings are linked through reasoning, not visible from either ELN entry alone.',
    ],
  },
];

export const ROI_METRICS: RoiMetric[] = [
  {
    metric: 'Time to root-cause an OOS/OOT event',
    elnOnly: '5–8 business days (manual cross-referencing of decks, threads, and prior deviations)',
    withReasoning: 'Minutes (single graph walk across linked provenance)',
    improvement: '~95% cycle-time reduction',
    narrative:
      'Investigators currently reconstruct context manually from OneNote, Teams and slide decks. A Memory Graph query replaces that reconstruction with a typed subgraph walk.',
  },
  {
    metric: 'False-positive stability excursions escalated to QA',
    elnOnly: 'Every OOS/OOT is escalated regardless of assignable-cause likelihood',
    withReasoning: 'Pre-triaged by likely assignable cause before human escalation',
    improvement: 'Est. 30–40% reduction in unnecessary escalations',
    narrative:
      'Cross-study and cross-instrument correlation (as in DEV-2291 and DEV-2114) lets the agent flag likely-artifact events before they consume QA review cycles.',
  },
  {
    metric: 'Analyst / scientist time spent reconstructing "why" for regulatory queries',
    elnOnly: 'Hours to days per query, dependent on tenure of staff involved',
    withReasoning: 'Provenance trail answered directly from the graph, cited to source triples',
    improvement: '~70–80% time saved per regulatory information request',
    narrative:
      'The graph answers "how do we know" by walking the provenance chain to the originating run, analyst, method and approval — no dependency on institutional memory of specific people.',
  },
  {
    metric: 'Formulation-lock decision cycle (e.g., FP-207 PS-80 lot issue)',
    elnOnly: 'Root cause surfaces late, often after formulation lock, risking rework',
    withReasoning: 'Root cause (lot-linked, cross-attribute) surfaces during the stress study itself',
    improvement: 'Avoids downstream formulation rework — high-value avoidance, case-specific',
    narrative:
      'Linking oxidation and aggregation findings through shared lot metadata during the study — not after — changes the decision window entirely.',
  },
  {
    metric: 'Institutional knowledge retention when staff turn over',
    elnOnly: 'Reasoning lives in individual heads/threads; lost on attrition',
    withReasoning: 'Reasoning is graph data — persists independent of any individual',
    improvement: 'Durable, compounding institutional memory',
    narrative:
      'The white paper\'s core thesis: reasoning as first-class data survives the attrition that erodes everything built only on top of the ELN.',
  },
];

export const PERSONA_IMPACTS: PersonaImpact[] = [
  {
    persona: 'QC / Stability Analyst',
    role: 'Runs the assay, logs the result, initiates retests on OOS/OOT.',
    painPointToday:
      'Spends hours manually checking whether a similar excursion happened before, on which instrument, and whether a deviation is already open — often relying on memory or asking colleagues.',
    benefitWithReasoning:
      'Gets a pre-assembled reasoning chain (prior deviations, related studies, instrument history) the moment an OOS is logged — investigation starts from a hypothesis, not a blank page.',
  },
  {
    persona: 'Stability / Formulation Scientist',
    role: 'Owns the scientific interpretation of stability trends and formulation decisions.',
    painPointToday:
      'Reconstructs cross-study correlations (e.g., a shared excipient lot across two quality attributes) manually and often only discovers them in governance review, late in the program.',
    benefitWithReasoning:
      'Agent surfaces cross-attribute, cross-study correlations automatically as they emerge, shifting root-cause discovery earlier in the decision window.',
  },
  {
    persona: 'QA Reviewer',
    role: 'Reviews and dispositions OOS/OOT investigations before batch release or regulatory submission.',
    painPointToday:
      'Every OOS/OOT arrives undifferentiated; QA must independently judge assignable-cause likelihood with limited context.',
    benefitWithReasoning:
      'Receives a pre-triaged view — likely-artifact events (with cited evidence) versus events with no corroborating pattern — improving review throughput and consistency.',
  },
  {
    persona: 'CMC Program Lead',
    role: 'Owns the overall program timeline, filing readiness and risk register.',
    painPointToday:
      'Learns about root-cause findings that affect timeline (e.g., formulation-lock risk) only when they surface in a review meeting, sometimes after key decisions are already made.',
    benefitWithReasoning:
      'Sees a live, queryable risk/reasoning trail across labs and studies, enabling earlier intervention and more defensible timeline decisions.',
  },
  {
    persona: 'Regulatory Affairs / Submissions',
    role: 'Assembles the scientific narrative and justification for stability claims in regulatory filings.',
    painPointToday:
      'Reconstructs "why we believe this shelf-life claim is sound" from scattered reports, decks and personal knowledge — a slow, audit-risky process.',
    benefitWithReasoning:
      'Can generate a provenance-backed narrative directly from the graph — every claim traceable to its originating run, analyst, deviation and decision (satisfying EU AI Act Art. 12/13-style traceability as a byproduct).',
  },
];

export const PROVENANCE_TRAIL: ProvenanceEvent[] = [
  {
    id: 'prov-01',
    timestamp: '2025-08-04 09:12',
    actor: 'R. Fischer (Analyst)',
    actorType: 'human',
    action: 'Logged SEC run 18M-R1 result (3.4% HMW) into IDBS',
    entity: 'exp-114lt-t18-scf',
    studyId: 'study-mab114-lt',
  },
  {
    id: 'prov-02',
    timestamp: '2025-08-04 09:15',
    actor: 'IDBS (system)',
    actorType: 'agent',
    action: 'Flagged result as OOS against 3.0% specification; auto-triggered SOP-QC-014 retest workflow',
    entity: 'exp-114lt-t18-scf',
    studyId: 'study-mab114-lt',
  },
  {
    id: 'prov-03',
    timestamp: '2025-08-04 11:40',
    actor: 'Memory Graph Reasoning Agent',
    actorType: 'agent',
    action: 'Executed cross-study graph walk: joined instrument maintenance record, open deviation DEV-2291, and accelerated-study HMW trend for the same lot',
    entity: 'reasoning-chain-114lt-18m',
    studyId: 'study-mab114-lt',
  },
  {
    id: 'prov-04',
    timestamp: '2025-08-04 11:41',
    actor: 'Memory Graph Reasoning Agent',
    actorType: 'agent',
    action: 'Wrote back hypothesis triple: "OOS 18M-R1 likely attributable to DEV-2291 (column-performance deviation), not product degradation" — marked as agent-asserted, pending SME review',
    entity: 'hypothesis-114lt-18m-01',
    studyId: 'study-mab114-lt',
  },
  {
    id: 'prov-05',
    timestamp: '2025-08-05 14:02',
    actor: 'R. Fischer (Analyst)',
    actorType: 'human',
    action: 'Performed retest 18M-R2 on a qualified column; result 2.9% HMW, in specification',
    entity: 'exp-114lt-t18-scf',
    studyId: 'study-mab114-lt',
  },
  {
    id: 'prov-06',
    timestamp: '2025-08-06 10:20',
    actor: 'Dr. A. Kessler (QA Reviewer)',
    actorType: 'human',
    action: 'Reviewed agent-asserted hypothesis and retest evidence; approved disposition of 18M-R1 as invalid (assignable instrument cause)',
    entity: 'hypothesis-114lt-18m-01',
    studyId: 'study-mab114-lt',
  },
  {
    id: 'prov-07',
    timestamp: '2025-08-06 10:22',
    actor: 'Dr. A. Kessler (QA Reviewer)',
    actorType: 'human',
    action: 'Human-approved hypothesis promoted from "pending SME review" to accepted institutional knowledge in the graph',
    entity: 'hypothesis-114lt-18m-01',
    studyId: 'study-mab114-lt',
  },
  {
    id: 'prov-08',
    timestamp: '2025-08-06 10:25',
    actor: 'Memory Graph (system)',
    actorType: 'agent',
    action: 'Flagged OpenLab-HPLC-04 for preventive-maintenance review ahead of next scheduled stability pull, citing DEV-2291 and the accepted hypothesis as provenance',
    entity: 'pm-flag-hplc04',
    studyId: 'study-mab114-lt',
  },
];

export function getLab(id: string): Lab | undefined {
  return LABS.find((l) => l.id === id);
}

export function getStudy(id: string): StabilityStudy | undefined {
  return STUDIES.find((s) => s.id === id);
}

export function getExperimentsForStudy(studyId: string): Experiment[] {
  return EXPERIMENTS.filter((e) => e.studyId === studyId);
}

export function getFailureEventsForStudy(studyId: string): FailureEvent[] {
  return FAILURE_EVENTS.filter((f) => f.studyId === studyId);
}

export function getInsightComparison(studyId: string): InsightComparison | undefined {
  return INSIGHT_COMPARISONS.find((i) => i.studyId === studyId);
}

export function getProvenanceForStudy(studyId: string): ProvenanceEvent[] {
  return PROVENANCE_TRAIL.filter((p) => p.studyId === studyId);
}
