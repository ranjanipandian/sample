/**
 * White Paper Concepts — Sections 3–7 virtual-lab data.
 *
 * Section 1 (The Reasoning Gap) and part of Section 2 (Memory Graph definition)
 * are demonstrated by the Landscape + Stability Studies pages
 * (landscape.model.ts / stability.model.ts). This file covers the remaining
 * sections of "The Memory Graph" white paper so the virtual lab reflects the
 * full document, not just the opening premise:
 *
 *   §3 The Semantic Medallion Architecture (Bronze / Silver / Gold)
 *   §4 Agents on the Memory Graph (Retrieval / Reasoning / Write-back)
 *   §5 Confidentiality and Multi-Tenancy by Design (7 layers of control)
 *   §6 Strategic Implications
 *   §7 Attribution, Compute Cost, and the Graph as Ledger
 *
 * All examples reuse the same illustrative mAb-114 / stability story already
 * established in landscape.model.ts and stability.model.ts (18M HMW OOS,
 * DEV-2291, DEV-2114, FP-207 PS-80 lot) so the whole virtual lab reads as one
 * continuous narrative rather than disconnected demos. Entity names/ids are
 * illustrative (virtual lab), not real GSK data.
 */

/* ────────────────────────────────────────────────────────────────────────
 * §3 — The Semantic Medallion Architecture
 * ──────────────────────────────────────────────────────────────────────── */

export type MedallionLayerId = 'bronze' | 'silver' | 'gold';

export interface MedallionArtifact {
  label: string;
  detail: string;
}

export interface MedallionLayer {
  id: MedallionLayerId;
  name: string;
  tagline: string;
  description: string;
  standard: string;
  artifacts: MedallionArtifact[];
}

export const MEDALLION_LAYERS: MedallionLayer[] = [
  {
    id: 'bronze',
    name: 'Bronze — Harvest and Land',
    tagline: 'Raw artefacts, byte-for-byte, no interpretation.',
    description:
      'Raw exports exactly as they exist in source systems today — an auditor can reconstruct any original byte-for-byte. No parsing, no typing, no reconciliation happens here.',
    standard: 'Object storage + Parquet',
    artifacts: [
      { label: 'IDBS export — exp-114lt-t18-scf.xml', detail: 'Raw ELN entry for the 18-month SEC run, exactly as R. Fischer logged it, including the free-text SOP-QC-014 retest note.' },
      { label: 'OpenLab-HPLC-04 instrument log — RUN-18M-R1.raw', detail: 'Untouched chromatography instrument output for the same run.' },
      { label: 'Applied Smart Factory telemetry dump — ASF-ANOM-2214.json', detail: 'Raw shop-floor sensor stream around the fill-finish anomaly window.' },
      { label: 'Teams thread export (unstructured)', detail: 'The analyst\'s informal discussion of the column-performance concern — landed as-is, not yet mined for reasoning.' },
    ],
  },
  {
    id: 'silver',
    name: 'Silver — Structure and Identify',
    tagline: 'Parsed, locally typed, identity resolved within each source.',
    description:
      'Each Bronze artefact is parsed into a locally consistent, typed record. Vendor instrument formats are converted to open standards where they exist (ASM, AnIML). Identity is resolved within each source system, but not yet reconciled across sources. Every Silver dataset is published as a W3C DCAT Distribution.',
    standard: 'ASM / AnIML + W3C DCAT Distribution',
    artifacts: [
      { label: 'Typed Experiment record (IDBS namespace)', detail: 'exp-114lt-t18-scf: parameter=SEC-HMW, timepoint=18M, result=3.4%, status=OOS — structured fields, IDBS-local identifiers only.' },
      { label: 'Typed Deviation record (Quality namespace)', detail: 'DEV-2291: column-performance deviation, opened/overlapping the 18M-R1 run window — still a QMS-local record at this layer.' },
      { label: 'Typed Telemetry-Anomaly record (MES namespace)', detail: 'ASF-ANOM-2214: anomaly class, timestamp, affected line — structured, but not yet linked to the batch record it actually affects.' },
    ],
  },
  {
    id: 'gold',
    name: 'Gold — Harmonise and Publish as RDF',
    tagline: 'One URI per real-world entity. Reasoning becomes first-class. Queryable.',
    description:
      'Cross-source entity reconciliation: Benchling\'s "A123", registration\'s "CMP-114-09" and stability\'s "S-A123-01" style identifiers become one URI. Reasoning artefacts (hypotheses, decisions, evidence claims) are modelled as first-class graph entities, public ontologies are applied, PROV-O lineage is embedded throughout, and the whole catalogue is published over a SPARQL endpoint. Gold is the institutional asset — Bronze and Silver are implementation choices that can evolve underneath it.',
    standard: 'RDF + PROV-O + DCAT catalogue over SPARQL',
    artifacts: [
      { label: 'mg:Batch_mAb114_SL-2024-118 (reconciled URI)', detail: 'COMET\'s "SL-2024-118", Batch Tracking\'s "BT-GEN-SL-2024-118" and IDBS\'s lot reference all resolve to this one graph entity.' },
      { label: 'mg:Hypothesis_114lt-18m-01 (first-class reasoning entity)', detail: '"OOS 18M-R1 likely attributable to DEV-2291, not product degradation" — linked to the experiment it explains, the deviation it cites, and the agent that asserted it (PROV-O Agent).' },
      { label: 'mg:Decision_18MR1-disposition', detail: 'The QA Reviewer\'s disposition decision, linked back through provenance to the hypothesis, the retest evidence, and forward to the preventive-maintenance flag it triggered.' },
    ],
  },
];

/* ────────────────────────────────────────────────────────────────────────
 * §4 — Agents on the Memory Graph (Retrieval / Reasoning / Write-back)
 * ──────────────────────────────────────────────────────────────────────── */

export type AgentCapability = 'retrieval' | 'reasoning' | 'write-back';

export interface SampleQuery {
  id: string;
  capability: AgentCapability;
  question: string;
  /** The typed subgraph / graph-walk result an agent grounded on the Memory Graph would return. */
  resultSummary: string;
  citedTriples: string[];
  /** For write-back queries: the new triple the agent proposes to add, and its review state. */
  writeBack?: {
    triple: string;
    state: 'pending-sme-review' | 'accepted' | 'quarantined';
  };
}

export const SAMPLE_QUERIES: SampleQuery[] = [
  {
    id: 'q-retrieval-1',
    capability: 'retrieval',
    question:
      'Show experiments where mAb-114 was the active ingredient, conducted under GMP, in the last 24 months, with the prior decisions that motivated them and the downstream decisions they informed.',
    resultSummary:
      'Returns a typed subgraph of 7 experiments across study-mab114-lt and study-mab114-acc — not a document list. Each node carries its acting system, result, status, and linked reasoning entities (hypotheses, deviations) as explicit edges, not free text.',
    citedTriples: [
      'mg:Experiment_exp-114lt-t18-scf mg:hasStatus "OOS"',
      'mg:Experiment_exp-114lt-t18-scf mg:motivatedBy mg:Decision_designSpaceReviewB',
      'mg:Experiment_exp-114lt-t18-scf mg:informedDecision mg:Decision_18MR1-disposition',
    ],
  },
  {
    id: 'q-reasoning-1',
    capability: 'reasoning',
    question:
      'Does the 18-month stability anomaly on lot SL-2024-118 correlate with the fill-finish telemetry anomaly logged the same week, and does the original stability rationale still hold?',
    resultSummary:
      'Multi-hop graph walk: ASF-ANOM-2214 (Applied Smart Factory) and DEV-2291 (OpenLab-HPLC-04 column deviation) both fall inside the same 72-hour window as the 18M-R1 run on the same batch URI. The graph walk surfaces this as a candidate shared-cause link — something neither Applied Smart Factory nor IDBS records on its own. Original long-term stability rationale (formulation option B, §1 design-space review) is unaffected: the anomaly resolves to an assignable instrument/process cause, not a formulation risk.',
    citedTriples: [
      'mg:Batch_mAb114_SL-2024-118 mg:hadEvent mg:TelemetryAnomaly_ASF-ANOM-2214',
      'mg:Batch_mAb114_SL-2024-118 mg:hadEvent mg:Deviation_DEV-2291',
      'mg:TelemetryAnomaly_ASF-ANOM-2214 prov:generatedAtTime "2024-01-24T08:12"',
      'mg:Deviation_DEV-2291 mg:overlapsRun mg:Run_18M-R1',
    ],
  },
  {
    id: 'q-writeback-1',
    capability: 'write-back',
    question:
      'Agent flags a candidate root-cause hypothesis for the 18-month HMW OOS after the graph walk above and proposes writing it back.',
    resultSummary:
      'The agent writes back a new hypothesis triple, tagged as agent-asserted (PROV-O Agent), and routes it to quarantine pending SME review — it is not treated as accepted institutional knowledge until a human reviewer approves it. This is the same hypothesis later approved in the Provenance Trail (Dr. A. Kessler, QA Reviewer).',
    citedTriples: [
      'mg:Hypothesis_114lt-18m-01 a mg:Hypothesis',
      'mg:Hypothesis_114lt-18m-01 prov:wasAttributedTo mg:Agent_MemoryGraphReasoningAgent',
      'mg:Hypothesis_114lt-18m-01 mg:reviewState "pending-sme-review"',
    ],
    writeBack: {
      triple: '"OOS 18M-R1 likely attributable to DEV-2291 (column-performance deviation), not product degradation."',
      state: 'pending-sme-review',
    },
  },
  {
    id: 'q-writeback-2',
    capability: 'write-back',
    question:
      'Formulation team asks: has this PS-80 lot issue on FP-207 been seen before, and should the graph remember it for other programmes?',
    resultSummary:
      'Retrieval finds no prior linked record for this exact lot, but the graph walk correlates the 1-month oxidation OOT and 3-month aggregation OOS through shared lot metadata. The agent writes back a cross-attribute hypothesis, scoped to the FP-207 named graph only — it is not automatically visible to other therapeutic-area programmes (per §5 partitioning) until a human explicitly grants cross-programme entitlement.',
    citedTriples: [
      'mg:Experiment_exp-fp207-t1-oxidation mg:sharesLot mg:Lot_PS80-2024-07',
      'mg:Experiment_exp-fp207-t3-aggregation mg:sharesLot mg:Lot_PS80-2024-07',
      'mg:Hypothesis_fp207-ps80-lotcause prov:wasAttributedTo mg:Agent_MemoryGraphReasoningAgent',
    ],
    writeBack: {
      triple: '"Met-oxidation and aggregate growth both trace to PS-80 lot 2024-07 — a shared excipient root cause, not two independent stress artefacts."',
      state: 'quarantined',
    },
  },
];

/* ────────────────────────────────────────────────────────────────────────
 * §5 — Confidentiality and Multi-Tenancy by Design (7 layers of control)
 * ──────────────────────────────────────────────────────────────────────── */

export interface ConfidentialityLayer {
  id: string;
  layer: string;
  mechanism: string;
  preEmpts: string;
  /** How this control shows up concretely in the virtual lab's existing entities. */
  virtualLabExample: string;
}

export const CONFIDENTIALITY_LAYERS: ConfidentialityLayer[] = [
  {
    id: 'partitioning',
    layer: 'Partitioning',
    mechanism:
      'Named graphs per programme, study, JV or therapeutic area. Default state is isolation; cross-graph queries require explicit entitlement.',
    preEmpts: 'Cross-programme leakage by construction.',
    virtualLabExample:
      'lab-analytical-stability (mAb-114 studies) and lab-formulation-stability (FP-207 study) are separate named graphs. A query scoped to mAb-114 cannot see FP-207\'s PS-80 lot hypothesis unless cross-graph access is explicitly granted.',
  },
  {
    id: 'triple-auth',
    layer: 'Triple-level authorisation',
    mechanism:
      'Attribute-based access control at the SPARQL endpoint. Queries are rewritten against the requester\'s entitlements; unauthorised triples are filtered before data leaves the graph.',
    preEmpts: 'Application bugs exposing data they should not see.',
    virtualLabExample:
      'A QC Analyst querying study-mab114-lt receives the experiment and failure-event triples they\'re entitled to; the same query issued by an unentitled external CRO account returns a filtered, incomplete subgraph — not an error, just fewer triples.',
  },
  {
    id: 'sensitivity-ontology',
    layer: 'Sensitivity in the ontology',
    mechanism:
      'Confidentiality classes — blinded, JV-restricted, pre-disclosure, GxP — are first-class entities. Policies query the model rather than scattered application config.',
    preEmpts: 'Policy drift across applications and over time.',
    virtualLabExample:
      'study-mab114-lt is tagged mg:confidentialityClass "GxP" directly on the study entity — any policy engine anywhere in the estate reads that one flag instead of maintaining a separate rulebook per application.',
  },
  {
    id: 'agent-scoping',
    layer: 'Agent scoping',
    mechanism:
      'Agents authenticate with project-scoped credentials and are recorded as PROV-O Agents. Retrieval and write-back are both scoped to authorised named graphs.',
    preEmpts: 'Cross-project pollution and ungoverned agent writes.',
    virtualLabExample:
      'The Memory Graph Reasoning Agent that wrote the 18M-R1 hypothesis is scoped only to the mAb-114 named graph — it cannot write back a hypothesis into the FP-207 graph even if the pattern looks similar.',
  },
  {
    id: 'pre-graph',
    layer: 'Pre-graph controls',
    mechanism:
      'Sensitivity classification at ingest. Tokenisation of commercially sensitive identifiers (compound codes, JV partner names) before Silver. HSM-backed encryption in transit and at rest.',
    preEmpts: 'Sensitive data exposed in landing zones.',
    virtualLabExample:
      'Before mAb-114\'s raw IDBS export even reaches Silver, the compound code and any JV-partner references in it are classified and tokenised at Bronze intake — long before entity reconciliation happens.',
  },
  {
    id: 'continuous-audit',
    layer: 'Continuous audit',
    mechanism:
      'Every read and write is provenanced via PROV-O. A suspected leak becomes a SPARQL query, not a six-week forensic investigation. Annex 11 / 21 CFR Part 11 are satisfied as a side-effect of provenance discipline.',
    preEmpts: 'Unauditable historical access.',
    virtualLabExample:
      'This is exactly what the Provenance Trail page already shows for study-mab114-lt — every human and agent read/write, timestamped, actor-typed, queryable.',
  },
  {
    id: 'cross-client',
    layer: 'Cross-client isolation (Cognizant)',
    mechanism:
      'Each client\'s graph runs in their tenancy on their infrastructure. Project-scoped access for delivery teams. Methodology, ontology patterns and engineering practice are reused across our client base; instance data is not.',
    preEmpts: 'Cross-client contamination.',
    virtualLabExample:
      'The GSK mAb-114 / stability virtual lab you are looking at runs entirely inside GSK\'s illustrative tenancy. The same Bronze/Silver/Gold pattern and ontology approach could be reused for Sanofi\'s data — but never this instance data.',
  },
];

export const CONFIDENTIALITY_SPECIAL_CASES: { title: string; detail: string }[] = [
  { title: 'Blinded studies', detail: 'De-blinding is prevented in the ontology itself, not by relying on user trust.' },
  { title: 'Pre-publication / patent-sensitive work', detail: 'Programme-coded until disclosure — the sensitive identifier is tokenised until a disclosure event flips the flag.' },
  { title: 'JV and collaboration boundaries', detail: 'Separate named graphs with negotiated, explicit cross-graph access.' },
  { title: 'Cross-border residency', detail: 'Federation across jurisdictions without copying data out of its residency boundary.' },
];

/* ────────────────────────────────────────────────────────────────────────
 * §6 — Strategic Implications
 * ──────────────────────────────────────────────────────────────────────── */

export interface StrategicImplication {
  id: string;
  title: string;
  body: string;
}

export const STRATEGIC_IMPLICATIONS: StrategicImplication[] = [
  {
    id: 'eln-agnostic',
    title: 'ELN-agnostic',
    body:
      'The Memory Graph survives ELN consolidation, federation, and the emerging post-ELN future in which instruments and agents record science directly. ELN strategy becomes a procurement decision, not an architectural one — IDBS could be replaced tomorrow and the mAb-114 reasoning chain would persist.',
  },
  {
    id: 'vendor-independent',
    title: 'Vendor-independent',
    body:
      'Gold speaks W3C standards. No vendor — ELN, LIMS, cloud, or AI — controls institutional memory. Platform decisions become reversible; data strategy does not follow vendor strategy.',
  },
  {
    id: 'regulator-aligned',
    title: 'Regulator-aligned',
    body:
      'DCAT and PROV-O align with IDMP, EU CTR, FDA structured submissions, KASA, and European data spaces. The provenance architecture directly satisfies EU AI Act Articles 12 and 13 — automatic logging of high-risk AI system operations and transparency to deployers — where they apply to R&D use cases. Compliance is a side-effect of good architecture, not a retrofit.',
  },
  {
    id: 'agent-ready',
    title: 'Agent-ready by design',
    body:
      'Any current or future agent — internal, partnered, open-source — is grounded against the same graph. The foundational investment compounds across every agent. The marginal cost of the next agent is the cost of defining its use case, not rebuilding its knowledge foundation.',
  },
  {
    id: 'reasoning-capturing',
    title: 'Reasoning-capturing',
    body:
      'The only architectural layer holding both results and reasoning. As scientific work is increasingly performed with agents, the graph is where joint reasoning persists and survives the attrition, platform migrations, and AI vendor cycles that erode everything built on top of it.',
  },
];

export const DELIVERY_REALITIES: { title: string; detail: string }[] = [
  { title: 'Built, not bought', detail: 'Vendors sell components, not the architectural commitment to ontology stewardship and standards governance.' },
  { title: 'GxP scope is bounded', detail: 'Validation is contained to GxP-classified named graphs (e.g. study-mab114-lt), not the whole estate.' },
  { title: 'Cost concentrates in Gold', detail: 'Gold reconciliation and ontology stewardship carry the cost; Bronze and Silver are commodity engineering.' },
];

/* ────────────────────────────────────────────────────────────────────────
 * §7 — Attribution, Compute Cost, and the Graph as Ledger
 * ──────────────────────────────────────────────────────────────────────── */

export interface AttributionNode {
  id: string;
  label: string;
  contributor: string;
  /** Downstream decisions/nodes this contribution reaches. */
  downstream: string[];
  /** Whether this contribution has been superseded/deprecated. */
  status: 'active' | 'deprecated';
  weight: number; // illustrative 0-100 contribution weight
  note: string;
}

export const ATTRIBUTION_CHAIN: AttributionNode[] = [
  {
    id: 'attr-hmw-hypothesis',
    label: 'Hypothesis: 18M-R1 OOS attributable to DEV-2291 (instrument cause)',
    contributor: 'Memory Graph Reasoning Agent (compute: 1 SPARQL walk + 1 LLM inference)',
    downstream: ['Decision: disposition of 18M-R1 as invalid', 'PM flag on OpenLab-HPLC-04'],
    status: 'active',
    weight: 62,
    note:
      'Agent compute cost for this inference is attributed back to the knowledge it actually consulted: DEV-2291 (Quality team contribution) and the accelerated-study cross-check (R. Fischer\'s analytical run). Not just billed to "the agent" or "the programme" — billed to the contributing knowledge.',
  },
  {
    id: 'attr-refstd-hypothesis',
    label: 'Prior finding: aging reference standard biases potency 4–8% low (DEV-2114)',
    contributor: 'Bioassay Scientist (human, unrelated prior programme)',
    downstream: ['Recovered hypothesis for ACC-6M-BA05 potency OOS', 'SOP update: reference-standard qualification interval'],
    status: 'active',
    weight: 78,
    note:
      'A human contribution from a different, unrelated programme is reused here — the graph makes that reuse visible and attributable, something a flat ledger or a document archive cannot do.',
  },
  {
    id: 'attr-ps80-superseded',
    label: 'Original finding: FP-207 aggregation is a generic thermal-stress artefact',
    contributor: 'Initial IDBS entry (R. Fischer analyst note, no cross-attribute link)',
    downstream: [],
    status: 'deprecated',
    weight: 0,
    note:
      'Superseded once the PS-80 lot-linked hypothesis was written back. Attribution weight for this finding is revised to zero and transferred to the superseding cross-attribute hypothesis below — exactly the dynamic re-weighting the white paper describes as impossible for a flat ledger.',
  },
  {
    id: 'attr-ps80-superseding',
    label: 'Superseding finding: PS-80 lot 2024-07 links oxidation + aggregation',
    contributor: 'Memory Graph Reasoning Agent (compute: 1 SPARQL walk across shared-lot metadata)',
    downstream: ['Recommendation: flag PS-80 lot before formulation lock', 'Re-run design for thermal-stress arm'],
    status: 'active',
    weight: 84,
    note:
      'Inherits the attribution weight released by the deprecated generic-artefact finding above, plus new weight from the cross-attribute correlation itself.',
  },
];

export const LEDGER_PROPERTIES: { title: string; body: string }[] = [
  {
    title: 'Multi-party boundaries are already drawn',
    body:
      'The named graphs that enforce confidentiality (§5) double as economic units. A cross-graph query is an access event — logged, provenanced, attributable — without a shared blockchain or bespoke bilateral accounting system. The Memory Graph is already the ledger.',
  },
  {
    title: 'Influence is computable, not estimated',
    body:
      'Because every triple carries provenance and every agent query is logged, the reach of a contribution — how many downstream decisions depended on it, how deep the chain runs — is a graph query, not an audit exercise.',
  },
  {
    title: 'Value adjusts with the knowledge',
    body:
      'When a finding is superseded (as with the FP-207 thermal-stress artefact above), the graph marks those triples deprecated and can revise or transfer the associated attribution weight — as part of normal provenance discipline, not a special process.',
  },
];
