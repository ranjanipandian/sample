/**
 * Models for the self-service "MCP Tools" settings page.
 *
 * The page merges two backends, keyed by `server_name` + tool `name`:
 *   - orchestrator GET /v1/mcp/catalog  → the live, full tool list + descriptions
 *   - identity     GET /v1/me/tools     → the caller's per-tool access status
 */

/* ── Orchestrator catalog (GET /v1/mcp/catalog) ──────────────────────── */

export interface McpCatalogTool {
  name: string;
  description: string;
}

/** Live reachability when requested via ?health=true, else 'unknown'. */
export type McpConnectionStatus = 'connected' | 'disconnected' | 'unknown';

export interface McpCatalogServer {
  server_name: string;
  style: string;
  tool_count: number;
  status: McpConnectionStatus;
  tools: McpCatalogTool[];
}

export interface McpCatalogResponse {
  servers: McpCatalogServer[];
}

/* ── Identity self-service status (GET/PUT /v1/me/tools) ──────────────── */

/**
 * enabled         — effective ALLOW; the user can invoke now.
 * needs_approval  — in-envelope, user opted into a per-invocation approval gate.
 * self_disabled   — role allows but the user opted out (per-user DENY).
 * pending_approval— user requested an out-of-envelope tool; awaiting SUPERVISOR.
 * denied          — governed role-level DENY (set by supervisor/admin); blocked,
 *                   and lifting it requires SUPERVISOR approval.
 * requestable     — outside the role envelope; enabling raises an approval.
 */
export type McpToolStatus =
  | 'enabled'
  | 'needs_approval'
  | 'self_disabled'
  | 'pending_approval'
  | 'denied'
  | 'requestable';

export interface MyTool {
  name: string;
  status: McpToolStatus;
  in_role_envelope: boolean;
}

export interface MyToolsServer {
  server_name: string;
  tools: MyTool[];
}

export interface MyToolsResponse {
  user_id: string;
  role: string;
  self_service_enabled: boolean;
  servers: MyToolsServer[];
}

/** The three user-selectable controls, matching identity's ToolAction enum. */
export type ToolAccessAction = 'enable' | 'require_approval' | 'disable';

export interface UpdateMyToolRequest {
  server: string;
  tool: string;
  action: ToolAccessAction;
}

export interface UpdateMyToolResponse {
  server: string;
  tool: string;
  action: ToolAccessAction;
  effective_access: string;
  status: McpToolStatus;
  message: string;
}

/* ── Merged view-model rendered per row in the UI ────────────────────── */

export interface McpToolRow {
  name: string;
  description: string;
  status: McpToolStatus;
  in_role_envelope: boolean;
  /** Set true while a PUT for this row is in flight. */
  saving?: boolean;
  /** Inline note from the last update (e.g. the SUPERVISOR-approval message). */
  note?: string;
}

export interface McpServerView {
  server_name: string;
  style: string;
  tools: McpToolRow[];
  /** UI accordion state. */
  expanded: boolean;
}
