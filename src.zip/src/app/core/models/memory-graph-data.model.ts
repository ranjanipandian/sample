/**
 * Memory Graph — sample graph dataset for visualization.
 *
 * This is the concrete, renderable graph (nodes + typed/provenance-bearing
 * edges) that the Workflow A ingestion-pipeline demo populates once the
 * mAb-114 18-month HMW OOS story (DEV-2291) has been "ingested."
 *
 * Every node/edge here is a direct graph-shaped restatement of the same
 * story already used elsewhere in the virtual lab:
 *   - stability.model.ts    → FAILURE_EVENTS[0] ("fail-114lt-18m-hmw") and
 *                              PROVENANCE_TRAIL (prov-01 … prov-08)
 *   - memory-graph-blueprint.model.ts → ONTOLOGY_CLASSES / ONTOLOGY_RELATIONSHIPS
 *     (mg:/prov: namespace) and FAILURE_INTELLIGENCE_TRIPLE_EXAMPLE
 *
 * Nothing here is invented content — it is the same narrative, expressed as
 * a graph of typed nodes and relationships instead of prose, so the
 * ingestion-pipeline animation has something concrete to "write" into.
 */

export type GraphNodeType =
  | 'mg:Hypothesis'
  | 'mg:Result'
  | 'mg:FailureEvent'
  | 'mg:Decision'
  | 'mg:EvidenceClaim'
  | 'prov:Entity'
  | 'prov:Agent';

export type AssertionOrigin = 'human' | 'agent';

export type ReviewStatus =
  | 'candidate'
  | 'machine-validated'
  | 'sme-reviewed'
  | 'pending-sme-review'
  | 'regulatory-safe';

export interface GraphNode {
  id: string;
  label: string;
  entityType: GraphNodeType;
  /** Was this node's claim asserted by a human or written back by an agent? */
  assertionOrigin: AssertionOrigin;
  reviewStatus: ReviewStatus;
  /** Where this node's claim can be traced back to — shown in the provenance panel. */
  sourceRef: string;
  /** Optional confidence score (0–1) for agent-asserted nodes. */
  confidence?: number;
  /** Longer explanatory text shown when the node is selected. */
  detail: string;
}

export type GraphRelationship =
  | 'mg:hasFailureReason'
  | 'mg:causedBy'
  | 'mg:supports'
  | 'mg:contradicts'
  | 'mg:ledToDecision'
  | 'prov:wasDerivedFrom'
  | 'prov:wasAttributedTo'
  | 'prov:wasAssociatedWith';

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  relationship: GraphRelationship;
}

/* ────────────────────────────────────────────────────────────────────────
 * Sample dataset — mAb-114 / DEV-2291 (18-month SEC HMW OOS) ingested graph
 * ──────────────────────────────────────────────────────────────────────── */

export const SAMPLE_GRAPH_NODES: GraphNode[] = [
  {
    id: 'result-12m-hmw',
    label: '12M SEC: 2.8% HMW (pass)',
    entityType: 'mg:Result',
    assertionOrigin: 'human',
    reviewStatus: 'sme-reviewed',
    sourceRef: 'exp-114lt-t12-scf — SEC run 12M-R2, IDBS',
    detail: 'SEC run 12M-R2 logged 2.8% HMW, within the 3.0% specification. Analyst: R. Fischer, instrument OpenLab-HPLC-04.',
  },
  {
    id: 'result-18m-r1-hmw',
    label: '18M SEC: 3.4% HMW (OOS)',
    entityType: 'mg:Result',
    assertionOrigin: 'human',
    reviewStatus: 'sme-reviewed',
    sourceRef: 'exp-114lt-t18-scf — SEC run 18M-R1, IDBS',
    detail: 'SEC run 18M-R1 logged 3.4% HMW, breaching the 3.0% specification. Retest triggered per SOP-QC-014.',
  },
  {
    id: 'result-18m-r2-hmw',
    label: '18M SEC retest: 2.9% HMW (pass)',
    entityType: 'mg:Result',
    assertionOrigin: 'human',
    reviewStatus: 'sme-reviewed',
    sourceRef: 'exp-114lt-t18-scf — retest 18M-R2, IDBS',
    detail: 'Retest performed on a qualified column; result 2.9% HMW, in specification.',
  },
  {
    id: 'dev-2291',
    label: 'DEV-2291: column-performance deviation',
    entityType: 'mg:FailureEvent',
    assertionOrigin: 'human',
    reviewStatus: 'sme-reviewed',
    sourceRef: 'Deviation record DEV-2291, OpenLab-HPLC-04',
    detail: 'Open column-performance deviation on OpenLab-HPLC-04, overlapping the 18M-R1 run date.',
  },
  {
    id: 'evidence-acc-trend',
    label: 'Accelerated study: no comparable HMW trend',
    entityType: 'mg:EvidenceClaim',
    assertionOrigin: 'agent',
    reviewStatus: 'machine-validated',
    sourceRef: 'study-mab114-acc HMW trend, cross-study graph walk',
    confidence: 0.81,
    detail: 'The accelerated-condition study on the same lot shows no comparable HMW uptick at an equivalent aging point — corroborates an instrument artifact rather than real degradation.',
  },
  {
    id: 'hyp-114lt-18m-01',
    label: 'Hypothesis: OOS caused by DEV-2291, not degradation',
    entityType: 'mg:Hypothesis',
    assertionOrigin: 'agent',
    reviewStatus: 'sme-reviewed',
    sourceRef: 'Memory Graph Reasoning Agent — cross-study graph walk',
    confidence: 0.87,
    detail: '"OOS 18M-R1 likely attributable to DEV-2291 (column-performance deviation), not product degradation." Written back as agent-asserted, pending SME review; later approved by Dr. A. Kessler.',
  },
  {
    id: 'decision-114lt-18m',
    label: 'Decision: disposition 18M-R1 invalid, accept 18M-R2',
    entityType: 'mg:Decision',
    assertionOrigin: 'human',
    reviewStatus: 'regulatory-safe',
    sourceRef: 'QA disposition, approved by Dr. A. Kessler',
    detail: 'Disposition the 18M-R1 result as invalid due to assignable instrument cause (DEV-2291); accept 18M-R2 as the reportable result; flag OpenLab-HPLC-04 for preventive maintenance.',
  },
  {
    id: 'agent-fischer',
    label: 'R. Fischer (Analyst)',
    entityType: 'prov:Agent',
    assertionOrigin: 'human',
    reviewStatus: 'sme-reviewed',
    sourceRef: 'IDBS user record',
    detail: 'Ran the SEC assays and logged the 12M, 18M-R1, and 18M-R2 results into IDBS.',
  },
  {
    id: 'agent-kessler',
    label: 'Dr. A. Kessler (QA Reviewer)',
    entityType: 'prov:Agent',
    assertionOrigin: 'human',
    reviewStatus: 'sme-reviewed',
    sourceRef: 'IDBS user record',
    detail: 'Reviewed the agent-asserted hypothesis and retest evidence; approved the disposition and promoted the hypothesis to accepted institutional knowledge.',
  },
  {
    id: 'agent-mg-reasoning',
    label: 'Memory Graph Reasoning Agent',
    entityType: 'prov:Agent',
    assertionOrigin: 'agent',
    reviewStatus: 'machine-validated',
    sourceRef: 'Agent layer — Workflow B (reasoning modes)',
    detail: 'Executed the cross-study graph walk joining the instrument maintenance record, DEV-2291, and the accelerated-study HMW trend for the same lot.',
  },
];

export const SAMPLE_GRAPH_EDGES: GraphEdge[] = [
  { id: 'e1', source: 'result-18m-r1-hmw', target: 'dev-2291', relationship: 'mg:hasFailureReason' },
  { id: 'e2', source: 'dev-2291', target: 'hyp-114lt-18m-01', relationship: 'prov:wasDerivedFrom' },
  { id: 'e3', source: 'evidence-acc-trend', target: 'hyp-114lt-18m-01', relationship: 'mg:supports' },
  { id: 'e4', source: 'result-18m-r2-hmw', target: 'hyp-114lt-18m-01', relationship: 'mg:supports' },
  { id: 'e5', source: 'result-12m-hmw', target: 'evidence-acc-trend', relationship: 'prov:wasDerivedFrom' },
  { id: 'e6', source: 'hyp-114lt-18m-01', target: 'decision-114lt-18m', relationship: 'mg:ledToDecision' },
  { id: 'e7', source: 'result-18m-r1-hmw', target: 'agent-fischer', relationship: 'prov:wasAttributedTo' },
  { id: 'e8', source: 'result-18m-r2-hmw', target: 'agent-fischer', relationship: 'prov:wasAttributedTo' },
  { id: 'e9', source: 'hyp-114lt-18m-01', target: 'agent-mg-reasoning', relationship: 'prov:wasAttributedTo' },
  { id: 'e10', source: 'decision-114lt-18m', target: 'agent-kessler', relationship: 'prov:wasAttributedTo' },
  { id: 'e11', source: 'agent-mg-reasoning', target: 'hyp-114lt-18m-01', relationship: 'prov:wasAssociatedWith' },
];

export function getNode(id: string): GraphNode | undefined {
  return SAMPLE_GRAPH_NODES.find((n) => n.id === id);
}

export function getEdgesForNode(id: string): GraphEdge[] {
  return SAMPLE_GRAPH_EDGES.filter((e) => e.source === id || e.target === id);
}
