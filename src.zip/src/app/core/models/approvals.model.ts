/* ── Supervisor tool-access approvals (identity /v1/approvals) ───────────────
 *
 * A support engineer who hits a tool outside their role envelope (e.g. a
 * role-level DENY, or an un-granted tool) can request access from the MCP Tools
 * page; that raises a pending request here. A SUPERVISOR approves (→ the user
 * gets an ALLOW grant that overrides the role decision) or rejects it.
 */

export interface PendingApproval {
  auth_id: string;
  user_id: string;
  user_email: string;
  user_role: string;
  server_name: string;
  tool_name: string;
  requested_by: string;
  requested_at: string; // ISO 8601
}

export interface ApprovalsListResponse {
  pending: PendingApproval[];
}

export type ApprovalDecision = 'approve' | 'reject';

export interface ApprovalDecisionRequest {
  decision: ApprovalDecision;
  reason?: string | null;
}

export interface ApprovalDecisionResponse {
  auth_id: string;
  decision: ApprovalDecision;
  server_name: string;
  tool_name: string;
  user_id: string;
  effective_access: string;
}
