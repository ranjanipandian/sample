/**
 * R&D CMC Technology Landscape — static reference data.
 *
 * Modelled directly on the "R&D CMC Technology Landscape" diagram shared by
 * the team (GSK + Cognizant IntelliBench workstream). This is the enterprise
 * application map for the CMC (Chemistry, Manufacturing & Controls) function:
 * 7 pipeline stages left→right, plus 3 cross-cutting bands that sit under
 * specific stages (or the full width, for Forecasting/Planning/Scheduling).
 *
 * Every system here is an "ELN-equivalent" for its stage — it records WHAT
 * was done. None of them, by design, capture WHY (the hypothesis, the
 * decision, the failure rationale) — that is the Reasoning Gap the Memory
 * Graph white paper names. `reasoningCaptured` + `gap` on each SystemInfo
 * entry make that gap explicit, system by system.
 */

export type SystemStatus = 'none' | 'partial' | 'captured';

export interface SystemInfo {
  key: string;
  name: string;
  /** True for the emerging/agentic-AI tooling called out in tan on the diagram. */
  aiEnabled?: boolean;
  /** What this system captures today — the "what was done" (ELN-style) data. */
  captures: string;
  /** Whether reasoning / failure-intelligence is captured alongside the result. */
  reasoningStatus: SystemStatus;
  /** Plain-English description of the Reasoning Gap for this system. */
  gap: string;
}

export interface Stage {
  id: string;
  /** 1-based left→right position — also the CSS grid column index. */
  order: number;
  name: string;
  /** Standard (blue) system keys under this stage. */
  systems: string[];
  /** Emerging / AI-enabled (tan) system keys under this stage, if any. */
  aiSystems?: string[];
}

export interface Band {
  id: string;
  name: string;
  /** Stage `order` values this band visually spans under. */
  spanFrom: number;
  spanTo: number;
  fullWidth?: boolean;
  systems: string[];
  aiSystems?: string[];
}

export const STAGES: Stage[] = [
  {
    id: 'product-process-design',
    order: 1,
    name: 'Product & Process Design',
    systems: ['risx', 'pdlm'],
  },
  {
    id: 'drug-substance-mfg',
    order: 2,
    name: 'Drug Substance Manufacturing',
    systems: ['comet', 'batch-tracking'],
  },
  {
    id: 'drug-product-mfg',
    order: 3,
    name: 'Drug Product Manufacturing',
    systems: ['comet', 'batch-tracking', 'applied-smart-factory'],
  },
  {
    id: 'packaging-labelling',
    order: 4,
    name: 'Packaging & Labelling',
    systems: ['comet', 'smartsupplies-pmo', 'smart-ls', 'prisym360'],
  },
  {
    id: 'logistics-distribution',
    order: 5,
    name: 'Logistics / Distribution',
    systems: ['comet', 'smartsupplies-pmo', 'cold-chain-is', 'modula', 'temm'],
  },
  {
    id: 'dispensing-clinical-interface',
    order: 6,
    name: 'Dispensing & Clinical Interface',
    systems: ['ramos', 'ramos-ng', 'sbr-vx', 'external-irts'],
    aiSystems: ['digital-twin', 'robo-reporter'],
  },
  {
    id: 'tech-transfer-mfg',
    order: 7,
    name: 'Tech Transfer to Manufacturing',
    systems: ['irisk', 'pdlm'],
  },
];

export const BANDS: Band[] = [
  {
    id: 'analytical-testing',
    name: 'Analytical Testing & Method Development',
    spanFrom: 2,
    spanTo: 3,
    systems: ['openlab', 'gproms', 'idbs', 'swatch', 'plato', 'aclimits'],
    aiSystems: ['digital-twin', 'robo-reporter'],
  },
  {
    id: 'regulatory',
    name: 'Regulatory',
    spanFrom: 4,
    spanTo: 5,
    systems: ['openlab', 'cmc-control-tower'],
  },
  {
    id: 'forecasting-planning-scheduling',
    name: 'Forecasting, Planning & Scheduling',
    spanFrom: 1,
    spanTo: 7,
    fullWidth: true,
    systems: ['cmc-control-tower'],
  },
];

export const TOP_BANNER = 'CODE Orange CMC Data Products (Experiment, Instrument, etc.)';

export const SYSTEM_INFO: Record<string, SystemInfo> = {
  risx: {
    key: 'risx',
    name: 'RISX',
    captures: 'Product & process design records — formulation parameters, design-space boundaries, target product profile.',
    reasoningStatus: 'none',
    gap: 'Does not record why a given design space or formulation option was chosen over the alternatives evaluated during design.',
  },
  pdlm: {
    key: 'pdlm',
    name: 'PDLM',
    captures: 'Product & process design lifecycle records; document versions and approvals for process design and tech-transfer packages.',
    reasoningStatus: 'none',
    gap: 'Captures the approved document, not the discussion or evidence trail that led to that version being approved over prior drafts.',
  },
  comet: {
    key: 'comet',
    name: 'COMET',
    captures: 'Batch execution records across Drug Substance, Drug Product, Packaging and Logistics — what was run, on which line, with what result.',
    reasoningStatus: 'none',
    gap: 'Logs execution outcomes only. Deviations and OOS/OOT events are flagged, but the investigative reasoning for root cause is not modelled as linked data.',
  },
  'batch-tracking': {
    key: 'batch-tracking',
    name: 'Batch Tracking',
    captures: 'Batch genealogy and status across Drug Substance and Drug Product manufacturing stages.',
    reasoningStatus: 'none',
    gap: 'Tracks batch state transitions, not the rationale behind hold/release/rework decisions at each transition.',
  },
  'applied-smart-factory': {
    key: 'applied-smart-factory',
    name: 'Applied Smart Factory',
    captures: 'Shop-floor sensor and equipment telemetry for Drug Product Manufacturing.',
    reasoningStatus: 'partial',
    gap: 'Surfaces anomalies from telemetry patterns, but does not capture the engineer’s accepted/rejected root-cause hypothesis for each anomaly.',
  },
  'smartsupplies-pmo': {
    key: 'smartsupplies-pmo',
    name: 'SmartSupplies PMO',
    captures: 'Supply planning and packaging-materials PMO tracking for Packaging & Labelling and Logistics/Distribution.',
    reasoningStatus: 'none',
    gap: 'Records the plan, not the trade-off reasoning (cost vs. lead-time vs. risk) behind supply decisions.',
  },
  'smart-ls': {
    key: 'smart-ls',
    name: 'Smart LS',
    captures: 'Labelling & serialisation execution records for Packaging & Labelling.',
    reasoningStatus: 'none',
    gap: 'No linkage between a labelling exception and the compliance reasoning used to resolve it.',
  },
  prisym360: {
    key: 'prisym360',
    name: 'Prisym360',
    captures: 'Label content management — approved artwork and label-copy versions.',
    reasoningStatus: 'none',
    gap: 'Version history shows what changed, not the regulatory or market rationale for the change.',
  },
  'cold-chain-is': {
    key: 'cold-chain-is',
    name: 'Cold Chain IS',
    captures: 'Temperature-controlled logistics monitoring — excursion events and thresholds.',
    reasoningStatus: 'partial',
    gap: 'Excursions are logged with severity, but the disposition rationale (why a batch was released despite an excursion) is not captured as structured, queryable data.',
  },
  modula: {
    key: 'modula',
    name: 'Modula',
    captures: 'Automated warehouse storage/retrieval records for distribution logistics.',
    reasoningStatus: 'none',
    gap: 'No record of why inventory allocation or picking decisions were made under constrained supply.',
  },
  temm: {
    key: 'temm',
    name: 'TEMM',
    captures: 'Transport / environment monitoring for in-transit shipments.',
    reasoningStatus: 'none',
    gap: 'Captures the sensor trace, not the shipment-risk judgement made in response to it.',
  },
  ramos: {
    key: 'ramos',
    name: 'RAMOS',
    captures: 'Randomisation and medication ordering for clinical supply.',
    reasoningStatus: 'none',
    gap: 'Order records don’t retain the clinical-supply rationale for depot allocation choices.',
  },
  'ramos-ng': {
    key: 'ramos-ng',
    name: 'RAMOS NG',
    captures: 'Next-gen randomisation/medication ordering — same function as RAMOS on the modern stack.',
    reasoningStatus: 'none',
    gap: 'Same limitation as RAMOS: outcome without the decision trail behind it.',
  },
  'sbr-vx': {
    key: 'sbr-vx',
    name: 'SBR (Vx)',
    captures: 'Study-build & randomisation configuration for clinical trials (Veeva-based).',
    reasoningStatus: 'none',
    gap: 'Configuration is versioned, but the protocol-design reasoning behind a configuration choice is not linked.',
  },
  'external-irts': {
    key: 'external-irts',
    name: 'External IRTs',
    captures: 'Third-party Interactive Response Technology feeds for dispensing.',
    reasoningStatus: 'none',
    gap: 'External system boundary — reasoning context from the CRO/vendor side is typically not passed through at all.',
  },
  'digital-twin': {
    key: 'digital-twin',
    name: 'Digital Twin',
    aiEnabled: true,
    captures: 'Simulated process/model state used to predict manufacturing or stability outcomes before they occur.',
    reasoningStatus: 'partial',
    gap: 'Model assumptions and simulation parameters are logged, but the human decision to accept/override a simulated prediction is not written back as linked reasoning.',
  },
  'robo-reporter': {
    key: 'robo-reporter',
    name: 'Robo Reporter',
    aiEnabled: true,
    captures: 'Auto-generated draft reports assembled from raw instrument and batch data.',
    reasoningStatus: 'partial',
    gap: 'Drafts the "what happened" narrative automatically, but does not yet capture the reviewer’s reasoning for edits, or why an anomaly was judged not reportable.',
  },
  irisk: {
    key: 'irisk',
    name: 'iRisk',
    captures: 'Risk register for tech-transfer-to-manufacturing readiness.',
    reasoningStatus: 'partial',
    gap: 'Risk scores are recorded, but the underlying judgement — why a risk was scored as it was, and what evidence changed that score — is not preserved as linked data.',
  },
  openlab: {
    key: 'openlab',
    name: 'OpenLab',
    captures: 'Chromatography Data System — analytical run results for method development and regulatory submission packages.',
    reasoningStatus: 'none',
    gap: 'Captures the chromatogram and result, not the analyst’s interpretation of a borderline peak or an OOS investigation’s reasoning chain.',
  },
  gproms: {
    key: 'gproms',
    name: 'gPROMS',
    captures: 'Process modelling and simulation outputs for method development.',
    reasoningStatus: 'partial',
    gap: 'Model outputs are stored; the modeller’s rationale for parameter selection and model validation decisions is not.',
  },
  idbs: {
    key: 'idbs',
    name: 'IDBS',
    captures: 'Electronic Lab Notebook entries for analytical testing — the canonical "what was done" record for stability and analytical studies.',
    reasoningStatus: 'none',
    gap: 'This is the clearest instance of the white paper’s core problem: IDBS records the experiment, never the hypothesis it was testing or the decision it fed.',
  },
  swatch: {
    key: 'swatch',
    name: 'SWATCH',
    captures: 'Stability study scheduling and pull-point tracking.',
    reasoningStatus: 'none',
    gap: 'Tracks what pulls are due/complete, not the scientific reasoning behind protocol amendments or accelerated-condition decisions.',
  },
  plato: {
    key: 'plato',
    name: 'Plato',
    captures: 'Analytical method parameters and specification limits.',
    reasoningStatus: 'none',
    gap: 'Specification limits are stored as values; the risk/statistical reasoning used to set them is not linked back to the limit itself.',
  },
  aclimits: {
    key: 'aclimits',
    name: 'ACLimits',
    captures: 'Acceptance-criteria / limits management for analytical results.',
    reasoningStatus: 'none',
    gap: 'When a result fails a limit, the system flags OOS — but the failure-investigation reasoning (why it failed, what was ruled out) lives outside the system.',
  },
  'cmc-control-tower': {
    key: 'cmc-control-tower',
    name: 'CMC Control Tower',
    captures: 'Cross-programme forecasting, planning & regulatory scheduling dashboard.',
    reasoningStatus: 'partial',
    gap: 'Aggregates status across systems for visibility, but does not itself capture the planning trade-off reasoning behind a schedule change.',
  },
};

export function getSystem(key: string): SystemInfo | undefined {
  return SYSTEM_INFO[key];
}

/**
 * Batch Journey — the pipeline-in-motion view.
 *
 * The diagram GSK shared is a *process flow*: a batch/lot moves left→right
 * through the 7 CMC stages, cross-cut by Analytical Testing, Regulatory and
 * Forecasting. This models one illustrative batch moving through that flow
 * so the Landscape page can render an actual stage-by-stage journey (a
 * stepper) instead of a static picture of the diagram — each stage carries
 * which systems acted, what data product it emitted (feeding the CODE
 * Orange log), any gate decision, and the Reasoning Gap for that specific
 * transition. Entity/data is illustrative (virtual lab), not real GSK data.
 */

export type StageRunStatus = 'complete' | 'current' | 'upcoming';
export type GateVerdict = 'passed' | 'hold' | 'deviation';

export interface GateDecision {
  verdict: GateVerdict;
  note: string;
}

export interface PipelineStageRun {
  stageId: string;
  order: number;
  status: StageRunStatus;
  dateRange: string;
  /** System keys that acted on the batch at this stage (subset of Stage.systems/aiSystems). */
  actingSystems: string[];
  /** Data products emitted at this stage — feeds the CODE Orange ticker. */
  dataProductsEmitted: string[];
  gateDecision?: GateDecision;
  /** The Reasoning Gap specific to this stage transition for this batch. */
  reasoningGapNote: string;
}

export interface CodeOrangeEvent {
  timestamp: string;
  product: string;
  source: string;
  stageId: string;
}

export interface BatchJourney {
  batchId: string;
  molecule: string;
  modality: string;
  lotNumber: string;
  currentStageOrder: number;
  stageRuns: PipelineStageRun[];
  codeOrangeLog: CodeOrangeEvent[];
}

export const BATCH_JOURNEY: BatchJourney = {
  batchId: 'mAb-114-SL-2024-118',
  molecule: 'mAb-114',
  modality: 'Monoclonal Antibody (IgG1) — Large Molecule',
  lotNumber: 'SL-2024-118',
  currentStageOrder: 1,
  stageRuns: [
    {
      stageId: 'product-process-design',
      order: 1,
      status: 'current',
      dateRange: '2023-11-02 → in progress',
      actingSystems: ['risx', 'pdlm'],
      dataProductsEmitted: [
        'Design-space boundary record — draft (RISX-DS-4471)',
      ],
      reasoningGapNote:
        'RISX and PDLM are capturing the design-space boundaries and process-design package as work progresses — neither will record why one formulation option is ultimately chosen over the alternatives under evaluation in the design-space review.',
    },
    {
      stageId: 'drug-substance-mfg',
      order: 2,
      status: 'upcoming',
      dateRange: 'Not yet started',
      actingSystems: ['comet', 'batch-tracking', 'openlab', 'idbs'],
      dataProductsEmitted: [],
      reasoningGapNote:
        'Once drug substance manufacturing begins, COMET and IDBS will record run outcomes and results — not the analyst\'s working hypothesis behind any early out-of-trend result that later resolves within spec.',
    },
    {
      stageId: 'drug-product-mfg',
      order: 3,
      status: 'upcoming',
      dateRange: 'Not yet started',
      actingSystems: ['comet', 'batch-tracking', 'applied-smart-factory', 'idbs', 'openlab'],
      dataProductsEmitted: [],
      reasoningGapNote:
        'Once drug product manufacturing begins, Applied Smart Factory and IDBS will separately log telemetry anomalies and stability results — neither system will record whether those two events are connected; that link would only exist in the Memory Graph reasoning chain.',
    },

    {
      stageId: 'packaging-labelling',
      order: 4,
      status: 'upcoming',
      dateRange: 'Not yet started',
      actingSystems: ['comet', 'smartsupplies-pmo', 'smart-ls', 'prisym360'],
      dataProductsEmitted: [],
      reasoningGapNote:
        'Once packaging begins, Smart LS and Prisym360 will record label execution and content versions — not the compliance reasoning behind any labelling exception.',
    },
    {
      stageId: 'logistics-distribution',
      order: 5,
      status: 'upcoming',
      dateRange: 'Not yet started',
      actingSystems: ['comet', 'smartsupplies-pmo', 'cold-chain-is', 'modula', 'temm'],
      dataProductsEmitted: [],
      reasoningGapNote:
        'Cold Chain IS will log any temperature excursion in transit; the disposition rationale for releasing a batch despite an excursion is not captured as structured data today.',
    },
    {
      stageId: 'dispensing-clinical-interface',
      order: 6,
      status: 'upcoming',
      dateRange: 'Not yet started',
      actingSystems: ['ramos', 'ramos-ng', 'sbr-vx', 'external-irts'],
      dataProductsEmitted: [],
      reasoningGapNote:
        'RAMOS/RAMOS NG will record depot allocation outcomes; the clinical-supply rationale behind allocation choices will not be captured as linked data.',
    },
    {
      stageId: 'tech-transfer-mfg',
      order: 7,
      status: 'upcoming',
      dateRange: 'Not yet started',
      actingSystems: ['irisk', 'pdlm'],
      dataProductsEmitted: [],
      reasoningGapNote:
        'iRisk will record a risk score for tech-transfer readiness; the judgement behind that score, and what evidence would change it, will not be preserved as linked data.',
    },
  ],
  codeOrangeLog: [
    { timestamp: '2023-11-06 11:20', product: 'RISX-DS-4471 — design-space boundary record (draft)', source: 'RISX', stageId: 'product-process-design' },
  ],

};

export function getBatchJourney(): BatchJourney {
  return BATCH_JOURNEY;
}

export function getStageRun(stageId: string): PipelineStageRun | undefined {
  return BATCH_JOURNEY.stageRuns.find((r) => r.stageId === stageId);
}

/** Whether a cross-cutting band is "active" for a given stage order (lit up in the UI). */
export function isBandActiveForStage(band: Band, stageOrder: number): boolean {
  if (band.fullWidth) return true;
  return stageOrder >= band.spanFrom && stageOrder <= band.spanTo;
}

/**
 * Dashboard-level roll-ups — how many systems in a given stage capture
 * reasoning today ('captured'), capture it partially ('partial'), or don't
 * capture it at all ('none'). Drives the reasoning-status chips on the
 * Dashboard's CMC Pipeline Stages cards.
 */
export interface StageSystemCounts {
  total: number;
  aiCount: number;
  captured: number;
  partial: number;
  none: number;
}

export function getStageSystemCounts(stage: Stage): StageSystemCounts {
  const allKeys = [...stage.systems, ...(stage.aiSystems || [])];
  const counts: StageSystemCounts = { total: 0, aiCount: (stage.aiSystems || []).length, captured: 0, partial: 0, none: 0 };
  for (const key of allKeys) {
    const info = SYSTEM_INFO[key];
    if (!info) continue;
    counts.total++;
    if (info.reasoningStatus === 'captured') counts.captured++;
    else if (info.reasoningStatus === 'partial') counts.partial++;
    else counts.none++;
  }
  return counts;
}

/** Human status label for a stage, derived from the batch-journey run (or
 *  'Upcoming' when the batch hasn't reached it yet). Used on both the
 *  Dashboard cards and the stage detail page. */
export type StageStatusLabel = 'Active' | 'In Progress' | 'Upcoming';

export function getStageStatusLabel(stage: Stage): StageStatusLabel {
  const run = getStageRun(stage.id);
  if (!run) return 'Upcoming';
  if (run.status === 'complete') return 'Active';
  if (run.status === 'current') return 'In Progress';
  return 'Upcoming';
}

/**
 * AI Agent Opportunities — the emerging / agentic-AI capabilities called out
 * across the CMC pipeline (Digital Twin, Robo Reporter, and the Memory Graph
 * Reasoning Agent surfaced in the Stability pilot). Feeds the Dashboard's
 * "AI Agent Opportunities" table.
 */
export interface AgentOpportunity {
  stageId: string;
  agentKey: string;
  agentName: string;
  description: string;
  status: StageStatusLabel;
}

export const AI_AGENT_OPPORTUNITIES: AgentOpportunity[] = [
  {
    stageId: 'drug-substance-mfg',
    agentKey: 'memory-graph-reasoning-agent',
    agentName: 'Memory Graph Reasoning Agent',
    description:
      'Executes cross-study graph walks joining instrument maintenance records, open deviations and prior study trends to recover root-cause hypotheses for stability OOS/OOT events before they reach QA.',
    status: 'Active',
  },
  {
    stageId: 'drug-product-mfg',
    agentKey: 'digital-twin',
    agentName: 'Digital Twin',
    description:
      'Simulated process/model state used to predict manufacturing or stability outcomes before they occur; assumptions and parameters are logged for review.',
    status: 'In Progress',
  },
  {
    stageId: 'drug-product-mfg',
    agentKey: 'robo-reporter',
    agentName: 'Robo Reporter',
    description:
      'Auto-generated draft reports assembled from raw instrument and batch data — drafts the "what happened" narrative automatically ahead of reviewer sign-off.',
    status: 'In Progress',
  },
  {
    stageId: 'dispensing-clinical-interface',
    agentKey: 'digital-twin',
    agentName: 'Digital Twin (Clinical Interface)',
    description:
      'Extends process simulation into dispensing/clinical-supply forecasting — predicts depot-level demand shifts ahead of RAMOS allocation decisions.',
    status: 'Upcoming',
  },
  {
    stageId: 'tech-transfer-mfg',
    agentKey: 'irisk',
    agentName: 'iRisk Reasoning Assistant',
    description:
      'Proposed agent to surface the evidence and prior risk-score history behind a tech-transfer readiness score, closing the reasoning gap iRisk leaves today.',
    status: 'Upcoming',
  },
];

export function getAgentOpportunitiesForStage(stageId: string): AgentOpportunity[] {
  return AI_AGENT_OPPORTUNITIES.filter((a) => a.stageId === stageId);
}



