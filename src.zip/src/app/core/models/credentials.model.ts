/** How a per-user credential is supplied for an MCP server. */
export type AuthType = 'username_password' | 'api_key' | 'oauth';

/** An MCP server from identity GET /v1/mcp-servers. */
export interface McpServerInfo {
  server_name: string;
  display_name: string;
  auth_type: AuthType;
  is_active: boolean;
}

export interface McpServerListResponse {
  servers: McpServerInfo[];
  total: number;
}

/** Metadata for the caller's stored credential (identity GET /v1/me/credentials). */
export interface MyCredentialInfo {
  server_name: string;
  auth_type: AuthType;
  credential_type: string;
  is_active: boolean;
  updated_at: string | null;
}

export interface MyCredentialsResponse {
  credentials: MyCredentialInfo[];
  total: number;
}

export interface UpdateMyCredentialRequest {
  server: string;
  plaintext: Record<string, string>;
  /** SUPERVISOR-only: provision this credential for every user, not just the caller. */
  apply_to_all?: boolean;
}

export interface UpdateMyCredentialResponse {
  server_name: string;
  credential_type: string;
  is_active: boolean;
  updated_at: string;
  message: string;
  applied_to_count?: number;
}
