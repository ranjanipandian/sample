/**
 * Memory Graph Implementation Blueprint — virtual-lab data.
 *
 * This file covers the *implementation-detail* architecture shared by the TL
 * ("Memory Graph Construction Using LLMs + Agentic AI") — the layer beneath
 * the white paper's concepts (whitepaper.model.ts) that specifies exactly
 * HOW the Bronze/Silver/Gold pipeline, the LLM extraction step, the agent
 * workflows, the ontology, and the reasoning-gap detection would actually be
 * built:
 *
 *   1. Layered architecture (Source → Bronze → Silver → Gold → Agent → Governance)
 *   2. LLM extraction pattern (two-pass) + extraction target objects + JSON contract
 *   3. Agentic workflows — Workflow A (9-agent ingestion), Workflow B (5 reasoning
 *      modes), Workflow C (5-state write-back lifecycle)
 *   4. Data model — mg:/prov: ontology classes + relationships
 *   5. Reasoning gaps as structured, typed entities (5 gap categories)
 *   6. Reference implementation approach — tech-stack options + Minimal Viable
 *      Implementation (MVI) 9-step roadmap
 *   7. Why this lets agentic AI reason like a scientist — capability comparison
 *      + the closing "Scientific Reasoning Memory Platform" recommendation
 *
 * All examples reuse the same illustrative mAb-114 / stability story already
 * established in landscape.model.ts and stability.model.ts (18M HMW OOS,
 * DEV-2291, DEV-2114, FP-207 PS-80 lot) so this reads as one continuous
 * virtual lab, not a disconnected demo. Entity names/ids are illustrative
 * (virtual lab), not real GSK data. Nothing here is a live pipeline — no
 * backend, no real LLM calls, no real graph database — this is reference
 * architecture rendered as UI, exactly like the rest of the white paper
 * content in whitepaper.model.ts.
 */

/* ────────────────────────────────────────────────────────────────────────
 * 1 — Layered architecture (Source → Bronze → Silver → Gold → Agent → Governance)
 * ──────────────────────────────────────────────────────────────────────── */

export interface ArchitectureLayerRow {
  id: string;
  layer: string;
  purpose: string;
  inputs: string;
  keyOutputs: string;
}

export const LAYERED_ARCHITECTURE: ArchitectureLayerRow[] = [
  {
    id: 'source',
    layer: 'Source layer',
    purpose: 'Enterprise scientific systems of record',
    inputs: 'ELN (IDBS), LIMS, SDMS, instrument files, reports, chats, emails, decks',
    keyOutputs: 'Raw records and documents',
  },
  {
    id: 'bronze',
    layer: 'Bronze',
    purpose: 'Fidelity-preserving landing zone',
    inputs: 'Original artefacts',
    keyOutputs: 'Immutable raw copies, source metadata, hash, access classification',
  },
  {
    id: 'silver',
    layer: 'Silver',
    purpose: 'Structure and identity',
    inputs: 'Report sections, chat/email snippets, instrument outputs',
    keyOutputs: 'Normalized entities, extracted candidate triples, embeddings, confidence scores',
  },
  {
    id: 'gold',
    layer: 'Gold',
    purpose: 'Semantic Memory Graph',
    inputs: 'Validated triples and ontology mappings',
    keyOutputs: 'RDF / property graph with hypotheses, decisions, evidence, results, failures, provenance',
  },
  {
    id: 'agent',
    layer: 'Agent layer',
    purpose: 'Reasoning + write-back',
    inputs: 'Graph subgraphs + vector context + tools',
    keyOutputs: 'New hypotheses, anomaly flags, failure patterns, decision recommendations',
  },
  {
    id: 'governance',
    layer: 'Governance layer',
    purpose: 'Controls and audit',
    inputs: 'Every graph read/write',
    keyOutputs: 'PROV-O lineage, reviewer status, access policy, rollback, trust scoring',
  },
];

export const ARCHITECTURE_PRINCIPLE = {
  title: 'Architectural principle',
  body:
    'Do not treat the ELN, vector store, or LLM memory as the destination. Treat the Memory Graph as the durable reasoning layer that persists beyond applications, vendors, and agents.',
};

export const ARCHITECTURE_CORE_SHIFT = {
  title: 'Core shift',
  body:
    'Move from experiment records to institutional scientific memory: hypothesis → experiment → result → interpretation → failure reason → decision → provenance.',
};

export const LAYER_RULES: { title: string; body: string }[] = [
  { title: 'Bronze should avoid interpretation.', body: 'It stores source documents and raw exports exactly as received so an auditor can reconstruct the original artefact.' },
  { title: 'Silver should parse and locally type data.', body: 'Including converting vendor instrument formats to open standards where available, and resolving identities within each source.' },
  { title: 'Gold should reconcile entities across sources.', body: 'Apply public ontologies, model reasoning artefacts as first-class entities, embed PROV-O lineage, and expose the graph through a SPARQL endpoint.' },
];

/* ────────────────────────────────────────────────────────────────────────
 * 2 — LLM extraction: two-pass pattern, extraction targets, JSON contract
 * ──────────────────────────────────────────────────────────────────────── */

export const LLM_EXTRACTION_ROLE_NOTE =
  'The LLM role is not just named entity recognition. It should perform schema-guided scientific knowledge extraction: identify experiment facts, infer candidate reasoning objects from narrative context, and produce structured outputs that can be validated before graph write. Recent KG construction research describes LLM-enabled pipelines as moving beyond rule-based systems toward ontology engineering, knowledge extraction, and knowledge fusion, including schema-based and schema-free approaches.';

export interface ExtractionTarget {

  id: string;
  object: string;
  exampleFromSource: string;
  whyItMatters: string;
}

export const EXTRACTION_TARGETS: ExtractionTarget[] = [
  { id: 'hypothesis', object: 'Hypothesis', exampleFromSource: '"Aggregation increases under accelerated condition due to buffer interaction"', whyItMatters: 'Captures scientific intent' },
  { id: 'experiment', object: 'Experiment / Run', exampleFromSource: 'Stability study, assay, batch, method, condition', whyItMatters: 'Captures what happened' },
  { id: 'parameter', object: 'Parameter', exampleFromSource: 'Temperature, pH, buffer, concentration, timepoint, acceptance limit', whyItMatters: 'Links conditions to outcomes' },
  { id: 'result', object: 'Result', exampleFromSource: 'Measured value, trend, out-of-spec event, chromatogram feature', whyItMatters: 'Captures evidence' },
  { id: 'interpretation', object: 'Interpretation', exampleFromSource: '"Trend suggests degradation pathway"', whyItMatters: 'Converts data into scientific meaning' },
  { id: 'decision', object: 'Decision', exampleFromSource: 'Continue study, change formulation, repeat assay, reject batch', whyItMatters: 'Captures action logic' },
  { id: 'failure-reason', object: 'Failure reason', exampleFromSource: '"Parameter failed due to method interference / sample handling / degradation trend"', whyItMatters: 'Converts failure into reusable intelligence' },
  { id: 'reasoning-chain', object: 'Reasoning chain', exampleFromSource: 'Hypothesis → experiment → result → interpretation → decision', whyItMatters: 'Enables multi-hop agent reasoning' },
  { id: 'provenance', object: 'Provenance', exampleFromSource: 'Source document, author, timestamp, extraction model, reviewer', whyItMatters: 'Enables traceability and audit' },
];

export interface ExtractionPass {
  id: string;
  order: number;
  name: string;
  description: string;
}

export const EXTRACTION_PASSES: ExtractionPass[] = [
  {
    id: 'grounded-extraction',
    order: 1,
    name: 'Grounded extraction pass',
    description:
      'The LLM extracts only evidence-supported items from bounded chunks. Output must include source span, confidence, extraction rationale, and whether the item is explicit or inferred.',
  },
  {
    id: 'reasoning-object-construction',
    order: 2,
    name: 'Reasoning-object construction pass',
    description:
      'A second LLM call organizes extracted items into typed graph objects: hypothesis, evidence claim, decision, interpretation, failure reason, and reasoning chain. This is where "why" is modeled, but only when supported by source text or SME validation.',
  },
];

export const EXTRACTION_JSON_EXAMPLE = `{
  "source_id": "report_123_section_4.2",
  "extracted_objects": [
    {
      "type": "Hypothesis",
      "label": "Protein aggregation may increase under accelerated temperature",
      "evidence_span": "section 4.2, paragraph 3",
      "confidence": 0.82,
      "assertion_status": "candidate",
      "explicitness": "inferred_from_text"
    },
    {
      "type": "FailureReason",
      "parameter": "aggregation_percent",
      "observed_failure": "above acceptance threshold",
      "reason": "temperature-driven degradation trend",
      "supporting_evidence": ["result_456", "interpretation_789"],
      "confidence": 0.76,
      "assertion_status": "requires_sme_review"
    }
  ]
}`;

export const EXTRACTION_IMPLEMENTATION_RULE =
  'LLM output should not be written directly as trusted truth. It should become candidate triples with provenance, confidence, and review state — agent-derived triples must be distinguishable from human-asserted triples, quarantined pending SME review in high-stakes domains, and excluded from human-only evidence use cases when needed.';

/* ────────────────────────────────────────────────────────────────────────
 * 3a — Workflow A: continuous ingestion and graph update (9 agents)
 * ──────────────────────────────────────────────────────────────────────── */

export const AGENTIC_AI_WORKFLOWS_INTRO =
  'The agent layer should be built as a controlled multi-agent system over the graph, not as one monolithic chatbot. The white paper says agents should borrow from the Memory Graph, reason against it, and write back meaningful outputs such as flagged anomalies, proposed risk assessments, hypotheses, and reasoning chains. Research on agentic graph reasoning similarly describes systems that iteratively generate concepts and relationships, merge them into a global graph, and generate subsequent prompts from the evolving graph state.';

export interface IngestionAgent {

  id: string;
  order: number;
  name: string;
  description: string;
  icon: string;
}

export const INGESTION_AGENTS: IngestionAgent[] = [
  { id: 'source-monitor', order: 1, name: 'Source Monitor Agent', description: 'Watches for new ELN exports, reports, documents, chats, emails, meeting notes, and instrument files.', icon: 'ti ti-radar-2' },
  { id: 'classifier', order: 2, name: 'Classifier Agent', description: 'Classifies source type: ELN record, stability report, decision log, lab note, chat decision, failure discussion, regulatory narrative.', icon: 'ti ti-category' },
  { id: 'parser', order: 3, name: 'Parser Agent', description: 'Converts source into canonical text/tables/images/metadata. For structured data, preserves original columns and units.', icon: 'ti ti-file-scan' },
  { id: 'extractor', order: 4, name: 'Extractor Agent', description: 'Uses LLM extraction prompts to produce candidate entities, relations, reasoning objects, and failure explanations.', icon: 'ti ti-cpu' },
  { id: 'entity-resolution', order: 5, name: 'Entity Resolution Agent', description: 'Reconciles entities across sources: same molecule, batch, sample, study, lab, or parameter.', icon: 'ti ti-git-merge' },
  { id: 'ontology-alignment', order: 6, name: 'Ontology Alignment Agent', description: 'Maps extracted terms to public biomedical/lab ontologies and internal extensions (ChEBI, BAO, OBI, EFO, Allotrope).', icon: 'ti ti-binary-tree-2' },
  { id: 'validation', order: 7, name: 'Validation Agent', description: 'Runs schema, SHACL-like constraints, unit checks, confidence thresholds, duplicate detection, and contradiction checks.', icon: 'ti ti-shield-check' },
  { id: 'graph-publisher', order: 8, name: 'Graph Publisher Agent', description: 'Writes approved or quarantined candidate triples to named graphs with provenance.', icon: 'ti ti-database-export' },
  { id: 'reflection', order: 9, name: 'Reflection Agent', description: 'Reviews extraction errors, missing mappings, and recurring unknown concepts; proposes ontology updates for human approval.', icon: 'ti ti-refresh-alert' },
];

/* ────────────────────────────────────────────────────────────────────────
 * 3b — Workflow B: reasoning over the graph (5 reasoning modes)
 * ──────────────────────────────────────────────────────────────────────── */

export interface ReasoningMode {
  id: string;
  mode: string;
  whatTheAgentDoes: string;
  example: string;
}

export const REASONING_MODES: ReasoningMode[] = [
  {
    id: 'multi-hop',
    mode: 'Multi-hop reasoning',
    whatTheAgentDoes: 'Traverses hypothesis → experiment → result → decision chains',
    example: '"Which formulation decision was influenced by this stability anomaly?"',
  },
  {
    id: 'hypothesis-validation',
    mode: 'Hypothesis validation',
    whatTheAgentDoes: 'Compares evidence across runs/studies',
    example: '"Does the new result support or contradict the prior degradation hypothesis?"',
  },
  {
    id: 'failure-pattern-detection',
    mode: 'Failure pattern detection',
    whatTheAgentDoes: 'Searches recurring failure reasons across labs, batches, parameters',
    example: '"Which parameters fail under similar conditions, and why?"',
  },
  {
    id: 'contradiction-detection',
    mode: 'Contradiction detection',
    whatTheAgentDoes: 'Finds conflicting interpretations or decisions',
    example: '"Was this parameter accepted in one report but rejected elsewhere?"',
  },
  {
    id: 'provenance-reasoning',
    mode: 'Provenance reasoning',
    whatTheAgentDoes: 'Explains how a conclusion is known',
    example: '"Which source, analyst, run, and approval support this claim?"',
  },
];

export const WORKFLOW_B_PURPOSE =
  'Turn Memory Graph into scientific reasoning substrate. Instead of "documents mentioning compound X," agents retrieve typed subgraphs containing entities, explicit relationships, and provenance — the agent can answer multi-hop scientific questions as graph walks with cited triples.';

/**
 * Six named agent capabilities for Workflow B, grounded in the shelf-life
 * justification scenario from the Stability Reasoning POC briefs (SME Brief
 * + Build Brief): a scientist justifying a shelf-life claim for a new mAb
 * (mAb-Y) draws on precedent from two comparable prior products — mAb-X
 * (accepted justification, JUS-A) and mAb-Z (a justification initially
 * rejected by a regulatory query, then revised and accepted, JUS-B).
 * Illustrative virtual-lab content, not real submission data.
 */
export interface WorkflowBCapability {
  id: string;
  order: number;
  name: string;
  icon: string;
  whatItDoes: string;
  example: string;
  /** The Build Brief calls contradiction surfacing "the demo's most important capability." */
  flagship?: boolean;
}

export const WORKFLOW_B_CAPABILITIES: WorkflowBCapability[] = [
  {
    id: 'precedent-retrieval',
    order: 1,
    name: 'Precedent Retrieval',
    icon: 'ti ti-git-compare',
    whatItDoes:
      'Given a target product, returns prior products/batches judged comparable by typed criteria — modality, formulation family, container closure — as a traceable graph query, not a black-box similarity score.',
    example:
      'For mAb-Y, the agent returns mAb-X and mAb-Z as comparable, each with its similarity dimensions shown and click-through to how the match was determined. A query for a vaccine product returns no mAb precedent.',
  },
  {
    id: 'justification-retrieval',
    order: 2,
    name: 'Prior Justification & Reasoning Retrieval',
    icon: 'ti ti-file-search',
    whatItDoes:
      'Surfaces the shelf-life justification arguments used for comparable products, with cited reasoning chains and the regulatory outcome each one actually received.',
    example:
      'Returns JUS-A (accepted, mAb-X) and both JUS-B versions (originally rejected, then revised and accepted, mAb-Z) — every claim traces back to a specific evidence node in the source narrative.',
  },
  {
    id: 'attribute-identification',
    order: 3,
    name: 'Shelf-Life-Limiting Attribute Identification',
    icon: 'ti ti-list-numbers',
    whatItDoes:
      'Ranks the quality attributes historically most likely to drive shelf-life determination for the modality class, grounded in the underlying justifications rather than asserted.',
    example:
      'For mAbs the ranking surfaces aggregation (SE-HPLC HMW), potency, and charge isoforms; a vaccine query instead surfaces antigen integrity and in-vivo potency — modality-specific, not one-size-fits-all.',
  },
  {
    id: 'extrapolation-support',
    order: 4,
    name: 'Extrapolation Reasoning Support',
    icon: 'ti ti-chart-line',
    whatItDoes:
      'For a given attribute, surfaces the extrapolation approaches — Arrhenius, linear, ASAP — used historically on comparable molecules, with their prior successes and failures. The agent never proposes a shelf-life value itself.',
    example:
      'For aggregation on mAb-Y, surfaces linear regression (successful in JUS-A) and Arrhenius (successful in JUS-A, but the primary argument originally rejected in JUS-B) — reasoning cited, no number asserted.',
  },
  {
    id: 'contradiction-surfacing',
    order: 5,
    name: 'Contradiction Surfacing',
    icon: 'ti ti-scale',
    whatItDoes:
      'Where a similar argument was considered and rejected — by internal review, by regulators, or by later evidence — returns the rejection reasoning explicitly alongside the supporting precedent. A graph-walk capability, not a search capability.',
    example:
      'Surfaces the JUS-B-original rejection with its linked regulatory query, a clear "argument accepted" vs "argument rejected" distinction, and the resulting learning captured as a general principle for future claims.',
    flagship: true,
  },
  {
    id: 'writeback-provenance',
    order: 6,
    name: 'Reasoning Write-Back with Provenance',
    icon: 'ti ti-pencil-plus',
    whatItDoes:
      'When the scientist confirms an argument, updates evidence, or approves a recommendation, the reasoning is captured as new typed triples — tagged with provenance and kept distinguishable from agent-derived triples.',
    example:
      'On approval, an explicit "N triples captured" notification breaks down new Recommendation, Argument, Evidence, Alternative and Decision nodes — each carrying actor, timestamp, and review status.',
  },
];

export const WORKFLOW_B_FLAGSHIP_NOTE =
  'Contradiction surfacing is called out across the POC briefs as the single most important capability in the demo — it is what separates a Memory Graph agent from a well-tuned document search: the graph represents "argument accepted" and "argument rejected" as typed, coupled relationships, not sentiment analysis over regulator correspondence after the fact.';

/**
 * A static "before/after" illustration of the differentiator most
 * strongly emphasized in the POC briefs: the same question, asked against
 * plain document search vs. against the Memory Graph.
 */
export interface DocumentSearchVsMemoryGraph {
  query: string;
  documentSearchResult: string;
  memoryGraphResult: string;
}

export const DOCUMENT_SEARCH_VS_MEMORY_GRAPH: DocumentSearchVsMemoryGraph = {
  query: 'Has an Arrhenius extrapolation argument for HMW aggregation ever been rejected for a similar mAb?',
  documentSearchResult:
    'Returns three documents that mention "Arrhenius" and "aggregation." The scientist must open each one and read it to find out what actually happened.',
  memoryGraphResult:
    'Returns a reasoned answer: "Yes — rejected in JUS-B (mAb-Z) after a regulatory query; the revised justification using linear extrapolation was later accepted," with a cited reasoning chain and click-through to the source regulatory query and the revised argument.',
};

export const DOCUMENT_SEARCH_VS_MEMORY_GRAPH_NOTE =
  'A RAG system can cite documents; a Memory Graph agent can cite typed reasoning chains. Get cited-provenance answers, contradiction surfacing, and visible reasoning write-back into a UI and the demo earns its keep — without them, it is a chatbot.';


/* ────────────────────────────────────────────────────────────────────────
 * 3c — Workflow C: write-back of new insights (5-state lifecycle)
 * ──────────────────────────────────────────────────────────────────────── */

export type WriteBackStateId = 'candidate' | 'machine-validated' | 'sme-reviewed' | 'deprecated' | 'regulatory-safe';

export interface WriteBackStateInfo {
  id: WriteBackStateId;
  state: string;
  meaning: string;
}

export const WRITE_BACK_STATES: WriteBackStateInfo[] = [
  { id: 'candidate', state: 'Candidate', meaning: 'LLM/agent proposed it; not yet reviewed' },
  { id: 'machine-validated', state: 'Machine-validated', meaning: 'Passed schema, unit, provenance, duplicate, and consistency checks' },
  { id: 'sme-reviewed', state: 'SME-reviewed', meaning: 'Human expert accepted, edited, or rejected' },
  { id: 'deprecated', state: 'Deprecated', meaning: 'Superseded by later evidence' },
  { id: 'regulatory-safe', state: 'Regulatory-safe', meaning: 'Approved for use in regulated evidence packages' },
];

export const WORKFLOW_C_NOTE =
  'Write-back is what makes the graph memory, not just retrieval. Agent outputs should be written as new triples only when they include: source inputs, reasoning trace, model identity, timestamp, confidence, validation result, and review state. Every memory entry should carry provenance and trust level; provenance tagging, memory audits, rollback, consensus validation, and sandboxing are the controls that keep agent memory from being poisoned.';

export const MEMORY_POISONING_SOURCE_NOTE =
  'The internal Memory_Poisoning_Agentic_AI_WhitePaper.pdf is also relevant here: it warns that agent memory must be protected because poisoned memories can shape future agent behavior. The same document is the source for the provenance tagging, memory audits, rollback, consensus validation, and sandboxing controls listed above.';

/**
 * Workflow C write-back detail, grounded in Screen 5 of the Stability
 * Reasoning POC storyboard ("Draft, review, writeback"): when the scientist
 * approves a shelf-life justification for mAb-Y, the reasoning chain is
 * captured as new typed triples, tagged with provenance, and reported back
 * as an explicit "N triples captured" notification with a type breakdown.
 * Illustrative virtual-lab content, not real submission data.
 */
export interface WriteBackTripleBreakdownRow {
  id: string;
  entityType: string;
  count: number;
  icon: string;
}

export const WRITE_BACK_TRIPLE_BREAKDOWN: WriteBackTripleBreakdownRow[] = [
  { id: 'recommendation', entityType: 'Recommendation', count: 1, icon: 'ti ti-flag-3' },
  { id: 'argument', entityType: 'Argument', count: 4, icon: 'ti ti-scale' },
  { id: 'evidence', entityType: 'Evidence', count: 7, icon: 'ti ti-flask-2' },
  { id: 'alternative', entityType: 'Alternative Considered', count: 2, icon: 'ti ti-git-compare' },
  { id: 'decision', entityType: 'Decision', count: 1, icon: 'ti ti-gavel' },
];

export const WRITE_BACK_NOTIFICATION_HEADLINE = '15 triples captured';

export interface WriteBackProvenanceField {
  id: string;
  field: string;
  exampleValue: string;
}

export const WRITE_BACK_PROVENANCE_EXAMPLE: WriteBackProvenanceField[] = [
  { id: 'actor', field: 'Actor', exampleValue: 'Dr. R. Kapoor (stability scientist)' },
  { id: 'timestamp', field: 'Timestamp', exampleValue: '2025-03-14T11:42:00Z' },
  { id: 'method', field: 'Method', exampleValue: 'workflow-approved' },
  { id: 'review-status', field: 'Review status', exampleValue: 'approved' },
];

export const WRITE_BACK_PROVENANCE_RULE =
  'Every written triple carries provenance — actor, timestamp, method, and review status — non-negotiable. A triple without provenance is a build defect, and a writeback that captures only "the answer" without the reasoning chain that produced it is a build defect too: the next agent must be able to walk the same chain the scientist walked.';

export const WRITE_BACK_FILTER_NOTE =
  'Human-asserted and agent-derived triples are tagged at origin and stay separately filterable at query time — human-only, agent-only, or mixed. A graph that mixes these indistinguishably is not fit for production upgrade.';

/**
 * Three candidate mechanisms for getting tacit knowledge into the graph
 * without asking scientists to document more — the open question the
 * critique notes say must be answered before the workshop.
 */
export interface TacitCaptureMechanism {
  id: string;
  order: number;
  name: string;
  icon: string;
  description: string;
  defensible: string;
}

export const TACIT_CAPTURE_MECHANISMS: TacitCaptureMechanism[] = [
  {
    id: 'passive-capture',
    order: 1,
    name: 'Passive Capture From Existing Artefacts',
    icon: 'ti ti-file-search',
    description:
      'The graph is populated by parsing narratives scientists already produce — shelf-life justifications, review board minutes, regulatory correspondence, extrapolation memos — using LLMs to extract typed reasoning entities (hypothesis, decision, evidence, alternative considered).',
    defensible: 'No new scientist effort required.',
  },
  {
    id: 'agent-mediated-capture',
    order: 2,
    name: 'Agent-Mediated Capture',
    icon: 'ti ti-robot',
    description:
      'When a scientist works through a shelf-life justification with the Memory Graph agent, the write-back at approval time becomes new reasoning triples. This is Workflow C itself — the graph grows through use, not through documentation.',
    defensible: 'The graph grows through use, not through separate documentation work.',
  },
  {
    id: 'point-of-decision-prompts',
    order: 3,
    name: 'Point-of-Decision Prompts',
    icon: 'ti ti-message-2',
    description:
      'At specific high-value moments only — specification setting, shelf-life extrapolation, OOS closure — the scientist is briefly prompted to record reasoning, because the payback is immediate: the next agent touching a similar decision uses it right away.',
    defensible: 'Narrowly scoped to moments with immediate payback, not blanket documentation.',
  },
];

export const TACIT_CAPTURE_WARNING =
  'A senior sponsor has seen prior "knowledge capture" initiatives fail for the same reason: they added burden without giving the scientist anything back. If the answer to "how does the reasoning get in?" is "please annotate as you go," it will be politely nodded at and then quietly deprioritised — the graveyard of knowledge management in pharma. At least one of these three mechanisms, usually a combination, needs to be locked before a sponsor demo.';



/* ────────────────────────────────────────────────────────────────────────
 * 4 — Data model: mg:/prov: ontology classes + relationships
 * ──────────────────────────────────────────────────────────────────────── */

export interface OntologyClass {
  id: string;
  className: string;
  description: string;
  namespace: 'mg' | 'prov';
}

export const ONTOLOGY_CLASSES: OntologyClass[] = [
  { id: 'study', className: 'mg:Study', description: 'Stability study, CMC study, method development study', namespace: 'mg' },
  { id: 'experiment', className: 'mg:Experiment', description: 'Lab experiment or assay execution', namespace: 'mg' },
  { id: 'run', className: 'mg:Run', description: 'Specific execution instance', namespace: 'mg' },
  { id: 'sample', className: 'mg:Sample', description: 'Sample tested', namespace: 'mg' },
  { id: 'batch', className: 'mg:Batch', description: 'Manufacturing or lab batch', namespace: 'mg' },
  { id: 'parameter', className: 'mg:Parameter', description: 'Controlled or measured parameter', namespace: 'mg' },
  { id: 'result', className: 'mg:Result', description: 'Numeric, categorical, image-derived, or textual result', namespace: 'mg' },
  { id: 'hypothesis', className: 'mg:Hypothesis', description: 'Scientific proposition being tested', namespace: 'mg' },
  { id: 'evidence-claim', className: 'mg:EvidenceClaim', description: 'Claim derived from result or observation', namespace: 'mg' },
  { id: 'interpretation', className: 'mg:Interpretation', description: 'Human/agent explanation of evidence', namespace: 'mg' },
  { id: 'decision', className: 'mg:Decision', description: 'Scientific or operational decision', namespace: 'mg' },
  { id: 'failure-event', className: 'mg:FailureEvent', description: 'Parameter/result/process failure', namespace: 'mg' },
  { id: 'failure-reason', className: 'mg:FailureReason', description: 'Explanation of why a failure occurred', namespace: 'mg' },
  { id: 'reasoning-chain', className: 'mg:ReasoningChain', description: 'Ordered chain linking hypothesis, evidence, interpretation, decision', namespace: 'mg' },
  { id: 'anomaly', className: 'mg:Anomaly', description: 'Detected unusual pattern', namespace: 'mg' },
  { id: 'agent-insight', className: 'mg:AgentInsight', description: 'Agent-generated observation or recommendation', namespace: 'mg' },
  { id: 'prov-entity', className: 'prov:Entity', description: 'Data object, result, hypothesis, decision, report section', namespace: 'prov' },
  { id: 'prov-activity', className: 'prov:Activity', description: 'Extraction, experiment, analysis, review, agent reasoning', namespace: 'prov' },
  { id: 'prov-agent', className: 'prov:Agent', description: 'Scientist, reviewer, software agent, LLM pipeline', namespace: 'prov' },
];

export interface OntologyRelationship {
  id: string;
  relationship: string;
  example: string;
  namespace: 'mg' | 'prov';
}

export const ONTOLOGY_RELATIONSHIPS: OntologyRelationship[] = [
  { id: 'tests-hypothesis', relationship: 'mg:testsHypothesis', example: 'Experiment tests hypothesis', namespace: 'mg' },
  { id: 'motivated-experiment', relationship: 'mg:motivatedExperiment', example: 'Hypothesis motivated experiment', namespace: 'mg' },
  { id: 'has-parameter', relationship: 'mg:hasParameter', example: 'Experiment has parameter', namespace: 'mg' },
  { id: 'produced-result', relationship: 'mg:producedResult', example: 'Run produced result', namespace: 'mg' },
  { id: 'supports', relationship: 'mg:supports', example: 'Evidence supports hypothesis', namespace: 'mg' },
  { id: 'contradicts', relationship: 'mg:contradicts', example: 'Evidence contradicts hypothesis', namespace: 'mg' },
  { id: 'interpreted-as', relationship: 'mg:interpretedAs', example: 'Result interpreted as degradation trend', namespace: 'mg' },
  { id: 'led-to-decision', relationship: 'mg:ledToDecision', example: 'Interpretation led to decision', namespace: 'mg' },
  { id: 'has-failure-reason', relationship: 'mg:hasFailureReason', example: 'Failure event has reason', namespace: 'mg' },
  { id: 'caused-by', relationship: 'mg:causedBy', example: 'Failure reason caused by condition/method/sample issue', namespace: 'mg' },
  { id: 'supersedes', relationship: 'mg:supersedes', example: 'New evidence supersedes old interpretation', namespace: 'mg' },
  { id: 'was-generated-by', relationship: 'prov:wasGeneratedBy', example: 'Result generated by experiment activity', namespace: 'prov' },
  { id: 'used', relationship: 'prov:used', example: 'Analysis used result/report/ELN record', namespace: 'prov' },
  { id: 'was-derived-from', relationship: 'prov:wasDerivedFrom', example: 'Interpretation derived from evidence', namespace: 'prov' },
  { id: 'was-associated-with', relationship: 'prov:wasAssociatedWith', example: 'Activity associated with scientist or software agent', namespace: 'prov' },
  { id: 'was-attributed-to', relationship: 'prov:wasAttributedTo', example: 'Assertion attributed to agent/person', namespace: 'prov' },
  { id: 'qualified-influence', relationship: 'prov:qualifiedInfluence', example: 'Attach role/confidence/rationale to influence', namespace: 'prov' },
];

export const QUALIFIED_INFLUENCE_NOTE =
  "PROV-O's qualified influence pattern is especially useful because it lets you annotate relationships with extra details, such as role, time, confidence, source span, and rationale.";


/* ────────────────────────────────────────────────────────────────────────
 * 5 — Reasoning gaps as structured, typed entities (5 gap categories)
 * ──────────────────────────────────────────────────────────────────────── */

export type ReasoningGapTypeId =
  | 'missing-hypothesis'
  | 'missing-decision-rationale'
  | 'missing-failure-reason'
  | 'missing-contradiction-link'
  | 'missing-provenance';

export interface ReasoningGapType {
  id: ReasoningGapTypeId;
  gapType: string;
  detectionRule: string;
}

export const REASONING_GAP_TYPES: ReasoningGapType[] = [
  { id: 'missing-hypothesis', gapType: 'Missing hypothesis', detectionRule: 'Experiment has no mg:testsHypothesis' },
  { id: 'missing-decision-rationale', gapType: 'Missing decision rationale', detectionRule: 'Decision has no supporting evidence chain' },
  { id: 'missing-failure-reason', gapType: 'Missing failure reason', detectionRule: 'Failed parameter has no mg:hasFailureReason' },
  { id: 'missing-contradiction-link', gapType: 'Missing contradiction link', detectionRule: 'Result conflicts with prior result but no interpretation' },
  { id: 'missing-provenance', gapType: 'Missing provenance', detectionRule: 'Claim lacks source, agent, or generation activity' },
];

export const REASONING_GAP_DEFINITION =
  'The reasoning gap is the missing "why": why this experiment, what hypothesis it tested, how the result changed confidence, what prior evidence it confirms or contradicts, and which downstream decision it supports. A gap is modeled as an explicit mg:ReasoningGap entity whenever an ELN record contains the experimental "what" but no linked "why" — not just left as a red cell in a table.';

export const REASONING_GAP_TRIPLE_EXAMPLE = `:gap_001 a mg:ReasoningGap ;
  mg:gapType "MissingHypothesis" ;
  mg:observedIn :eln_record_123 ;
  mg:missingLink "Experiment has no linked hypothesis or decision rationale" ;
  prov:wasGeneratedBy :gap_detection_activity_456 .`;

export const FAILURE_INTELLIGENCE_TRIPLE_EXAMPLE = `:failure_event_101 a mg:FailureEvent ;
  mg:failedParameter :aggregation_percent ;
  mg:observedResult :result_789 ;
  mg:hasFailureReason :failure_reason_202 ;
  mg:affectedStudy :stability_study_55 ;
  prov:wasGeneratedBy :stability_run_12 .

:failure_reason_202 a mg:FailureReason ;
  mg:reasonCategory "Temperature-driven degradation trend" ;
  mg:confidenceScore "0.78" ;
  mg:evidenceBasis :interpretation_333 ;
  prov:wasDerivedFrom :report_section_4_2 ;
  prov:wasAttributedTo :llm_extractor_agent .`;

/* ────────────────────────────────────────────────────────────────────────
 * 6 — Reference implementation approach (tech stack + MVI roadmap)
 * ──────────────────────────────────────────────────────────────────────── */

export interface ReferenceStackRow {
  id: string;
  capability: string;
  viableTools: string;
}

export const REFERENCE_STACK: ReferenceStackRow[] = [
  { id: 'ingestion', capability: 'Data ingestion', viableTools: 'Airflow, Dagster, Kafka, Azure Data Factory, AWS Glue, Databricks Workflows' },
  { id: 'parsing', capability: 'Document parsing', viableTools: 'Apache Tika, Unstructured, Azure AI Document Intelligence, Amazon Textract, Google Document AI' },
  { id: 'extraction', capability: 'LLM extraction', viableTools: 'Azure OpenAI, OpenAI API, Anthropic Claude, Gemini, Llama / Mistral hosted models' },
  { id: 'embeddings', capability: 'Embeddings', viableTools: 'text-embedding models, BioBERT/SciBERT-style embeddings, domain-specific embeddings' },
  { id: 'vector-store', capability: 'Vector store', viableTools: 'pgvector, Pinecone, Weaviate, Milvus, Azure AI Search, OpenSearch' },
  { id: 'graph-store-rdf', capability: 'Graph store — RDF', viableTools: 'GraphDB, Stardog, Apache Jena Fuseki, Amazon Neptune (RDF), AllegroGraph, Virtuoso' },
  { id: 'graph-store-pg', capability: 'Graph store — property graph', viableTools: 'Neo4j, TigerGraph, Neptune (property graph), Memgraph' },
  { id: 'ontology-mgmt', capability: 'Ontology management', viableTools: 'Protégé, TopBraid, ROBOT, SHACL validators' },
  { id: 'agent-orchestration', capability: 'Agent orchestration', viableTools: 'LangGraph, Semantic Kernel, AutoGen, CrewAI, LlamaIndex workflows' },
  { id: 'metadata-provenance', capability: 'Metadata / provenance', viableTools: 'PROV-O, DCAT, OpenLineage, MLflow lineage, custom provenance service' },
  { id: 'governance', capability: 'Governance', viableTools: 'ABAC/RBAC, named graphs, audit logs, review workflow, rollback store' },
];

export const REFERENCE_STACK_NOTE =
  'Cloud-neutral but standards-led. The white paper specifically recommends W3C standards, DCAT, PROV-O, public biomedical ontologies, named graphs, SPARQL endpoints, and graph-layer confidentiality controls. For graph querying, SPARQL is appropriate because W3C describes it as the query language and protocol for RDF data.';

export interface MviStep {
  id: string;
  order: number;
  step: string;
  /** Whether the current virtual lab already conceptually covers this step. */
  coveredInVirtualLab: boolean;
  virtualLabNote?: string;
  subSteps?: string[];
}

export const MVI_STEPS: MviStep[] = [
  {
    id: 'domain-slice',
    order: 1,
    step: 'Pick one scientific domain slice: e.g., large-molecule stability studies.',
    coveredInVirtualLab: true,
    virtualLabNote: 'This is exactly the scope of the mAb-114 / FP-207 stability program already modeled in the Stability Studies section.',
  },
  {
    id: 'ingest-sources',
    order: 2,
    step: 'Ingest 3–5 source types: ELN export, stability report, method document, Teams/chat decision thread, result spreadsheet.',
    coveredInVirtualLab: false,
  },
  {
    id: 'bronze-silver-gold',
    order: 3,
    step: 'Build Bronze/Silver/Gold pipeline.',
    coveredInVirtualLab: true,
    virtualLabNote: 'Modeled as reference architecture in the Semantic Architecture tab (medallion layers) — not a running pipeline.',
  },
  {
    id: 'ontology-v01',
    order: 4,
    step: 'Define ontology v0.1 for study, experiment, parameter, result, hypothesis, decision, failure event, failure reason.',
    coveredInVirtualLab: true,
    virtualLabNote: 'Reference ontology classes/relationships defined in this blueprint (mg:/prov: namespaces).',
  },
  {
    id: 'llm-extraction',
    order: 5,
    step: 'Run LLM extraction into candidate JSON.',
    coveredInVirtualLab: false,
  },
  {
    id: 'validate-candidates',
    order: 6,
    step: 'Validate candidates with schema + SME review.',
    coveredInVirtualLab: false,
  },
  {
    id: 'publish-rdf',
    order: 7,
    step: 'Publish RDF triples with PROV-O.',
    coveredInVirtualLab: false,
  },
  {
    id: 'demo-queries',
    order: 8,
    step: 'Build three demo queries: ELN-only "what was done?", Memory Graph "why was it done?", Failure intelligence "why did it fail, and where else did similar failures occur?"',
    coveredInVirtualLab: true,
    virtualLabNote: 'Already demonstrated via the ELN-only vs. with-reasoning Insight Comparison and the Failure Events tab in each Stability Study.',
  },
  {
    id: 'agent-workflow',
    order: 9,
    step: 'Add agent workflow for anomaly detection and hypothesis write-back.',
    coveredInVirtualLab: true,
    virtualLabNote: 'Illustrated narratively via the Provenance Trail (agent-asserted hypothesis, pending SME review, human approval) and the Agents & Reasoning tab\'s write-back examples.',
  },
];

/* ────────────────────────────────────────────────────────────────────────
 * 7 — Why this lets agentic AI reason like a scientist
 * ──────────────────────────────────────────────────────────────────────── */

export interface CapabilityComparisonRow {
  id: string;
  capability: string;
  elnOnly: string;
  memoryGraphEnabled: string;
}

export const CAPABILITY_COMPARISON: CapabilityComparisonRow[] = [
  { id: 'retrieve-history', capability: 'Retrieve experiment history', elnOnly: 'Yes', memoryGraphEnabled: 'Yes' },
  { id: 'explain-why-selected', capability: 'Explain why experiment was selected', elnOnly: 'Usually no', memoryGraphEnabled: 'Yes, through hypothesis and decision links' },
  { id: 'identify-failure-patterns', capability: 'Identify failure patterns', elnOnly: 'Limited to observed failures', memoryGraphEnabled: 'Yes, with failure reason and evidence chains' },
  { id: 'validate-hypothesis', capability: 'Validate hypothesis', elnOnly: 'Hard, document-heavy', memoryGraphEnabled: 'Graph traversal across evidence' },
  { id: 'explain-confidence', capability: 'Explain confidence', elnOnly: 'Weak', memoryGraphEnabled: 'Evidence + provenance + review state' },
  { id: 'generate-new-hypothesis', capability: 'Generate new hypothesis', elnOnly: 'Possible but weakly grounded', memoryGraphEnabled: 'Grounded in graph paths and prior reasoning' },
  { id: 'audit-agent-reasoning', capability: 'Audit agent reasoning', elnOnly: 'Limited', memoryGraphEnabled: 'PROV-O chain and graph write-back' },
];

export const CAPABILITY_COMPARISON_TAKEAWAY =
  'ELN-only agents learn procedure: records, methods, measurements, timestamps. An agent grounded on results alone learns procedures, while an agent grounded on results plus reasoning learns science. The key architectural difference is that the Memory Graph makes reasoning queryable — instead of asking an LLM to infer scientific context from scattered documents every time, the enterprise creates a durable, governed, provenance-rich scientific memory that agents can traverse, reason over, and extend.';

export interface FinalRecommendationPoint {
  id: string;
  order: number;
  point: string;
}

export const FINAL_RECOMMENDATION_TITLE = 'Scientific Reasoning Memory Platform';

export const FINAL_RECOMMENDATION_POINTS: FinalRecommendationPoint[] = [
  { id: 'eln-system-of-record', order: 1, point: 'ELN remains the system of record for execution.' },
  { id: 'memory-graph-system-of-reasoning', order: 2, point: 'Memory Graph becomes the system of reasoning for science.' },
  { id: 'llms-extract-candidates', order: 3, point: 'LLMs extract candidate reasoning objects from documents, chats, reports, and ELN narratives.' },
  { id: 'agentic-workflows-validate', order: 4, point: 'Agentic workflows validate, connect, reason, and write back insights with provenance.' },
  { id: 'trust-via-standards', order: 5, point: 'PROV-O, RDF/SPARQL, named graphs, ontology governance, and SME review make the platform trustworthy.' },
  { id: 'failure-intelligence-reusable', order: 6, point: 'Failure intelligence becomes reusable institutional memory rather than buried narrative.' },
];

export const FINAL_RECOMMENDATION_CLOSING =
  'This is the cleanest way to connect the "what vs why" concept — ELN captures what was done, Memory Graph captures why it was done, including reasoning decisions and failure intelligence as first-class data — to an implementable LLM + agentic AI architecture.';

/* ────────────────────────────────────────────────────────────────────────
 * Helper lookups
 * ──────────────────────────────────────────────────────────────────────── */

export function getMviCoverageSummary(): { total: number; covered: number } {
  return {
    total: MVI_STEPS.length,
    covered: MVI_STEPS.filter((s) => s.coveredInVirtualLab).length,
  };
}
