/** Support tiers a supervisor may assign (mirrors identity SUPPORT_TIERS). */
export type SupportTier = 'L1' | 'L1.5' | 'L2';

export const SUPPORT_TIERS: SupportTier[] = ['L1', 'L1.5', 'L2'];

/** A support-tier user (identity GET /v1/users/support-engineers). */
export interface SupportEngineer {
  email: string;
  name: string;
  current_role: string;
}

export interface SupportEngineersResponse {
  users: SupportEngineer[];
  total: number;
}

/** Response of identity PUT /v1/users/{email}/role. */
export interface SetRoleResponse {
  email: string;
  role: string;
  previous_role: string;
}
