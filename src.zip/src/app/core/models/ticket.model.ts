export type TicketColumnKey =
  | 'number'
  | 'type'
  | 'short_desc'
  | 'priority'
  | 'stage'
  | 'action'
  | 'opened'
  | 'category'
  | 'created_by'
  | 'state'
  | 'assign_grp'
  | 'assigned_to';

export interface TicketColumn {
  key: TicketColumnKey;
  label: string;
  default: boolean;
  locked: boolean;
}

export type Ticket = Record<TicketColumnKey, string>;

export interface ChatMessage {
  author: 'ai' | 'user';
  text: string;
  meta: string;
}

export interface NotificationItem {
  iconClass: string;
  iconBg: 'ni-r' | 'ni-y' | 'ni-b' | 'ni-g';
  title: string;
  sub: string;
  time: string;
  unread: boolean;
}
