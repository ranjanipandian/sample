import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, finalize, map, of, switchMap } from 'rxjs';

import { FetchTicketResponse, ServiceNowTicket } from '@core/models/api.model';
import { Ticket, TicketColumn, TicketColumnKey } from '@core/models/ticket.model';
import { AuthService } from '@core/services/auth.service';
import { FetchTicketsOpts, SentinelApiService } from '@core/services/sentinel-api.service';
import { SupervisorTeamService } from '@core/services/supervisor-team.service';

@Injectable({ providedIn: 'root' })
export class TicketService {
  readonly columns: TicketColumn[] = [
    { key: 'number', label: 'Ticket ID', default: true, locked: true },
    { key: 'type', label: 'Type', default: true, locked: false },
    { key: 'short_desc', label: 'Short Description', default: true, locked: false },
    { key: 'priority', label: 'Priority', default: true, locked: false },
    { key: 'stage', label: 'Status', default: true, locked: false },
    { key: 'action', label: 'Action', default: true, locked: true },
    { key: 'opened', label: 'Opened', default: false, locked: false },
    { key: 'category', label: 'Category', default: false, locked: false },
    { key: 'created_by', label: 'Created By', default: false, locked: false },
    { key: 'state', label: 'State', default: false, locked: false },
    { key: 'assign_grp', label: 'Assignment Group', default: false, locked: false },
    { key: 'assigned_to', label: 'Assigned To', default: false, locked: false },
  ];

  /**
   * Action descriptor derived from ticket status (stage/state).
   * Used by the Live Tickets table to render a Resolve / Resume / View button.
   */
  actionFor(t: Ticket): { label: string; icon: string; theme: 'resolve' | 'resume' | 'view' } {
    const s = (t.stage || t.state || '').toLowerCase();
    if (s.includes('resolved') || s.includes('closed') || s.includes('cancel')) {
      return { label: 'View Ticket', icon: 'ti ti-eye', theme: 'view' };
    }
    if (
      s.includes('progress') ||
      s.includes('hitl') ||
      s.includes('hold') ||
      s.includes('escalated') ||
      s.includes('assigned') ||
      s.includes('scheduled')
    ) {
      return { label: 'Resume Ticket', icon: 'ti ti-player-play', theme: 'resume' };
    }
    return { label: 'Resolve Ticket', icon: 'ti ti-circle-check', theme: 'resolve' };
  }

  private readonly ticketsSubject = new BehaviorSubject<Ticket[]>([]);
  readonly tickets$: Observable<Ticket[]> = this.ticketsSubject.asObservable();

  private readonly loadingSubject = new BehaviorSubject<boolean>(false);
  readonly loading$: Observable<boolean> = this.loadingSubject.asObservable();

  private readonly errorSubject = new BehaviorSubject<string | null>(null);
  readonly error$: Observable<string | null> = this.errorSubject.asObservable();

  constructor(
    private api: SentinelApiService,
    private auth: AuthService,
    private team: SupervisorTeamService
  ) {}

  get tickets(): Ticket[] {
    return this.ticketsSubject.value;
  }

  /**
   * Fetch tickets from the Cognizant fetch_ticket API and replace the cached list.
   * `opts.ticketType` (UI label from the route) scopes the backend query to a
   * single ServiceNow table — avoids the 403 from tables the integration user
   * can't read AND speeds the query up. Pass undefined to query ALL_TABLES.
   *
   * Supervisors are scoped to their linked team: we first resolve the team's
   * assignee emails from the scheduler roster, then query tickets assigned to
   * any of them. The supervisor's own email is always included in that set, so
   * tickets assigned directly to the supervisor show alongside their team's
   * queue — even when the supervisor owns no rostered engineers.
   *
   * Returns the same Observable so the caller can react (e.g. show toast).
   */
  refresh(opts?: FetchTicketsOpts): Observable<Ticket[]> {
    this.loadingSubject.next(true);
    this.errorSubject.next(null);

    const user = this.auth.user;
    const source$: Observable<FetchTicketResponse> =
      user.role === 'SUPERVISOR'
        ? this.team.teamEmails(user.email).pipe(
            map((emails) => this.dedupeEmails([user.email, ...emails])),
            switchMap((assignees) => this.api.fetchTickets({ ...opts, assignees }))
          )
        : this.api.fetchTickets(opts);

    return source$.pipe(
      map((res) =>
        this.dedupeBySysId(res.tickets || [])
          .sort((a, b) => this.compareByCreatedDesc(a, b))
          .map((t) => this.mapServiceNowToUi(t))
      ),
      catchError((err: unknown) => {
        this.errorSubject.next(this.formatError(err));
        return of<Ticket[]>([]);
      }),
      map((tickets) => {
        this.ticketsSubject.next(tickets);
        return tickets;
      }),
      finalize(() => this.loadingSubject.next(false))
    );
  }

  /**
   * Backend aggregates results across ALL_TABLES (incident, sc_request, …, task).
   * Since 'task' is ServiceNow's polymorphic parent of every concrete table, each
   * incident/request/problem is also a task — so the response contains the same
   * record twice. Collapse on sys_id (falling back to number) to get unique rows.
   */
  /**
   * Case-insensitively de-duplicate assignee emails, preserving first-seen
   * order (so the supervisor's own email stays first). Drops blanks.
   */
  private dedupeEmails(emails: string[]): string[] {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const e of emails) {
      const key = (e || '').trim().toLowerCase();
      if (!key || seen.has(key)) continue;
      seen.add(key);
      out.push(e.trim());
    }
    return out;
  }

  private dedupeBySysId(rows: ServiceNowTicket[]): ServiceNowTicket[] {
    const seen = new Set<string>();
    const out: ServiceNowTicket[] = [];
    for (const r of rows) {
      const key = String(r.sys_id ?? r['number'] ?? '');
      if (!key || seen.has(key)) continue;
      seen.add(key);
      out.push(r);
    }
    return out;
  }

  /**
   * Newest-first ordering by the ticket's creation timestamp, so the grid opens
   * on the most recently created ticket. The backend already returns rows
   * ORDERBYDESC sys_created_on per table, but a multi-table (All Tickets) fetch
   * concatenates per-table results without a global sort — so we re-sort here.
   *
   * sys_created_on is the canonical record-creation time (falling back to
   * opened_at). ServiceNow's default format is fixed-width
   * "YYYY-MM-DD HH:mm:ss", which sorts correctly as a plain string compare, so
   * we avoid Date parsing (whose result varies with the user's display locale).
   */
  private compareByCreatedDesc(a: ServiceNowTicket, b: ServiceNowTicket): number {
    const ka = this.s(a.sys_created_on) || this.s(a.opened_at);
    const kb = this.s(b.sys_created_on) || this.s(b.opened_at);
    return kb.localeCompare(ka);
  }

  /* ─── field mapping ServiceNow → UI ─── */

  private mapServiceNowToUi(sn: ServiceNowTicket): Ticket {
    return {
      number: this.s(sn['number']),
      type: this.mapType(sn['sys_class_name']),
      short_desc: this.s(sn['short_description']),
      priority: this.mapPriority(sn['priority']),
      stage: this.s(sn['stage']) || this.s(sn['state']),
      action: '', // virtual column, rendered from stage/state at display time
      opened: this.s(sn['opened_at']) || this.s(sn['sys_created_on']),
      category: this.s(sn['category']),
      created_by: this.s(sn['opened_by']) || this.s(sn['caller_id']),
      state: this.s(sn['state']),
      assign_grp: this.s(sn['assignment_group']),
      assigned_to: this.s(sn['assigned_to']),
    };
  }

  private s(v: unknown): string {
    if (v === null || v === undefined) return '';
    if (typeof v === 'string') return v;
    if (typeof v === 'object' && v !== null && 'display_value' in (v as object)) {
      return String((v as { display_value: unknown }).display_value ?? '');
    }
    return String(v);
  }

  private mapType(snTable: unknown): string {
    const t = this.s(snTable).toLowerCase();
    if (!t) return '';
    if (t === 'incident') return 'Incident';
    if (t === 'sc_request' || t === 'sc_req_item') return 'Service Request';
    if (t === 'problem') return 'Problem';
    if (t === 'change_request' || t === 'change') return 'Change';
    return this.s(snTable);
  }

  /**
   * ServiceNow priority comes back as "1 - Critical" (display_value=true).
   * UI uses "P1 Critical" labels (matches the badge palette).
   */
  private mapPriority(snPriority: unknown): string {
    const p = this.s(snPriority);
    if (!p) return '';
    if (p.startsWith('1')) return 'P1 Critical';
    if (p.startsWith('2')) return 'P2 High';
    if (p.startsWith('3')) return 'P3 Medium';
    if (p.startsWith('4')) return 'P4 Low';
    if (p.startsWith('5')) return 'P5 Planning';
    return p;
  }

  private formatError(err: unknown): string {
    if (typeof err === 'object' && err !== null) {
      const e = err as { status?: number; message?: string; error?: { error?: string } };
      if (e.status === 0)
        return 'Cannot reach Cognizant backend (is it running on the configured URL?)';
      const inner = e.error?.error ?? e.message ?? '';
      // Detect ServiceNow's "403 Forbidden" pattern and surface a friendly,
      // actionable message instead of dumping the upstream URL. The MCP
      // backend bubbles the requests.HTTPError verbatim, e.g.
      //   "Client error '403 Forbidden' for url '.../api/now/table/change_request?...'"
      // `.*?` (lazy) crosses over the embedded quotes in the upstream URL.
      const m = inner.match(/403 Forbidden.*?\/table\/([a-z_]+)/i);
      if (m) {
        const table = m[1];
        return (
          `Your ServiceNow account does not have read access to the "${table}" table. ` +
          `Ask the ServiceNow admin to grant the 'itil' role (or '${table}_user' specifically).`
        );
      }
      return inner ? `Backend error: ${inner}` : 'Unknown error contacting backend';
    }
    return 'Unknown error contacting backend';
  }

  /* ─── badge mapping (unchanged) ─── */

  private readonly badgeMaps: Partial<Record<TicketColumnKey, Record<string, string>>> = {
    type: {
      Incident: 'b-red',
      'Service Request': 'b-blue',
      Problem: 'b-yellow',
      Change: 'b-green',
    },
    priority: {
      'P1 Critical': 'b-red',
      'P2 High': 'b-yellow',
      'P3 Medium': 'b-blue',
      'P4 Low': 'b-green',
      'P5 Planning': 'b-blue',
    },
    stage: {
      'Pending HITL': 'b-yellow',
      'In Progress': 'b-blue',
      Resolved: 'b-green',
      Escalated: 'b-red',
      Assigned: 'b-blue',
      New: 'b-blue',
      'On Hold': 'b-yellow',
      Closed: 'b-green',
      Cancelled: 'b-red',
    },
    state: {
      Open: 'b-red',
      'In Progress': 'b-blue',
      Closed: 'b-green',
      Scheduled: 'b-yellow',
      New: 'b-blue',
      'On Hold': 'b-yellow',
      Resolved: 'b-green',
      Cancelled: 'b-red',
    },
  };

  isBadgeColumn(key: TicketColumnKey): boolean {
    return key in this.badgeMaps;
  }

  badgeClass(key: TicketColumnKey, val: string): string {
    const map = this.badgeMaps[key];
    return map?.[val] ?? 'b-blue';
  }
}
