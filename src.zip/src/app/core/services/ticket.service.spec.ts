import { TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';

import { FetchTicketResponse, ServiceNowTicket } from '@core/models/api.model';
import { AuthService, AuthUser } from '@core/services/auth.service';
import { SupervisorTeamService } from '@core/services/supervisor-team.service';
import { SentinelApiService } from './sentinel-api.service';
import { TicketService } from './ticket.service';

const engineer: AuthUser = {
  authenticated: true,
  sub: 'sub-1',
  userId: 'sub-1',
  email: 'jane.doe@cognizant.com',
  name: 'Jane Doe',
  role: 'L2',
  sessionId: 'sess-1',
  groups: ['L2'],
};

describe('TicketService', () => {
  let service: TicketService;
  let api: jasmine.SpyObj<SentinelApiService>;
  let team: jasmine.SpyObj<SupervisorTeamService>;
  let currentUser: AuthUser;

  beforeEach(() => {
    currentUser = { ...engineer };
    api = jasmine.createSpyObj<SentinelApiService>('SentinelApiService', [
      'fetchTickets',
      'health',
    ]);
    team = jasmine.createSpyObj<SupervisorTeamService>('SupervisorTeamService', ['teamEmails']);
    TestBed.configureTestingModule({
      providers: [
        TicketService,
        { provide: SentinelApiService, useValue: api },
        { provide: SupervisorTeamService, useValue: team },
        {
          provide: AuthService,
          useValue: {
            get user() {
              return currentUser;
            },
          },
        },
      ],
    });
    service = TestBed.inject(TicketService);
  });

  it('maps ServiceNow rows to UI Tickets on refresh()', (done) => {
    const sn: ServiceNowTicket = {
      number: 'INC0042156',
      sys_class_name: 'incident',
      short_description: 'CPU spike',
      priority: '1 - Critical',
      state: 'In Progress',
      sys_id: 'sys-1',
    };
    const res: FetchTicketResponse = { tickets: [sn] };
    api.fetchTickets.and.returnValue(of(res));

    service.refresh().subscribe((tickets) => {
      expect(tickets.length).toBe(1);
      expect(tickets[0].number).toBe('INC0042156');
      expect(tickets[0].type).toBe('Incident');
      expect(tickets[0].priority).toBe('P1 Critical');
      done();
    });
  });

  it('orders tickets newest-first by creation time', (done) => {
    const older: ServiceNowTicket = {
      number: 'INC-OLD',
      sys_id: '1',
      sys_class_name: 'incident',
      sys_created_on: '2026-06-01 09:00:00',
    };
    const newer: ServiceNowTicket = {
      number: 'INC-NEW',
      sys_id: '2',
      sys_class_name: 'incident',
      sys_created_on: '2026-06-10 17:30:00',
    };
    const noCreatedFallsBackToOpened: ServiceNowTicket = {
      number: 'INC-MID',
      sys_id: '3',
      sys_class_name: 'incident',
      opened_at: '2026-06-05 12:00:00',
    };
    // Feed them out of order; refresh() must sort newest-first.
    api.fetchTickets.and.returnValue(of({ tickets: [older, newer, noCreatedFallsBackToOpened] }));

    service.refresh().subscribe((tickets) => {
      expect(tickets.map((t) => t.number)).toEqual(['INC-NEW', 'INC-MID', 'INC-OLD']);
      done();
    });
  });

  it('dedupes rows by sys_id', (done) => {
    const a: ServiceNowTicket = { number: 'INC1', sys_id: 'x', sys_class_name: 'incident' };
    const b: ServiceNowTicket = { number: 'INC1', sys_id: 'x', sys_class_name: 'task' };
    api.fetchTickets.and.returnValue(of({ tickets: [a, b] }));

    service.refresh().subscribe((tickets) => {
      expect(tickets.length).toBe(1);
      done();
    });
  });

  it('returns an empty list and reports an error string on HTTP failure', (done) => {
    api.fetchTickets.and.returnValue(throwError(() => ({ status: 0 })));
    let errorMsg: string | null = null;
    const sub = service.error$.subscribe((e) => (errorMsg = e));

    service.refresh().subscribe((tickets) => {
      expect(tickets).toEqual([]);
      expect(errorMsg).toContain('Cannot reach Cognizant backend');
      sub.unsubscribe();
      done();
    });
  });

  it('rewrites a ServiceNow 403 into a friendly, actionable message', (done) => {
    const upstream =
      "Client error '403 Forbidden' for url 'https://cognizantdemo4.service-now.com/api/now/table/change_request?sysparm_query=...'";
    api.fetchTickets.and.returnValue(throwError(() => ({ error: { error: upstream } })));
    let errorMsg: string | null = null;
    const sub = service.error$.subscribe((e) => (errorMsg = e));

    service.refresh().subscribe((tickets) => {
      expect(tickets).toEqual([]);
      expect(errorMsg).toContain('change_request');
      expect(errorMsg).toContain('does not have read access');
      expect(errorMsg).toContain('itil');
      expect(errorMsg).not.toContain('cognizantdemo4.service-now.com');
      sub.unsubscribe();
      done();
    });
  });

  it('forwards ticketType opt to the API for route-scoped queries', (done) => {
    api.fetchTickets.and.returnValue(of({ tickets: [] }));
    service.refresh({ ticketType: 'Incident' }).subscribe(() => {
      expect(api.fetchTickets).toHaveBeenCalledWith({ ticketType: 'Incident' });
      done();
    });
  });

  it('SUPERVISOR: queries the team plus the supervisor’s own tickets', (done) => {
    currentUser = {
      ...engineer,
      email: 'sue.boss@cognizant.com',
      role: 'SUPERVISOR',
      groups: ['SUPERVISOR'],
    };
    team.teamEmails.and.returnValue(of(['a@x.com', 'b@x.com']));
    api.fetchTickets.and.returnValue(of({ tickets: [] }));

    service.refresh({ ticketType: 'Incident' }).subscribe(() => {
      expect(team.teamEmails).toHaveBeenCalledWith('sue.boss@cognizant.com');
      expect(api.fetchTickets).toHaveBeenCalledWith({
        ticketType: 'Incident',
        assignees: ['sue.boss@cognizant.com', 'a@x.com', 'b@x.com'],
      });
      done();
    });
  });

  it('SUPERVISOR: de-dupes their own email if the roster also returns it', (done) => {
    currentUser = {
      ...engineer,
      email: 'sue.boss@cognizant.com',
      role: 'SUPERVISOR',
      groups: ['SUPERVISOR'],
    };
    team.teamEmails.and.returnValue(of(['Sue.Boss@cognizant.com', 'a@x.com']));
    api.fetchTickets.and.returnValue(of({ tickets: [] }));

    service.refresh({ ticketType: 'Incident' }).subscribe(() => {
      expect(api.fetchTickets).toHaveBeenCalledWith({
        ticketType: 'Incident',
        assignees: ['sue.boss@cognizant.com', 'a@x.com'],
      });
      done();
    });
  });

  it('SUPERVISOR with no linked engineers: still queries their own tickets', (done) => {
    currentUser = { ...engineer, email: 'sue.boss@cognizant.com', role: 'SUPERVISOR' };
    team.teamEmails.and.returnValue(of([]));
    api.fetchTickets.and.returnValue(of({ tickets: [] }));

    service.refresh({ ticketType: 'Incident' }).subscribe(() => {
      expect(api.fetchTickets).toHaveBeenCalledWith({
        ticketType: 'Incident',
        assignees: ['sue.boss@cognizant.com'],
      });
      done();
    });
  });

  it('actionFor returns the right theme for each status', () => {
    expect(service.actionFor({ stage: 'Resolved' } as never).theme).toBe('view');
    expect(service.actionFor({ stage: 'In Progress' } as never).theme).toBe('resume');
    expect(service.actionFor({ stage: 'New' } as never).theme).toBe('resolve');
  });

  it('isBadgeColumn and badgeClass behave as expected', () => {
    expect(service.isBadgeColumn('priority')).toBe(true);
    expect(service.isBadgeColumn('short_desc')).toBe(false);
    expect(service.badgeClass('priority', 'P1 Critical')).toBe('b-red');
    expect(service.badgeClass('priority', 'unknown')).toBe('b-blue');
  });
});
