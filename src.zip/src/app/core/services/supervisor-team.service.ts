import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';

import { environment } from '@env/environment';

/** Scheduler base URL — runtime-overridable via window.__env for Helm. */
function schedulerBaseUrl(): string {
  const env = (window as unknown as { __env?: { schedulerBaseUrl?: string } }).__env;
  return env?.schedulerBaseUrl || environment.schedulerBaseUrl;
}

interface SupervisorTeamMember {
  email: string;
  full_name: string;
  tier?: string | null;
  engineer_id?: string | null;
}

interface SupervisorTeamResponse {
  supervisor_email: string;
  members: SupervisorTeamMember[];
  total: number;
}

/**
 * Resolves the engineers linked to a supervisor via the scheduler roster
 * (GET /v1/scheduler/shift-roster/team), i.e. the active resources in every
 * roster group the supervisor's triage config owns. The ticket view uses these
 * emails to scope a supervisor's ServiceNow query to their team's assignees, so
 * a supervisor sees their team's tickets rather than only their own. The session
 * JWT is attached by authInterceptor.
 */
@Injectable({ providedIn: 'root' })
export class SupervisorTeamService {
  constructor(private http: HttpClient) {}

  /** Emails of the engineers bound to `supervisorEmail`. Empty when the
   *  supervisor owns no roster group / has no rostered engineers. */
  teamEmails(supervisorEmail: string): Observable<string[]> {
    const params = new HttpParams().set('supervisor_email', supervisorEmail);
    return this.http
      .get<SupervisorTeamResponse>(`${schedulerBaseUrl()}/shift-roster/team`, { params })
      .pipe(map((res) => (res.members || []).map((m) => m.email).filter(Boolean)));
  }
}
