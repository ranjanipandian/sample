import { TestBed } from '@angular/core/testing';

import { IntelService } from './intel.service';

describe('IntelService', () => {
  let service: IntelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IntelService);
  });

  it('starts closed', () => {
    expect(service.isOpen).toBe(false);
  });

  it('toggle flips the open state', () => {
    service.toggle();
    expect(service.isOpen).toBe(true);
    service.toggle();
    expect(service.isOpen).toBe(false);
  });

  it('set drives open$ directly', (done) => {
    const seen: boolean[] = [];
    const sub = service.open$.subscribe((v) => seen.push(v));
    service.set(true);
    service.set(false);
    queueMicrotask(() => {
      expect(seen).toEqual([false, true, false]);
      sub.unsubscribe();
      done();
    });
  });
});
