import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import {
  ApprovalDecision,
  ApprovalDecisionRequest,
  ApprovalDecisionResponse,
  ApprovalsListResponse,
} from '@core/models/approvals.model';
import { environment } from '@env/environment';

/** Identity base URL — runtime-overridable via window.__env for Helm. */
function identityBaseUrl(): string {
  const env = (window as unknown as { __env?: { identityBaseUrl?: string } }).__env;
  return env?.identityBaseUrl || environment.identityBaseUrl;
}

/**
 * Backs the Settings → Tool Access Approvals page (SUPERVISOR only). The session
 * JWT is attached by authInterceptor, and the identity service enforces the
 * SUPERVISOR role on both endpoints — this service does no auth itself.
 */
@Injectable({ providedIn: 'root' })
export class ApprovalsService {
  constructor(private http: HttpClient) {}

  /** Pending tool-access requests awaiting a supervisor decision. */
  listPending(): Observable<ApprovalsListResponse> {
    return this.http.get<ApprovalsListResponse>(`${identityBaseUrl()}/v1/approvals`);
  }

  /** Approve (→ active ALLOW grant) or reject (→ removed) a pending request. */
  decide(
    authId: string,
    decision: ApprovalDecision,
    reason?: string
  ): Observable<ApprovalDecisionResponse> {
    const body: ApprovalDecisionRequest = { decision, reason: reason?.trim() || null };
    return this.http.post<ApprovalDecisionResponse>(
      `${identityBaseUrl()}/v1/approvals/${authId}`,
      body
    );
  }
}
