import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AuthService } from './auth.service';
import { environment } from '../../../environments/environment';

function makeJwt(payload: Record<string, unknown>): string {
  const b64 = (s: string) => btoa(s).replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
  const header = b64(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const body = b64(JSON.stringify(payload));
  return `${header}.${body}.signature-not-verified-in-browser`;
}

const ID = environment.identityBaseUrl;

describe('AuthService', () => {
  let service: AuthService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({ imports: [HttpClientTestingModule] });
    service = TestBed.inject(AuthService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
    sessionStorage.clear();
  });

  it('starts anonymous', () => {
    expect(service.user.authenticated).toBe(false);
    expect(service.isAuthenticated()).toBe(false);
  });

  it('handleCallback exchanges code/state and populates the user from the session JWT', async () => {
    const exp = Math.floor(Date.now() / 1000) + 3600;
    const jwt = makeJwt({
      sub: 'user-uuid-1',
      email: 'jane.doe@cognizant.com',
      name: 'Jane Doe',
      role: 'L2',
      session_id: 'sess-9',
      exp,
    });

    const promise = service.handleCallback('the-code', 'the-state');

    const req = httpMock.expectOne(`${ID}/v1/auth/oidc/callback?code=the-code&state=the-state`);
    expect(req.request.method).toBe('GET');
    req.flush({
      session_token: jwt,
      refresh_token: 'refresh-xyz',
      user_id: 'user-uuid-1',
      email: 'jane.doe@cognizant.com',
      role: 'L2',
      expires_at: new Date(exp * 1000).toISOString(),
    });

    const user = await promise;
    expect(user.authenticated).toBe(true);
    expect(user.userId).toBe('user-uuid-1');
    expect(user.email).toBe('jane.doe@cognizant.com');
    expect(user.role).toBe('L2');
    expect(user.sessionId).toBe('sess-9');
    expect(user.groups).toEqual(['L2']);
    expect(service.getSessionToken()).toBe(jwt);
    expect(service.isAuthenticated()).toBe(true);
    expect(sessionStorage.getItem('ams.refresh')).toBe('refresh-xyz');
  });

  it('load() stays anonymous when no refresh token is stored', async () => {
    const user = await service.load();
    expect(user.authenticated).toBe(false);
  });

  it('load() silently refreshes when a refresh token survived a reload', async () => {
    const exp = Math.floor(Date.now() / 1000) + 3600;
    const jwt = makeJwt({ sub: 'u2', email: 'a@b.com', role: 'L1', session_id: 's2', exp });
    sessionStorage.setItem('ams.refresh', 'stored-refresh');

    const promise = service.load();
    const req = httpMock.expectOne(`${ID}/v1/auth/token/refresh`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ refresh_token: 'stored-refresh' });
    req.flush({
      session_token: jwt,
      refresh_token: 'rotated-refresh',
      expires_at: new Date(exp * 1000).toISOString(),
    });

    const user = await promise;
    expect(user.authenticated).toBe(true);
    expect(user.userId).toBe('u2');
    expect(sessionStorage.getItem('ams.refresh')).toBe('rotated-refresh');
  });

  it('load() clears state when refresh fails', async () => {
    sessionStorage.setItem('ams.refresh', 'bad-refresh');
    const promise = service.load();
    httpMock
      .expectOne(`${ID}/v1/auth/token/refresh`)
      .flush({ error: 'INVALID_REFRESH' }, { status: 401, statusText: 'Unauthorized' });
    const user = await promise;
    expect(user.authenticated).toBe(false);
    expect(sessionStorage.getItem('ams.refresh')).toBeNull();
  });
});
