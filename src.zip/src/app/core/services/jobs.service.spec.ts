import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AuthService, AuthUser } from '@core/services/auth.service';
import { environment } from '@env/environment';
import { JobsService, JobState } from './jobs.service';

const anon: AuthUser = {
  authenticated: false,
  sub: '',
  userId: '',
  email: '',
  name: '',
  role: '',
  sessionId: '',
  groups: [],
};

function authStub(user: AuthUser): Partial<AuthService> {
  return {
    get user() {
      return user;
    },
  };
}

/* Reusable Resolve response fixture (mirrors the real backend shape). */
function plannedStepsFixture() {
  return [
    {
      Classification: [
        { step_name: 'parse_ticket', description: 'Parse ticket fields' },
        { step_name: 'apply_classifier', description: 'Apply classifier' },
      ],
    },
    {
      'Document Remediation': [
        { step_name: 'parse_ticket_context', description: 'Parse context' },
        { step_name: 'confirm_application', description: 'Confirm app' },
        { step_name: 'hitl_approval_gate', description: 'HITL gate' },
        { step_name: 'execute_document_updates', description: 'Execute updates' },
      ],
    },
    {
      Completion: [
        { step_name: 'validate_ticket_state', description: 'Validate state' },
        { step_name: 'close_ticket', description: 'Close ticket' },
      ],
    },
  ];
}

describe('JobsService', () => {
  let httpMock: HttpTestingController;

  function setup(user: AuthUser = anon): JobsService {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [{ provide: AuthService, useValue: authStub(user) }],
    });
    httpMock = TestBed.inject(HttpTestingController);
    return TestBed.inject(JobsService);
  }

  afterEach(() => httpMock.verify());

  it('builds groups + Classification=done + Document Remediation=awaiting_hitl after resolve', () => {
    const service = setup(anon);
    const ticket = 'INC0501180';
    const states: Array<JobState | null> = [];
    const sub = service.getJobForTicket(ticket).subscribe((s) => states.push(s));

    service.resolveTicket(ticket);

    const req = httpMock.expectOne(environment.jobsResolveUrl);
    expect(req.request.method).toBe('POST');
    req.flush({
      job_id: 'job-1',
      status: 'accepted',
      planned_steps: plannedStepsFixture(),
    });

    const last = states[states.length - 1];
    expect(last?.phase).toBe('awaiting_hitl');
    expect(last?.jobId).toBe('job-1');
    expect(last?.groups.length).toBe(3);
    expect(last?.groups[0].name).toBe('Classification');
    expect(last?.groups[0].status).toBe('done');
    expect(last?.groups[0].substeps.every((s) => s.status === 'done')).toBe(true);
    expect(last?.groups[1].name).toBe('Document Remediation');
    expect(last?.groups[1].status).toBe('awaiting_hitl');
    expect(last?.groups[1].awaitingHitl).toBe(true);
    expect(last?.groups[2].status).toBe('pending');
    expect(last?.currentGroupIdx).toBe(1);
    sub.unsubscribe();
  });

  it('approve() fires POST resume and keeps phase=awaiting_hitl when HITL still pending', () => {
    const service = setup(anon);
    const ticket = 'INC0501180';
    const sub = service.getJobForTicket(ticket).subscribe();

    service.resolveTicket(ticket);
    httpMock.expectOne(environment.jobsResolveUrl).flush({
      job_id: 'job-1',
      status: 'accepted',
      planned_steps: plannedStepsFixture(),
    });

    service.approve(ticket);

    const resumeReq = httpMock.expectOne(`${environment.jobsOrchStepsBase}/job-1/resume`);
    expect(resumeReq.request.method).toBe('POST');
    expect((resumeReq.request.body as { user_context: object }).user_context).toBeDefined();
    resumeReq.flush({
      job_id: 'job-1',
      ticket_id: ticket,
      status: 'AWAITING_HITL',
      trigger: 'DIRECT',
      current_step: 'hitl_approval_gate',
      steps: [
        {
          step_id: 'STEP-001.parse_ticket_context',
          capability: 'parse_ticket_context',
          status: 'SUCCEEDED',
          parent_step_id: 'p1',
          outcome: { input_summary: 'in', output_summary: 'out' },
        },
        {
          step_id: 'STEP-001.confirm_application',
          capability: 'confirm_application',
          status: 'SUCCEEDED',
          parent_step_id: 'p1',
          outcome: { input_summary: 'in2', output_summary: 'out2' },
        },
        {
          step_id: 'STEP-001.hitl_approval_gate',
          capability: 'hitl_approval_gate',
          status: 'PENDING',
          parent_step_id: 'p1',
          outcome: { input_summary: 'gate', output_summary: 'awaiting' },
        },
      ],
    });

    let latest: JobState | null = null;
    service.getJobForTicket(ticket).subscribe((s) => (latest = s));
    const state = latest as unknown as JobState;
    expect(state.phase).toBe('awaiting_hitl');
    expect(state.status).toBe('AWAITING_HITL');
    const docRem = state.groups[1];
    expect(docRem.substeps.find((s) => s.capability === 'parse_ticket_context')?.status).toBe(
      'done'
    );
    expect(docRem.substeps.find((s) => s.capability === 'hitl_approval_gate')?.status).toBe(
      'current'
    );
    expect(docRem.awaitingHitl).toBe(true);
    sub.unsubscribe();
  });

  it('flips phase to resolved when resume returns status=RESOLVED', () => {
    const service = setup(anon);
    const ticket = 'INC0501180';
    const sub = service.getJobForTicket(ticket).subscribe();

    service.resolveTicket(ticket);
    httpMock.expectOne(environment.jobsResolveUrl).flush({
      job_id: 'job-1',
      status: 'accepted',
      planned_steps: plannedStepsFixture(),
    });

    service.approve(ticket);
    httpMock.expectOne(`${environment.jobsOrchStepsBase}/job-1/resume`).flush({
      job_id: 'job-1',
      ticket_id: ticket,
      status: 'RESOLVED',
      current_step: null,
      steps: [
        {
          step_id: 'STEP-001.parse_ticket_context',
          capability: 'parse_ticket_context',
          status: 'SUCCEEDED',
          parent_step_id: 'p1',
        },
        {
          step_id: 'STEP-001.confirm_application',
          capability: 'confirm_application',
          status: 'SUCCEEDED',
          parent_step_id: 'p1',
        },
        {
          step_id: 'STEP-001.hitl_approval_gate',
          capability: 'hitl_approval_gate',
          status: 'BYPASSED',
          parent_step_id: 'p1',
        },
        {
          step_id: 'STEP-001.execute_document_updates',
          capability: 'execute_document_updates',
          status: 'SUCCEEDED',
          parent_step_id: 'p1',
        },
        {
          step_id: 'STEP-002.validate_ticket_state',
          capability: 'validate_ticket_state',
          status: 'SUCCEEDED',
          parent_step_id: 'p2',
        },
        {
          step_id: 'STEP-002.close_ticket',
          capability: 'close_ticket',
          status: 'SUCCEEDED',
          parent_step_id: 'p2',
        },
      ],
    });

    let latest: JobState | null = null;
    service.getJobForTicket(ticket).subscribe((s) => (latest = s));
    const state = latest as unknown as JobState;
    expect(state.phase).toBe('resolved');
    expect(state.status).toBe('RESOLVED');
    expect(state.groups[1].status).toBe('done');
    expect(state.groups[2].status).toBe('done');
    sub.unsubscribe();
  });

  it('reject() halts the workflow with a stored comment', () => {
    const service = setup(anon);
    const ticket = 'INC0501180';
    let latest: JobState | null = null;
    const sub = service.getJobForTicket(ticket).subscribe((s) => (latest = s));

    service.resolveTicket(ticket);
    httpMock.expectOne(environment.jobsResolveUrl).flush({
      job_id: 'job-1',
      status: 'accepted',
      planned_steps: plannedStepsFixture(),
    });

    service.reject(ticket, 'Wrong document set');

    const state = latest as unknown as JobState;
    expect(state.phase).toBe('rejected');
    expect(state.status).toBe('REJECTED');
    expect(state.rejectComment).toBe('Wrong document set');
    sub.unsubscribe();
  });

  it('reports an error phase when resolve fails with status 0', () => {
    const service = setup(anon);
    const ticket = 'INC9999';
    let latest: JobState | null = null;
    const sub = service.getJobForTicket(ticket).subscribe((s) => (latest = s));

    service.resolveTicket(ticket);
    httpMock
      .expectOne(environment.jobsResolveUrl)
      .error(new ProgressEvent('error'), { status: 0, statusText: 'unreachable' });

    const state = latest as unknown as JobState;
    expect(state.phase).toBe('error');
    sub.unsubscribe();
  });

  it('overlays the authenticated user identity onto the resolve user_context', () => {
    const service = setup({
      authenticated: true,
      sub: 'sub-x',
      userId: 'sub-x',
      email: 'jane.doe@cognizant.com',
      name: 'Jane Doe',
      role: 'L2',
      sessionId: 'sess-x',
      groups: ['L2'],
    });

    service.resolveTicket('INC0042156');

    const req = httpMock.expectOne(environment.jobsResolveUrl);
    const ctx = (req.request.body as { user_context: Record<string, string> }).user_context;
    expect(ctx['engineer_id']).toBe('jane.doe@cognizant.com');
    expect(ctx['engineer_mail']).toBe('jane.doe@cognizant.com');
    expect(ctx['engineer_name']).toBe('Jane Doe');
    expect(ctx['role']).toBe(environment.jobsUserContext.role);
    req.flush({ job_id: 'j', status: 'accepted' });
  });

  it('falls back to env user_context defaults when no user is authenticated', () => {
    const service = setup(anon);
    service.resolveTicket('INC0042156');

    const req = httpMock.expectOne(environment.jobsResolveUrl);
    const ctx = (req.request.body as { user_context: Record<string, string> }).user_context;
    expect(ctx['engineer_id']).toBe(environment.jobsUserContext.engineer_id);
    expect(ctx['engineer_name']).toBe(environment.jobsUserContext.engineer_name);
    req.flush({ job_id: 'j', status: 'accepted' });
  });

  it('viewJob() short-circuits the lookup when a job_id is already cached and builds groups from parent_step_id', () => {
    const service = setup(anon);
    const ticket = 'INC0501178';
    let latest: JobState | null = null;
    const sub = service.getJobForTicket(ticket).subscribe((s) => (latest = s));

    // Seed in-memory state with a known job_id (simulates Resolve already ran).
    service.resolveTicket(ticket);
    httpMock.expectOne(environment.jobsResolveUrl).flush({
      job_id: 'job-cached',
      status: 'accepted',
      planned_steps: plannedStepsFixture(),
    });

    service.viewJob(ticket);

    const viewReq = httpMock.expectOne(
      `${environment.jobsViewUrlBase}/job-cached?include_steps=true`
    );
    expect(viewReq.request.method).toBe('GET');
    // JobsService no longer sets Authorization — the session JWT bearer is
    // attached centrally by authInterceptor (covered in its own spec).
    expect(viewReq.request.headers.has('Authorization')).toBe(false);
    viewReq.flush({
      job_id: 'job-cached',
      ticket_id: ticket,
      job_status: 'RESOLVED',
      steps: [
        {
          step_id: 'parent-1',
          capability: 'resolve_user_access_management_cases',
          mcp_server: 'veeva',
          status: 'SUCCEEDED',
          parent_step_id: null,
          outcome: { input_summary: 'in', output_summary: null, outcome_status: 'success' },
        },
        {
          step_id: 'child-1a',
          capability: 'parse_incident_context',
          mcp_server: 'veeva',
          status: 'SUCCEEDED',
          parent_step_id: 'parent-1',
          outcome: { input_summary: 'parse in', output_summary: 'parse out' },
        },
        {
          step_id: 'child-1b',
          capability: 'verify_access_applied',
          mcp_server: 'veeva',
          status: 'SUCCEEDED',
          parent_step_id: 'parent-1',
          outcome: { input_summary: 'verify in', output_summary: 'verify out' },
        },
        {
          step_id: 'parent-2',
          capability: 'close_ticket',
          mcp_server: 'servicenow',
          status: 'SUCCEEDED',
          parent_step_id: null,
        },
        {
          step_id: 'child-2a',
          capability: 'validate_ticket_state',
          mcp_server: 'servicenow',
          status: 'SUCCEEDED',
          parent_step_id: 'parent-2',
        },
      ],
    });

    const state = latest as unknown as JobState;
    expect(state.phase).toBe('resolved');
    expect(state.status).toBe('RESOLVED');
    expect(state.groups.length).toBe(2);
    expect(state.groups[0].name).toBe('Resolve User Access Management Cases');
    expect(state.groups[0].status).toBe('done');
    expect(state.groups[0].substeps.length).toBe(2);
    expect(
      state.groups[0].substeps.find((s) => s.capability === 'parse_incident_context')?.status
    ).toBe('done');
    expect(state.groups[1].name).toBe('Close Ticket');
    expect(state.groups[1].substeps[0].capability).toBe('validate_ticket_state');
    sub.unsubscribe();
  });

  it('viewJob() falls back to the lookup endpoint when no job_id is cached', () => {
    const service = setup(anon);
    const ticket = 'INC0501178';
    const sub = service.getJobForTicket(ticket).subscribe();

    service.viewJob(ticket);

    const lookupReq = httpMock.expectOne(
      `${environment.jobsLookupUrl}?ticket_id=${encodeURIComponent(ticket)}`
    );
    expect(lookupReq.request.method).toBe('GET');
    lookupReq.flush({
      jobs: [{ job_id: 'job-found', status: 'RESOLVED', resolved_at: '2026-05-22T10:00:00Z' }],
    });

    const viewReq = httpMock.expectOne(
      `${environment.jobsViewUrlBase}/job-found?include_steps=true`
    );
    viewReq.flush({
      job_id: 'job-found',
      ticket_id: ticket,
      job_status: 'RESOLVED',
      steps: [],
    });

    sub.unsubscribe();
  });

  it('viewJob() emits phase=error when lookup returns no job', () => {
    const service = setup(anon);
    const ticket = 'INC0099999';
    let latest: JobState | null = null;
    const sub = service.getJobForTicket(ticket).subscribe((s) => (latest = s));

    service.viewJob(ticket);

    httpMock
      .expectOne(`${environment.jobsLookupUrl}?ticket_id=${encodeURIComponent(ticket)}`)
      .flush({ jobs: [] });

    const state = latest as unknown as JobState;
    expect(state.phase).toBe('error');
    expect(state.errorMessage).toContain(ticket);
    sub.unsubscribe();
  });

  it('attaches Bearer token to resume requests', () => {
    const service = setup(anon);
    const ticket = 'INC0042156';
    const sub = service.getJobForTicket(ticket).subscribe();

    service.resolveTicket(ticket);
    httpMock.expectOne(environment.jobsResolveUrl).flush({
      job_id: 'job-1',
      status: 'accepted',
      planned_steps: plannedStepsFixture(),
    });

    service.approve(ticket);
    const req = httpMock.expectOne(`${environment.jobsOrchStepsBase}/job-1/resume`);
    // Authorization is attached by authInterceptor, not JobsService.
    expect(req.request.headers.has('Authorization')).toBe(false);
    req.flush({
      job_id: 'job-1',
      ticket_id: ticket,
      status: 'RESOLVED',
      current_step: null,
      steps: [],
    });
    sub.unsubscribe();
  });
});
