import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import {
  BATCH_JOURNEY,
  BatchJourney,
  CodeOrangeEvent,
  PipelineStageRun,
  STAGES,
  StageStatusLabel,
} from '@core/models/landscape.model';

/** Minimal, mock "upload batch data" payload — no real backend/parsing yet.
 *  Molecule + lot number are required; modality/fileName are optional and
 *  purely cosmetic (surfaced on the batch strip / CODE Orange ticker). */
export interface UploadBatchInput {
  molecule: string;
  lotNumber: string;
  modality?: string;
  fileName?: string;
}

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

function nowStr(): string {
  const d = new Date();
  return `${d.toISOString().slice(0, 10)} ${d.toTimeString().slice(0, 5)}`;
}

function cloneJourney(journey: BatchJourney): BatchJourney {
  return JSON.parse(JSON.stringify(journey));
}

/**
 * Live, reactive home for the Batch Journey — replaces reading the static
 * `BATCH_JOURNEY` const directly. Backs the sidebar's "CMC Pipeline Stages"
 * stepper, the Memory Graph page's batch strip/stepper, and every
 * `/landscape/stage/:id` detail page with the SAME live state, so an
 * "Upload Batch Data" action on the Memory Graph page is instantly reflected
 * everywhere else in the app.
 *
 * Mock only (per current scope) — `uploadBatch` / `advanceStage` simulate
 * pipeline progression locally; nothing is sent to a backend. Swapping this
 * for a real API later only means changing the bodies of those two methods.
 */
@Injectable({ providedIn: 'root' })
export class BatchJourneyService {
  private readonly journeySubject = new BehaviorSubject<BatchJourney>(cloneJourney(BATCH_JOURNEY));

  /** Observable stream, for components that want to react to changes explicitly. */
  readonly journey$: Observable<BatchJourney> = this.journeySubject.asObservable();

  /** Synchronous snapshot — safe to call from template bindings; Angular's
   *  default change detection re-evaluates these on every app-wide event, so
   *  the sidebar stepper and the current page stay in sync automatically. */
  get journey(): BatchJourney {
    return this.journeySubject.value;
  }

  getStageRun(stageId: string): PipelineStageRun | undefined {
    return this.journey.stageRuns.find((r) => r.stageId === stageId);
  }

  getStageStatusLabel(stageId: string): StageStatusLabel {
    const run = this.getStageRun(stageId);
    if (!run) return 'Upcoming';
    if (run.status === 'complete') return 'Active';
    if (run.status === 'current') return 'In Progress';
    return 'Upcoming';
  }

  /** True while any stage is mid-flight — drives "Advance to Next Stage" enablement. */
  get hasActiveStage(): boolean {
    return this.journey.stageRuns.some((r) => r.status === 'current');
  }

  /** Mock "Upload Batch Data" — resets the journey to a fresh run for the
   *  given batch: stage 1 marked current, every other stage upcoming.
   *  Re-uses each stage's static acting-systems / reasoning-gap copy from the
   *  seed `BATCH_JOURNEY` so the narrative text stays meaningful even though
   *  no real file is parsed. */
  uploadBatch(input: UploadBatchInput): void {
    const seed = BATCH_JOURNEY;
    const stageRuns: PipelineStageRun[] = seed.stageRuns
      .slice()
      .sort((a, b) => a.order - b.order)
      .map((run, i) => ({
        stageId: run.stageId,
        order: run.order,
        status: i === 0 ? 'current' : 'upcoming',
        dateRange: i === 0 ? `${todayStr()} → in progress` : 'Not yet started',
        actingSystems: [...run.actingSystems],
        dataProductsEmitted: [] as string[],
        reasoningGapNote: run.reasoningGapNote,
      }));

    const codeOrangeLog: CodeOrangeEvent[] = [
      {
        timestamp: nowStr(),
        product: `${input.fileName || 'Batch dataset'} ingested — ${input.molecule} / Lot ${input.lotNumber}`,
        source: 'Upload',
        stageId: STAGES[0].id,
      },
    ];

    const newJourney: BatchJourney = {
      batchId: `${input.molecule}-${input.lotNumber}`,
      molecule: input.molecule,
      modality: input.modality || seed.modality,
      lotNumber: input.lotNumber,
      currentStageOrder: 1,
      stageRuns,
      codeOrangeLog,
    };

    this.journeySubject.next(newJourney);
  }

  /** Mock "Advance to Next Stage" — marks the current stage complete and the
   *  next stage current, stamping a date range, so the pipeline can be
   *  demoed end-to-end without a real backend driving stage transitions. */
  advanceStage(): void {
    const j = this.journey;
    const idx = j.stageRuns.findIndex((r) => r.status === 'current');
    if (idx === -1) return;

    const stageRuns = j.stageRuns.map((r) => ({ ...r }));
    const startDate = stageRuns[idx].dateRange.split('→')[0].trim();
    const completedStageName = STAGES.find((s) => s.id === stageRuns[idx].stageId)?.name ?? stageRuns[idx].stageId;

    stageRuns[idx] = {
      ...stageRuns[idx],
      status: 'complete',
      dateRange: `${startDate} → ${todayStr()}`,
      dataProductsEmitted: stageRuns[idx].dataProductsEmitted.length
        ? stageRuns[idx].dataProductsEmitted
        : [`${completedStageName} — completion record`],
    };

    let currentStageOrder = j.currentStageOrder;
    const codeOrangeLog = [...j.codeOrangeLog];

    if (idx + 1 < stageRuns.length) {
      stageRuns[idx + 1] = {
        ...stageRuns[idx + 1],
        status: 'current',
        dateRange: `${todayStr()} → in progress`,
      };
      currentStageOrder = stageRuns[idx + 1].order;
    }

    codeOrangeLog.push({
      timestamp: nowStr(),
      product: `${completedStageName} — stage complete`,
      source: 'Pipeline',
      stageId: stageRuns[idx].stageId,
    });

    this.journeySubject.next({ ...j, currentStageOrder, stageRuns, codeOrangeLog });
  }

  /** Back to the original static demo journey (mAb-114 / SL-2024-118). */
  reset(): void {
    this.journeySubject.next(cloneJourney(BATCH_JOURNEY));
  }
}
