import { TestBed } from '@angular/core/testing';

import { ThemeService } from './theme.service';

describe('ThemeService', () => {
  let service: ThemeService;

  beforeEach(() => {
    document.body.classList.remove('dark');
    TestBed.configureTestingModule({});
    service = TestBed.inject(ThemeService);
  });

  it('starts in light mode', () => {
    expect(service.isDark).toBe(false);
  });

  it('toggles to dark and applies the body class', () => {
    service.toggle();
    expect(service.isDark).toBe(true);
    expect(document.body.classList.contains('dark')).toBe(true);
  });

  it('toggles back to light and removes the body class', () => {
    service.toggle();
    service.toggle();
    expect(service.isDark).toBe(false);
    expect(document.body.classList.contains('dark')).toBe(false);
  });

  it('emits via dark$ on toggle', (done) => {
    const emitted: boolean[] = [];
    const sub = service.dark$.subscribe((v) => emitted.push(v));
    service.toggle();
    queueMicrotask(() => {
      expect(emitted).toEqual([false, true]);
      sub.unsubscribe();
      done();
    });
  });
});
