import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import {
  McpCatalogResponse,
  MyToolsResponse,
  ToolAccessAction,
  UpdateMyToolRequest,
  UpdateMyToolResponse,
} from '@core/models/mcp.model';
import { environment } from '@env/environment';

/** Identity base URL — runtime-overridable via window.__env for Helm. */
function identityBaseUrl(): string {
  const env = (window as unknown as { __env?: { identityBaseUrl?: string } }).__env;
  return env?.identityBaseUrl || environment.identityBaseUrl;
}

/** Orchestrator base URL — runtime-overridable via window.__env for Helm. */
function orchestratorBaseUrl(): string {
  const env = (window as unknown as { __env?: { orchestratorBaseUrl?: string } }).__env;
  return env?.orchestratorBaseUrl || environment.orchestratorBaseUrl;
}

/**
 * Backs the Settings → MCP Tools page. The session JWT is attached by
 * authInterceptor, so no manual auth handling is needed here.
 */
@Injectable({ providedIn: 'root' })
export class McpToolsService {
  constructor(private http: HttpClient) {}

  /**
   * Live, full server+tool catalog from the orchestrator. Pass `health = true`
   * to also run a live per-server reachability probe (sets `status`) — used by
   * the Connectors screen. The MCP Tools page omits it to stay fast.
   */
  getCatalog(health = false): Observable<McpCatalogResponse> {
    const url = `${orchestratorBaseUrl()}/v1/mcp/catalog${health ? '?health=true' : ''}`;
    return this.http.get<McpCatalogResponse>(url);
  }

  /** The caller's per-tool access status from the identity service. */
  getMyTools(): Observable<MyToolsResponse> {
    return this.http.get<MyToolsResponse>(`${identityBaseUrl()}/v1/me/tools`);
  }

  /** Set the caller's own access for one tool (Allow / Need Approval / Deny). */
  updateTool(
    server: string,
    tool: string,
    action: ToolAccessAction
  ): Observable<UpdateMyToolResponse> {
    const body: UpdateMyToolRequest = { server, tool, action };
    return this.http.put<UpdateMyToolResponse>(`${identityBaseUrl()}/v1/me/tools`, body);
  }
}
