import { Injectable } from '@angular/core';

import { TicketColumnKey } from '@core/models/ticket.model';

/** Persisted table view preferences for the Incidents/tickets list. */
export interface TablePrefs {
  rowsPerPage: number;
  activeCols: TicketColumnKey[];
}

const PREFS_KEY = 'ams.incidents.tablePrefs';
const STARTED_KEY = 'ams.incidents.startedTickets';
const APPROVED_KEY = 'ams.incidents.approvedTickets';
const RESOLVED_KEY = 'ams.incidents.resolvedTickets';

/**
 * Small localStorage-backed store for ticket-list UI state that must survive
 * tab switches AND a full page refresh:
 *   - table prefs (rows-per-page, chosen columns)
 *   - which tickets the engineer has already kicked off ("Resolve" clicked) so
 *     the action stays "View Ticket" instead of re-triggering resolve/approve
 *   - which of those have reached a terminal success (stops the "processing"
 *     blink on the View button)
 * All reads/writes are defensively wrapped so a disabled/full localStorage
 * never breaks the page.
 */
@Injectable({ providedIn: 'root' })
export class TicketUiStateService {
  /* ── Table preferences ─────────────────────────────────────────────── */
  getPrefs(): TablePrefs | null {
    try {
      const raw = localStorage.getItem(PREFS_KEY);
      return raw ? (JSON.parse(raw) as TablePrefs) : null;
    } catch {
      return null;
    }
  }

  savePrefs(prefs: TablePrefs): void {
    try {
      localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
    } catch {
      /* ignore quota / disabled storage */
    }
  }

  /* ── Started / resolved ticket sets ────────────────────────────────── */
  markStarted(ticketNumber: string): void {
    this.add(STARTED_KEY, ticketNumber);
  }
  hasStarted(ticketNumber: string): boolean {
    return this.read(STARTED_KEY).has(ticketNumber);
  }

  /** Set when the engineer clicks "Approve Plan & Continue". Until then a
   *  started ticket should resume at the Plan Approval page, not the workflow. */
  markApproved(ticketNumber: string): void {
    this.add(APPROVED_KEY, ticketNumber);
  }
  isApproved(ticketNumber: string): boolean {
    return this.read(APPROVED_KEY).has(ticketNumber);
  }

  markResolved(ticketNumber: string): void {
    this.add(RESOLVED_KEY, ticketNumber);
  }
  isResolvedLocally(ticketNumber: string): boolean {
    return this.read(RESOLVED_KEY).has(ticketNumber);
  }

  /** Forget a ticket entirely (started/approved/resolved) — used when a HITL
   *  gate is rejected so the Incidents action reverts to "Resolve Ticket". */
  clearTicket(ticketNumber: string): void {
    for (const key of [STARTED_KEY, APPROVED_KEY, RESOLVED_KEY]) {
      const set = this.read(key);
      if (set.delete(ticketNumber)) {
        try {
          localStorage.setItem(key, JSON.stringify([...set]));
        } catch {
          /* ignore */
        }
      }
    }
  }

  /* ── internals ─────────────────────────────────────────────────────── */
  private read(key: string): Set<string> {
    try {
      const raw = localStorage.getItem(key);
      return new Set<string>(raw ? (JSON.parse(raw) as string[]) : []);
    } catch {
      return new Set<string>();
    }
  }

  private add(key: string, value: string): void {
    if (!value) return;
    const set = this.read(key);
    set.add(value);
    try {
      localStorage.setItem(key, JSON.stringify([...set]));
    } catch {
      /* ignore */
    }
  }
}
