import { TestBed } from '@angular/core/testing';

import { AuthService, AuthUser } from '@core/services/auth.service';
import { LogEntry, LoggingService } from './logging.service';

const anon: AuthUser = {
  authenticated: false,
  sub: '',
  userId: '',
  email: '',
  name: '',
  role: '',
  sessionId: '',
  groups: [],
};

function authStub(user: AuthUser): Partial<AuthService> {
  return {
    get user() {
      return user;
    },
  };
}

describe('LoggingService', () => {
  function setup(user: AuthUser = anon): LoggingService {
    TestBed.configureTestingModule({
      providers: [{ provide: AuthService, useValue: authStub(user) }],
    });
    return TestBed.inject(LoggingService);
  }

  it('emits a JSON entry with ts/level/logger/msg', () => {
    const log = setup();
    const spy = spyOn(console, 'info');
    log.info('http', 'request_started', { method: 'GET', url: '/foo' });
    expect(spy).toHaveBeenCalled();
    const entry = spy.calls.mostRecent().args[1] as LogEntry;
    expect(entry.level).toBe('INFO');
    expect(entry.logger).toBe('http');
    expect(entry.msg).toBe('request_started');
    expect(entry['method']).toBe('GET');
    expect(entry['url']).toBe('/foo');
    expect(new Date(entry.ts).toString()).not.toBe('Invalid Date');
  });

  it('attaches user_sub + user_email when authenticated', () => {
    const log = setup({
      authenticated: true,
      sub: 'sub-1',
      userId: 'sub-1',
      email: 'jane.doe@cognizant.com',
      name: 'Jane Doe',
      role: 'L2',
      sessionId: 'sess-1',
      groups: ['L2'],
    });
    const spy = spyOn(console, 'warn');
    log.warn('test', 'something');
    const entry = spy.calls.mostRecent().args[1] as LogEntry;
    expect(entry.user_sub).toBe('sub-1');
    expect(entry.user_email).toBe('jane.doe@cognizant.com');
  });

  it('omits user fields when anonymous', () => {
    const log = setup(anon);
    const spy = spyOn(console, 'debug');
    log.debug('test', 'no-user');
    const entry = spy.calls.mostRecent().args[1] as LogEntry;
    expect(entry.user_sub).toBeUndefined();
    expect(entry.user_email).toBeUndefined();
  });

  it('routes each level to the matching console method', () => {
    const log = setup();
    const debugSpy = spyOn(console, 'debug');
    const infoSpy = spyOn(console, 'info');
    const warnSpy = spyOn(console, 'warn');
    const errorSpy = spyOn(console, 'error');
    log.debug('t', 'd');
    log.info('t', 'i');
    log.warn('t', 'w');
    log.error('t', 'e');
    expect(debugSpy).toHaveBeenCalled();
    expect(infoSpy).toHaveBeenCalled();
    expect(warnSpy).toHaveBeenCalled();
    expect(errorSpy).toHaveBeenCalled();
  });

  it('newRequestId returns a UUID-shape string', () => {
    const log = setup();
    const id = log.newRequestId();
    expect(typeof id).toBe('string');
    expect(id.length).toBeGreaterThanOrEqual(10);
  });
});
