import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { SetRoleResponse, SupportEngineersResponse } from '@core/models/team-roles.model';
import { environment } from '@env/environment';

/** Identity base URL — runtime-overridable via window.__env for Helm. */
function identityBaseUrl(): string {
  const env = (window as unknown as { __env?: { identityBaseUrl?: string } }).__env;
  return env?.identityBaseUrl || environment.identityBaseUrl;
}

/**
 * Backs the Settings → Team Roles page (supervisor only). The session JWT is
 * attached by authInterceptor, so no manual auth handling is needed here.
 */
@Injectable({ providedIn: 'root' })
export class TeamRolesService {
  constructor(private http: HttpClient) {}

  /** Support-tier users (L1/L1.5/L2) — the elevation candidates. */
  getSupportEngineers(): Observable<SupportEngineersResponse> {
    return this.http.get<SupportEngineersResponse>(
      `${identityBaseUrl()}/v1/users/support-engineers`
    );
  }

  /** Set a user's support tier. The backend enforces tier scoping. */
  setRole(email: string, role: string): Observable<SetRoleResponse> {
    const url = `${identityBaseUrl()}/v1/users/${encodeURIComponent(email)}/role`;
    return this.http.put<SetRoleResponse>(url, { role });
  }
}
