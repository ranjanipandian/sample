import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { FetchTicketResponse, HealthResponse } from '@core/models/api.model';
import { AuthService, AuthUser } from '@core/services/auth.service';
import { environment } from '@env/environment';
import { SentinelApiService } from './sentinel-api.service';

const anon: AuthUser = {
  authenticated: false,
  sub: '',
  userId: '',
  email: '',
  name: '',
  role: '',
  sessionId: '',
  groups: [],
};

function authStub(user: AuthUser): Partial<AuthService> {
  return {
    get user() {
      return user;
    },
  };
}

describe('SentinelApiService', () => {
  let httpMock: HttpTestingController;

  function setup(user: AuthUser = anon): SentinelApiService {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [{ provide: AuthService, useValue: authStub(user) }],
    });
    httpMock = TestBed.inject(HttpTestingController);
    return TestBed.inject(SentinelApiService);
  }

  afterEach(() => httpMock.verify());

  it('POSTs the env ticketQuery body (page 1, max page size) when no user is authenticated', () => {
    const service = setup(anon);
    const fakeRes: FetchTicketResponse = { tickets: [] };

    service.fetchTickets().subscribe();

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    expect(req.request.method).toBe('POST');
    const body = req.request.body as Record<string, unknown>;
    // Env defaults pass through unchanged (created_by stays empty)...
    expect(body['created_by']).toBe(environment.ticketQuery.created_by);
    // ...but pagination is driven by fetchTickets: first page at the backend max.
    expect(body['page']).toBe(1);
    expect(body['page_size']).toBe(100);
    req.flush(fakeRes);
  });

  it('substitutes the authenticated email into every userIdentityFields key', () => {
    const service = setup({
      authenticated: true,
      sub: 'sub-1',
      userId: 'sub-1',
      email: 'jane.doe@cognizant.com',
      name: 'Jane Doe',
      role: 'L2',
      sessionId: 'sess-1',
      groups: ['L2'],
    });

    service.fetchTickets().subscribe();

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    for (const key of environment.userIdentityFields) {
      expect((req.request.body as Record<string, unknown>)[key]).toBe('jane.doe@cognizant.com');
    }
    // Other fields unchanged.
    expect((req.request.body as Record<string, unknown>)['page']).toBe(
      environment.ticketQuery.page
    );
    req.flush({ tickets: [] });
  });

  const supervisor: AuthUser = {
    authenticated: true,
    sub: 'sub-sup',
    userId: 'sub-sup',
    email: 'sue.boss@cognizant.com',
    name: 'Sue Boss',
    role: 'SUPERVISOR',
    sessionId: 'sess-sup',
    groups: ['SUPERVISOR'],
  };

  it('scopes SUPERVISOR to their team via a ServiceNow IN filter on the assignees', () => {
    const service = setup(supervisor);

    service.fetchTickets({ ticketType: 'Incident', assignees: ['a@x.com', 'b@x.com'] }).subscribe();

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    for (const key of environment.userIdentityFields) {
      expect((req.request.body as Record<string, unknown>)[key]).toBe('INa@x.com,b@x.com');
    }
    expect((req.request.body as Record<string, unknown>)['ticket_type']).toBe('incident');
    // Team queue spans many engineers — request the backend max page, not the default 10.
    expect((req.request.body as Record<string, unknown>)['page_size']).toBe(100);
    req.flush({ tickets: [] });
  });

  it('falls back to the SUPERVISOR own email when no team assignees are provided', () => {
    const service = setup(supervisor);

    service.fetchTickets({ ticketType: 'Incident' }).subscribe();

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    for (const key of environment.userIdentityFields) {
      expect((req.request.body as Record<string, unknown>)[key]).toBe('sue.boss@cognizant.com');
    }
    req.flush({ tickets: [] });
  });

  it('does NOT mutate environment.ticketQuery in place', () => {
    const service = setup({
      authenticated: true,
      sub: 'sub-1',
      userId: 'sub-1',
      email: 'someone@cognizant.com',
      name: '',
      role: 'L2',
      sessionId: 'sess-1',
      groups: ['L2'],
    });
    const before = JSON.stringify(environment.ticketQuery);
    service.fetchTickets().subscribe();
    httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath).flush({ tickets: [] });
    expect(JSON.stringify(environment.ticketQuery)).toBe(before);
  });

  it('sends ticket_type=incident when caller scopes to "Incident"', () => {
    const service = setup(anon);

    service.fetchTickets({ ticketType: 'Incident' }).subscribe();

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    expect((req.request.body as Record<string, unknown>)['ticket_type']).toBe('incident');
    req.flush({ tickets: [] });
  });

  it('maps every UI label to the right ServiceNow table', () => {
    const service = setup(anon);
    const cases: Array<[string, string]> = [
      ['Incident', 'incident'],
      ['Service Request', 'sc_request'],
      ['Problem', 'problem'],
      ['Change', 'change_request'],
    ];
    for (const [label, table] of cases) {
      service.fetchTickets({ ticketType: label }).subscribe();
      const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
      expect((req.request.body as Record<string, unknown>)['ticket_type'])
        .withContext(`label=${label}`)
        .toBe(table);
      req.flush({ tickets: [] });
    }
  });

  it('does NOT set ticket_type when caller passes nothing', () => {
    const service = setup(anon);
    service.fetchTickets().subscribe();
    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    expect((req.request.body as Record<string, unknown>)['ticket_type']).toBeUndefined();
    req.flush({ tickets: [] });
  });

  it('GETs /health on apiBaseUrl', () => {
    const service = setup(anon);
    const fakeRes: HealthResponse = { status: 'ok' };

    service.health().subscribe((res) => {
      expect(res).toEqual(fakeRes);
    });

    const req = httpMock.expectOne(environment.apiBaseUrl + '/health');
    expect(req.request.method).toBe('GET');
    req.flush(fakeRes);
  });

  it('unwraps the Go MCP {status,data} envelope to the bare FetchTicketResponse', () => {
    const service = setup(anon);
    let emitted: FetchTicketResponse | undefined;

    service.fetchTickets().subscribe((res) => (emitted = res));

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    req.flush({
      status: 'ok',
      data: { tickets: [{ number: 'INC-1' }, { number: 'INC-2' }] },
      meta: { tool: 'fetch_ticket', schema_version: '1.0' },
    });

    expect(emitted?.tickets.length).toBe(2);
    expect(emitted?.tickets[0].number).toBe('INC-1');
  });

  it('unwraps the orchestrator {outcome_status, output_result} envelope to the tickets', () => {
    const service = setup(anon);
    let emitted: FetchTicketResponse | undefined;

    service.fetchTickets().subscribe((res) => (emitted = res));

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    req.flush({
      outcome_status: 'success',
      action_taken: 'Ticket fetched successfully',
      output_result: { tickets: [{ number: 'INC0501617' }, { number: 'INC0501484' }] },
      retry_eligible: false,
      execution_steps: [],
    });

    expect(emitted?.tickets.length).toBe(2);
    expect(emitted?.tickets[0].number).toBe('INC0501617');
  });

  it('throws when the orchestrator outcome_status is not "success"', () => {
    const service = setup(anon);
    let errMsg = '';

    service.fetchTickets().subscribe({
      next: () => fail('expected an error'),
      error: (e: Error) => (errMsg = e.message),
    });

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    req.flush({
      outcome_status: 'failed',
      action_taken: 'Tool fetch_ticket failed',
      output_result: { error: 'integration user cannot read table' },
    });

    expect(errMsg).toContain('cannot read table');
  });

  it('passes through a legacy un-enveloped response unchanged', () => {
    const service = setup(anon);
    let emitted: FetchTicketResponse | undefined;

    service.fetchTickets().subscribe((res) => (emitted = res));

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    req.flush({ tickets: [{ number: 'INC-9' }] });

    expect(emitted?.tickets.length).toBe(1);
    expect(emitted?.tickets[0].number).toBe('INC-9');
  });

  it('throws when the envelope status is "error" so the caller can surface it', () => {
    const service = setup(anon);
    let errMsg = '';

    service.fetchTickets().subscribe({
      next: () => fail('expected an error'),
      error: (e: Error) => (errMsg = e.message),
    });

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    req.flush({
      status: 'error',
      errors: [{ code: 'FORBIDDEN', message: 'integration user cannot read table' }],
      meta: { tool: 'fetch_ticket' },
    });

    expect(errMsg).toContain('cannot read table');
  });

  it('walks every page for a single-table query until a short page ends it', () => {
    const service = setup(anon);
    let emitted: FetchTicketResponse | undefined;

    service.fetchTickets({ ticketType: 'Incident' }).subscribe((res) => (emitted = res));

    // Page 1: a full page (100) → keep going.
    const page1 = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    expect((page1.request.body as Record<string, unknown>)['page']).toBe(1);
    page1.flush({ tickets: Array.from({ length: 100 }, (_, i) => ({ number: `INC-${i}` })) });

    // Page 2: short page (1 row) → stop after this.
    const page2 = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    expect((page2.request.body as Record<string, unknown>)['page']).toBe(2);
    page2.flush({ tickets: [{ number: 'INC-100' }] });

    expect(emitted?.tickets.length).toBe(101);
  });

  it('does NOT paginate past page 1 for an all-tables query (offset unsupported)', () => {
    const service = setup(anon);
    let emitted: FetchTicketResponse | undefined;

    // No ticketType → ALL_TABLES; backend ignores offset, so we issue one page
    // even when it comes back full.
    service.fetchTickets().subscribe((res) => (emitted = res));

    const req = httpMock.expectOne(environment.apiBaseUrl + environment.fetchTicketPath);
    req.flush({ tickets: Array.from({ length: 100 }, (_, i) => ({ number: `INC-${i}` })) });

    httpMock.verify(); // asserts no second request was made
    expect(emitted?.tickets.length).toBe(100);
  });
});
