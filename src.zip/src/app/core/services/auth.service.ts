import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, firstValueFrom, of } from 'rxjs';
import { catchError, map, shareReplay } from 'rxjs/operators';

import { environment } from '../../../environments/environment';

/**
 * Identity for the current user, established by the sentinel_identity_service
 * OIDC login. `authenticated` is false (ANONYMOUS) before login or after the
 * session is cleared.
 */
export interface AuthUser {
  authenticated: boolean;
  sub: string; // user UUID (JWT 'sub')
  userId: string; // alias of sub
  email: string;
  name: string;
  role: string; // SUPERVISOR | L2 | L1.5 | L1
  sessionId: string; // JWT 'session_id'
  groups: string[]; // kept for back-compat — derived from [role]
}

/** Shape of GET /v1/auth/oidc/callback (OidcCallbackResponse). */
interface CallbackResponse {
  session_token: string;
  refresh_token: string;
  user_id: string;
  email: string;
  role: string;
  expires_at: string;
}

/** Shape of POST /v1/auth/token/refresh (TokenRefreshResponse). */
interface RefreshResponse {
  session_token: string;
  refresh_token: string;
  expires_at: string;
}

const ANONYMOUS: AuthUser = {
  authenticated: false,
  sub: '',
  userId: '',
  email: '',
  name: '',
  role: '',
  sessionId: '',
  groups: [],
};

const REFRESH_KEY = 'ams.refresh';
const POST_LOGIN_REDIRECT_KEY = 'ams.postLoginRedirect';

/** Identity service base URL — runtime-overridable via window.__env for Helm. */
function identityBaseUrl(): string {
  const env = (window as unknown as { __env?: { identityBaseUrl?: string } }).__env;
  return env?.identityBaseUrl || environment.identityBaseUrl;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly userSubject = new BehaviorSubject<AuthUser>(ANONYMOUS);
  readonly user$: Observable<AuthUser> = this.userSubject.asObservable();

  private sessionToken: string | null = null;
  private refreshTimer: ReturnType<typeof setTimeout> | null = null;
  /** De-dupes concurrent refreshes (e.g. several 401s arriving together). */
  private refreshInFlight$: Observable<AuthUser> | null = null;

  constructor(private http: HttpClient) {}

  get user(): AuthUser {
    return this.userSubject.value;
  }

  getSessionToken(): string | null {
    return this.sessionToken;
  }

  isAuthenticated(): boolean {
    return !!this.sessionToken && !this.isExpired(this.sessionToken);
  }

  /**
   * Begin OIDC login. Stashes the intended post-login URL, then does a
   * full-page navigation to the identity service authorize endpoint, which
   * redirects through the enterprise IdP and back to our /auth/callback route.
   */
  login(redirectTo?: string): void {
    try {
      sessionStorage.setItem(POST_LOGIN_REDIRECT_KEY, redirectTo || '/landscape');

    } catch {
      /* sessionStorage unavailable — proceed without remembering the target */
    }
    window.location.assign(`${identityBaseUrl()}/v1/auth/oidc/authorize`);
  }

  /**
   * Frontend-only demo/dev session — mints a locally-signed-looking JWT and
   * establishes it as the active session without any backend call. Mirrors
   * the pattern used by other Cognizant demo apps (e.g. Video Language
   * Studio) for environments where the real sentinel_identity_service OIDC
   * backend is not reachable (local dev, sandbox demos, virtual-lab walkthroughs).
   * Never used in production — the real "Login as SSO" flow above still goes
   * through full OIDC when a backend is present.
   */
  mockLogin(role: string = 'Admin', name: string = 'Demo Admin'): AuthUser {
    const email = `${name.toLowerCase().replace(/\s+/g, '.')}@cognizant.com`;
    const header = this.base64UrlEncode(JSON.stringify({ alg: 'none', typ: 'JWT' }));
    const nowSec = Math.floor(Date.now() / 1000);
    const payload = this.base64UrlEncode(
      JSON.stringify({
        sub: `mock-${role.toLowerCase()}`,
        email,
        name,
        role,
        session_id: `mock-session-${nowSec}`,
        iat: nowSec,
        exp: nowSec + 86400, // 24h
      })
    );
    const mockToken = `${header}.${payload}.mock-signature`;
    const mockRefresh = `mock-refresh-${nowSec}`;
    return this.setSession(mockToken, mockRefresh, new Date((nowSec + 86400) * 1000).toISOString());
  }

  private base64UrlEncode(input: string): string {
    return btoa(input).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }


  /**
   * Complete the OIDC handshake. The IdP redirected the browser back to
   * /auth/callback with code+state; we exchange them via a same-origin GET to
   * the proxied identity callback (the identity service holds the PKCE
   * verifier and returns the tokens as JSON).
   */
  async handleCallback(code: string, state: string): Promise<AuthUser> {
    const url =
      `${identityBaseUrl()}/v1/auth/oidc/callback` +
      `?code=${encodeURIComponent(code)}&state=${encodeURIComponent(state)}`;
    const res = await firstValueFrom(this.http.get<CallbackResponse>(url));
    return this.setSession(res.session_token, res.refresh_token, res.expires_at);
  }

  /** Where to navigate after a successful login (then clears it). */
  consumePostLoginRedirect(): string {
    let target = '/landscape';

    try {
      target = sessionStorage.getItem(POST_LOGIN_REDIRECT_KEY) || target;
      sessionStorage.removeItem(POST_LOGIN_REDIRECT_KEY);
    } catch {
      /* ignore */
    }
    return target;
  }

  /**
   * Bootstrap hook (APP_INITIALIZER). If a refresh token survived a reload,
   * silently restore the in-memory session; otherwise resolve ANONYMOUS.
   * Never throws — keeps early bootstrap safe.
   */
  async load(): Promise<AuthUser> {
    const stored = this.readRefreshToken();
    if (!stored) {
      this.userSubject.next(ANONYMOUS);
      return ANONYMOUS;
    }
    return firstValueFrom(this.refresh().pipe(catchError(() => of(ANONYMOUS))));
  }

  /**
   * Refresh the session via POST /v1/auth/token/refresh. Returns a shared
   * observable so concurrent callers (interceptor 401 retries, bootstrap)
   * await a single in-flight request.
   */
  refresh(): Observable<AuthUser> {
    if (this.refreshInFlight$) return this.refreshInFlight$;

    const refreshToken = this.readRefreshToken();
    if (!refreshToken) {
      this.clearSession();
      return of(ANONYMOUS);
    }

    this.refreshInFlight$ = this.http
      .post<RefreshResponse>(`${identityBaseUrl()}/v1/auth/token/refresh`, {
        refresh_token: refreshToken,
      })
      .pipe(
        map((res) => this.setSession(res.session_token, res.refresh_token, res.expires_at)),
        catchError(() => {
          this.clearSession();
          return of(ANONYMOUS);
        }),
        shareReplay(1)
      );

    // Clear the in-flight marker once it settles so the next refresh starts fresh.
    this.refreshInFlight$.subscribe({
      next: () => (this.refreshInFlight$ = null),
      error: () => (this.refreshInFlight$ = null),
    });
    return this.refreshInFlight$;
  }

  /** Revoke the session server-side (best-effort), clear local state, go to login. */
  logout(): void {
    this.http
      .post(`${identityBaseUrl()}/v1/auth/logout`, {})
      .pipe(catchError(() => of(null)))
      .subscribe(() => {
        this.clearSession();
        window.location.assign('/login');
      });
  }

  // ── internals ────────────────────────────────────────────────────────────

  private setSession(sessionToken: string, refreshToken: string, expiresAt?: string): AuthUser {
    this.sessionToken = sessionToken;
    this.writeRefreshToken(refreshToken);

    const claims = this.decodeJwtPayload(sessionToken);
    const role = String(claims['role'] ?? '');
    const user: AuthUser = {
      authenticated: true,
      sub: String(claims['sub'] ?? ''),
      userId: String(claims['sub'] ?? ''),
      email: String(claims['email'] ?? ''),
      name: String(claims['name'] ?? claims['email'] ?? ''),
      role,
      sessionId: String(claims['session_id'] ?? ''),
      groups: role ? [role] : [],
    };
    this.userSubject.next(user);
    this.scheduleRefresh(claims['exp'], expiresAt);
    return user;
  }

  private clearSession(): void {
    this.sessionToken = null;
    if (this.refreshTimer) {
      clearTimeout(this.refreshTimer);
      this.refreshTimer = null;
    }
    try {
      sessionStorage.removeItem(REFRESH_KEY);
    } catch {
      /* ignore */
    }
    this.userSubject.next(ANONYMOUS);
  }

  /** Schedule a silent refresh ~60s before the session JWT expires. */
  private scheduleRefresh(expClaim: unknown, expiresAt?: string): void {
    if (this.refreshTimer) clearTimeout(this.refreshTimer);
    const expEpochMs = this.resolveExpiryMs(expClaim, expiresAt);
    if (!expEpochMs) return;
    const delay = expEpochMs - Date.now() - 60_000;
    if (delay <= 0) {
      // Already within the refresh window — refresh on next tick.
      this.refreshTimer = setTimeout(() => this.refresh().subscribe(), 0);
      return;
    }
    this.refreshTimer = setTimeout(() => this.refresh().subscribe(), delay);
  }

  private resolveExpiryMs(expClaim: unknown, expiresAt?: string): number | null {
    if (typeof expClaim === 'number' && expClaim > 0) return expClaim * 1000;
    if (expiresAt) {
      const ms = Date.parse(expiresAt);
      if (!Number.isNaN(ms)) return ms;
    }
    return null;
  }

  private isExpired(token: string): boolean {
    const exp = this.decodeJwtPayload(token)['exp'];
    if (typeof exp !== 'number') return false; // can't tell → treat as valid
    return Date.now() >= exp * 1000;
  }

  private readRefreshToken(): string | null {
    try {
      return sessionStorage.getItem(REFRESH_KEY);
    } catch {
      return null;
    }
  }

  private writeRefreshToken(token: string): void {
    // sessionStorage (not localStorage): cleared on tab close, never sent to a
    // server. Residual XSS risk is documented; an HttpOnly cookie is the future
    // hardening once the identity service supports it.
    try {
      sessionStorage.setItem(REFRESH_KEY, token);
    } catch {
      /* ignore */
    }
  }

  /**
   * Decode the payload section of a JWT without verifying the signature. The
   * token was just issued by the identity service over TLS; the orchestrator
   * and MCP servers verify the RS256 signature via JWKS server-side. The
   * browser only reads non-sensitive display claims here.
   */
  private decodeJwtPayload(jwt: string): Record<string, unknown> {
    const parts = jwt.split('.');
    if (parts.length < 2) return {};
    const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const pad = b64.length % 4;
    const padded = pad ? b64 + '='.repeat(4 - pad) : b64;
    try {
      return JSON.parse(atob(padded));
    } catch {
      return {};
    }
  }
}
