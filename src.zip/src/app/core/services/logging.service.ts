import { Injectable } from '@angular/core';

import { AuthService } from '@core/services/auth.service';

/** Log level — matches the org-wide convention (DEBUG/INFO/WARN/ERROR). */
export type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';

/**
 * One log entry matches the JSON shape the Python services emit:
 *   { ts, level, logger, msg, request_id, user_sub, ...extra }
 * so Grafana can label-filter the same fields across SPA and backends.
 */
export interface LogEntry {
  ts: string;
  level: LogLevel;
  logger: string;
  msg: string;
  request_id?: string;
  user_sub?: string;
  user_email?: string;
  [key: string]: unknown;
}

/**
 * Browser-side structured logger. Logs to the browser console with the same
 * field schema as the Python services use server-side. The HTTP interceptor
 * (logging.interceptor.ts) generates a per-request UUID and threads it via
 * the X-Request-ID header; this service stamps the same id on every log line
 * the SPA emits, so a developer can grep CloudWatch + the browser console
 * for the same id and see the full chain.
 *
 * For now, output is console-only. A future enhancement could POST log
 * lines to nginx for relay to CloudWatch — see README "E2E logging".
 */
@Injectable({ providedIn: 'root' })
export class LoggingService {
  constructor(private auth: AuthService) {}

  debug(logger: string, msg: string, extra?: Record<string, unknown>): void {
    this.emit('DEBUG', logger, msg, extra);
  }

  info(logger: string, msg: string, extra?: Record<string, unknown>): void {
    this.emit('INFO', logger, msg, extra);
  }

  warn(logger: string, msg: string, extra?: Record<string, unknown>): void {
    this.emit('WARN', logger, msg, extra);
  }

  error(logger: string, msg: string, extra?: Record<string, unknown>): void {
    this.emit('ERROR', logger, msg, extra);
  }

  /**
   * Generate a correlation id (UUIDv4) that the HTTP interceptor sends as
   * `X-Request-ID` on outbound requests. nginx forwards this to backend
   * services, which thread their own logs against the same id.
   */
  newRequestId(): string {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
    // Fallback for very old environments.
    return 'req-' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  }

  private emit(
    level: LogLevel,
    logger: string,
    msg: string,
    extra?: Record<string, unknown>
  ): void {
    const u = this.auth.user;
    const entry: LogEntry = {
      ts: new Date().toISOString(),
      level,
      logger,
      msg,
      ...(u.authenticated ? { user_sub: u.sub, user_email: u.email } : {}),
      ...(extra ?? {}),
    };
    const method = LEVEL_TO_CONSOLE_METHOD[level];
    // Print as a single JSON line — easy to copy/paste into log queries.
    // (Most browsers' devtools will still let you expand the inline object.)
    (console[method] as (msg: string, obj: object) => void)(`[${level}] ${logger}: ${msg}`, entry);
  }
}

const LEVEL_TO_CONSOLE_METHOD: Record<LogLevel, 'debug' | 'info' | 'warn' | 'error'> = {
  DEBUG: 'debug',
  INFO: 'info',
  WARN: 'warn',
  ERROR: 'error',
};
