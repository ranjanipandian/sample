import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import {
  McpServerListResponse,
  MyCredentialsResponse,
  UpdateMyCredentialRequest,
  UpdateMyCredentialResponse,
} from '@core/models/credentials.model';
import { environment } from '@env/environment';

/** Identity base URL — runtime-overridable via window.__env for Helm. */
function identityBaseUrl(): string {
  const env = (window as unknown as { __env?: { identityBaseUrl?: string } }).__env;
  return env?.identityBaseUrl || environment.identityBaseUrl;
}

/**
 * Backs the Settings → Credentials page. The session JWT is attached by
 * authInterceptor, so no manual auth handling is needed here.
 */
@Injectable({ providedIn: 'root' })
export class CredentialsService {
  constructor(private http: HttpClient) {}

  /** Registered MCP servers + their per-user credential auth type. */
  listServers(): Observable<McpServerListResponse> {
    return this.http.get<McpServerListResponse>(`${identityBaseUrl()}/v1/mcp-servers`);
  }

  /** Metadata for the caller's own stored credentials (never secrets). */
  getMyCredentials(): Observable<MyCredentialsResponse> {
    return this.http.get<MyCredentialsResponse>(`${identityBaseUrl()}/v1/me/credentials`);
  }

  /**
   * Set/rotate a credential for one server (applied immediately). By default the
   * caller's own credential; supervisors may pass `applyToAll` to provision it for
   * every user (the identity service enforces the SUPERVISOR role).
   */
  updateCredential(
    server: string,
    plaintext: Record<string, string>,
    applyToAll = false
  ): Observable<UpdateMyCredentialResponse> {
    const body: UpdateMyCredentialRequest = { server, plaintext, apply_to_all: applyToAll };
    return this.http.put<UpdateMyCredentialResponse>(
      `${identityBaseUrl()}/v1/me/credentials`,
      body
    );
  }
}
