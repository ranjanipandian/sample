import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly darkSubject = new BehaviorSubject<boolean>(false);
  readonly dark$ = this.darkSubject.asObservable();

  toggle(): void {
    const next = !this.darkSubject.value;
    this.darkSubject.next(next);
    document.body.classList.toggle('dark', next);
  }

  get isDark(): boolean {
    return this.darkSubject.value;
  }
}
