import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EMPTY, Observable, expand, map, reduce } from 'rxjs';

import {
  FetchTicketRequest,
  FetchTicketResponse,
  HealthResponse,
  McpEnvelope,
  OrchEnvelope,
} from '@core/models/api.model';
import { AuthService } from '@core/services/auth.service';
import { environment } from '@env/environment';

/**
 * UI ticket-type label → ServiceNow table name used by the MCP backend's
 * `input.ticket_type` field. When unset, the backend iterates ALL_TABLES
 * — which 403s as soon as it hits a table the integration user can't read.
 * Scoping per-route avoids that.
 */
const SN_TABLE_BY_TYPE: Record<string, string> = {
  Incident: 'incident',
  'Service Request': 'sc_request',
  Problem: 'problem',
  Change: 'change_request',
};

/**
 * Per-request page size. The Go MCP caps page_size at 100 (internal/tools/
 * inputs.go), so 100 is the largest page we can pull and the fewest round-trips
 * per ticket. fetchTickets() walks pages of this size until the queue is
 * exhausted (a short page signals the end).
 */
const PAGE_SIZE = 100;

/**
 * Hard ceiling on pages walked per refresh — a safety valve so a mis-scoped
 * query (or a future server-side change) can't spin forever. 100 pages × 100 =
 * 10 000 tickets, well above any single user's or team's real queue.
 */
const MAX_PAGES = 100;

export interface FetchTicketsOpts {
  /** UI label from the route's `data.ticketType` (e.g. "Incident"). */
  ticketType?: string | null;
  /**
   * Assignee emails to scope the query to (SUPERVISOR only) — the supervisor's
   * linked team, resolved upstream from the scheduler roster. When set, the
   * query matches tickets assigned to ANY of them (ServiceNow IN operator).
   */
  assignees?: string[];
}

@Injectable({ providedIn: 'root' })
export class SentinelApiService {
  private readonly url = environment.apiBaseUrl + environment.fetchTicketPath;
  private readonly healthUrl = environment.apiBaseUrl + '/health';

  constructor(
    private http: HttpClient,
    private auth: AuthService
  ) {}

  /**
   * Fetch ALL tickets matching the query, walking the backend's pagination so
   * the incident grid shows the complete queue (not just the first page). We
   * request the max page size and keep pulling pages until one comes back
   * shorter than a full page — the signal that the queue is exhausted.
   *
   * Offset pagination only works when the query is scoped to a single
   * ServiceNow table (`ticket_type` set); the Go MCP treats page>1 as a no-op
   * for the ALL_TABLES fan-out (internal/servicenow/adapter.go). So we only
   * walk pages when a ticketType is given; otherwise a single max-size page is
   * issued. Either way the backend returns rows newest-first
   * (ORDERBYDESC sys_created_on), and TicketService sorts again defensively.
   */
  fetchTickets(opts?: FetchTicketsOpts): Observable<FetchTicketResponse> {
    const canPaginate = !!(opts?.ticketType && SN_TABLE_BY_TYPE[opts.ticketType]);

    return this.fetchPage(opts, 1).pipe(
      map((res) => ({ res, page: 1 })),
      expand(({ res, page }) => {
        const full = (res.tickets?.length ?? 0) >= PAGE_SIZE;
        const more = canPaginate && full && page < MAX_PAGES;
        return more
          ? this.fetchPage(opts, page + 1).pipe(map((next) => ({ res: next, page: page + 1 })))
          : EMPTY;
      }),
      reduce<{ res: FetchTicketResponse; page: number }, FetchTicketResponse>(
        (acc, { res }) => {
          acc.tickets.push(...(res.tickets ?? []));
          return acc;
        },
        { tickets: [] }
      )
    );
  }

  /** Fetch one page of tickets and unwrap it to the bare FetchTicketResponse. */
  private fetchPage(
    opts: FetchTicketsOpts | undefined,
    page: number
  ): Observable<FetchTicketResponse> {
    const body = this.buildTicketQuery(opts);
    body.page = page;
    body.page_size = PAGE_SIZE;
    return this.http
      .post<
        FetchTicketResponse | McpEnvelope<FetchTicketResponse> | OrchEnvelope<FetchTicketResponse>
      >(this.url, body)
      .pipe(map((res) => this.unwrap(res)));
  }

  /**
   * Unwrap a fetch_ticket response to the bare FetchTicketResponse, tolerating
   * the three shapes seen across the Python→Go cutover:
   *   1. Orchestrator envelope { outcome_status, output_result } — what the Go
   *      server's POST /tools/{name} actually returns; the tickets live under
   *      output_result. A non-'success' outcome is thrown.
   *   2. Legacy MCP envelope { status, data } — a status==='error' is thrown.
   *   3. Bare payload { tickets } from the old Python server — passes through.
   * Throwing (rather than returning empty) lets the caller's catchError surface
   * the failure instead of silently rendering an empty grid.
   */
  private unwrap(
    res: FetchTicketResponse | McpEnvelope<FetchTicketResponse> | OrchEnvelope<FetchTicketResponse>
  ): FetchTicketResponse {
    if (res && typeof res === 'object' && 'outcome_status' in res) {
      const env = res as OrchEnvelope<FetchTicketResponse>;
      if (env.outcome_status !== 'success') {
        throw new Error(env.output_result?.error || env.action_taken || 'ServiceNow MCP error');
      }
      return env.output_result ?? { tickets: [] };
    }
    if (res && typeof res === 'object' && 'status' in res) {
      const env = res as McpEnvelope<FetchTicketResponse>;
      if (env.status === 'error') {
        const msg = env.errors?.map((e) => e.message).join('; ') || 'ServiceNow MCP error';
        throw new Error(msg);
      }
      return env.data ?? { tickets: [] };
    }
    return res as FetchTicketResponse;
  }

  health(): Observable<HealthResponse> {
    return this.http.get<HealthResponse>(this.healthUrl);
  }

  /**
   * Build the request body. Layered overrides on top of env defaults:
   *   1. `userIdentityFields` keys get the authenticated engineer's email so
   *      each engineer sees only their own tickets. SUPERVISORS instead scope
   *      to their linked team (`opts.assignees`, from the scheduler roster):
   *      the same keys get a ServiceNow `IN` filter matching any team assignee.
   *      With no team resolved, a supervisor falls back to their own email
   *      (rather than the whole table) — though TicketService skips the fetch
   *      entirely in that case.
   *   2. `ticket_type` is set when the caller scopes to one ServiceNow table.
   */
  private buildTicketQuery(opts?: FetchTicketsOpts): FetchTicketRequest {
    const body: FetchTicketRequest = { ...environment.ticketQuery };
    const user = this.auth.user;
    if (user.role === 'SUPERVISOR') {
      const assignees = (opts?.assignees ?? []).filter(Boolean);
      const value = assignees.length ? 'IN' + assignees.join(',') : user.email;
      for (const key of environment.userIdentityFields) {
        (body as Record<string, unknown>)[key] = value;
      }
      // page/page_size are set per-page by fetchPage(); the supervisor's
      // (larger) team queue is covered by walking all pages, same as everyone.
    } else if (user.authenticated && user.email) {
      for (const key of environment.userIdentityFields) {
        (body as Record<string, unknown>)[key] = user.email;
      }
    }
    if (opts?.ticketType) {
      const table = SN_TABLE_BY_TYPE[opts.ticketType];
      if (table) body.ticket_type = table;
    }
    return body;
  }
}
