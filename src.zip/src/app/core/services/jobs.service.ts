import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import {
  ApproveJobRequest,
  ApproveJobResponse,
  JobListResponse,
  JobLookupResponse,
  PlannedStepGroup,
  PlannedSubstep,
  ResolveClassificationOutput,
  ResolveJobRequest,
  ResolveJobResponse,
  ResolveJobUserContext,
  ResumeJobRequest,
  ResumeJobResponse,
  ResumeJobUserContext,
  ResumeOutputSummary,
  ViewJobResponse,
  ViewJobStep,
} from '@core/models/api.model';
import { AuthService } from '@core/services/auth.service';
import { environment } from '@env/environment';

/** UI status for a single sub-step inside a group. */
export type SubstepStatus = 'done' | 'pending' | 'failed' | 'current' | 'bypassed';

/** UI status for a whole group (one row in the workflow rail). */
export type GroupStatus = 'done' | 'current' | 'awaiting_hitl' | 'pending' | 'failed';

export interface WorkflowSubstepUi {
  capability: string;
  /** Humanized display label (Title Case of capability). */
  name: string;
  description: string;
  status: SubstepStatus;
  inputSummary?: string;
  outputSummary?: string;
}

export interface WorkflowGroupUi {
  /** Group name from the planned_steps key (e.g. "Classification"). */
  name: string;
  /** Position in planned_steps (0-based). */
  index: number;
  status: GroupStatus;
  substeps: WorkflowSubstepUi[];
  /** True when this group has a substep awaiting HITL approval. */
  awaitingHitl: boolean;
  /** Routing tag from the top-level resume outcome (STP / HITL). */
  routing?: string;
  /** Free-form notes from the resume outcome — drives the right-pane summary. */
  notes?: string;
  confidence?: number;
}

export type JobPhase = 'idle' | 'pending' | 'awaiting_hitl' | 'resolved' | 'rejected' | 'error';

export interface JobState {
  ticketNumber: string;
  jobId: string;
  phase: JobPhase;
  /** Mirrors backend `status` (accepted / AWAITING_HITL / RESOLVED / REJECTED). */
  status?: string;
  groups: WorkflowGroupUi[];
  /** 0-based index of the group that's currently active (awaiting HITL / running). */
  currentGroupIdx: number;
  errorMessage?: string;
  /** Local-only: captured when the user clicks Reject + submits a reason. */
  rejectComment?: string;
  /** Classification output the Resolve API auto-ran before returning — drives
   *  the Plan Approval page's category / use-case banner. */
  classification?: ResolveClassificationOutput;
  /** Human-readable summary of what classification did (action_taken). */
  actionTaken?: string;
}

@Injectable({ providedIn: 'root' })
export class JobsService {
  /** ticketNumber → BehaviorSubject<JobState | null>. */
  private readonly subjects = new Map<string, BehaviorSubject<JobState | null>>();

  constructor(
    private http: HttpClient,
    private auth: AuthService
  ) {}

  /** Observable of the latest job state for a given ticket number. */
  getJobForTicket(ticketNumber: string): Observable<JobState | null> {
    return this.subject(ticketNumber).asObservable();
  }

  /**
   * Click "Resolve" on a ticket: POST {jobsResolveUrl}. Response gives us
   * the job_id + planned_steps blueprint. The backend has already auto-run
   * Classification by the time we see the response, so we mark its group
   * 'done' and flag the next group as awaiting_hitl so the UI surfaces
   * Approve/Reject buttons immediately without an extra round-trip.
   */
  resolveTicket(ticketNumber: string): void {
    if (!ticketNumber) return;
    const subj = this.subject(ticketNumber);

    subj.next({
      ticketNumber,
      jobId: '',
      phase: 'pending',
      groups: [],
      currentGroupIdx: 0,
    });

    const body: ResolveJobRequest = {
      ticket_id: ticketNumber,
      source: 'serviceNow',
      trigger: 'manual',
      user_context: this.buildResolveUserContext(),
    };

    this.http.post<ResolveJobResponse>(environment.jobsResolveUrl, body).subscribe({
      next: (res) => {
        const groups = this.buildGroupsFromPlannedSteps(res.planned_steps || []);
        const currentGroupIdx = this.firstNonDoneIdx(groups);
        const classStep = res.executed_steps?.find((s) => s.classification)?.classification;
        subj.next({
          ticketNumber,
          jobId: res.job_id,
          phase: 'awaiting_hitl',
          status: res.status || 'accepted',
          groups,
          currentGroupIdx,
          classification: classStep?.output,
          actionTaken: classStep?.action_taken,
        });
      },
      error: (err: unknown) => {
        subj.next({
          ticketNumber,
          jobId: '',
          phase: 'error',
          groups: [],
          currentGroupIdx: 0,
          errorMessage: this.formatError(err, 'resolve'),
        });
      },
    });
  }

  /** Synchronous accessor for the cached job_id of a ticket (set by resolve).
   *  Empty string when this ticket hasn't been resolved in this session. */
  jobIdFor(ticketNumber: string): string {
    return this.subject(ticketNumber).value?.jobId || '';
  }

  /** The planned-step blueprint captured at resolve time (the same groups the
   *  Plan Approval page rendered). Used by the workflow page as a stable rail
   *  skeleton so its steps match the approved plan exactly. */
  plannedGroups(ticketNumber: string): WorkflowGroupUi[] {
    return this.subject(ticketNumber).value?.groups || [];
  }

  /**
   * Click "Approve Plan & Continue" on the Plan Approval page:
   * POST {jobsOrchStepsBase}/{job_id}/approve. The backend starts execution
   * in the background and returns status: "executing". The workflow page then
   * polls getJobStatus() until job_status is terminal. Returns the HTTP
   * observable so the caller can navigate on success / show an error.
   */
  approvePlan(ticketNumber: string): Observable<ApproveJobResponse> {
    const subj = this.subject(ticketNumber);
    const jobId = subj.value?.jobId || '';
    if (!jobId) {
      return throwError(() => new Error('No job to approve — resolve the ticket first.'));
    }
    return this.approveJob(jobId).pipe(
      tap((res) => {
        const cur = subj.value;
        if (cur) subj.next({ ...cur, phase: 'pending', status: res.status || 'executing' });
      })
    );
  }

  /**
   * Approve a job by id: POST {jobsApproveBase}/{job_id}/approve. Used both for
   * the initial "Approve Plan & Continue" and to advance past a mid-flow HITL
   * gate (same endpoint resumes the job).
   */
  approveJob(jobId: string): Observable<ApproveJobResponse> {
    const url = `${environment.jobsApproveBase}/${encodeURIComponent(jobId)}/approve`;
    const body: ApproveJobRequest = { user_context: this.buildResumeUserContext() };
    return this.http.post<ApproveJobResponse>(url, body);
  }

  /**
   * Poll the job status endpoint once:
   * GET /api/jobs/{job_id}?include_steps=true&page=1&limit=10  (wss-service).
   * The workflow page calls this on a 20s timer until job_status is terminal.
   */
  getJobStatus(jobId: string): Observable<ViewJobResponse> {
    const url = `${environment.jobsOrchStepsBase}/${encodeURIComponent(jobId)}?include_steps=true&page=1&limit=10`;
    return this.http.get<ViewJobResponse>(url);
  }

  /**
   * "View Ticket" on a resolved ticket: resolve the ticket's job_id from the
   * lookup endpoint (GET /api/view-jobs?ticket_id=INC...) so the workflow page
   * can then poll GET /api/jobs/{job_id}?include_steps=true to show history.
   * Emits '' when no job exists for the ticket.
   */
  lookupJobId(ticketNumber: string): Observable<string> {
    const url = `${environment.jobsLookupUrl}?ticket_id=${encodeURIComponent(ticketNumber)}`;
    return this.http.get<JobLookupResponse>(url).pipe(map((res) => this.extractJobId(res) || ''));
  }

  /**
   * Click "View Ticket" on a resolved/closed ticket: load the historical
   * job state. Three paths:
   *   1. If we already have a job_id cached in BehaviorSubject state for
   *      this ticket (resolved earlier in this session) → skip lookup and
   *      go straight to the view endpoint.
   *   2. Otherwise → GET {lookupUrl}?ticket_id={ticketNumber} to find the
   *      job_id, then GET {viewBase}/{job_id}?include_steps=true.
   *   3. If lookup yields no job_id → emit phase='error' with a clear
   *      message; the UI's ticket-detail rail stays in its empty state.
   */
  viewJob(ticketNumber: string): void {
    if (!ticketNumber) return;
    const subj = this.subject(ticketNumber);

    subj.next({
      ticketNumber,
      jobId: subj.value?.jobId || '',
      phase: 'pending',
      groups: [],
      currentGroupIdx: 0,
    });

    const existing = subj.value;
    const cachedJobId = existing?.jobId;
    if (cachedJobId) {
      this.fireView(ticketNumber, cachedJobId);
      return;
    }

    // No cached job_id — lookup first, then view.
    // The session JWT bearer is attached centrally by authInterceptor.
    const url = `${environment.jobsLookupUrl}?ticket_id=${encodeURIComponent(ticketNumber)}`;

    this.http.get<JobLookupResponse>(url).subscribe({
      next: (res) => {
        const jobId = this.extractJobId(res);
        if (!jobId) {
          subj.next({
            ticketNumber,
            jobId: '',
            phase: 'error',
            groups: [],
            currentGroupIdx: 0,
            errorMessage: `No job found for ticket ${ticketNumber}.`,
          });
          return;
        }
        this.fireView(ticketNumber, jobId);
      },
      error: (err: unknown) => {
        subj.next({
          ticketNumber,
          jobId: '',
          phase: 'error',
          groups: [],
          currentGroupIdx: 0,
          errorMessage: this.formatError(err, 'lookup'),
        });
      },
    });
  }

  /**
   * Dashboard's "AI Agent Activity" table: paginated list of jobs scoped to
   * the logged-in engineer with their executed steps. Returns an Observable
   * so the component can render loading / error states from the same stream.
   *
   * GET {jobsViewUrlBase}?assigned_to={email}&include_steps=true&page={page}&limit={limit}
   *
   * `assigned_to` defaults to the authenticated user's email (from AuthService)
   * and falls back to environment.jobsUserContext.engineer_id when anonymous —
   * same overlay pattern as Resolve / Resume so audit attribution is consistent.
   * Omitted entirely when neither value is available (lets the backend decide).
   */
  listJobs(page = 1, limit = 10): Observable<JobListResponse> {
    const params: string[] = [];
    const assignedTo = this.resolveAssignedTo();
    if (assignedTo) {
      params.push(`assigned_to=${encodeURIComponent(assignedTo)}`);
    }
    params.push('include_steps=true', `page=${page}`, `limit=${limit}`);
    const url = `${environment.jobsViewUrlBase}?${params.join('&')}`;
    return this.http.get<JobListResponse>(url);
  }

  /** Email to scope the jobs list to — authenticated user wins, env default
   *  is the fallback. Empty string when neither is set (caller omits the param). */
  private resolveAssignedTo(): string {
    const user = this.auth.user;
    if (user.authenticated && user.email) return user.email;
    return environment.jobsUserContext.engineer_id || '';
  }

  /** Click "Approve" at a HITL gate: POST /v1/jobs/{id}/resume. */
  approve(ticketNumber: string): void {
    const state = this.subject(ticketNumber).value;
    if (!state || !state.jobId) return;
    this.fireResume(ticketNumber, state.jobId);
  }

  /**
   * Click "Reject" at a HITL gate. Local-only for now: halt the workflow
   * and store the rejection reason. The component appends it to the ticket
   * comment thread.
   */
  reject(ticketNumber: string, comment: string): void {
    const subj = this.subject(ticketNumber);
    const state = subj.value;
    if (!state) return;
    subj.next({
      ...state,
      phase: 'rejected',
      status: 'REJECTED',
      rejectComment: comment,
    });
  }

  /* ─────────────────────── internals ─────────────────────── */

  private subject(ticketNumber: string): BehaviorSubject<JobState | null> {
    let s = this.subjects.get(ticketNumber);
    if (!s) {
      s = new BehaviorSubject<JobState | null>(null);
      this.subjects.set(ticketNumber, s);
    }
    return s;
  }

  /** GET {viewBase}/{job_id}?include_steps=true — pulls the full historical
   *  job + executed steps. Builds groups from parent_step_id relationships
   *  rather than planned_steps because the View payload doesn't carry the
   *  planned blueprint (it shows what actually happened). */
  private fireView(ticketNumber: string, jobId: string): void {
    const subj = this.subject(ticketNumber);
    const url = `${environment.jobsViewUrlBase}/${jobId}?include_steps=true`;

    this.http.get<ViewJobResponse>(url).subscribe({
      next: (res) => {
        const groups = this.buildGroupsFromViewSteps(res.steps || []);
        // The View payload always represents a finished job — phase=resolved.
        // If the backend ever returns AWAITING_HITL for view, fall back to
        // awaiting_hitl so the rail still surfaces the right state.
        const phase: JobPhase = res.job_status === 'AWAITING_HITL' ? 'awaiting_hitl' : 'resolved';
        subj.next({
          ticketNumber,
          jobId: res.job_id || jobId,
          phase,
          status: res.job_status,
          groups,
          currentGroupIdx: this.firstNonDoneIdx(groups),
        });
      },
      error: (err: unknown) => {
        subj.next({
          ticketNumber,
          jobId,
          phase: 'error',
          groups: [],
          currentGroupIdx: 0,
          errorMessage: this.formatError(err, 'view'),
        });
      },
    });
  }

  /** Build WorkflowGroupUi[] from a flat list of executed steps. Top-level
   *  steps (parent_step_id === null) become groups; everything else is a
   *  substep nested under its parent group by parent_step_id. */
  private buildGroupsFromViewSteps(steps: ViewJobStep[]): WorkflowGroupUi[] {
    const tops = steps.filter((s) => !s.parent_step_id);
    const byParent = new Map<string, ViewJobStep[]>();
    for (const s of steps) {
      if (!s.parent_step_id) continue;
      const list = byParent.get(s.parent_step_id) || [];
      list.push(s);
      byParent.set(s.parent_step_id, list);
    }

    return tops.map((top, idx) => {
      const children = byParent.get(top.step_id) || [];
      const substeps: WorkflowSubstepUi[] = children.map((c) => ({
        capability: c.capability,
        name: this.humanize(c.capability),
        description: '',
        status: this.mapViewSubstepStatus(c.status),
        inputSummary: this.toText(c.outcome?.input_summary),
        outputSummary: this.toText(c.outcome?.output_summary),
      }));
      return {
        name: this.humanize(top.capability),
        index: idx,
        status: this.mapViewGroupStatus(top.status, substeps),
        substeps,
        awaitingHitl: false,
      };
    });
  }

  private mapViewSubstepStatus(raw: string | undefined): SubstepStatus {
    const v = (raw || '').toUpperCase();
    if (v === 'SUCCEEDED') return 'done';
    if (v === 'BYPASSED') return 'bypassed';
    if (v === 'FAILED' || v === 'ERROR') return 'failed';
    if (v === 'PENDING') return 'pending';
    return 'pending';
  }

  /** Top-level group status combines its own status with its substeps so a
   *  half-failed group is visible even when the top row says SUCCEEDED. */
  private mapViewGroupStatus(raw: string | undefined, substeps: WorkflowSubstepUi[]): GroupStatus {
    const v = (raw || '').toUpperCase();
    if (substeps.some((s) => s.status === 'failed')) return 'failed';
    if (substeps.length && substeps.every((s) => s.status === 'done' || s.status === 'bypassed')) {
      return 'done';
    }
    if (v === 'SUCCEEDED') return 'done';
    if (v === 'FAILED' || v === 'ERROR') return 'failed';
    if (v === 'PENDING') return 'pending';
    return 'pending';
  }

  /** Pull a job_id out of whatever shape the lookup endpoint returned. */
  private extractJobId(res: JobLookupResponse | null | undefined): string | null {
    if (!res) return null;
    if (typeof res.job_id === 'string' && res.job_id) return res.job_id;
    if (Array.isArray(res.jobs) && res.jobs.length) {
      const sorted = [...res.jobs].sort((a, b) =>
        (b.resolved_at || '').localeCompare(a.resolved_at || '')
      );
      const id = sorted[0]?.job_id;
      if (typeof id === 'string' && id) return id;
    }
    // Some backends return a bare array — handle that too.
    if (Array.isArray(res) && (res as Array<{ job_id?: string }>).length) {
      const first = (res as Array<{ job_id?: string }>)[0];
      if (first?.job_id) return first.job_id;
    }
    return null;
  }

  /** POST /v1/jobs/{job_id}/resume — synchronous per call (no polling). */
  private fireResume(ticketNumber: string, jobId: string): void {
    const subj = this.subject(ticketNumber);
    const state = subj.value;
    if (!state) return;

    // Mark pending so the UI can spinner the Approve button.
    subj.next({ ...state, phase: 'pending' });

    const url = `${environment.jobsOrchStepsBase}/${jobId}/resume`;
    const body: ResumeJobRequest = {
      user_context: this.buildResumeUserContext(),
    };

    // The session JWT bearer is attached centrally by authInterceptor.
    this.http.post<ResumeJobResponse>(url, body).subscribe({
      next: (res) => {
        const after = subj.value;
        if (!after) return;
        const mergedGroups = this.mergeResumeIntoGroups(after.groups, res);
        const currentGroupIdx = this.firstNonDoneIdx(mergedGroups);
        const phase: JobPhase = res.status === 'RESOLVED' ? 'resolved' : 'awaiting_hitl';
        subj.next({
          ...after,
          phase,
          status: res.status,
          groups: mergedGroups,
          currentGroupIdx,
        });
      },
      error: (err: unknown) => {
        const after = subj.value;
        if (!after) return;
        subj.next({
          ...after,
          phase: 'error',
          errorMessage: this.formatError(err, 'resume'),
        });
      },
    });
  }

  /**
   * Build the initial WorkflowGroupUi[] from the Resolve API's planned_steps.
   * Convention: the first group (Classification) is treated as auto-done
   * since the backend ran it before returning. Every subsequent group is
   * pending. The first pending group flips to 'awaiting_hitl' so the
   * UI shows Approve/Reject without an extra round-trip.
   */
  private buildGroupsFromPlannedSteps(planned: PlannedStepGroup[]): WorkflowGroupUi[] {
    const groups: WorkflowGroupUi[] = planned.map((entry, idx) => {
      const [groupName, substeps] = Object.entries(entry)[0] ?? ['', []];
      return {
        name: groupName,
        index: idx,
        status: idx === 0 ? 'done' : 'pending',
        substeps: (substeps || []).map((s) => this.makeSubstep(s, idx === 0 ? 'done' : 'pending')),
        awaitingHitl: false,
      };
    });

    const firstPending = groups.find((g) => g.status === 'pending');
    if (firstPending) {
      firstPending.status = 'awaiting_hitl';
      firstPending.awaitingHitl = true;
    }
    return groups;
  }

  private makeSubstep(s: PlannedSubstep, status: SubstepStatus): WorkflowSubstepUi {
    return {
      capability: s.step_name,
      name: s.display_name || this.humanize(s.step_name),
      description: s.description || '',
      status,
    };
  }

  /**
   * Merge the Resume API's flat step list into the existing UI groups.
   * Step IDs encode the group:
   *   "STEP-001"               → top-level row for the second planned group
   *                              (since Classification, idx 0, isn't in the
   *                              Resume payload)
   *   "STEP-001.parse_ticket"  → substep within that group
   * Top-level rows carry the rich output_summary (routing / notes / etc.)
   * — we lift those onto the group itself for the right-pane display.
   */
  private mergeResumeIntoGroups(
    existing: WorkflowGroupUi[],
    res: ResumeJobResponse
  ): WorkflowGroupUi[] {
    const out = existing.map((g) => ({
      ...g,
      substeps: g.substeps.map((s) => ({ ...s })),
    }));

    for (const step of res.steps || []) {
      const { groupIndex, substepCapability } = this.parseStepId(step.step_id);
      const group = out[groupIndex];
      if (!group) continue;

      if (!substepCapability) {
        const rich = this.asOutputSummary(step.outcome?.output_summary);
        if (rich) {
          group.routing = rich.routing;
          group.notes = rich.notes;
          group.confidence = rich.confidence;
        }
        continue;
      }

      const sub = group.substeps.find((s) => s.capability === substepCapability);
      if (!sub) continue;
      sub.status = this.mapSubstepStatus(step.status, step.capability, res.current_step);
      sub.inputSummary = this.toText(step.outcome?.input_summary);
      sub.outputSummary = this.toText(step.outcome?.output_summary);
    }

    for (const g of out) {
      g.awaitingHitl = g.substeps.some((s) => s.status === 'current');
      if (g.substeps.length === 0) {
        // Shouldn't happen — planned_steps always carries substeps — but be defensive.
        g.status = 'pending';
      } else if (g.substeps.every((s) => s.status === 'done' || s.status === 'bypassed')) {
        g.status = 'done';
      } else if (g.awaitingHitl) {
        g.status = 'awaiting_hitl';
      } else if (g.substeps.some((s) => s.status === 'failed')) {
        g.status = 'failed';
      } else if (g.substeps.some((s) => s.status === 'done')) {
        g.status = 'current';
      } else {
        g.status = 'pending';
      }
    }

    return out;
  }

  /** "STEP-001"               → { groupIndex: 1 }
   *  "STEP-001.parse_ticket"  → { groupIndex: 1, substepCapability: "parse_ticket" }
   *  "anything else"          → { groupIndex: -1 } */
  private parseStepId(stepId: string): { groupIndex: number; substepCapability?: string } {
    const m = /^STEP-0*(\d+)(?:\.(.+))?$/.exec(stepId || '');
    if (!m) return { groupIndex: -1 };
    return { groupIndex: parseInt(m[1], 10), substepCapability: m[2] };
  }

  private mapSubstepStatus(
    raw: string | undefined,
    capability: string | undefined,
    currentStep: string | null
  ): SubstepStatus {
    const v = (raw || '').toUpperCase();
    if (v === 'SUCCEEDED') return 'done';
    if (v === 'BYPASSED') return 'bypassed';
    if (v === 'FAILED' || v === 'ERROR') return 'failed';
    // The substep capability matches the API's current_step → this is the HITL gate.
    if (v === 'PENDING' && capability && capability === currentStep) return 'current';
    return 'pending';
  }

  /** First group that isn't done. Defaults to the last group when everything's done. */
  private firstNonDoneIdx(groups: WorkflowGroupUi[]): number {
    const idx = groups.findIndex((g) => g.status !== 'done');
    return idx >= 0 ? idx : Math.max(0, groups.length - 1);
  }

  private toText(v: unknown): string | undefined {
    if (v === null || v === undefined) return undefined;
    if (typeof v === 'string') return v;
    try {
      return JSON.stringify(v);
    } catch {
      return String(v);
    }
  }

  private asOutputSummary(v: unknown): ResumeOutputSummary | null {
    if (v && typeof v === 'object' && !Array.isArray(v)) return v as ResumeOutputSummary;
    return null;
  }

  /**
   * Build the Resolve user_context — overlay the authenticated user onto
   * env defaults so audit logs attribute to whoever clicked Resolve.
   */
  private buildResolveUserContext(): ResolveJobUserContext {
    const base: ResolveJobUserContext = { ...environment.jobsUserContext };
    const user = this.auth.user;
    if (user.authenticated && user.email) {
      base.engineer_id = user.email;
      base.engineer_mail = user.email;
      if (user.name) base.engineer_name = user.name;
      // session_id and role come from the verified session JWT; the orchestrator
      // independently re-derives the user UUID from the bearer token's `sub`.
      if (user.sessionId) base.session_id = user.sessionId;
      if (user.role) base.role = user.role;
    }
    return base;
  }

  /** Resume payload omits ticket_categories / priority_rules. */
  private buildResumeUserContext(): ResumeJobUserContext {
    const ctx = this.buildResolveUserContext();
    return {
      engineer_id: ctx.engineer_id,
      engineer_name: ctx.engineer_name,
      engineer_mail: ctx.engineer_mail,
      role: ctx.role,
      lead_id: ctx.lead_id,
      session_id: ctx.session_id,
    };
  }

  /** snake_case → Title Case for substep labels. */
  private humanize(s: string): string {
    if (!s) return '';
    return s
      .replace(/_/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }

  private formatError(err: unknown, phase: 'resolve' | 'resume' | 'view' | 'lookup'): string {
    const e = err as { status?: number; message?: string };
    const where =
      phase === 'resolve'
        ? 'job resolve'
        : phase === 'resume'
          ? 'job resume'
          : phase === 'view'
            ? 'job view'
            : 'job lookup';
    if (e?.status === 0) return `Cannot reach the ${where} service. Is it running?`;
    return e?.message ? `${where}: ${e.message}` : `${where} failed`;
  }
}
