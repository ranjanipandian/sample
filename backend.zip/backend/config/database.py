"""
Database Configuration and Connection Module
Handles PostgreSQL connections for the Research Intelligence Search Platform
"""

import os
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv
from typing import Optional

# Load environment variables
load_dotenv()

# Database Configuration
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_USER = os.getenv('DB_USER', 'postgres')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME', 'research_kb')


class DatabaseConnection:
    """Database connection manager with context support"""
    
    def __init__(self):
        self.conn = None
        self.cursor = None
    
    def __enter__(self):
        """Context manager entry"""
        self.conn = self.get_connection()
        return self.conn
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        if self.conn:
            self.conn.close()
    
    @staticmethod
    def get_connection():
        """Create and return a database connection"""
        try:
            conn = psycopg2.connect(
                host=DB_HOST,
                port=DB_PORT,
                user=DB_USER,
                password=DB_PASSWORD,
                database=DB_NAME,
                cursor_factory=RealDictCursor
            )
            return conn
        except Exception as e:
            print(f"❌ Database connection error: {e}")
            raise


def get_db_connection():
    """
    Get database connection (legacy function for compatibility)
    Returns a connection with RealDictCursor
    """
    return DatabaseConnection.get_connection()


def test_connection() -> bool:
    """Test database connection"""
    try:
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            cursor.close()
            return result is not None
    except Exception as e:
        print(f"❌ Connection test failed: {e}")
        return False


def get_database_stats() -> dict:
    """Get database statistics"""
    stats = {
        'total_documents': 0,
        'total_visual': 0,
        'by_type': {},
        'database_size': 'Unknown'
    }
    
    try:
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            
            # Count documents
            cursor.execute("""
                SELECT file_type, COUNT(*) as count
                FROM document_embeddings
                GROUP BY file_type
            """)
            doc_counts = cursor.fetchall()
            
            for row in doc_counts:
                file_type = row['file_type']
                count = row['count']
                stats['by_type'][file_type] = count
                stats['total_documents'] += count
            
            # Try to count visual embeddings if table exists
            try:
                cursor.execute("""
                    SELECT file_type, COUNT(*) as count
                    FROM visual_embeddings
                    GROUP BY file_type
                """)
                visual_counts = cursor.fetchall()
                
                for row in visual_counts:
                    file_type = row['file_type']
                    count = row['count']
                    if file_type in stats['by_type']:
                        stats['by_type'][file_type] += count
                    else:
                        stats['by_type'][file_type] = count
                    stats['total_visual'] += count
            except:
                pass  # Table might not exist
            
            # Get database size
            cursor.execute("""
                SELECT pg_size_pretty(pg_database_size(%s)) as size
            """, (DB_NAME,))
            size_result = cursor.fetchone()
            if size_result:
                stats['database_size'] = size_result['size']
            
            cursor.close()
            
    except Exception as e:
        print(f"❌ Error getting database stats: {e}")
    
    return stats


if __name__ == "__main__":
    print("=" * 70)
    print("🔧 Database Configuration Test")
    print("=" * 70)
    print(f"\nConfiguration:")
    print(f"  Host: {DB_HOST}")
    print(f"  Port: {DB_PORT}")
    print(f"  Database: {DB_NAME}")
    print(f"  User: {DB_USER}")
    print(f"  Password: {'*' * len(DB_PASSWORD) if DB_PASSWORD else 'Not set'}")
    
    print("\n🔍 Testing connection...")
    if test_connection():
        print("✅ Connection successful!")
        
        print("\n📊 Database Statistics:")
        stats = get_database_stats()
        print(f"  Total Documents: {stats['total_documents']}")
        print(f"  Total Visual: {stats['total_visual']}")
        print(f"  Database Size: {stats['database_size']}")
        print(f"\n  By Type:")
        for file_type, count in stats['by_type'].items():
            print(f"    {file_type}: {count}")
    else:
        print("❌ Connection failed!")
