"""
Q&A Service for Research Intelligence Search Platform
Uses GPT-4o to answer questions based on document database
"""

import os
import sys
from typing import Dict, List, Any
from openai import AzureOpenAI

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.database import get_db_connection

# Azure OpenAI Configuration
AZURE_OPENAI_KEY = os.getenv('AZURE_OPENAI_KEY')
AZURE_OPENAI_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT')
AZURE_OPENAI_DEPLOYMENT = os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4o')
AZURE_OPENAI_API_VERSION = os.getenv('AZURE_OPENAI_API_VERSION', '2024-12-01-preview')

# Initialize Azure OpenAI client
try:
    client = AzureOpenAI(
        api_key=AZURE_OPENAI_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
        azure_endpoint=AZURE_OPENAI_ENDPOINT
    )
    print("✅ Azure OpenAI client initialized successfully")
except Exception as e:
    print(f"⚠️ Warning: Could not initialize Azure OpenAI client: {e}")
    client = None


def get_relevant_context(query: str, max_docs: int = 5) -> str:
    """
    Retrieve relevant document content from database to provide context for GPT-4o
    Uses semantic search for better relevance
    """
    context_docs = []
    
    try:
        # Import semantic_search from query_service
        from .query_service import semantic_search
        
        # Use semantic search to find relevant documents
        results = semantic_search(query, top_k=max_docs, min_score=0.5)
        
        for result in results:
            if result['content_preview']:
                context_docs.append(
                    f"Document: {result['file_name']} ({result['file_type']}) [Relevance: {result['relevance_score']:.2f}]\n"
                    f"Content: {result['content_preview'][:1500]}\n"
                )
        
    except Exception as e:
        print(f"❌ Error retrieving context: {e}")
        import traceback
        traceback.print_exc()
    
    return "\n---\n".join(context_docs) if context_docs else "No relevant documents found in database."


def extract_insights(answer: str) -> List[str]:
    """
    Extract key insights from the GPT-4o answer
    """
    if not client:
        return []
    
    try:
        insight_prompt = f"""Analyze the following answer and extract 3-5 key insights or important points as bullet points.
Be concise and focus on the most important information.

Answer:
{answer}

Provide only the bullet points, one per line, starting with a dash (-)."""
        
        response = client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=[
                {"role": "user", "content": insight_prompt}
            ],
            temperature=0.3,
            max_tokens=300
        )
        
        insights_text = response.choices[0].message.content
        # Parse bullet points
        insights = [
            line.strip().lstrip('-').strip() 
            for line in insights_text.split('\n') 
            if line.strip().startswith('-')
        ]
        return insights
        
    except Exception as e:
        print(f"❌ Error extracting insights: {e}")
        return []


def answer_question(question: str) -> Dict[str, Any]:
    """
    Use GPT-4o to answer questions based on document database
    Returns a dictionary with answer and insights
    """
    if not client:
        return {
            'answer': "❌ Error: Azure OpenAI client not initialized. Please check your credentials in .env file.",
            'insights': [],
            'error': True
        }
    
    try:
        # Get relevant context from database
        context = get_relevant_context(question, max_docs=5)
        
        # Create system prompt
        system_prompt = """You are a helpful research assistant with access to a document database. 
Your task is to answer questions directly and concisely based on the provided document context.
- Provide direct, factual answers without meta-commentary about what the documents contain or don't contain
- If the documents have relevant information, use it to answer the question directly
- Cite document names when referencing specific information
- If documents lack information, supplement with your general knowledge while noting what came from documents vs. general knowledge
- Be concise and informative"""
        
        # Create user prompt with context
        user_prompt = f"""Question: {question}

Relevant Documents from Database:
{context}

Please answer the question based on the above documents. If the documents don't contain relevant information, please state that clearly."""
        
        # Call GPT-4o
        response = client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.7,
            max_tokens=1000
        )
        
        answer = response.choices[0].message.content
        
        # Extract insights from the answer
        insights = extract_insights(answer)
        
        return {
            'answer': answer,
            'insights': insights,
            'error': False
        }
        
    except Exception as e:
        print(f"❌ Error in Q&A service: {e}")
        import traceback
        traceback.print_exc()
        return {
            'answer': f"❌ Error generating answer: {str(e)}",
            'insights': [],
            'error': True
        }


if __name__ == "__main__":
    print("=" * 70)
    print("💬 Q&A Service Test (GPT-4o)")
    print("=" * 70)
    
    # Test database connection
    try:
        conn = get_db_connection()
        if conn:
            print("✅ Database connection successful")
            conn.close()
        else:
            print("❌ Database connection failed")
            exit(1)
    except Exception as e:
        print(f"❌ Database connection error: {e}")
        exit(1)
    
    # Test Azure OpenAI
    if not client:
        print("❌ Azure OpenAI client not initialized")
        exit(1)
    
    print("✅ Azure OpenAI client ready")
    print("\n" + "=" * 70)
    
    # Interactive Q&A loop
    while True:
        question = input("\nAsk a question (or 'exit' to quit): ").strip()
        if question.lower() == 'exit':
            break
        
        print("\n💭 Thinking...")
        result = answer_question(question)
        
        print("\n📝 Answer:")
        print(result['answer'])
        
        if result['insights']:
            print("\n💡 Key Insights:")
            for i, insight in enumerate(result['insights'], 1):
                print(f"{i}. {insight}")
        
        print("\n" + "=" * 70)
