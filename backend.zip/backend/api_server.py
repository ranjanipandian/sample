"""
FastAPI Server for Research Intelligence Search Platform
Provides REST API endpoints for the Next.js frontend
"""

import os
import sys
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import uvicorn

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.query_service import keyword_search, semantic_search, hybrid_search
from services.qa_service import answer_question
from config.database import test_connection, get_database_stats

# Initialize FastAPI app
app = FastAPI(
    title="Research Intelligence Search API",
    description="Backend API for multi-modal research document search",
    version="1.0.0"
)

# Configure CORS for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request/Response Models
class SearchRequest(BaseModel):
    query: str
    top_k: Optional[int] = 10
    min_score: Optional[float] = 0.5


class SearchResponse(BaseModel):
    results: List[Dict[str, Any]]
    total: int
    query: str
    search_type: str


class QARequest(BaseModel):
    question: str


class QAResponse(BaseModel):
    answer: str
    insights: List[str]
    error: bool = False


class HealthResponse(BaseModel):
    status: str
    database: str
    message: str


class StatsResponse(BaseModel):
    total_documents: int
    total_visual: int
    by_type: Dict[str, int]
    database_size: str


# API Endpoints

@app.get("/", response_model=Dict[str, str])
async def root():
    """Root endpoint"""
    return {
        "message": "Research Intelligence Search API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/api/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    db_status = "connected" if test_connection() else "disconnected"
    
    return HealthResponse(
        status="healthy" if db_status == "connected" else "unhealthy",
        database=db_status,
        message="API is running" if db_status == "connected" else "Database connection failed"
    )


@app.get("/api/stats", response_model=StatsResponse)
async def get_stats():
    """Get database statistics"""
    try:
        stats = get_database_stats()
        return StatsResponse(**stats)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting stats: {str(e)}")


@app.post("/api/search/keyword", response_model=SearchResponse)
async def search_keyword(request: SearchRequest):
    """Keyword search endpoint"""
    try:
        results = keyword_search(
            query=request.query,
            top_k=request.top_k,
            min_score=0.0  # Keyword search doesn't use min_score
        )
        
        return SearchResponse(
            results=results,
            total=len(results),
            query=request.query,
            search_type="keyword"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Keyword search error: {str(e)}")


@app.post("/api/search/semantic", response_model=SearchResponse)
async def search_semantic(request: SearchRequest):
    """Semantic search endpoint (uses GPT-4o)"""
    try:
        results = semantic_search(
            query=request.query,
            top_k=request.top_k,
            min_score=request.min_score
        )
        
        return SearchResponse(
            results=results,
            total=len(results),
            query=request.query,
            search_type="semantic"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Semantic search error: {str(e)}")


@app.post("/api/search/hybrid", response_model=SearchResponse)
async def search_hybrid(request: SearchRequest):
    """Hybrid search endpoint (combines keyword and semantic)"""
    try:
        results = hybrid_search(
            query=request.query,
            top_k=request.top_k,
            min_score=request.min_score
        )
        
        return SearchResponse(
            results=results,
            total=len(results),
            query=request.query,
            search_type="hybrid"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Hybrid search error: {str(e)}")


@app.post("/api/qa", response_model=QAResponse)
async def qa_endpoint(request: QARequest):
    """Q&A endpoint (uses GPT-4o)"""
    try:
        result = answer_question(request.question)
        
        return QAResponse(
            answer=result['answer'],
            insights=result['insights'],
            error=result.get('error', False)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Q&A error: {str(e)}")


@app.get("/api/search")
async def search_unified(
    query: str = Query(..., description="Search query"),
    type: str = Query("semantic", description="Search type: keyword, semantic, or hybrid"),
    top_k: int = Query(10, description="Number of results to return"),
    min_score: float = Query(0.5, description="Minimum relevance score")
):
    """Unified search endpoint (GET method for easy testing)"""
    try:
        if type == "keyword":
            results = keyword_search(query=query, top_k=top_k, min_score=0.0)
        elif type == "semantic":
            results = semantic_search(query=query, top_k=top_k, min_score=min_score)
        elif type == "hybrid":
            results = hybrid_search(query=query, top_k=top_k, min_score=min_score)
        else:
            raise HTTPException(status_code=400, detail="Invalid search type. Use: keyword, semantic, or hybrid")
        
        return {
            "results": results,
            "total": len(results),
            "query": query,
            "search_type": type
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search error: {str(e)}")


# Run server
if __name__ == "__main__":
    print("=" * 70)
    print("🚀 Starting Research Intelligence Search API Server")
    print("=" * 70)
    print("\n📋 Configuration:")
    print(f"   Host: 0.0.0.0")
    print(f"   Port: 8000")
    print(f"   Reload: True (development mode)")
    print("\n🔗 API Endpoints:")
    print(f"   Health Check: http://localhost:8000/api/health")
    print(f"   Statistics: http://localhost:8000/api/stats")
    print(f"   Keyword Search: POST http://localhost:8000/api/search/keyword")
    print(f"   Semantic Search: POST http://localhost:8000/api/search/semantic")
    print(f"   Hybrid Search: POST http://localhost:8000/api/search/hybrid")
    print(f"   Q&A: POST http://localhost:8000/api/qa")
    print(f"   Unified Search: GET http://localhost:8000/api/search?query=<query>&type=<type>")
    print(f"\n📚 API Documentation:")
    print(f"   Swagger UI: http://localhost:8000/docs")
    print(f"   ReDoc: http://localhost:8000/redoc")
    print("\n" + "=" * 70)
    
    uvicorn.run(
        "api_server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
